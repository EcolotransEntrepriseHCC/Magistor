
package atelier_facturation.ecolotrans_salesforce_service_detail_import_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT implements TalendJob {
	static {System.setProperty("TalendJob.log", "ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(ODS_Database != null){
				
					this.setProperty("ODS_Database", ODS_Database.toString());
				
			}
			
			if(PBI_Database != null){
				
					this.setProperty("PBI_Database", PBI_Database.toString());
				
			}
			
			if(PBI_PC_Database != null){
				
					this.setProperty("PBI_PC_Database", PBI_PC_Database.toString());
				
			}
			
			if(PBI_RT_Database != null){
				
					this.setProperty("PBI_RT_Database", PBI_RT_Database.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(Salesforce_Name != null){
				
					this.setProperty("Salesforce_Name", Salesforce_Name.toString());
				
			}
			
			if(Salesforce_Password != null){
				
					this.setProperty("Salesforce_Password", Salesforce_Password.toString());
				
			}
			
			if(Salesforce_Security_Token != null){
				
					this.setProperty("Salesforce_Security_Token", Salesforce_Security_Token.toString());
				
			}
			
			if(Salesforce_User_ID != null){
				
					this.setProperty("Salesforce_User_ID", Salesforce_User_ID.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String ODS_Database;
public String getODS_Database(){
	return this.ODS_Database;
}
public String PBI_Database;
public String getPBI_Database(){
	return this.PBI_Database;
}
public String PBI_PC_Database;
public String getPBI_PC_Database(){
	return this.PBI_PC_Database;
}
public String PBI_RT_Database;
public String getPBI_RT_Database(){
	return this.PBI_RT_Database;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String Salesforce_Name;
public String getSalesforce_Name(){
	return this.Salesforce_Name;
}
public java.lang.String Salesforce_Password;
public java.lang.String getSalesforce_Password(){
	return this.Salesforce_Password;
}
public java.lang.String Salesforce_Security_Token;
public java.lang.String getSalesforce_Security_Token(){
	return this.Salesforce_Security_Token;
}
public String Salesforce_User_ID;
public String getSalesforce_User_ID(){
	return this.Salesforce_User_ID;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT";
	private final String projectName = "ATELIER_FACTURATION";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_omMvcNboEe6yzsZuOmbiYw", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "f0f24d_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tWarn_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "8fS5CN_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tSalesforceConnection_1Process(globalMap);



/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void tSalesforceConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceConnection_1");
		org.slf4j.MDC.put("_subJobPid", "JK03bS_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSalesforceConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceConnection_1", false);
		start_Hash.put("tSalesforceConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
		int tos_count_tSalesforceConnection_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceConnection_1", "Salesforce_connexion", "tSalesforceConnection");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceConnection_1 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceConnection_1 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceConnection_1 = (String)(restRequest_tSalesforceConnection_1 != null ? restRequest_tSalesforceConnection_1.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceConnection_1 =
        new org.talend.components.salesforce.tsalesforceconnection.TSalesforceConnectionDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceConnection_1 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceConnection_1 = null;


org.talend.components.salesforce.SalesforceConnectionProperties props_tSalesforceConnection_1 =
        (org.talend.components.salesforce.SalesforceConnectionProperties) def_tSalesforceConnection_1.createRuntimeProperties();
 		                    props_tSalesforceConnection_1.setValue("endpoint",
 		                    "https://login.salesforce.com/services/Soap/u/45.0");
 		                    
 		                    props_tSalesforceConnection_1.setValue("loginType",
 		                        org.talend.components.salesforce.SalesforceConnectionProperties.LoginType.Basic);
 		                    
 		                    props_tSalesforceConnection_1.setValue("bulkConnection",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("reuseSession",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("needCompression",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("timeout",
 		                    60000);
 		                    
 		                    props_tSalesforceConnection_1.setValue("httpChunked",
 		                    true);
 		                    
 		                    props_tSalesforceConnection_1.setValue("clientId",
 		                    "");
 		                    
 		                        props_tSalesforceConnection_1.userPassword.setValue("securityKey",
 		                        routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:KnrnmdGfhbXHucNbVGc4ayLxuDl3e1d98VlLIPPrFBR9psxz8pvHJ5DwAsNcTSyaLXMN8aA="));
 		                        
 		                    props_tSalesforceConnection_1.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.userPassword.setValue("userId",
 		                    "admin_sf@ecolotrans.com");
 		                    
 		                        props_tSalesforceConnection_1.userPassword.setValue("password",
 		                        routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:5ABtVgzFHvvUutExf+4Icp3TJYGwz4m5OL7NYdZgOOi4fYI6fcOVXrkxXA=="));
 		                        
 		                    props_tSalesforceConnection_1.sslProperties.setValue("mutualAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.proxy.setValue("useProxy",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceConnection_1.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceConnection_1 = props_tSalesforceConnection_1.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceConnection_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceConnection_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceConnection_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceConnection_1.referencedComponent.setReference(referencedComponentProperties_tSalesforceConnection_1);
        }
    }
globalMap.put("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceConnection_1);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceConnection_1= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceConnection_1_MAPPINGS_URL", mappings_url_tSalesforceConnection_1);

org.talend.components.api.container.RuntimeContainer container_tSalesforceConnection_1 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceConnection_1";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceConnection_1 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceConnection_1 = null;
topology_tSalesforceConnection_1 = org.talend.components.api.component.ConnectorTopology.NONE;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceConnection_1 = def_tSalesforceConnection_1.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceConnection_1, topology_tSalesforceConnection_1);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceConnection_1 = def_tSalesforceConnection_1.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceConnection_1.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceConnection_1 = componentRuntime_tSalesforceConnection_1.initialize(container_tSalesforceConnection_1, props_tSalesforceConnection_1);

if (initVr_tSalesforceConnection_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceConnection_1.getMessage());
}

if(componentRuntime_tSalesforceConnection_1 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceConnection_1;
	compDriverInitialization_tSalesforceConnection_1.runAtDriver(container_tSalesforceConnection_1);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceConnection_1 = null;
if(componentRuntime_tSalesforceConnection_1 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceConnection_1;
	if (doesNodeBelongToRequest_tSalesforceConnection_1) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceConnection_1 = sourceOrSink_tSalesforceConnection_1.validate(container_tSalesforceConnection_1);
        if (vr_tSalesforceConnection_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceConnection_1.getMessage());
        }
	}
}

 



/**
 * [tSalesforceConnection_1 begin ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 main ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 


	tos_count_tSalesforceConnection_1++;

/**
 * [tSalesforceConnection_1 main ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 



/**
 * [tSalesforceConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 



/**
 * [tSalesforceConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 end ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
// end of generic

 

ok_Hash.put("tSalesforceConnection_1", true);
end_Hash.put("tSalesforceConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tSalesforceConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSalesforceConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
// finally of generic

 



/**
 * [tSalesforceConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "f8re4A_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tSalesforceInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class service_detailStruct implements routines.system.IPersistableRow<service_detailStruct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public int id_client;

				public int getId_client () {
					return this.id_client;
				}

				public Boolean id_clientIsNullable(){
				    return false;
				}
				public Boolean id_clientIsKey(){
				    return false;
				}
				public Integer id_clientLength(){
				    return 10;
				}
				public Integer id_clientPrecision(){
				    return 0;
				}
				public String id_clientDefault(){
				
					return null;
				
				}
				public String id_clientComment(){
				
				    return "";
				
				}
				public String id_clientPattern(){
				
					return "";
				
				}
				public String id_clientOriginalDbColumnName(){
				
					return "id_client";
				
				}

				
			    public String service;

				public String getService () {
					return this.service;
				}

				public Boolean serviceIsNullable(){
				    return true;
				}
				public Boolean serviceIsKey(){
				    return false;
				}
				public Integer serviceLength(){
				    return 100;
				}
				public Integer servicePrecision(){
				    return 0;
				}
				public String serviceDefault(){
				
					return null;
				
				}
				public String serviceComment(){
				
				    return "";
				
				}
				public String servicePattern(){
				
					return "";
				
				}
				public String serviceOriginalDbColumnName(){
				
					return "service";
				
				}

				
			    public String category;

				public String getCategory () {
					return this.category;
				}

				public Boolean categoryIsNullable(){
				    return false;
				}
				public Boolean categoryIsKey(){
				    return false;
				}
				public Integer categoryLength(){
				    return 100;
				}
				public Integer categoryPrecision(){
				    return 0;
				}
				public String categoryDefault(){
				
					return null;
				
				}
				public String categoryComment(){
				
				    return "";
				
				}
				public String categoryPattern(){
				
					return "";
				
				}
				public String categoryOriginalDbColumnName(){
				
					return "category";
				
				}

				
			    public String sub_category;

				public String getSub_category () {
					return this.sub_category;
				}

				public Boolean sub_categoryIsNullable(){
				    return true;
				}
				public Boolean sub_categoryIsKey(){
				    return false;
				}
				public Integer sub_categoryLength(){
				    return 200;
				}
				public Integer sub_categoryPrecision(){
				    return 0;
				}
				public String sub_categoryDefault(){
				
					return null;
				
				}
				public String sub_categoryComment(){
				
				    return "";
				
				}
				public String sub_categoryPattern(){
				
					return "";
				
				}
				public String sub_categoryOriginalDbColumnName(){
				
					return "sub_category";
				
				}

				
			    public String unit;

				public String getUnit () {
					return this.unit;
				}

				public Boolean unitIsNullable(){
				    return true;
				}
				public Boolean unitIsKey(){
				    return false;
				}
				public Integer unitLength(){
				    return 100;
				}
				public Integer unitPrecision(){
				    return 0;
				}
				public String unitDefault(){
				
					return null;
				
				}
				public String unitComment(){
				
				    return "";
				
				}
				public String unitPattern(){
				
					return "";
				
				}
				public String unitOriginalDbColumnName(){
				
					return "unit";
				
				}

				
			    public String billing_type;

				public String getBilling_type () {
					return this.billing_type;
				}

				public Boolean billing_typeIsNullable(){
				    return false;
				}
				public Boolean billing_typeIsKey(){
				    return false;
				}
				public Integer billing_typeLength(){
				    return 100;
				}
				public Integer billing_typePrecision(){
				    return 0;
				}
				public String billing_typeDefault(){
				
					return null;
				
				}
				public String billing_typeComment(){
				
				    return "";
				
				}
				public String billing_typePattern(){
				
					return "";
				
				}
				public String billing_typeOriginalDbColumnName(){
				
					return "billing_type";
				
				}

				
			    public java.util.Date created_at;

				public java.util.Date getCreated_at () {
					return this.created_at;
				}

				public Boolean created_atIsNullable(){
				    return true;
				}
				public Boolean created_atIsKey(){
				    return false;
				}
				public Integer created_atLength(){
				    return 19;
				}
				public Integer created_atPrecision(){
				    return 0;
				}
				public String created_atDefault(){
				
					return null;
				
				}
				public String created_atComment(){
				
				    return "";
				
				}
				public String created_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_atOriginalDbColumnName(){
				
					return "created_at";
				
				}

				
			    public java.util.Date updated_at;

				public java.util.Date getUpdated_at () {
					return this.updated_at;
				}

				public Boolean updated_atIsNullable(){
				    return true;
				}
				public Boolean updated_atIsKey(){
				    return false;
				}
				public Integer updated_atLength(){
				    return 19;
				}
				public Integer updated_atPrecision(){
				    return 0;
				}
				public String updated_atDefault(){
				
					return null;
				
				}
				public String updated_atComment(){
				
				    return "";
				
				}
				public String updated_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_atOriginalDbColumnName(){
				
					return "updated_at";
				
				}

				
			    public String origine;

				public String getOrigine () {
					return this.origine;
				}

				public Boolean origineIsNullable(){
				    return true;
				}
				public Boolean origineIsKey(){
				    return false;
				}
				public Integer origineLength(){
				    return 45;
				}
				public Integer originePrecision(){
				    return 0;
				}
				public String origineDefault(){
				
					return null;
				
				}
				public String origineComment(){
				
				    return "";
				
				}
				public String originePattern(){
				
					return "";
				
				}
				public String origineOriginalDbColumnName(){
				
					return "origine";
				
				}

				
			    public String id_salesforce;

				public String getId_salesforce () {
					return this.id_salesforce;
				}

				public Boolean id_salesforceIsNullable(){
				    return true;
				}
				public Boolean id_salesforceIsKey(){
				    return false;
				}
				public Integer id_salesforceLength(){
				    return 150;
				}
				public Integer id_salesforcePrecision(){
				    return 0;
				}
				public String id_salesforceDefault(){
				
					return null;
				
				}
				public String id_salesforceComment(){
				
				    return "";
				
				}
				public String id_salesforcePattern(){
				
					return "";
				
				}
				public String id_salesforceOriginalDbColumnName(){
				
					return "id_salesforce";
				
				}

				
			    public int is_activated;

				public int getIs_activated () {
					return this.is_activated;
				}

				public Boolean is_activatedIsNullable(){
				    return false;
				}
				public Boolean is_activatedIsKey(){
				    return false;
				}
				public Integer is_activatedLength(){
				    return 10;
				}
				public Integer is_activatedPrecision(){
				    return 0;
				}
				public String is_activatedDefault(){
				
					return "1";
				
				}
				public String is_activatedComment(){
				
				    return "";
				
				}
				public String is_activatedPattern(){
				
					return "";
				
				}
				public String is_activatedOriginalDbColumnName(){
				
					return "is_activated";
				
				}

				
			    public String Vehicule;

				public String getVehicule () {
					return this.Vehicule;
				}

				public Boolean VehiculeIsNullable(){
				    return true;
				}
				public Boolean VehiculeIsKey(){
				    return false;
				}
				public Integer VehiculeLength(){
				    return 25;
				}
				public Integer VehiculePrecision(){
				    return 0;
				}
				public String VehiculeDefault(){
				
					return null;
				
				}
				public String VehiculeComment(){
				
				    return "";
				
				}
				public String VehiculePattern(){
				
					return "";
				
				}
				public String VehiculeOriginalDbColumnName(){
				
					return "Vehicule";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final service_detailStruct other = (service_detailStruct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(service_detailStruct other) {

		other.id = this.id;
	            other.id_client = this.id_client;
	            other.service = this.service;
	            other.category = this.category;
	            other.sub_category = this.sub_category;
	            other.unit = this.unit;
	            other.billing_type = this.billing_type;
	            other.created_at = this.created_at;
	            other.updated_at = this.updated_at;
	            other.origine = this.origine;
	            other.id_salesforce = this.id_salesforce;
	            other.is_activated = this.is_activated;
	            other.Vehicule = this.Vehicule;
	            
	}

	public void copyKeysDataTo(service_detailStruct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.id_client = dis.readInt();
					
					this.service = readString(dis);
					
					this.category = readString(dis);
					
					this.sub_category = readString(dis);
					
					this.unit = readString(dis);
					
					this.billing_type = readString(dis);
					
					this.created_at = readDate(dis);
					
					this.updated_at = readDate(dis);
					
					this.origine = readString(dis);
					
					this.id_salesforce = readString(dis);
					
			        this.is_activated = dis.readInt();
					
					this.Vehicule = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.id_client = dis.readInt();
					
					this.service = readString(dis);
					
					this.category = readString(dis);
					
					this.sub_category = readString(dis);
					
					this.unit = readString(dis);
					
					this.billing_type = readString(dis);
					
					this.created_at = readDate(dis);
					
					this.updated_at = readDate(dis);
					
					this.origine = readString(dis);
					
					this.id_salesforce = readString(dis);
					
			        this.is_activated = dis.readInt();
					
					this.Vehicule = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.id_client);
					
					// String
				
						writeString(this.service,dos);
					
					// String
				
						writeString(this.category,dos);
					
					// String
				
						writeString(this.sub_category,dos);
					
					// String
				
						writeString(this.unit,dos);
					
					// String
				
						writeString(this.billing_type,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
					// java.util.Date
				
						writeDate(this.updated_at,dos);
					
					// String
				
						writeString(this.origine,dos);
					
					// String
				
						writeString(this.id_salesforce,dos);
					
					// int
				
		            	dos.writeInt(this.is_activated);
					
					// String
				
						writeString(this.Vehicule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.id_client);
					
					// String
				
						writeString(this.service,dos);
					
					// String
				
						writeString(this.category,dos);
					
					// String
				
						writeString(this.sub_category,dos);
					
					// String
				
						writeString(this.unit,dos);
					
					// String
				
						writeString(this.billing_type,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
					// java.util.Date
				
						writeDate(this.updated_at,dos);
					
					// String
				
						writeString(this.origine,dos);
					
					// String
				
						writeString(this.id_salesforce,dos);
					
					// int
				
		            	dos.writeInt(this.is_activated);
					
					// String
				
						writeString(this.Vehicule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",service="+service);
		sb.append(",category="+category);
		sb.append(",sub_category="+sub_category);
		sb.append(",unit="+unit);
		sb.append(",billing_type="+billing_type);
		sb.append(",created_at="+String.valueOf(created_at));
		sb.append(",updated_at="+String.valueOf(updated_at));
		sb.append(",origine="+origine);
		sb.append(",id_salesforce="+id_salesforce);
		sb.append(",is_activated="+String.valueOf(is_activated));
		sb.append(",Vehicule="+Vehicule);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				sb.append(id_client);
        			
        			sb.append("|");
        		
        				if(service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(service);
            			}
            		
        			sb.append("|");
        		
        				if(category == null){
        					sb.append("<null>");
        				}else{
            				sb.append(category);
            			}
            		
        			sb.append("|");
        		
        				if(sub_category == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_category);
            			}
            		
        			sb.append("|");
        		
        				if(unit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(unit);
            			}
            		
        			sb.append("|");
        		
        				if(billing_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billing_type);
            			}
            		
        			sb.append("|");
        		
        				if(created_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_at);
            			}
            		
        			sb.append("|");
        		
        				if(updated_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_at);
            			}
            		
        			sb.append("|");
        		
        				if(origine == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origine);
            			}
            		
        			sb.append("|");
        		
        				if(id_salesforce == null){
        					sb.append("<null>");
        				}else{
            				sb.append(id_salesforce);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_activated);
        			
        			sb.append("|");
        		
        				if(Vehicule == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Vehicule);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(service_detailStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class serviceStruct implements routines.system.IPersistableRow<serviceStruct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return true;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(serviceStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Double RL_External_id__c;

				public Double getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tSalesforceInput_1Struct implements routines.system.IPersistableRow<after_tSalesforceInput_1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Double RL_External_id__c;

				public Double getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tSalesforceInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tSalesforceInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceInput_1");
		org.slf4j.MDC.put("_subJobPid", "yfBlvq_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tSalesforceInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
row3Struct row3 = new row3Struct();
row4Struct row4 = new row4Struct();
serviceStruct service = new serviceStruct();
service_detailStruct service_detail = new service_detailStruct();








	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"service_detail");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"service_detail\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "tDBOutput_1", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
         if (updateKeyCount_tDBOutput_1 == 13 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "service_detail";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "service_detail" + "` (`id`,`id_client`,`service`,`category`,`sub_category`,`unit`,`billing_type`,`created_at`,`updated_at`,`origine`,`id_salesforce`,`is_activated`,`Vehicule`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `id_client` = ?,`service` = ?,`category` = ?,`sub_category` = ?,`unit` = ?,`billing_type` = ?,`created_at` = ?,`updated_at` = ?,`origine` = ?,`id_salesforce` = ?,`is_activated` = ?,`Vehicule` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"service");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_service_tMap_1 = 0;
		
		int count_row8_tMap_1 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
					globalMap.get( "tHash_Lookup_row8" ))
					;					
					
	

row8Struct row8HashKey = new row8Struct();
row8Struct row8Default = new row8Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
	String var1;
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_service_detail_tMap_1 = 0;
				
service_detailStruct service_detail_tmp = new service_detailStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tUniqRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
                    log4jParamters_tUniqRow_1.append("Parameters:");
                            log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Id")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("OwnerId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("IsDeleted")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("SystemModstamp")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastViewedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastReferencedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Is_Modified__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Billing_type__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Category__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Client__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_External_id__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Deleted__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Service__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Sub_category__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Unit__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Active__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Vehicle__c")+"}]");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + (log4jParamters_tUniqRow_1) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
	log.debug("tUniqRow_1 - Start to process the data from datasource."); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tFilterRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_11", false);
		start_Hash.put("tFilterRow_11", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_11";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tFilterRow_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_11{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_11 = new StringBuilder();
                    log4jParamters_tFilterRow_11.append("Parameters:");
                            log4jParamters_tFilterRow_11.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_11.append(" | ");
                            log4jParamters_tFilterRow_11.append("CONDITIONS" + " = " + "[{OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("RL_External_id__c")+", FUNCTION="+("")+"}, {OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("RL_Category__c")+", FUNCTION="+("")+"}, {OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("RL_Billing_type__c")+", FUNCTION="+("")+"}]");
                        log4jParamters_tFilterRow_11.append(" | ");
                            log4jParamters_tFilterRow_11.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + (log4jParamters_tFilterRow_11) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_11().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_11", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_11 = 0;
    int nb_line_ok_tFilterRow_11 = 0;
    int nb_line_reject_tFilterRow_11 = 0;

    class Operator_tFilterRow_11 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_11(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_11 begin ] stop
 */



	
	/**
	 * [tConvertType_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_1", false);
		start_Hash.put("tConvertType_1", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tConvertType_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_1", "tConvertType_1", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_1 = 0;  
 



/**
 * [tConvertType_1 begin ] stop
 */



	
	/**
	 * [tSalesforceInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceInput_1", false);
		start_Hash.put("tSalesforceInput_1", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		
		int tos_count_tSalesforceInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceInput_1", "RL_Service_Detail__c", "tSalesforceInput");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceInput_1 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceInput_1 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceInput_1 = (String)(restRequest_tSalesforceInput_1 != null ? restRequest_tSalesforceInput_1.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceInput_1 =
        new org.talend.components.salesforce.tsalesforceinput.TSalesforceInputDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceInput_1 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceInput_1 = null;


org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties props_tSalesforceInput_1 =
        (org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties) def_tSalesforceInput_1.createRuntimeProperties();
 		                    props_tSalesforceInput_1.setValue("queryMode",
 		                        org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties.QueryMode.Query);
 		                    
 		                    props_tSalesforceInput_1.setValue("condition",
 		                    "");
 		                    
 		                    props_tSalesforceInput_1.setValue("manualQuery",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.setValue("includeDeleted",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.setValue("batchSize",
 		                    250);
 		                    
 		                    props_tSalesforceInput_1.setValue("normalizeDelimiter",
 		                    ";");
 		                    
 		                    props_tSalesforceInput_1.setValue("columnNameDelimiter",
 		                    "_");
 		                    
 		                    props_tSalesforceInput_1.setValue("dataTimeUTC",
 		                    true);
 		                    
 		                    props_tSalesforceInput_1.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    props_tSalesforceInput_1.module.setValue("moduleName",
 		                    "RL_Service_Detail__c");
 		                    
 		                    props_tSalesforceInput_1.module.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.module.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    class SchemaSettingTool_tSalesforceInput_1_1_fisrt {
 		                    		
 		                    		String getSchemaValue() {
 		                    				
 		                    						StringBuilder s = new StringBuilder();
                    						
     		                    						a("{\"type\":\"record\",",s);
     		                    						
     		                    						a("\"name\":\"RL_Service_Detail__c\",\"fields\":[{",s);
     		                    						
     		                    						a("\"name\":\"Id\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Id\",\"talend.field.dbColumnName\":\"Id\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Id\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"OwnerId\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"OwnerId\",\"talend.field.dbColumnName\":\"OwnerId\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"OwnerId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"IsDeleted\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"IsDeleted\",\"talend.field.dbColumnName\":\"IsDeleted\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"IsDeleted\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Name\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Name\",\"talend.field.dbColumnName\":\"Name\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Name\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"CreatedDate\",\"talend.field.dbColumnName\":\"CreatedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"CreatedById\",\"talend.field.dbColumnName\":\"CreatedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedDate\",\"talend.field.dbColumnName\":\"LastModifiedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedById\",\"talend.field.dbColumnName\":\"LastModifiedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"SystemModstamp\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"SystemModstamp\",\"talend.field.dbColumnName\":\"SystemModstamp\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"SystemModstamp\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastViewedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastViewedDate\",\"talend.field.dbColumnName\":\"LastViewedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastViewedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastReferencedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastReferencedDate\",\"talend.field.dbColumnName\":\"LastReferencedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastReferencedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Is_Modified__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Is_Modified__c\",\"talend.field.dbColumnName\":\"Is_Modified__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Is_Modified__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Billing_type__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Billing_type__c\",\"talend.field.dbColumnName\":\"RL_Billing_type__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Billing_type__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Category__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Category__c\",\"talend.field.dbColumnName\":\"RL_Category__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Category__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Client__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Client__c\",\"talend.field.dbColumnName\":\"RL_Client__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Client__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_External_id__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_External_id__c\",\"talend.field.dbColumnName\":\"RL_External_id__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"16\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_External_id__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Deleted__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Deleted__c\",\"talend.field.dbColumnName\":\"RL_Is_Deleted__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Deleted__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Service__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Service__c\",\"talend.field.dbColumnName\":\"RL_Service__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Service__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Sub_category__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Sub_category__c\",\"talend.field.dbColumnName\":\"RL_Sub_category__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Sub_category__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Unit__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Unit__c\",\"talend.field.dbColumnName\":\"RL_Unit__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Unit__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Active__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Active__c\",\"talend.field.dbColumnName\":\"RL_Is_Active__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Active__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Vehicle__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Vehicle__c\",\"talend.field.dbColumnName\":\"RL_Vehicle__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Vehicle__c\",\"di.column.relatedEntity\":\"\"}],\"di.table.name\":\"MAIN\",\"di.table.label\":\"RL_Service_Detail__c\"}",s);
     		                    						
     		                    				return s.toString();
     		                    		
 		                    		}
 		                    		
 		                    		void a(String part, StringBuilder strB) {
 		                    				strB.append(part);
 		                    		}
 		                    		
 		                    }
 		                    
 		                    SchemaSettingTool_tSalesforceInput_1_1_fisrt sst_tSalesforceInput_1_1_fisrt = new SchemaSettingTool_tSalesforceInput_1_1_fisrt();
 		                    
 		                    props_tSalesforceInput_1.module.main.setValue("schema",
 		                        new org.apache.avro.Schema.Parser().setValidateDefaults(false).parse(sst_tSalesforceInput_1_1_fisrt.getSchemaValue()));
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_1.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_1 = props_tSalesforceInput_1.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_1.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_1);
        }
    }
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_1.module.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_1 = props_tSalesforceInput_1.module.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_1.module.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_1);
        }
    }
globalMap.put("tSalesforceInput_1_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceInput_1);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceInput_1= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceInput_1_MAPPINGS_URL", mappings_url_tSalesforceInput_1);

org.talend.components.api.container.RuntimeContainer container_tSalesforceInput_1 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceInput_1";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceInput_1 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceInput_1 = null;
topology_tSalesforceInput_1 = org.talend.components.api.component.ConnectorTopology.OUTGOING;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceInput_1 = def_tSalesforceInput_1.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceInput_1, topology_tSalesforceInput_1);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceInput_1 = def_tSalesforceInput_1.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceInput_1 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceInput_1.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceInput_1 = componentRuntime_tSalesforceInput_1.initialize(container_tSalesforceInput_1, props_tSalesforceInput_1);

if (initVr_tSalesforceInput_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceInput_1.getMessage());
}

if(componentRuntime_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceInput_1 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceInput_1;
	compDriverInitialization_tSalesforceInput_1.runAtDriver(container_tSalesforceInput_1);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceInput_1 = null;
if(componentRuntime_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceInput_1 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceInput_1;
	if (doesNodeBelongToRequest_tSalesforceInput_1) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceInput_1 = sourceOrSink_tSalesforceInput_1.validate(container_tSalesforceInput_1);
        if (vr_tSalesforceInput_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceInput_1.getMessage());
        }
	}
}

    if (sourceOrSink_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.Source) {
        org.talend.components.api.component.runtime.Source source_tSalesforceInput_1 =
                (org.talend.components.api.component.runtime.Source)sourceOrSink_tSalesforceInput_1;
        reader_tSalesforceInput_1 = source_tSalesforceInput_1.createReader(container_tSalesforceInput_1);
	    reader_tSalesforceInput_1 = new org.talend.codegen.flowvariables.runtime.FlowVariablesReader(reader_tSalesforceInput_1, container_tSalesforceInput_1);

            boolean multi_output_is_allowed_tSalesforceInput_1 = false;
            org.talend.components.api.component.Connector c_tSalesforceInput_1 = null;
            for (org.talend.components.api.component.Connector currentConnector : props_tSalesforceInput_1.getAvailableConnectors(null, true)) {
                if (currentConnector.getName().equals("MAIN")) {
                    c_tSalesforceInput_1 = currentConnector;
                }

                if (currentConnector.getName().equals("REJECT")) {//it's better to move the code to javajet
                    multi_output_is_allowed_tSalesforceInput_1 = true;
                }
            }
            org.apache.avro.Schema schema_tSalesforceInput_1 = props_tSalesforceInput_1.getSchema(c_tSalesforceInput_1, true);

        org.talend.codegen.enforcer.OutgoingSchemaEnforcer outgoingEnforcer_tSalesforceInput_1 = org.talend.codegen.enforcer.EnforcerCreator.createOutgoingEnforcer(schema_tSalesforceInput_1, false);

        // Create a reusable factory that converts the output of the reader to an IndexedRecord.
        org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord> factory_tSalesforceInput_1 = null;

        // Iterate through the incoming data.
        boolean available_tSalesforceInput_1 = reader_tSalesforceInput_1.start();

        resourceMap.put("reader_tSalesforceInput_1", reader_tSalesforceInput_1);

        for (; available_tSalesforceInput_1; available_tSalesforceInput_1 = reader_tSalesforceInput_1.advance()) {
			nb_line_tSalesforceInput_1++;

			
			if (multi_output_is_allowed_tSalesforceInput_1) {
				
					row1 = null;
				

				
			}
			

			try {
				Object data_tSalesforceInput_1 = reader_tSalesforceInput_1.getCurrent();
				

					if(multi_output_is_allowed_tSalesforceInput_1) {
						row1 = new row1Struct();
					}

					
        // Construct the factory once when the first data arrives.
        if (factory_tSalesforceInput_1 == null) {
            factory_tSalesforceInput_1 = (org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord>)
                    new org.talend.daikon.avro.AvroRegistry()
                            .createIndexedRecordConverter(data_tSalesforceInput_1.getClass());
        }

        // Enforce the outgoing schema on the input.
        outgoingEnforcer_tSalesforceInput_1.setWrapped(factory_tSalesforceInput_1.convertToAvro(data_tSalesforceInput_1));
                Object columnValue_0_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(0);
                        row1.Id = (String) (columnValue_0_tSalesforceInput_1);
                Object columnValue_1_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(1);
                        row1.OwnerId = (String) (columnValue_1_tSalesforceInput_1);
                Object columnValue_2_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(2);
                    if (columnValue_2_tSalesforceInput_1 == null) {
                        row1.IsDeleted = false;
                    } else {
                            row1.IsDeleted = (boolean) (columnValue_2_tSalesforceInput_1);
                    }
                Object columnValue_3_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(3);
                        row1.Name = (String) (columnValue_3_tSalesforceInput_1);
                Object columnValue_4_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(4);
                        row1.CreatedDate = (java.util.Date) (columnValue_4_tSalesforceInput_1);
                Object columnValue_5_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(5);
                        row1.CreatedById = (String) (columnValue_5_tSalesforceInput_1);
                Object columnValue_6_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(6);
                        row1.LastModifiedDate = (java.util.Date) (columnValue_6_tSalesforceInput_1);
                Object columnValue_7_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(7);
                        row1.LastModifiedById = (String) (columnValue_7_tSalesforceInput_1);
                Object columnValue_8_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(8);
                        row1.SystemModstamp = (java.util.Date) (columnValue_8_tSalesforceInput_1);
                Object columnValue_9_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(9);
                        row1.LastViewedDate = (java.util.Date) (columnValue_9_tSalesforceInput_1);
                Object columnValue_10_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(10);
                        row1.LastReferencedDate = (java.util.Date) (columnValue_10_tSalesforceInput_1);
                Object columnValue_11_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(11);
                    if (columnValue_11_tSalesforceInput_1 == null) {
                        row1.Is_Modified__c = false;
                    } else {
                            row1.Is_Modified__c = (boolean) (columnValue_11_tSalesforceInput_1);
                    }
                Object columnValue_12_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(12);
                        row1.RL_Billing_type__c = (String) (columnValue_12_tSalesforceInput_1);
                Object columnValue_13_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(13);
                        row1.RL_Category__c = (String) (columnValue_13_tSalesforceInput_1);
                Object columnValue_14_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(14);
                        row1.RL_Client__c = (String) (columnValue_14_tSalesforceInput_1);
                Object columnValue_15_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(15);
                        row1.RL_External_id__c = (Double) (columnValue_15_tSalesforceInput_1);
                Object columnValue_16_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(16);
                    if (columnValue_16_tSalesforceInput_1 == null) {
                        row1.RL_Is_Deleted__c = false;
                    } else {
                            row1.RL_Is_Deleted__c = (boolean) (columnValue_16_tSalesforceInput_1);
                    }
                Object columnValue_17_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(17);
                        row1.RL_Service__c = (String) (columnValue_17_tSalesforceInput_1);
                Object columnValue_18_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(18);
                        row1.RL_Sub_category__c = (String) (columnValue_18_tSalesforceInput_1);
                Object columnValue_19_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(19);
                        row1.RL_Unit__c = (String) (columnValue_19_tSalesforceInput_1);
                Object columnValue_20_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(20);
                    if (columnValue_20_tSalesforceInput_1 == null) {
                        row1.RL_Is_Active__c = false;
                    } else {
                            row1.RL_Is_Active__c = (boolean) (columnValue_20_tSalesforceInput_1);
                    }
                Object columnValue_21_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(21);
                        row1.RL_Vehicle__c = (String) (columnValue_21_tSalesforceInput_1);
			} catch (org.talend.components.api.exception.DataRejectException e_tSalesforceInput_1) {
				java.util.Map<String,Object> info_tSalesforceInput_1 = e_tSalesforceInput_1.getRejectInfo();
				
					//TODO use a method instead of getting method by the special key "error/errorMessage"
					Object errorMessage_tSalesforceInput_1 = null;
					if(info_tSalesforceInput_1.containsKey("error")){
						errorMessage_tSalesforceInput_1 = info_tSalesforceInput_1.get("error");
					}else if(info_tSalesforceInput_1.containsKey("errorMessage")){
						errorMessage_tSalesforceInput_1 = info_tSalesforceInput_1.get("errorMessage");
					}else{
						errorMessage_tSalesforceInput_1 = "Rejected but error message missing";
					}
					errorMessage_tSalesforceInput_1 = "Row "+ nb_line_tSalesforceInput_1 + ": "+errorMessage_tSalesforceInput_1;
					System.err.println(errorMessage_tSalesforceInput_1);
				
					// If the record is reject, the main line record should put NULL
					row1 = null;
				
			} // end of catch

                java.lang.Iterable<?> outgoingMainRecordsList_tSalesforceInput_1 = new java.util.ArrayList<Object>();
                java.util.Iterator outgoingMainRecordsIt_tSalesforceInput_1 = null;


 



/**
 * [tSalesforceInput_1 begin ] stop
 */
	
	/**
	 * [tSalesforceInput_1 main ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		


 


	tos_count_tSalesforceInput_1++;

/**
 * [tSalesforceInput_1 main ] stop
 */
	
	/**
	 * [tSalesforceInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		


 



/**
 * [tSalesforceInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tConvertType_1 main ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tSalesforceInput_1","RL_Service_Detail__c","tSalesforceInput","tConvertType_1","tConvertType_1","tConvertType"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


  row3 = new row3Struct();
  boolean bHasError_tConvertType_1 = false;             
          try {
              if ("".equals(row1.Id)){  
                row1.Id = null;
              }
              row3.Id=TypeConvert.String2String(row1.Id);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.OwnerId)){  
                row1.OwnerId = null;
              }
              row3.OwnerId=TypeConvert.String2String(row1.OwnerId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.IsDeleted=TypeConvert.boolean2boolean(row1.IsDeleted);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.Name)){  
                row1.Name = null;
              }
              row3.Name=TypeConvert.String2String(row1.Name);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.CreatedDate=TypeConvert.Date2String(row1.CreatedDate, "yyyy-MM-dd'T'HH:mm:ss'.000Z'");
        	            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.CreatedById)){  
                row1.CreatedById = null;
              }
              row3.CreatedById=TypeConvert.String2String(row1.CreatedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastModifiedDate=TypeConvert.Date2Date(row1.LastModifiedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.LastModifiedById)){  
                row1.LastModifiedById = null;
              }
              row3.LastModifiedById=TypeConvert.String2String(row1.LastModifiedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.SystemModstamp=TypeConvert.Date2Date(row1.SystemModstamp);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastViewedDate=TypeConvert.Date2Date(row1.LastViewedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastReferencedDate=TypeConvert.Date2Date(row1.LastReferencedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.Is_Modified__c=TypeConvert.boolean2boolean(row1.Is_Modified__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Billing_type__c)){  
                row1.RL_Billing_type__c = null;
              }
              row3.RL_Billing_type__c=TypeConvert.String2String(row1.RL_Billing_type__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Category__c)){  
                row1.RL_Category__c = null;
              }
              row3.RL_Category__c=TypeConvert.String2String(row1.RL_Category__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Client__c)){  
                row1.RL_Client__c = null;
              }
              row3.RL_Client__c=TypeConvert.String2String(row1.RL_Client__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_External_id__c=TypeConvert.Double2Integer(row1.RL_External_id__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Is_Deleted__c=TypeConvert.boolean2boolean(row1.RL_Is_Deleted__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Service__c)){  
                row1.RL_Service__c = null;
              }
              row3.RL_Service__c=TypeConvert.String2String(row1.RL_Service__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Sub_category__c)){  
                row1.RL_Sub_category__c = null;
              }
              row3.RL_Sub_category__c=TypeConvert.String2String(row1.RL_Sub_category__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Unit__c)){  
                row1.RL_Unit__c = null;
              }
              row3.RL_Unit__c=TypeConvert.String2String(row1.RL_Unit__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Is_Active__c=TypeConvert.boolean2boolean(row1.RL_Is_Active__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Vehicle__c)){  
                row1.RL_Vehicle__c = null;
              }
              row3.RL_Vehicle__c=TypeConvert.String2String(row1.RL_Vehicle__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_1) {row3 = null;}

  nb_line_tConvertType_1 ++ ;

 


	tos_count_tConvertType_1++;

/**
 * [tConvertType_1 main ] stop
 */
	
	/**
	 * [tConvertType_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tFilterRow_11 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tConvertType_1","tConvertType_1","tConvertType","tFilterRow_11","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

          row4 = null;
    Operator_tFilterRow_11 ope_tFilterRow_11 = new Operator_tFilterRow_11("&&");
	        ope_tFilterRow_11.matches((row3.RL_External_id__c != null)
	                       , "RL_External_id__c!=null failed");
	        ope_tFilterRow_11.matches((row3.RL_Category__c != null)
	                       , "RL_Category__c!=null failed");
	        ope_tFilterRow_11.matches((row3.RL_Billing_type__c != null)
	                       , "RL_Billing_type__c!=null failed");
    
    if (ope_tFilterRow_11.getMatchFlag()) {
              if(row4 == null){ 
                row4 = new row4Struct();
              }
               row4.Id = row3.Id;
               row4.OwnerId = row3.OwnerId;
               row4.IsDeleted = row3.IsDeleted;
               row4.Name = row3.Name;
               row4.CreatedDate = row3.CreatedDate;
               row4.CreatedById = row3.CreatedById;
               row4.LastModifiedDate = row3.LastModifiedDate;
               row4.LastModifiedById = row3.LastModifiedById;
               row4.SystemModstamp = row3.SystemModstamp;
               row4.LastViewedDate = row3.LastViewedDate;
               row4.LastReferencedDate = row3.LastReferencedDate;
               row4.Is_Modified__c = row3.Is_Modified__c;
               row4.RL_Billing_type__c = row3.RL_Billing_type__c;
               row4.RL_Category__c = row3.RL_Category__c;
               row4.RL_Client__c = row3.RL_Client__c;
               row4.RL_External_id__c = row3.RL_External_id__c;
               row4.RL_Is_Deleted__c = row3.RL_Is_Deleted__c;
               row4.RL_Service__c = row3.RL_Service__c;
               row4.RL_Sub_category__c = row3.RL_Sub_category__c;
               row4.RL_Unit__c = row3.RL_Unit__c;
               row4.RL_Is_Active__c = row3.RL_Is_Active__c;
               row4.RL_Vehicle__c = row3.RL_Vehicle__c;
					log.debug("tFilterRow_11 - Process the record " + (nb_line_tFilterRow_11+1) + ".");
					    
      nb_line_ok_tFilterRow_11++;
    } else {
      nb_line_reject_tFilterRow_11++;
    }

nb_line_tFilterRow_11++;

 


	tos_count_tFilterRow_11++;

/**
 * [tFilterRow_11 main ] stop
 */
	
	/**
	 * [tFilterRow_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tFilterRow_11","tFilterRow_1","tFilterRow","tUniqRow_1","tUniqRow_1","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		
service.Id = row4.Id;			service.OwnerId = row4.OwnerId;			service.IsDeleted = row4.IsDeleted;			service.Name = row4.Name;			service.CreatedDate = row4.CreatedDate;			service.CreatedById = row4.CreatedById;			service.LastModifiedDate = row4.LastModifiedDate;			service.LastModifiedById = row4.LastModifiedById;			service.SystemModstamp = row4.SystemModstamp;			service.LastViewedDate = row4.LastViewedDate;			service.LastReferencedDate = row4.LastReferencedDate;			service.Is_Modified__c = row4.Is_Modified__c;			service.RL_Billing_type__c = row4.RL_Billing_type__c;			service.RL_Category__c = row4.RL_Category__c;			service.RL_Client__c = row4.RL_Client__c;			service.RL_External_id__c = row4.RL_External_id__c;			service.RL_Is_Deleted__c = row4.RL_Is_Deleted__c;			service.RL_Service__c = row4.RL_Service__c;			service.RL_Sub_category__c = row4.RL_Sub_category__c;			service.RL_Unit__c = row4.RL_Unit__c;			service.RL_Is_Active__c = row4.RL_Is_Active__c;			service.RL_Vehicle__c = row4.RL_Vehicle__c;			

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "service"
if(service != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"service","tUniqRow_1","tUniqRow_1","tUniqRow","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("service - " + (service==null? "": service.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
						row8Struct row8 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row8" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow8 = false;
       		  	    	
       		  	    	
 							row8Struct row8ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row8HashKey.Id = service.RL_Client__c ;
                        		    		

								
		                        	row8HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row8.lookup( row8HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row8.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row8 != null && tHash_Lookup_row8.getCount(row8HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row8' and it contains more one result from keys :  row8.Id = '" + row8HashKey.Id + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row8Struct fromLookup_row8 = null;
							row8 = row8Default;
										 
							
								 
							
							
								if (tHash_Lookup_row8 !=null && tHash_Lookup_row8.hasNext()) { // G 099
								
							
								
								fromLookup_row8 = tHash_Lookup_row8.next();

							
							
								} // G 099
							
							

							if(fromLookup_row8 != null) {
								row8 = fromLookup_row8;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;
Var.var1 = service.CreatedDate != null ? service.CreatedDate.split("T")[0]+service.CreatedDate.split("T")[1] : "2024-01-0100:00:00" ;// ###############################
        // ###############################
        // # Output tables

service_detail = null;

if(!rejectedInnerJoin_tMap_1 ) {

// # Output table : 'service_detail'
count_service_detail_tMap_1++;

service_detail_tmp.id = service.RL_External_id__c ;
service_detail_tmp.id_client = row8.RL_ExternalId__c ;
service_detail_tmp.service = service.RL_Service__c ;
service_detail_tmp.category = service.RL_Category__c ;
service_detail_tmp.sub_category = service.RL_Sub_category__c ;
service_detail_tmp.unit = service.RL_Unit__c ;
service_detail_tmp.billing_type = service.RL_Billing_type__c ;
service_detail_tmp.created_at = TalendDate.parseDate("yyyy-MM-ddHH:mm:ss",Var.var1) ;
service_detail_tmp.updated_at = TalendDate.getCurrentDate();
service_detail_tmp.origine = null;
service_detail_tmp.id_salesforce = service.Id ;
service_detail_tmp.is_activated = (service.RL_Is_Active__c  == false) ? 0 : 1 ;
service_detail_tmp.Vehicule = service.RL_Vehicle__c ;
service_detail = service_detail_tmp;
log.debug("tMap_1 - Outputting the record " + count_service_detail_tMap_1 + " of the output table 'service_detail'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "service_detail"
if(service_detail != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"service_detail","tMap_1","tMap_1","tMap","tDBOutput_1","tDBOutput_1","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("service_detail - " + (service_detail==null? "": service_detail.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, service_detail.id);

                    pstmt_tDBOutput_1.setInt(2, service_detail.id_client);

                    if(service_detail.service == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, service_detail.service);
}

                    if(service_detail.category == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, service_detail.category);
}

                    if(service_detail.sub_category == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, service_detail.sub_category);
}

                    if(service_detail.unit == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, service_detail.unit);
}

                    if(service_detail.billing_type == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, service_detail.billing_type);
}

                    if(service_detail.created_at != null) {
date_tDBOutput_1 = service_detail.created_at.getTime();
if(date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
pstmt_tDBOutput_1.setString(8, "0000-00-00 00:00:00");
} else {pstmt_tDBOutput_1.setTimestamp(8, new java.sql.Timestamp(date_tDBOutput_1));
}
} else {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.DATE);
}

                    if(service_detail.updated_at != null) {
date_tDBOutput_1 = service_detail.updated_at.getTime();
if(date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
pstmt_tDBOutput_1.setString(9, "0000-00-00 00:00:00");
} else {pstmt_tDBOutput_1.setTimestamp(9, new java.sql.Timestamp(date_tDBOutput_1));
}
} else {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.DATE);
}

                    if(service_detail.origine == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, service_detail.origine);
}

                    if(service_detail.id_salesforce == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, service_detail.id_salesforce);
}

                    pstmt_tDBOutput_1.setInt(12, service_detail.is_activated);

                    if(service_detail.Vehicule == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, service_detail.Vehicule);
}

                    pstmt_tDBOutput_1.setInt(14 + count_tDBOutput_1, service_detail.id_client);

                    if(service_detail.service == null) {
pstmt_tDBOutput_1.setNull(15 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(15 + count_tDBOutput_1, service_detail.service);
}

                    if(service_detail.category == null) {
pstmt_tDBOutput_1.setNull(16 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(16 + count_tDBOutput_1, service_detail.category);
}

                    if(service_detail.sub_category == null) {
pstmt_tDBOutput_1.setNull(17 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(17 + count_tDBOutput_1, service_detail.sub_category);
}

                    if(service_detail.unit == null) {
pstmt_tDBOutput_1.setNull(18 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(18 + count_tDBOutput_1, service_detail.unit);
}

                    if(service_detail.billing_type == null) {
pstmt_tDBOutput_1.setNull(19 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(19 + count_tDBOutput_1, service_detail.billing_type);
}

                    if(service_detail.created_at != null) {
pstmt_tDBOutput_1.setTimestamp(20 + count_tDBOutput_1, new java.sql.Timestamp(service_detail.created_at.getTime()));
} else {
pstmt_tDBOutput_1.setNull(20 + count_tDBOutput_1, java.sql.Types.TIMESTAMP);
}

                    if(service_detail.updated_at != null) {
pstmt_tDBOutput_1.setTimestamp(21 + count_tDBOutput_1, new java.sql.Timestamp(service_detail.updated_at.getTime()));
} else {
pstmt_tDBOutput_1.setNull(21 + count_tDBOutput_1, java.sql.Types.TIMESTAMP);
}

                    if(service_detail.origine == null) {
pstmt_tDBOutput_1.setNull(22 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(22 + count_tDBOutput_1, service_detail.origine);
}

                    if(service_detail.id_salesforce == null) {
pstmt_tDBOutput_1.setNull(23 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(23 + count_tDBOutput_1, service_detail.id_salesforce);
}

                    pstmt_tDBOutput_1.setInt(24 + count_tDBOutput_1, service_detail.is_activated);

                    if(service_detail.Vehicule == null) {
pstmt_tDBOutput_1.setNull(25 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(25 + count_tDBOutput_1, service_detail.Vehicule);
}

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "service_detail"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "service"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */

} // End of branch "row4"




	
	/**
	 * [tFilterRow_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tConvertType_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_end ] stop
 */



	
	/**
	 * [tSalesforceInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		


 



/**
 * [tSalesforceInput_1 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceInput_1 end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		
// end of generic


resourceMap.put("finish_tSalesforceInput_1", Boolean.TRUE);

    } // while  
    } // end of "if (sourceOrSink_tSalesforceInput_1 instanceof ...Source)"
    java.util.Map<String, Object> resultMap_tSalesforceInput_1 = null;
    if (reader_tSalesforceInput_1 != null) {
        reader_tSalesforceInput_1.close();
        resultMap_tSalesforceInput_1 = reader_tSalesforceInput_1.getReturnValues();
    }
if(resultMap_tSalesforceInput_1!=null) {
	for(java.util.Map.Entry<String,Object> entry_tSalesforceInput_1 : resultMap_tSalesforceInput_1.entrySet()) {
		switch(entry_tSalesforceInput_1.getKey()) {
		case org.talend.components.api.component.ComponentDefinition.RETURN_ERROR_MESSAGE :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "ERROR_MESSAGE", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_TOTAL_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_LINE", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_SUCCESS_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_SUCCESS", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_REJECT_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_REJECT", entry_tSalesforceInput_1.getValue());
			break;
		default :
            StringBuilder studio_key_tSalesforceInput_1 = new StringBuilder();
            for (int i_tSalesforceInput_1 = 0; i_tSalesforceInput_1 < entry_tSalesforceInput_1.getKey().length(); i_tSalesforceInput_1++) {
                char ch_tSalesforceInput_1 = entry_tSalesforceInput_1.getKey().charAt(i_tSalesforceInput_1);
                if(Character.isUpperCase(ch_tSalesforceInput_1) && i_tSalesforceInput_1> 0) {
                	studio_key_tSalesforceInput_1.append('_');
                }
                studio_key_tSalesforceInput_1.append(ch_tSalesforceInput_1);
            }
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", studio_key_tSalesforceInput_1.toString().toUpperCase(java.util.Locale.ENGLISH), entry_tSalesforceInput_1.getValue());
			break;
		}
	}
}

 

ok_Hash.put("tSalesforceInput_1", true);
end_Hash.put("tSalesforceInput_1", System.currentTimeMillis());




/**
 * [tSalesforceInput_1 end ] stop
 */

	
	/**
	 * [tConvertType_1 end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
      globalMap.put("tConvertType_1_NB_LINE", nb_line_tConvertType_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tSalesforceInput_1","RL_Service_Detail__c","tSalesforceInput","tConvertType_1","tConvertType_1","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_1", true);
end_Hash.put("tConvertType_1", System.currentTimeMillis());




/**
 * [tConvertType_1 end ] stop
 */

	
	/**
	 * [tFilterRow_11 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	
    globalMap.put("tFilterRow_11_NB_LINE", nb_line_tFilterRow_11);
    globalMap.put("tFilterRow_11_NB_LINE_OK", nb_line_ok_tFilterRow_11);
    globalMap.put("tFilterRow_11_NB_LINE_REJECT", nb_line_reject_tFilterRow_11);
    
    	log.info("tFilterRow_11 - Processed records count:" + nb_line_tFilterRow_11 + ". Matched records count:" + nb_line_ok_tFilterRow_11 + ". Rejected records count:" + nb_line_reject_tFilterRow_11 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tConvertType_1","tConvertType_1","tConvertType","tFilterRow_11","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + ("Done.") );

ok_Hash.put("tFilterRow_11", true);
end_Hash.put("tFilterRow_11", System.currentTimeMillis());




/**
 * [tFilterRow_11 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);
	log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1)+" .");
	log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tFilterRow_11","tFilterRow_1","tFilterRow","tUniqRow_1","tUniqRow_1","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Done.") );

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());




/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row8 != null) {
						tHash_Lookup_row8.endGet();
					}
					globalMap.remove( "tHash_Lookup_row8" );

					
					
				
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'service_detail': " + count_service_detail_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"service",2,0,
			 			"tUniqRow_1","tUniqRow_1","tUniqRow","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"service_detail",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","tDBOutput_1","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row8"); 
				     			
				try{
					
	
	/**
	 * [tSalesforceInput_1 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Service_Detail__c";
		
// finally of generic


if(resourceMap.get("finish_tSalesforceInput_1")==null){
    if(resourceMap.get("reader_tSalesforceInput_1")!=null){
		try {
			((org.talend.components.api.component.runtime.Reader)resourceMap.get("reader_tSalesforceInput_1")).close();
		} catch (java.io.IOException e_tSalesforceInput_1) {
			String errorMessage_tSalesforceInput_1 = "failed to release the resource in tSalesforceInput_1 :" + e_tSalesforceInput_1.getMessage();
			System.err.println(errorMessage_tSalesforceInput_1);
		}
	}
}
 



/**
 * [tSalesforceInput_1 finally ] stop
 */

	
	/**
	 * [tConvertType_1 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_11 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableComparableLookupRow<row8Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String MasterRecordId;

				public String getMasterRecordId () {
					return this.MasterRecordId;
				}

				public Boolean MasterRecordIdIsNullable(){
				    return true;
				}
				public Boolean MasterRecordIdIsKey(){
				    return false;
				}
				public Integer MasterRecordIdLength(){
				    return 18;
				}
				public Integer MasterRecordIdPrecision(){
				    return null;
				}
				public String MasterRecordIdDefault(){
				
					return null;
				
				}
				public String MasterRecordIdComment(){
				
				    return "";
				
				}
				public String MasterRecordIdPattern(){
				
					return "";
				
				}
				public String MasterRecordIdOriginalDbColumnName(){
				
					return "MasterRecordId";
				
				}

				
			    public String AccountId;

				public String getAccountId () {
					return this.AccountId;
				}

				public Boolean AccountIdIsNullable(){
				    return true;
				}
				public Boolean AccountIdIsKey(){
				    return false;
				}
				public Integer AccountIdLength(){
				    return 18;
				}
				public Integer AccountIdPrecision(){
				    return null;
				}
				public String AccountIdDefault(){
				
					return null;
				
				}
				public String AccountIdComment(){
				
				    return "";
				
				}
				public String AccountIdPattern(){
				
					return "";
				
				}
				public String AccountIdOriginalDbColumnName(){
				
					return "AccountId";
				
				}

				
			    public String LastName;

				public String getLastName () {
					return this.LastName;
				}

				public Boolean LastNameIsNullable(){
				    return false;
				}
				public Boolean LastNameIsKey(){
				    return false;
				}
				public Integer LastNameLength(){
				    return 80;
				}
				public Integer LastNamePrecision(){
				    return null;
				}
				public String LastNameDefault(){
				
					return null;
				
				}
				public String LastNameComment(){
				
				    return "";
				
				}
				public String LastNamePattern(){
				
					return "";
				
				}
				public String LastNameOriginalDbColumnName(){
				
					return "LastName";
				
				}

				
			    public String FirstName;

				public String getFirstName () {
					return this.FirstName;
				}

				public Boolean FirstNameIsNullable(){
				    return true;
				}
				public Boolean FirstNameIsKey(){
				    return false;
				}
				public Integer FirstNameLength(){
				    return 40;
				}
				public Integer FirstNamePrecision(){
				    return null;
				}
				public String FirstNameDefault(){
				
					return null;
				
				}
				public String FirstNameComment(){
				
				    return "";
				
				}
				public String FirstNamePattern(){
				
					return "";
				
				}
				public String FirstNameOriginalDbColumnName(){
				
					return "FirstName";
				
				}

				
			    public String Salutation;

				public String getSalutation () {
					return this.Salutation;
				}

				public Boolean SalutationIsNullable(){
				    return true;
				}
				public Boolean SalutationIsKey(){
				    return false;
				}
				public Integer SalutationLength(){
				    return 40;
				}
				public Integer SalutationPrecision(){
				    return null;
				}
				public String SalutationDefault(){
				
					return null;
				
				}
				public String SalutationComment(){
				
				    return "";
				
				}
				public String SalutationPattern(){
				
					return "";
				
				}
				public String SalutationOriginalDbColumnName(){
				
					return "Salutation";
				
				}

				
			    public String MiddleName;

				public String getMiddleName () {
					return this.MiddleName;
				}

				public Boolean MiddleNameIsNullable(){
				    return true;
				}
				public Boolean MiddleNameIsKey(){
				    return false;
				}
				public Integer MiddleNameLength(){
				    return 40;
				}
				public Integer MiddleNamePrecision(){
				    return null;
				}
				public String MiddleNameDefault(){
				
					return null;
				
				}
				public String MiddleNameComment(){
				
				    return "";
				
				}
				public String MiddleNamePattern(){
				
					return "";
				
				}
				public String MiddleNameOriginalDbColumnName(){
				
					return "MiddleName";
				
				}

				
			    public String Suffix;

				public String getSuffix () {
					return this.Suffix;
				}

				public Boolean SuffixIsNullable(){
				    return true;
				}
				public Boolean SuffixIsKey(){
				    return false;
				}
				public Integer SuffixLength(){
				    return 40;
				}
				public Integer SuffixPrecision(){
				    return null;
				}
				public String SuffixDefault(){
				
					return null;
				
				}
				public String SuffixComment(){
				
				    return "";
				
				}
				public String SuffixPattern(){
				
					return "";
				
				}
				public String SuffixOriginalDbColumnName(){
				
					return "Suffix";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return false;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 121;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String RecordTypeId;

				public String getRecordTypeId () {
					return this.RecordTypeId;
				}

				public Boolean RecordTypeIdIsNullable(){
				    return true;
				}
				public Boolean RecordTypeIdIsKey(){
				    return false;
				}
				public Integer RecordTypeIdLength(){
				    return 18;
				}
				public Integer RecordTypeIdPrecision(){
				    return null;
				}
				public String RecordTypeIdDefault(){
				
					return null;
				
				}
				public String RecordTypeIdComment(){
				
				    return "";
				
				}
				public String RecordTypeIdPattern(){
				
					return "";
				
				}
				public String RecordTypeIdOriginalDbColumnName(){
				
					return "RecordTypeId";
				
				}

				
			    public String MailingStreet;

				public String getMailingStreet () {
					return this.MailingStreet;
				}

				public Boolean MailingStreetIsNullable(){
				    return true;
				}
				public Boolean MailingStreetIsKey(){
				    return false;
				}
				public Integer MailingStreetLength(){
				    return 255;
				}
				public Integer MailingStreetPrecision(){
				    return null;
				}
				public String MailingStreetDefault(){
				
					return null;
				
				}
				public String MailingStreetComment(){
				
				    return "";
				
				}
				public String MailingStreetPattern(){
				
					return "";
				
				}
				public String MailingStreetOriginalDbColumnName(){
				
					return "MailingStreet";
				
				}

				
			    public String MailingCity;

				public String getMailingCity () {
					return this.MailingCity;
				}

				public Boolean MailingCityIsNullable(){
				    return true;
				}
				public Boolean MailingCityIsKey(){
				    return false;
				}
				public Integer MailingCityLength(){
				    return 40;
				}
				public Integer MailingCityPrecision(){
				    return null;
				}
				public String MailingCityDefault(){
				
					return null;
				
				}
				public String MailingCityComment(){
				
				    return "";
				
				}
				public String MailingCityPattern(){
				
					return "";
				
				}
				public String MailingCityOriginalDbColumnName(){
				
					return "MailingCity";
				
				}

				
			    public String MailingState;

				public String getMailingState () {
					return this.MailingState;
				}

				public Boolean MailingStateIsNullable(){
				    return true;
				}
				public Boolean MailingStateIsKey(){
				    return false;
				}
				public Integer MailingStateLength(){
				    return 80;
				}
				public Integer MailingStatePrecision(){
				    return null;
				}
				public String MailingStateDefault(){
				
					return null;
				
				}
				public String MailingStateComment(){
				
				    return "";
				
				}
				public String MailingStatePattern(){
				
					return "";
				
				}
				public String MailingStateOriginalDbColumnName(){
				
					return "MailingState";
				
				}

				
			    public String MailingPostalCode;

				public String getMailingPostalCode () {
					return this.MailingPostalCode;
				}

				public Boolean MailingPostalCodeIsNullable(){
				    return true;
				}
				public Boolean MailingPostalCodeIsKey(){
				    return false;
				}
				public Integer MailingPostalCodeLength(){
				    return 20;
				}
				public Integer MailingPostalCodePrecision(){
				    return null;
				}
				public String MailingPostalCodeDefault(){
				
					return null;
				
				}
				public String MailingPostalCodeComment(){
				
				    return "";
				
				}
				public String MailingPostalCodePattern(){
				
					return "";
				
				}
				public String MailingPostalCodeOriginalDbColumnName(){
				
					return "MailingPostalCode";
				
				}

				
			    public String MailingCountry;

				public String getMailingCountry () {
					return this.MailingCountry;
				}

				public Boolean MailingCountryIsNullable(){
				    return true;
				}
				public Boolean MailingCountryIsKey(){
				    return false;
				}
				public Integer MailingCountryLength(){
				    return 80;
				}
				public Integer MailingCountryPrecision(){
				    return null;
				}
				public String MailingCountryDefault(){
				
					return null;
				
				}
				public String MailingCountryComment(){
				
				    return "";
				
				}
				public String MailingCountryPattern(){
				
					return "";
				
				}
				public String MailingCountryOriginalDbColumnName(){
				
					return "MailingCountry";
				
				}

				
			    public Double MailingLatitude;

				public Double getMailingLatitude () {
					return this.MailingLatitude;
				}

				public Boolean MailingLatitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLatitudeIsKey(){
				    return false;
				}
				public Integer MailingLatitudeLength(){
				    return 18;
				}
				public Integer MailingLatitudePrecision(){
				    return 15;
				}
				public String MailingLatitudeDefault(){
				
					return null;
				
				}
				public String MailingLatitudeComment(){
				
				    return "";
				
				}
				public String MailingLatitudePattern(){
				
					return "";
				
				}
				public String MailingLatitudeOriginalDbColumnName(){
				
					return "MailingLatitude";
				
				}

				
			    public Double MailingLongitude;

				public Double getMailingLongitude () {
					return this.MailingLongitude;
				}

				public Boolean MailingLongitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLongitudeIsKey(){
				    return false;
				}
				public Integer MailingLongitudeLength(){
				    return 18;
				}
				public Integer MailingLongitudePrecision(){
				    return 15;
				}
				public String MailingLongitudeDefault(){
				
					return null;
				
				}
				public String MailingLongitudeComment(){
				
				    return "";
				
				}
				public String MailingLongitudePattern(){
				
					return "";
				
				}
				public String MailingLongitudeOriginalDbColumnName(){
				
					return "MailingLongitude";
				
				}

				
			    public String MailingGeocodeAccuracy;

				public String getMailingGeocodeAccuracy () {
					return this.MailingGeocodeAccuracy;
				}

				public Boolean MailingGeocodeAccuracyIsNullable(){
				    return true;
				}
				public Boolean MailingGeocodeAccuracyIsKey(){
				    return false;
				}
				public Integer MailingGeocodeAccuracyLength(){
				    return 40;
				}
				public Integer MailingGeocodeAccuracyPrecision(){
				    return null;
				}
				public String MailingGeocodeAccuracyDefault(){
				
					return null;
				
				}
				public String MailingGeocodeAccuracyComment(){
				
				    return "";
				
				}
				public String MailingGeocodeAccuracyPattern(){
				
					return "";
				
				}
				public String MailingGeocodeAccuracyOriginalDbColumnName(){
				
					return "MailingGeocodeAccuracy";
				
				}

				
			    public String MailingAddress;

				public String getMailingAddress () {
					return this.MailingAddress;
				}

				public Boolean MailingAddressIsNullable(){
				    return true;
				}
				public Boolean MailingAddressIsKey(){
				    return false;
				}
				public Integer MailingAddressLength(){
				    return null;
				}
				public Integer MailingAddressPrecision(){
				    return null;
				}
				public String MailingAddressDefault(){
				
					return null;
				
				}
				public String MailingAddressComment(){
				
				    return "";
				
				}
				public String MailingAddressPattern(){
				
					return "";
				
				}
				public String MailingAddressOriginalDbColumnName(){
				
					return "MailingAddress";
				
				}

				
			    public String Phone;

				public String getPhone () {
					return this.Phone;
				}

				public Boolean PhoneIsNullable(){
				    return true;
				}
				public Boolean PhoneIsKey(){
				    return false;
				}
				public Integer PhoneLength(){
				    return 40;
				}
				public Integer PhonePrecision(){
				    return null;
				}
				public String PhoneDefault(){
				
					return null;
				
				}
				public String PhoneComment(){
				
				    return "";
				
				}
				public String PhonePattern(){
				
					return "";
				
				}
				public String PhoneOriginalDbColumnName(){
				
					return "Phone";
				
				}

				
			    public String Fax;

				public String getFax () {
					return this.Fax;
				}

				public Boolean FaxIsNullable(){
				    return true;
				}
				public Boolean FaxIsKey(){
				    return false;
				}
				public Integer FaxLength(){
				    return 40;
				}
				public Integer FaxPrecision(){
				    return null;
				}
				public String FaxDefault(){
				
					return null;
				
				}
				public String FaxComment(){
				
				    return "";
				
				}
				public String FaxPattern(){
				
					return "";
				
				}
				public String FaxOriginalDbColumnName(){
				
					return "Fax";
				
				}

				
			    public String MobilePhone;

				public String getMobilePhone () {
					return this.MobilePhone;
				}

				public Boolean MobilePhoneIsNullable(){
				    return true;
				}
				public Boolean MobilePhoneIsKey(){
				    return false;
				}
				public Integer MobilePhoneLength(){
				    return 40;
				}
				public Integer MobilePhonePrecision(){
				    return null;
				}
				public String MobilePhoneDefault(){
				
					return null;
				
				}
				public String MobilePhoneComment(){
				
				    return "";
				
				}
				public String MobilePhonePattern(){
				
					return "";
				
				}
				public String MobilePhoneOriginalDbColumnName(){
				
					return "MobilePhone";
				
				}

				
			    public String ReportsToId;

				public String getReportsToId () {
					return this.ReportsToId;
				}

				public Boolean ReportsToIdIsNullable(){
				    return true;
				}
				public Boolean ReportsToIdIsKey(){
				    return false;
				}
				public Integer ReportsToIdLength(){
				    return 18;
				}
				public Integer ReportsToIdPrecision(){
				    return null;
				}
				public String ReportsToIdDefault(){
				
					return null;
				
				}
				public String ReportsToIdComment(){
				
				    return "";
				
				}
				public String ReportsToIdPattern(){
				
					return "";
				
				}
				public String ReportsToIdOriginalDbColumnName(){
				
					return "ReportsToId";
				
				}

				
			    public String Email;

				public String getEmail () {
					return this.Email;
				}

				public Boolean EmailIsNullable(){
				    return true;
				}
				public Boolean EmailIsKey(){
				    return false;
				}
				public Integer EmailLength(){
				    return 80;
				}
				public Integer EmailPrecision(){
				    return null;
				}
				public String EmailDefault(){
				
					return null;
				
				}
				public String EmailComment(){
				
				    return "";
				
				}
				public String EmailPattern(){
				
					return "";
				
				}
				public String EmailOriginalDbColumnName(){
				
					return "Email";
				
				}

				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}

				public Boolean TitleIsNullable(){
				    return true;
				}
				public Boolean TitleIsKey(){
				    return false;
				}
				public Integer TitleLength(){
				    return 128;
				}
				public Integer TitlePrecision(){
				    return null;
				}
				public String TitleDefault(){
				
					return null;
				
				}
				public String TitleComment(){
				
				    return "";
				
				}
				public String TitlePattern(){
				
					return "";
				
				}
				public String TitleOriginalDbColumnName(){
				
					return "Title";
				
				}

				
			    public String Department;

				public String getDepartment () {
					return this.Department;
				}

				public Boolean DepartmentIsNullable(){
				    return true;
				}
				public Boolean DepartmentIsKey(){
				    return false;
				}
				public Integer DepartmentLength(){
				    return 80;
				}
				public Integer DepartmentPrecision(){
				    return null;
				}
				public String DepartmentDefault(){
				
					return null;
				
				}
				public String DepartmentComment(){
				
				    return "";
				
				}
				public String DepartmentPattern(){
				
					return "";
				
				}
				public String DepartmentOriginalDbColumnName(){
				
					return "Department";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastActivityDate;

				public java.util.Date getLastActivityDate () {
					return this.LastActivityDate;
				}

				public Boolean LastActivityDateIsNullable(){
				    return true;
				}
				public Boolean LastActivityDateIsKey(){
				    return false;
				}
				public Integer LastActivityDateLength(){
				    return null;
				}
				public Integer LastActivityDatePrecision(){
				    return null;
				}
				public String LastActivityDateDefault(){
				
					return null;
				
				}
				public String LastActivityDateComment(){
				
				    return "";
				
				}
				public String LastActivityDatePattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String LastActivityDateOriginalDbColumnName(){
				
					return "LastActivityDate";
				
				}

				
			    public java.util.Date LastCURequestDate;

				public java.util.Date getLastCURequestDate () {
					return this.LastCURequestDate;
				}

				public Boolean LastCURequestDateIsNullable(){
				    return true;
				}
				public Boolean LastCURequestDateIsKey(){
				    return false;
				}
				public Integer LastCURequestDateLength(){
				    return null;
				}
				public Integer LastCURequestDatePrecision(){
				    return null;
				}
				public String LastCURequestDateDefault(){
				
					return null;
				
				}
				public String LastCURequestDateComment(){
				
				    return "";
				
				}
				public String LastCURequestDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCURequestDateOriginalDbColumnName(){
				
					return "LastCURequestDate";
				
				}

				
			    public java.util.Date LastCUUpdateDate;

				public java.util.Date getLastCUUpdateDate () {
					return this.LastCUUpdateDate;
				}

				public Boolean LastCUUpdateDateIsNullable(){
				    return true;
				}
				public Boolean LastCUUpdateDateIsKey(){
				    return false;
				}
				public Integer LastCUUpdateDateLength(){
				    return null;
				}
				public Integer LastCUUpdateDatePrecision(){
				    return null;
				}
				public String LastCUUpdateDateDefault(){
				
					return null;
				
				}
				public String LastCUUpdateDateComment(){
				
				    return "";
				
				}
				public String LastCUUpdateDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCUUpdateDateOriginalDbColumnName(){
				
					return "LastCUUpdateDate";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public String EmailBouncedReason;

				public String getEmailBouncedReason () {
					return this.EmailBouncedReason;
				}

				public Boolean EmailBouncedReasonIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedReasonIsKey(){
				    return false;
				}
				public Integer EmailBouncedReasonLength(){
				    return 255;
				}
				public Integer EmailBouncedReasonPrecision(){
				    return null;
				}
				public String EmailBouncedReasonDefault(){
				
					return null;
				
				}
				public String EmailBouncedReasonComment(){
				
				    return "";
				
				}
				public String EmailBouncedReasonPattern(){
				
					return "";
				
				}
				public String EmailBouncedReasonOriginalDbColumnName(){
				
					return "EmailBouncedReason";
				
				}

				
			    public java.util.Date EmailBouncedDate;

				public java.util.Date getEmailBouncedDate () {
					return this.EmailBouncedDate;
				}

				public Boolean EmailBouncedDateIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedDateIsKey(){
				    return false;
				}
				public Integer EmailBouncedDateLength(){
				    return null;
				}
				public Integer EmailBouncedDatePrecision(){
				    return null;
				}
				public String EmailBouncedDateDefault(){
				
					return null;
				
				}
				public String EmailBouncedDateComment(){
				
				    return "";
				
				}
				public String EmailBouncedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String EmailBouncedDateOriginalDbColumnName(){
				
					return "EmailBouncedDate";
				
				}

				
			    public boolean IsEmailBounced;

				public boolean getIsEmailBounced () {
					return this.IsEmailBounced;
				}

				public Boolean IsEmailBouncedIsNullable(){
				    return false;
				}
				public Boolean IsEmailBouncedIsKey(){
				    return false;
				}
				public Integer IsEmailBouncedLength(){
				    return null;
				}
				public Integer IsEmailBouncedPrecision(){
				    return null;
				}
				public String IsEmailBouncedDefault(){
				
					return null;
				
				}
				public String IsEmailBouncedComment(){
				
				    return "";
				
				}
				public String IsEmailBouncedPattern(){
				
					return "";
				
				}
				public String IsEmailBouncedOriginalDbColumnName(){
				
					return "IsEmailBounced";
				
				}

				
			    public String PhotoUrl;

				public String getPhotoUrl () {
					return this.PhotoUrl;
				}

				public Boolean PhotoUrlIsNullable(){
				    return true;
				}
				public Boolean PhotoUrlIsKey(){
				    return false;
				}
				public Integer PhotoUrlLength(){
				    return 255;
				}
				public Integer PhotoUrlPrecision(){
				    return null;
				}
				public String PhotoUrlDefault(){
				
					return null;
				
				}
				public String PhotoUrlComment(){
				
				    return "";
				
				}
				public String PhotoUrlPattern(){
				
					return "";
				
				}
				public String PhotoUrlOriginalDbColumnName(){
				
					return "PhotoUrl";
				
				}

				
			    public String Jigsaw;

				public String getJigsaw () {
					return this.Jigsaw;
				}

				public Boolean JigsawIsNullable(){
				    return true;
				}
				public Boolean JigsawIsKey(){
				    return false;
				}
				public Integer JigsawLength(){
				    return 20;
				}
				public Integer JigsawPrecision(){
				    return null;
				}
				public String JigsawDefault(){
				
					return null;
				
				}
				public String JigsawComment(){
				
				    return "";
				
				}
				public String JigsawPattern(){
				
					return "";
				
				}
				public String JigsawOriginalDbColumnName(){
				
					return "Jigsaw";
				
				}

				
			    public String JigsawContactId;

				public String getJigsawContactId () {
					return this.JigsawContactId;
				}

				public Boolean JigsawContactIdIsNullable(){
				    return true;
				}
				public Boolean JigsawContactIdIsKey(){
				    return false;
				}
				public Integer JigsawContactIdLength(){
				    return 20;
				}
				public Integer JigsawContactIdPrecision(){
				    return null;
				}
				public String JigsawContactIdDefault(){
				
					return null;
				
				}
				public String JigsawContactIdComment(){
				
				    return "";
				
				}
				public String JigsawContactIdPattern(){
				
					return "";
				
				}
				public String JigsawContactIdOriginalDbColumnName(){
				
					return "JigsawContactId";
				
				}

				
			    public String RL_AccountingMail__c;

				public String getRL_AccountingMail__c () {
					return this.RL_AccountingMail__c;
				}

				public Boolean RL_AccountingMail__cIsNullable(){
				    return true;
				}
				public Boolean RL_AccountingMail__cIsKey(){
				    return false;
				}
				public Integer RL_AccountingMail__cLength(){
				    return 80;
				}
				public Integer RL_AccountingMail__cPrecision(){
				    return null;
				}
				public String RL_AccountingMail__cDefault(){
				
					return null;
				
				}
				public String RL_AccountingMail__cComment(){
				
				    return "";
				
				}
				public String RL_AccountingMail__cPattern(){
				
					return "";
				
				}
				public String RL_AccountingMail__cOriginalDbColumnName(){
				
					return "RL_AccountingMail__c";
				
				}

				
			    public String RL_Agency__c;

				public String getRL_Agency__c () {
					return this.RL_Agency__c;
				}

				public Boolean RL_Agency__cIsNullable(){
				    return true;
				}
				public Boolean RL_Agency__cIsKey(){
				    return false;
				}
				public Integer RL_Agency__cLength(){
				    return 45;
				}
				public Integer RL_Agency__cPrecision(){
				    return null;
				}
				public String RL_Agency__cDefault(){
				
					return null;
				
				}
				public String RL_Agency__cComment(){
				
				    return "";
				
				}
				public String RL_Agency__cPattern(){
				
					return "";
				
				}
				public String RL_Agency__cOriginalDbColumnName(){
				
					return "RL_Agency__c";
				
				}

				
			    public String RL_BankCode__c;

				public String getRL_BankCode__c () {
					return this.RL_BankCode__c;
				}

				public Boolean RL_BankCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankCode__cIsKey(){
				    return false;
				}
				public Integer RL_BankCode__cLength(){
				    return 45;
				}
				public Integer RL_BankCode__cPrecision(){
				    return null;
				}
				public String RL_BankCode__cDefault(){
				
					return null;
				
				}
				public String RL_BankCode__cComment(){
				
				    return "";
				
				}
				public String RL_BankCode__cPattern(){
				
					return "";
				
				}
				public String RL_BankCode__cOriginalDbColumnName(){
				
					return "RL_BankCode__c";
				
				}

				
			    public String RL_BankKey__c;

				public String getRL_BankKey__c () {
					return this.RL_BankKey__c;
				}

				public Boolean RL_BankKey__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankKey__cIsKey(){
				    return false;
				}
				public Integer RL_BankKey__cLength(){
				    return 45;
				}
				public Integer RL_BankKey__cPrecision(){
				    return null;
				}
				public String RL_BankKey__cDefault(){
				
					return null;
				
				}
				public String RL_BankKey__cComment(){
				
				    return "";
				
				}
				public String RL_BankKey__cPattern(){
				
					return "";
				
				}
				public String RL_BankKey__cOriginalDbColumnName(){
				
					return "RL_BankKey__c";
				
				}

				
			    public String RL_BillingCity__c;

				public String getRL_BillingCity__c () {
					return this.RL_BillingCity__c;
				}

				public Boolean RL_BillingCity__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCity__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCity__cLength(){
				    return 45;
				}
				public Integer RL_BillingCity__cPrecision(){
				    return null;
				}
				public String RL_BillingCity__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCity__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCity__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCity__cOriginalDbColumnName(){
				
					return "RL_BillingCity__c";
				
				}

				
			    public String RL_BillingCountry__c;

				public String getRL_BillingCountry__c () {
					return this.RL_BillingCountry__c;
				}

				public Boolean RL_BillingCountry__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCountry__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCountry__cLength(){
				    return 45;
				}
				public Integer RL_BillingCountry__cPrecision(){
				    return null;
				}
				public String RL_BillingCountry__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCountry__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCountry__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCountry__cOriginalDbColumnName(){
				
					return "RL_BillingCountry__c";
				
				}

				
			    public String RL_BillingName__c;

				public String getRL_BillingName__c () {
					return this.RL_BillingName__c;
				}

				public Boolean RL_BillingName__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingName__cIsKey(){
				    return false;
				}
				public Integer RL_BillingName__cLength(){
				    return 45;
				}
				public Integer RL_BillingName__cPrecision(){
				    return null;
				}
				public String RL_BillingName__cDefault(){
				
					return null;
				
				}
				public String RL_BillingName__cComment(){
				
				    return "";
				
				}
				public String RL_BillingName__cPattern(){
				
					return "";
				
				}
				public String RL_BillingName__cOriginalDbColumnName(){
				
					return "RL_BillingName__c";
				
				}

				
			    public String RL_BillingStreetNumber__c;

				public String getRL_BillingStreetNumber__c () {
					return this.RL_BillingStreetNumber__c;
				}

				public Boolean RL_BillingStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_BillingStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreetNumber__cOriginalDbColumnName(){
				
					return "RL_BillingStreetNumber__c";
				
				}

				
			    public String RL_BillingStreet__c;

				public String getRL_BillingStreet__c () {
					return this.RL_BillingStreet__c;
				}

				public Boolean RL_BillingStreet__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreet__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreet__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreet__cPrecision(){
				    return null;
				}
				public String RL_BillingStreet__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreet__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreet__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreet__cOriginalDbColumnName(){
				
					return "RL_BillingStreet__c";
				
				}

				
			    public String RL_BillingTel1__c;

				public String getRL_BillingTel1__c () {
					return this.RL_BillingTel1__c;
				}

				public Boolean RL_BillingTel1__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel1__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel1__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel1__cPrecision(){
				    return null;
				}
				public String RL_BillingTel1__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel1__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel1__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel1__cOriginalDbColumnName(){
				
					return "RL_BillingTel1__c";
				
				}

				
			    public String RL_BillingTel2__c;

				public String getRL_BillingTel2__c () {
					return this.RL_BillingTel2__c;
				}

				public Boolean RL_BillingTel2__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel2__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel2__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel2__cPrecision(){
				    return null;
				}
				public String RL_BillingTel2__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel2__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel2__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel2__cOriginalDbColumnName(){
				
					return "RL_BillingTel2__c";
				
				}

				
			    public String RL_BillingTel3__c;

				public String getRL_BillingTel3__c () {
					return this.RL_BillingTel3__c;
				}

				public Boolean RL_BillingTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel3__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel3__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel3__cPrecision(){
				    return null;
				}
				public String RL_BillingTel3__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel3__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel3__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel3__cOriginalDbColumnName(){
				
					return "RL_BillingTel3__c";
				
				}

				
			    public Double RL_CodeSettlement__c;

				public Double getRL_CodeSettlement__c () {
					return this.RL_CodeSettlement__c;
				}

				public Boolean RL_CodeSettlement__cIsNullable(){
				    return true;
				}
				public Boolean RL_CodeSettlement__cIsKey(){
				    return false;
				}
				public Integer RL_CodeSettlement__cLength(){
				    return 11;
				}
				public Integer RL_CodeSettlement__cPrecision(){
				    return null;
				}
				public String RL_CodeSettlement__cDefault(){
				
					return null;
				
				}
				public String RL_CodeSettlement__cComment(){
				
				    return "";
				
				}
				public String RL_CodeSettlement__cPattern(){
				
					return "";
				
				}
				public String RL_CodeSettlement__cOriginalDbColumnName(){
				
					return "RL_CodeSettlement__c";
				
				}

				
			    public java.util.Date RL_CreatedAt__c;

				public java.util.Date getRL_CreatedAt__c () {
					return this.RL_CreatedAt__c;
				}

				public Boolean RL_CreatedAt__cIsNullable(){
				    return true;
				}
				public Boolean RL_CreatedAt__cIsKey(){
				    return false;
				}
				public Integer RL_CreatedAt__cLength(){
				    return null;
				}
				public Integer RL_CreatedAt__cPrecision(){
				    return null;
				}
				public String RL_CreatedAt__cDefault(){
				
					return null;
				
				}
				public String RL_CreatedAt__cComment(){
				
				    return "";
				
				}
				public String RL_CreatedAt__cPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String RL_CreatedAt__cOriginalDbColumnName(){
				
					return "RL_CreatedAt__c";
				
				}

				
			    public String RL_Email__c;

				public String getRL_Email__c () {
					return this.RL_Email__c;
				}

				public Boolean RL_Email__cIsNullable(){
				    return true;
				}
				public Boolean RL_Email__cIsKey(){
				    return false;
				}
				public Integer RL_Email__cLength(){
				    return 255;
				}
				public Integer RL_Email__cPrecision(){
				    return null;
				}
				public String RL_Email__cDefault(){
				
					return null;
				
				}
				public String RL_Email__cComment(){
				
				    return "";
				
				}
				public String RL_Email__cPattern(){
				
					return "";
				
				}
				public String RL_Email__cOriginalDbColumnName(){
				
					return "RL_Email__c";
				
				}

				
			    public Double RL_ExternalAccountId__c;

				public Double getRL_ExternalAccountId__c () {
					return this.RL_ExternalAccountId__c;
				}

				public Boolean RL_ExternalAccountId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalAccountId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalAccountId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalAccountId__cPrecision(){
				    return null;
				}
				public String RL_ExternalAccountId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalAccountId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalAccountId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalAccountId__cOriginalDbColumnName(){
				
					return "RL_ExternalAccountId__c";
				
				}

				
			    public Integer RL_ExternalId__c;

				public Integer getRL_ExternalId__c () {
					return this.RL_ExternalId__c;
				}

				public Boolean RL_ExternalId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalId__cPrecision(){
				    return null;
				}
				public String RL_ExternalId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalId__cOriginalDbColumnName(){
				
					return "RL_ExternalId__c";
				
				}

				
			    public Double RL_IsActive__c;

				public Double getRL_IsActive__c () {
					return this.RL_IsActive__c;
				}

				public Boolean RL_IsActive__cIsNullable(){
				    return true;
				}
				public Boolean RL_IsActive__cIsKey(){
				    return false;
				}
				public Integer RL_IsActive__cLength(){
				    return 1;
				}
				public Integer RL_IsActive__cPrecision(){
				    return null;
				}
				public String RL_IsActive__cDefault(){
				
					return null;
				
				}
				public String RL_IsActive__cComment(){
				
				    return "";
				
				}
				public String RL_IsActive__cPattern(){
				
					return "";
				
				}
				public String RL_IsActive__cOriginalDbColumnName(){
				
					return "RL_IsActive__c";
				
				}

				
			    public String RL_RecoveryPostalCode__c;

				public String getRL_RecoveryPostalCode__c () {
					return this.RL_RecoveryPostalCode__c;
				}

				public Boolean RL_RecoveryPostalCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_RecoveryPostalCode__cIsKey(){
				    return false;
				}
				public Integer RL_RecoveryPostalCode__cLength(){
				    return 255;
				}
				public Integer RL_RecoveryPostalCode__cPrecision(){
				    return null;
				}
				public String RL_RecoveryPostalCode__cDefault(){
				
					return null;
				
				}
				public String RL_RecoveryPostalCode__cComment(){
				
				    return "";
				
				}
				public String RL_RecoveryPostalCode__cPattern(){
				
					return "";
				
				}
				public String RL_RecoveryPostalCode__cOriginalDbColumnName(){
				
					return "RL_RecoveryPostalCode__c";
				
				}

				
			    public String RL_RemovalStreetNumber__c;

				public String getRL_RemovalStreetNumber__c () {
					return this.RL_RemovalStreetNumber__c;
				}

				public Boolean RL_RemovalStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_RemovalStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_RemovalStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalStreetNumber__cOriginalDbColumnName(){
				
					return "RL_RemovalStreetNumber__c";
				
				}

				
			    public String RL_RemovalTel3__c;

				public String getRL_RemovalTel3__c () {
					return this.RL_RemovalTel3__c;
				}

				public Boolean RL_RemovalTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalTel3__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalTel3__cLength(){
				    return 40;
				}
				public Integer RL_RemovalTel3__cPrecision(){
				    return null;
				}
				public String RL_RemovalTel3__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalTel3__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalTel3__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalTel3__cOriginalDbColumnName(){
				
					return "RL_RemovalTel3__c";
				
				}

				
			    public String Code_Client__c;

				public String getCode_Client__c () {
					return this.Code_Client__c;
				}

				public Boolean Code_Client__cIsNullable(){
				    return true;
				}
				public Boolean Code_Client__cIsKey(){
				    return false;
				}
				public Integer Code_Client__cLength(){
				    return 30;
				}
				public Integer Code_Client__cPrecision(){
				    return null;
				}
				public String Code_Client__cDefault(){
				
					return null;
				
				}
				public String Code_Client__cComment(){
				
				    return "";
				
				}
				public String Code_Client__cPattern(){
				
					return "";
				
				}
				public String Code_Client__cOriginalDbColumnName(){
				
					return "Code_Client__c";
				
				}

				
			    public String Data_Quality_Description__c;

				public String getData_Quality_Description__c () {
					return this.Data_Quality_Description__c;
				}

				public Boolean Data_Quality_Description__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Description__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Description__cLength(){
				    return 1300;
				}
				public Integer Data_Quality_Description__cPrecision(){
				    return null;
				}
				public String Data_Quality_Description__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Description__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Description__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Description__cOriginalDbColumnName(){
				
					return "Data_Quality_Description__c";
				
				}

				
			    public Double Data_Quality_Score__c;

				public Double getData_Quality_Score__c () {
					return this.Data_Quality_Score__c;
				}

				public Boolean Data_Quality_Score__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Score__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Score__cLength(){
				    return 18;
				}
				public Integer Data_Quality_Score__cPrecision(){
				    return null;
				}
				public String Data_Quality_Score__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Score__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Score__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Score__cOriginalDbColumnName(){
				
					return "Data_Quality_Score__c";
				
				}

				
			    public String RL_Company__c;

				public String getRL_Company__c () {
					return this.RL_Company__c;
				}

				public Boolean RL_Company__cIsNullable(){
				    return true;
				}
				public Boolean RL_Company__cIsKey(){
				    return false;
				}
				public Integer RL_Company__cLength(){
				    return 45;
				}
				public Integer RL_Company__cPrecision(){
				    return null;
				}
				public String RL_Company__cDefault(){
				
					return null;
				
				}
				public String RL_Company__cComment(){
				
				    return "";
				
				}
				public String RL_Company__cPattern(){
				
					return "";
				
				}
				public String RL_Company__cOriginalDbColumnName(){
				
					return "RL_Company__c";
				
				}

				
			    public String RL_Removal_iso3_country__c;

				public String getRL_Removal_iso3_country__c () {
					return this.RL_Removal_iso3_country__c;
				}

				public Boolean RL_Removal_iso3_country__cIsNullable(){
				    return true;
				}
				public Boolean RL_Removal_iso3_country__cIsKey(){
				    return false;
				}
				public Integer RL_Removal_iso3_country__cLength(){
				    return 45;
				}
				public Integer RL_Removal_iso3_country__cPrecision(){
				    return null;
				}
				public String RL_Removal_iso3_country__cDefault(){
				
					return null;
				
				}
				public String RL_Removal_iso3_country__cComment(){
				
				    return "";
				
				}
				public String RL_Removal_iso3_country__cPattern(){
				
					return "";
				
				}
				public String RL_Removal_iso3_country__cOriginalDbColumnName(){
				
					return "RL_Removal_iso3_country__c";
				
				}

				
			    public boolean RL_Archived__c;

				public boolean getRL_Archived__c () {
					return this.RL_Archived__c;
				}

				public Boolean RL_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Archived__cLength(){
				    return null;
				}
				public Integer RL_Archived__cPrecision(){
				    return null;
				}
				public String RL_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Archived__cOriginalDbColumnName(){
				
					return "RL_Archived__c";
				
				}

				
			    public boolean RL_Tarification_par_palier__c;

				public boolean getRL_Tarification_par_palier__c () {
					return this.RL_Tarification_par_palier__c;
				}

				public Boolean RL_Tarification_par_palier__cIsNullable(){
				    return false;
				}
				public Boolean RL_Tarification_par_palier__cIsKey(){
				    return false;
				}
				public Integer RL_Tarification_par_palier__cLength(){
				    return null;
				}
				public Integer RL_Tarification_par_palier__cPrecision(){
				    return null;
				}
				public String RL_Tarification_par_palier__cDefault(){
				
					return null;
				
				}
				public String RL_Tarification_par_palier__cComment(){
				
				    return "";
				
				}
				public String RL_Tarification_par_palier__cPattern(){
				
					return "";
				
				}
				public String RL_Tarification_par_palier__cOriginalDbColumnName(){
				
					return "RL_Tarification_par_palier__c";
				
				}

				
			    public String Contact_Commercial__c;

				public String getContact_Commercial__c () {
					return this.Contact_Commercial__c;
				}

				public Boolean Contact_Commercial__cIsNullable(){
				    return true;
				}
				public Boolean Contact_Commercial__cIsKey(){
				    return false;
				}
				public Integer Contact_Commercial__cLength(){
				    return 255;
				}
				public Integer Contact_Commercial__cPrecision(){
				    return null;
				}
				public String Contact_Commercial__cDefault(){
				
					return null;
				
				}
				public String Contact_Commercial__cComment(){
				
				    return "";
				
				}
				public String Contact_Commercial__cPattern(){
				
					return "";
				
				}
				public String Contact_Commercial__cOriginalDbColumnName(){
				
					return "Contact_Commercial__c";
				
				}

				
			    public String SocieteInfo__Id__c;

				public String getSocieteInfo__Id__c () {
					return this.SocieteInfo__Id__c;
				}

				public Boolean SocieteInfo__Id__cIsNullable(){
				    return true;
				}
				public Boolean SocieteInfo__Id__cIsKey(){
				    return false;
				}
				public Integer SocieteInfo__Id__cLength(){
				    return 80;
				}
				public Integer SocieteInfo__Id__cPrecision(){
				    return null;
				}
				public String SocieteInfo__Id__cDefault(){
				
					return null;
				
				}
				public String SocieteInfo__Id__cComment(){
				
				    return "";
				
				}
				public String SocieteInfo__Id__cPattern(){
				
					return "";
				
				}
				public String SocieteInfo__Id__cOriginalDbColumnName(){
				
					return "SocieteInfo__Id__c";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Id == null) ? 0 : this.Id.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.Id == null) {
							if (other.Id != null)
								return false;
						
						} else if (!this.Id.equals(other.Id))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.Id = this.Id;
	            other.IsDeleted = this.IsDeleted;
	            other.MasterRecordId = this.MasterRecordId;
	            other.AccountId = this.AccountId;
	            other.LastName = this.LastName;
	            other.FirstName = this.FirstName;
	            other.Salutation = this.Salutation;
	            other.MiddleName = this.MiddleName;
	            other.Suffix = this.Suffix;
	            other.Name = this.Name;
	            other.RecordTypeId = this.RecordTypeId;
	            other.MailingStreet = this.MailingStreet;
	            other.MailingCity = this.MailingCity;
	            other.MailingState = this.MailingState;
	            other.MailingPostalCode = this.MailingPostalCode;
	            other.MailingCountry = this.MailingCountry;
	            other.MailingLatitude = this.MailingLatitude;
	            other.MailingLongitude = this.MailingLongitude;
	            other.MailingGeocodeAccuracy = this.MailingGeocodeAccuracy;
	            other.MailingAddress = this.MailingAddress;
	            other.Phone = this.Phone;
	            other.Fax = this.Fax;
	            other.MobilePhone = this.MobilePhone;
	            other.ReportsToId = this.ReportsToId;
	            other.Email = this.Email;
	            other.Title = this.Title;
	            other.Department = this.Department;
	            other.OwnerId = this.OwnerId;
	            other.CreatedDate = this.CreatedDate;
	            other.CreatedById = this.CreatedById;
	            other.LastModifiedDate = this.LastModifiedDate;
	            other.LastModifiedById = this.LastModifiedById;
	            other.SystemModstamp = this.SystemModstamp;
	            other.LastActivityDate = this.LastActivityDate;
	            other.LastCURequestDate = this.LastCURequestDate;
	            other.LastCUUpdateDate = this.LastCUUpdateDate;
	            other.LastViewedDate = this.LastViewedDate;
	            other.LastReferencedDate = this.LastReferencedDate;
	            other.EmailBouncedReason = this.EmailBouncedReason;
	            other.EmailBouncedDate = this.EmailBouncedDate;
	            other.IsEmailBounced = this.IsEmailBounced;
	            other.PhotoUrl = this.PhotoUrl;
	            other.Jigsaw = this.Jigsaw;
	            other.JigsawContactId = this.JigsawContactId;
	            other.RL_AccountingMail__c = this.RL_AccountingMail__c;
	            other.RL_Agency__c = this.RL_Agency__c;
	            other.RL_BankCode__c = this.RL_BankCode__c;
	            other.RL_BankKey__c = this.RL_BankKey__c;
	            other.RL_BillingCity__c = this.RL_BillingCity__c;
	            other.RL_BillingCountry__c = this.RL_BillingCountry__c;
	            other.RL_BillingName__c = this.RL_BillingName__c;
	            other.RL_BillingStreetNumber__c = this.RL_BillingStreetNumber__c;
	            other.RL_BillingStreet__c = this.RL_BillingStreet__c;
	            other.RL_BillingTel1__c = this.RL_BillingTel1__c;
	            other.RL_BillingTel2__c = this.RL_BillingTel2__c;
	            other.RL_BillingTel3__c = this.RL_BillingTel3__c;
	            other.RL_CodeSettlement__c = this.RL_CodeSettlement__c;
	            other.RL_CreatedAt__c = this.RL_CreatedAt__c;
	            other.RL_Email__c = this.RL_Email__c;
	            other.RL_ExternalAccountId__c = this.RL_ExternalAccountId__c;
	            other.RL_ExternalId__c = this.RL_ExternalId__c;
	            other.RL_IsActive__c = this.RL_IsActive__c;
	            other.RL_RecoveryPostalCode__c = this.RL_RecoveryPostalCode__c;
	            other.RL_RemovalStreetNumber__c = this.RL_RemovalStreetNumber__c;
	            other.RL_RemovalTel3__c = this.RL_RemovalTel3__c;
	            other.Code_Client__c = this.Code_Client__c;
	            other.Data_Quality_Description__c = this.Data_Quality_Description__c;
	            other.Data_Quality_Score__c = this.Data_Quality_Score__c;
	            other.RL_Company__c = this.RL_Company__c;
	            other.RL_Removal_iso3_country__c = this.RL_Removal_iso3_country__c;
	            other.RL_Archived__c = this.RL_Archived__c;
	            other.RL_Tarification_par_palier__c = this.RL_Tarification_par_palier__c;
	            other.Contact_Commercial__c = this.Contact_Commercial__c;
	            other.SocieteInfo__Id__c = this.SocieteInfo__Id__c;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.Id = this.Id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

	private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller ) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

	private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
	}
	
	private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
	}
	private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		Integer intReturn;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = unmarshaller.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, DataOutputStream dos,org.jboss.marshalling.Marshaller marshaller ) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.IsDeleted = dis.readBoolean();
					
						this.MasterRecordId = readString(dis,ois);
					
						this.AccountId = readString(dis,ois);
					
						this.LastName = readString(dis,ois);
					
						this.FirstName = readString(dis,ois);
					
						this.Salutation = readString(dis,ois);
					
						this.MiddleName = readString(dis,ois);
					
						this.Suffix = readString(dis,ois);
					
						this.Name = readString(dis,ois);
					
						this.RecordTypeId = readString(dis,ois);
					
						this.MailingStreet = readString(dis,ois);
					
						this.MailingCity = readString(dis,ois);
					
						this.MailingState = readString(dis,ois);
					
						this.MailingPostalCode = readString(dis,ois);
					
						this.MailingCountry = readString(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
						this.MailingGeocodeAccuracy = readString(dis,ois);
					
						this.MailingAddress = readString(dis,ois);
					
						this.Phone = readString(dis,ois);
					
						this.Fax = readString(dis,ois);
					
						this.MobilePhone = readString(dis,ois);
					
						this.ReportsToId = readString(dis,ois);
					
						this.Email = readString(dis,ois);
					
						this.Title = readString(dis,ois);
					
						this.Department = readString(dis,ois);
					
						this.OwnerId = readString(dis,ois);
					
						this.CreatedDate = readDate(dis,ois);
					
						this.CreatedById = readString(dis,ois);
					
						this.LastModifiedDate = readDate(dis,ois);
					
						this.LastModifiedById = readString(dis,ois);
					
						this.SystemModstamp = readDate(dis,ois);
					
						this.LastActivityDate = readDate(dis,ois);
					
						this.LastCURequestDate = readDate(dis,ois);
					
						this.LastCUUpdateDate = readDate(dis,ois);
					
						this.LastViewedDate = readDate(dis,ois);
					
						this.LastReferencedDate = readDate(dis,ois);
					
						this.EmailBouncedReason = readString(dis,ois);
					
						this.EmailBouncedDate = readDate(dis,ois);
					
			            this.IsEmailBounced = dis.readBoolean();
					
						this.PhotoUrl = readString(dis,ois);
					
						this.Jigsaw = readString(dis,ois);
					
						this.JigsawContactId = readString(dis,ois);
					
						this.RL_AccountingMail__c = readString(dis,ois);
					
						this.RL_Agency__c = readString(dis,ois);
					
						this.RL_BankCode__c = readString(dis,ois);
					
						this.RL_BankKey__c = readString(dis,ois);
					
						this.RL_BillingCity__c = readString(dis,ois);
					
						this.RL_BillingCountry__c = readString(dis,ois);
					
						this.RL_BillingName__c = readString(dis,ois);
					
						this.RL_BillingStreetNumber__c = readString(dis,ois);
					
						this.RL_BillingStreet__c = readString(dis,ois);
					
						this.RL_BillingTel1__c = readString(dis,ois);
					
						this.RL_BillingTel2__c = readString(dis,ois);
					
						this.RL_BillingTel3__c = readString(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
						this.RL_CreatedAt__c = readDate(dis,ois);
					
						this.RL_Email__c = readString(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
						this.RL_RecoveryPostalCode__c = readString(dis,ois);
					
						this.RL_RemovalStreetNumber__c = readString(dis,ois);
					
						this.RL_RemovalTel3__c = readString(dis,ois);
					
						this.Code_Client__c = readString(dis,ois);
					
						this.Data_Quality_Description__c = readString(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
						this.RL_Company__c = readString(dis,ois);
					
						this.RL_Removal_iso3_country__c = readString(dis,ois);
					
			            this.RL_Archived__c = dis.readBoolean();
					
			            this.RL_Tarification_par_palier__c = dis.readBoolean();
					
						this.Contact_Commercial__c = readString(dis,ois);
					
						this.SocieteInfo__Id__c = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.IsDeleted = objectIn.readBoolean();
					
						this.MasterRecordId = readString(dis,objectIn);
					
						this.AccountId = readString(dis,objectIn);
					
						this.LastName = readString(dis,objectIn);
					
						this.FirstName = readString(dis,objectIn);
					
						this.Salutation = readString(dis,objectIn);
					
						this.MiddleName = readString(dis,objectIn);
					
						this.Suffix = readString(dis,objectIn);
					
						this.Name = readString(dis,objectIn);
					
						this.RecordTypeId = readString(dis,objectIn);
					
						this.MailingStreet = readString(dis,objectIn);
					
						this.MailingCity = readString(dis,objectIn);
					
						this.MailingState = readString(dis,objectIn);
					
						this.MailingPostalCode = readString(dis,objectIn);
					
						this.MailingCountry = readString(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = objectIn.readDouble();
           				}
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = objectIn.readDouble();
           				}
					
						this.MailingGeocodeAccuracy = readString(dis,objectIn);
					
						this.MailingAddress = readString(dis,objectIn);
					
						this.Phone = readString(dis,objectIn);
					
						this.Fax = readString(dis,objectIn);
					
						this.MobilePhone = readString(dis,objectIn);
					
						this.ReportsToId = readString(dis,objectIn);
					
						this.Email = readString(dis,objectIn);
					
						this.Title = readString(dis,objectIn);
					
						this.Department = readString(dis,objectIn);
					
						this.OwnerId = readString(dis,objectIn);
					
						this.CreatedDate = readDate(dis,objectIn);
					
						this.CreatedById = readString(dis,objectIn);
					
						this.LastModifiedDate = readDate(dis,objectIn);
					
						this.LastModifiedById = readString(dis,objectIn);
					
						this.SystemModstamp = readDate(dis,objectIn);
					
						this.LastActivityDate = readDate(dis,objectIn);
					
						this.LastCURequestDate = readDate(dis,objectIn);
					
						this.LastCUUpdateDate = readDate(dis,objectIn);
					
						this.LastViewedDate = readDate(dis,objectIn);
					
						this.LastReferencedDate = readDate(dis,objectIn);
					
						this.EmailBouncedReason = readString(dis,objectIn);
					
						this.EmailBouncedDate = readDate(dis,objectIn);
					
			            this.IsEmailBounced = objectIn.readBoolean();
					
						this.PhotoUrl = readString(dis,objectIn);
					
						this.Jigsaw = readString(dis,objectIn);
					
						this.JigsawContactId = readString(dis,objectIn);
					
						this.RL_AccountingMail__c = readString(dis,objectIn);
					
						this.RL_Agency__c = readString(dis,objectIn);
					
						this.RL_BankCode__c = readString(dis,objectIn);
					
						this.RL_BankKey__c = readString(dis,objectIn);
					
						this.RL_BillingCity__c = readString(dis,objectIn);
					
						this.RL_BillingCountry__c = readString(dis,objectIn);
					
						this.RL_BillingName__c = readString(dis,objectIn);
					
						this.RL_BillingStreetNumber__c = readString(dis,objectIn);
					
						this.RL_BillingStreet__c = readString(dis,objectIn);
					
						this.RL_BillingTel1__c = readString(dis,objectIn);
					
						this.RL_BillingTel2__c = readString(dis,objectIn);
					
						this.RL_BillingTel3__c = readString(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = objectIn.readDouble();
           				}
					
						this.RL_CreatedAt__c = readDate(dis,objectIn);
					
						this.RL_Email__c = readString(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = objectIn.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = objectIn.readDouble();
           				}
					
						this.RL_RecoveryPostalCode__c = readString(dis,objectIn);
					
						this.RL_RemovalStreetNumber__c = readString(dis,objectIn);
					
						this.RL_RemovalTel3__c = readString(dis,objectIn);
					
						this.Code_Client__c = readString(dis,objectIn);
					
						this.Data_Quality_Description__c = readString(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = objectIn.readDouble();
           				}
					
						this.RL_Company__c = readString(dis,objectIn);
					
						this.RL_Removal_iso3_country__c = readString(dis,objectIn);
					
			            this.RL_Archived__c = objectIn.readBoolean();
					
			            this.RL_Tarification_par_palier__c = objectIn.readBoolean();
					
						this.Contact_Commercial__c = readString(dis,objectIn);
					
						this.SocieteInfo__Id__c = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeBoolean(this.IsDeleted);
					
						writeString(this.MasterRecordId, dos, oos);
					
						writeString(this.AccountId, dos, oos);
					
						writeString(this.LastName, dos, oos);
					
						writeString(this.FirstName, dos, oos);
					
						writeString(this.Salutation, dos, oos);
					
						writeString(this.MiddleName, dos, oos);
					
						writeString(this.Suffix, dos, oos);
					
						writeString(this.Name, dos, oos);
					
						writeString(this.RecordTypeId, dos, oos);
					
						writeString(this.MailingStreet, dos, oos);
					
						writeString(this.MailingCity, dos, oos);
					
						writeString(this.MailingState, dos, oos);
					
						writeString(this.MailingPostalCode, dos, oos);
					
						writeString(this.MailingCountry, dos, oos);
					
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
						writeString(this.MailingGeocodeAccuracy, dos, oos);
					
						writeString(this.MailingAddress, dos, oos);
					
						writeString(this.Phone, dos, oos);
					
						writeString(this.Fax, dos, oos);
					
						writeString(this.MobilePhone, dos, oos);
					
						writeString(this.ReportsToId, dos, oos);
					
						writeString(this.Email, dos, oos);
					
						writeString(this.Title, dos, oos);
					
						writeString(this.Department, dos, oos);
					
						writeString(this.OwnerId, dos, oos);
					
						writeDate(this.CreatedDate, dos, oos);
					
						writeString(this.CreatedById, dos, oos);
					
						writeDate(this.LastModifiedDate, dos, oos);
					
						writeString(this.LastModifiedById, dos, oos);
					
						writeDate(this.SystemModstamp, dos, oos);
					
						writeDate(this.LastActivityDate, dos, oos);
					
						writeDate(this.LastCURequestDate, dos, oos);
					
						writeDate(this.LastCUUpdateDate, dos, oos);
					
						writeDate(this.LastViewedDate, dos, oos);
					
						writeDate(this.LastReferencedDate, dos, oos);
					
						writeString(this.EmailBouncedReason, dos, oos);
					
						writeDate(this.EmailBouncedDate, dos, oos);
					
		            	dos.writeBoolean(this.IsEmailBounced);
					
						writeString(this.PhotoUrl, dos, oos);
					
						writeString(this.Jigsaw, dos, oos);
					
						writeString(this.JigsawContactId, dos, oos);
					
						writeString(this.RL_AccountingMail__c, dos, oos);
					
						writeString(this.RL_Agency__c, dos, oos);
					
						writeString(this.RL_BankCode__c, dos, oos);
					
						writeString(this.RL_BankKey__c, dos, oos);
					
						writeString(this.RL_BillingCity__c, dos, oos);
					
						writeString(this.RL_BillingCountry__c, dos, oos);
					
						writeString(this.RL_BillingName__c, dos, oos);
					
						writeString(this.RL_BillingStreetNumber__c, dos, oos);
					
						writeString(this.RL_BillingStreet__c, dos, oos);
					
						writeString(this.RL_BillingTel1__c, dos, oos);
					
						writeString(this.RL_BillingTel2__c, dos, oos);
					
						writeString(this.RL_BillingTel3__c, dos, oos);
					
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
						writeDate(this.RL_CreatedAt__c, dos, oos);
					
						writeString(this.RL_Email__c, dos, oos);
					
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					writeInteger(this.RL_ExternalId__c, dos, oos);
					
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
						writeString(this.RL_RecoveryPostalCode__c, dos, oos);
					
						writeString(this.RL_RemovalStreetNumber__c, dos, oos);
					
						writeString(this.RL_RemovalTel3__c, dos, oos);
					
						writeString(this.Code_Client__c, dos, oos);
					
						writeString(this.Data_Quality_Description__c, dos, oos);
					
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
						writeString(this.RL_Company__c, dos, oos);
					
						writeString(this.RL_Removal_iso3_country__c, dos, oos);
					
		            	dos.writeBoolean(this.RL_Archived__c);
					
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
						writeString(this.Contact_Commercial__c, dos, oos);
					
						writeString(this.SocieteInfo__Id__c, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeBoolean(this.IsDeleted);
					
						writeString(this.MasterRecordId, dos, objectOut);
					
						writeString(this.AccountId, dos, objectOut);
					
						writeString(this.LastName, dos, objectOut);
					
						writeString(this.FirstName, dos, objectOut);
					
						writeString(this.Salutation, dos, objectOut);
					
						writeString(this.MiddleName, dos, objectOut);
					
						writeString(this.Suffix, dos, objectOut);
					
						writeString(this.Name, dos, objectOut);
					
						writeString(this.RecordTypeId, dos, objectOut);
					
						writeString(this.MailingStreet, dos, objectOut);
					
						writeString(this.MailingCity, dos, objectOut);
					
						writeString(this.MailingState, dos, objectOut);
					
						writeString(this.MailingPostalCode, dos, objectOut);
					
						writeString(this.MailingCountry, dos, objectOut);
					
						if(this.MailingLatitude == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.MailingLatitude);
		            	}
					
						if(this.MailingLongitude == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.MailingLongitude);
		            	}
					
						writeString(this.MailingGeocodeAccuracy, dos, objectOut);
					
						writeString(this.MailingAddress, dos, objectOut);
					
						writeString(this.Phone, dos, objectOut);
					
						writeString(this.Fax, dos, objectOut);
					
						writeString(this.MobilePhone, dos, objectOut);
					
						writeString(this.ReportsToId, dos, objectOut);
					
						writeString(this.Email, dos, objectOut);
					
						writeString(this.Title, dos, objectOut);
					
						writeString(this.Department, dos, objectOut);
					
						writeString(this.OwnerId, dos, objectOut);
					
						writeDate(this.CreatedDate, dos, objectOut);
					
						writeString(this.CreatedById, dos, objectOut);
					
						writeDate(this.LastModifiedDate, dos, objectOut);
					
						writeString(this.LastModifiedById, dos, objectOut);
					
						writeDate(this.SystemModstamp, dos, objectOut);
					
						writeDate(this.LastActivityDate, dos, objectOut);
					
						writeDate(this.LastCURequestDate, dos, objectOut);
					
						writeDate(this.LastCUUpdateDate, dos, objectOut);
					
						writeDate(this.LastViewedDate, dos, objectOut);
					
						writeDate(this.LastReferencedDate, dos, objectOut);
					
						writeString(this.EmailBouncedReason, dos, objectOut);
					
						writeDate(this.EmailBouncedDate, dos, objectOut);
					
					objectOut.writeBoolean(this.IsEmailBounced);
					
						writeString(this.PhotoUrl, dos, objectOut);
					
						writeString(this.Jigsaw, dos, objectOut);
					
						writeString(this.JigsawContactId, dos, objectOut);
					
						writeString(this.RL_AccountingMail__c, dos, objectOut);
					
						writeString(this.RL_Agency__c, dos, objectOut);
					
						writeString(this.RL_BankCode__c, dos, objectOut);
					
						writeString(this.RL_BankKey__c, dos, objectOut);
					
						writeString(this.RL_BillingCity__c, dos, objectOut);
					
						writeString(this.RL_BillingCountry__c, dos, objectOut);
					
						writeString(this.RL_BillingName__c, dos, objectOut);
					
						writeString(this.RL_BillingStreetNumber__c, dos, objectOut);
					
						writeString(this.RL_BillingStreet__c, dos, objectOut);
					
						writeString(this.RL_BillingTel1__c, dos, objectOut);
					
						writeString(this.RL_BillingTel2__c, dos, objectOut);
					
						writeString(this.RL_BillingTel3__c, dos, objectOut);
					
						if(this.RL_CodeSettlement__c == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
						writeDate(this.RL_CreatedAt__c, dos, objectOut);
					
						writeString(this.RL_Email__c, dos, objectOut);
					
						if(this.RL_ExternalAccountId__c == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					writeInteger(this.RL_ExternalId__c, dos, objectOut);
					
						if(this.RL_IsActive__c == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.RL_IsActive__c);
		            	}
					
						writeString(this.RL_RecoveryPostalCode__c, dos, objectOut);
					
						writeString(this.RL_RemovalStreetNumber__c, dos, objectOut);
					
						writeString(this.RL_RemovalTel3__c, dos, objectOut);
					
						writeString(this.Code_Client__c, dos, objectOut);
					
						writeString(this.Data_Quality_Description__c, dos, objectOut);
					
						if(this.Data_Quality_Score__c == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.Data_Quality_Score__c);
		            	}
					
						writeString(this.RL_Company__c, dos, objectOut);
					
						writeString(this.RL_Removal_iso3_country__c, dos, objectOut);
					
					objectOut.writeBoolean(this.RL_Archived__c);
					
					objectOut.writeBoolean(this.RL_Tarification_par_palier__c);
					
						writeString(this.Contact_Commercial__c, dos, objectOut);
					
						writeString(this.SocieteInfo__Id__c, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",MasterRecordId="+MasterRecordId);
		sb.append(",AccountId="+AccountId);
		sb.append(",LastName="+LastName);
		sb.append(",FirstName="+FirstName);
		sb.append(",Salutation="+Salutation);
		sb.append(",MiddleName="+MiddleName);
		sb.append(",Suffix="+Suffix);
		sb.append(",Name="+Name);
		sb.append(",RecordTypeId="+RecordTypeId);
		sb.append(",MailingStreet="+MailingStreet);
		sb.append(",MailingCity="+MailingCity);
		sb.append(",MailingState="+MailingState);
		sb.append(",MailingPostalCode="+MailingPostalCode);
		sb.append(",MailingCountry="+MailingCountry);
		sb.append(",MailingLatitude="+String.valueOf(MailingLatitude));
		sb.append(",MailingLongitude="+String.valueOf(MailingLongitude));
		sb.append(",MailingGeocodeAccuracy="+MailingGeocodeAccuracy);
		sb.append(",MailingAddress="+MailingAddress);
		sb.append(",Phone="+Phone);
		sb.append(",Fax="+Fax);
		sb.append(",MobilePhone="+MobilePhone);
		sb.append(",ReportsToId="+ReportsToId);
		sb.append(",Email="+Email);
		sb.append(",Title="+Title);
		sb.append(",Department="+Department);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastActivityDate="+String.valueOf(LastActivityDate));
		sb.append(",LastCURequestDate="+String.valueOf(LastCURequestDate));
		sb.append(",LastCUUpdateDate="+String.valueOf(LastCUUpdateDate));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",EmailBouncedReason="+EmailBouncedReason);
		sb.append(",EmailBouncedDate="+String.valueOf(EmailBouncedDate));
		sb.append(",IsEmailBounced="+String.valueOf(IsEmailBounced));
		sb.append(",PhotoUrl="+PhotoUrl);
		sb.append(",Jigsaw="+Jigsaw);
		sb.append(",JigsawContactId="+JigsawContactId);
		sb.append(",RL_AccountingMail__c="+RL_AccountingMail__c);
		sb.append(",RL_Agency__c="+RL_Agency__c);
		sb.append(",RL_BankCode__c="+RL_BankCode__c);
		sb.append(",RL_BankKey__c="+RL_BankKey__c);
		sb.append(",RL_BillingCity__c="+RL_BillingCity__c);
		sb.append(",RL_BillingCountry__c="+RL_BillingCountry__c);
		sb.append(",RL_BillingName__c="+RL_BillingName__c);
		sb.append(",RL_BillingStreetNumber__c="+RL_BillingStreetNumber__c);
		sb.append(",RL_BillingStreet__c="+RL_BillingStreet__c);
		sb.append(",RL_BillingTel1__c="+RL_BillingTel1__c);
		sb.append(",RL_BillingTel2__c="+RL_BillingTel2__c);
		sb.append(",RL_BillingTel3__c="+RL_BillingTel3__c);
		sb.append(",RL_CodeSettlement__c="+String.valueOf(RL_CodeSettlement__c));
		sb.append(",RL_CreatedAt__c="+String.valueOf(RL_CreatedAt__c));
		sb.append(",RL_Email__c="+RL_Email__c);
		sb.append(",RL_ExternalAccountId__c="+String.valueOf(RL_ExternalAccountId__c));
		sb.append(",RL_ExternalId__c="+String.valueOf(RL_ExternalId__c));
		sb.append(",RL_IsActive__c="+String.valueOf(RL_IsActive__c));
		sb.append(",RL_RecoveryPostalCode__c="+RL_RecoveryPostalCode__c);
		sb.append(",RL_RemovalStreetNumber__c="+RL_RemovalStreetNumber__c);
		sb.append(",RL_RemovalTel3__c="+RL_RemovalTel3__c);
		sb.append(",Code_Client__c="+Code_Client__c);
		sb.append(",Data_Quality_Description__c="+Data_Quality_Description__c);
		sb.append(",Data_Quality_Score__c="+String.valueOf(Data_Quality_Score__c));
		sb.append(",RL_Company__c="+RL_Company__c);
		sb.append(",RL_Removal_iso3_country__c="+RL_Removal_iso3_country__c);
		sb.append(",RL_Archived__c="+String.valueOf(RL_Archived__c));
		sb.append(",RL_Tarification_par_palier__c="+String.valueOf(RL_Tarification_par_palier__c));
		sb.append(",Contact_Commercial__c="+Contact_Commercial__c);
		sb.append(",SocieteInfo__Id__c="+SocieteInfo__Id__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(MasterRecordId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MasterRecordId);
            			}
            		
        			sb.append("|");
        		
        				if(AccountId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccountId);
            			}
            		
        			sb.append("|");
        		
        				if(LastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastName);
            			}
            		
        			sb.append("|");
        		
        				if(FirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FirstName);
            			}
            		
        			sb.append("|");
        		
        				if(Salutation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Salutation);
            			}
            		
        			sb.append("|");
        		
        				if(MiddleName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MiddleName);
            			}
            		
        			sb.append("|");
        		
        				if(Suffix == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Suffix);
            			}
            		
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(RecordTypeId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RecordTypeId);
            			}
            		
        			sb.append("|");
        		
        				if(MailingStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingStreet);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCity);
            			}
            		
        			sb.append("|");
        		
        				if(MailingState == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingState);
            			}
            		
        			sb.append("|");
        		
        				if(MailingPostalCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingPostalCode);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCountry);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLatitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLatitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLongitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLongitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingGeocodeAccuracy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingGeocodeAccuracy);
            			}
            		
        			sb.append("|");
        		
        				if(MailingAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingAddress);
            			}
            		
        			sb.append("|");
        		
        				if(Phone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Phone);
            			}
            		
        			sb.append("|");
        		
        				if(Fax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Fax);
            			}
            		
        			sb.append("|");
        		
        				if(MobilePhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MobilePhone);
            			}
            		
        			sb.append("|");
        		
        				if(ReportsToId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ReportsToId);
            			}
            		
        			sb.append("|");
        		
        				if(Email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Email);
            			}
            		
        			sb.append("|");
        		
        				if(Title == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Title);
            			}
            		
        			sb.append("|");
        		
        				if(Department == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Department);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastActivityDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastActivityDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCURequestDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCURequestDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCUUpdateDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCUUpdateDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedReason);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsEmailBounced);
        			
        			sb.append("|");
        		
        				if(PhotoUrl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoUrl);
            			}
            		
        			sb.append("|");
        		
        				if(Jigsaw == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jigsaw);
            			}
            		
        			sb.append("|");
        		
        				if(JigsawContactId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JigsawContactId);
            			}
            		
        			sb.append("|");
        		
        				if(RL_AccountingMail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_AccountingMail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Agency__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Agency__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankKey__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankKey__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCountry__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCountry__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingName__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingName__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreet__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreet__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel1__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel1__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel2__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel2__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CodeSettlement__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CodeSettlement__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CreatedAt__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CreatedAt__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Email__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Email__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalAccountId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalAccountId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_IsActive__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_IsActive__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RecoveryPostalCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RecoveryPostalCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(Code_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Description__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Description__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Score__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Score__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Company__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Company__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Removal_iso3_country__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Removal_iso3_country__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Archived__c);
        			
        			sb.append("|");
        		
        				sb.append(RL_Tarification_par_palier__c);
        			
        			sb.append("|");
        		
        				if(Contact_Commercial__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact_Commercial__c);
            			}
            		
        			sb.append("|");
        		
        				if(SocieteInfo__Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SocieteInfo__Id__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Id, other.Id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String MasterRecordId;

				public String getMasterRecordId () {
					return this.MasterRecordId;
				}

				public Boolean MasterRecordIdIsNullable(){
				    return true;
				}
				public Boolean MasterRecordIdIsKey(){
				    return false;
				}
				public Integer MasterRecordIdLength(){
				    return 18;
				}
				public Integer MasterRecordIdPrecision(){
				    return null;
				}
				public String MasterRecordIdDefault(){
				
					return null;
				
				}
				public String MasterRecordIdComment(){
				
				    return "";
				
				}
				public String MasterRecordIdPattern(){
				
					return "";
				
				}
				public String MasterRecordIdOriginalDbColumnName(){
				
					return "MasterRecordId";
				
				}

				
			    public String AccountId;

				public String getAccountId () {
					return this.AccountId;
				}

				public Boolean AccountIdIsNullable(){
				    return true;
				}
				public Boolean AccountIdIsKey(){
				    return false;
				}
				public Integer AccountIdLength(){
				    return 18;
				}
				public Integer AccountIdPrecision(){
				    return null;
				}
				public String AccountIdDefault(){
				
					return null;
				
				}
				public String AccountIdComment(){
				
				    return "";
				
				}
				public String AccountIdPattern(){
				
					return "";
				
				}
				public String AccountIdOriginalDbColumnName(){
				
					return "AccountId";
				
				}

				
			    public String LastName;

				public String getLastName () {
					return this.LastName;
				}

				public Boolean LastNameIsNullable(){
				    return false;
				}
				public Boolean LastNameIsKey(){
				    return false;
				}
				public Integer LastNameLength(){
				    return 80;
				}
				public Integer LastNamePrecision(){
				    return null;
				}
				public String LastNameDefault(){
				
					return null;
				
				}
				public String LastNameComment(){
				
				    return "";
				
				}
				public String LastNamePattern(){
				
					return "";
				
				}
				public String LastNameOriginalDbColumnName(){
				
					return "LastName";
				
				}

				
			    public String FirstName;

				public String getFirstName () {
					return this.FirstName;
				}

				public Boolean FirstNameIsNullable(){
				    return true;
				}
				public Boolean FirstNameIsKey(){
				    return false;
				}
				public Integer FirstNameLength(){
				    return 40;
				}
				public Integer FirstNamePrecision(){
				    return null;
				}
				public String FirstNameDefault(){
				
					return null;
				
				}
				public String FirstNameComment(){
				
				    return "";
				
				}
				public String FirstNamePattern(){
				
					return "";
				
				}
				public String FirstNameOriginalDbColumnName(){
				
					return "FirstName";
				
				}

				
			    public String Salutation;

				public String getSalutation () {
					return this.Salutation;
				}

				public Boolean SalutationIsNullable(){
				    return true;
				}
				public Boolean SalutationIsKey(){
				    return false;
				}
				public Integer SalutationLength(){
				    return 40;
				}
				public Integer SalutationPrecision(){
				    return null;
				}
				public String SalutationDefault(){
				
					return null;
				
				}
				public String SalutationComment(){
				
				    return "";
				
				}
				public String SalutationPattern(){
				
					return "";
				
				}
				public String SalutationOriginalDbColumnName(){
				
					return "Salutation";
				
				}

				
			    public String MiddleName;

				public String getMiddleName () {
					return this.MiddleName;
				}

				public Boolean MiddleNameIsNullable(){
				    return true;
				}
				public Boolean MiddleNameIsKey(){
				    return false;
				}
				public Integer MiddleNameLength(){
				    return 40;
				}
				public Integer MiddleNamePrecision(){
				    return null;
				}
				public String MiddleNameDefault(){
				
					return null;
				
				}
				public String MiddleNameComment(){
				
				    return "";
				
				}
				public String MiddleNamePattern(){
				
					return "";
				
				}
				public String MiddleNameOriginalDbColumnName(){
				
					return "MiddleName";
				
				}

				
			    public String Suffix;

				public String getSuffix () {
					return this.Suffix;
				}

				public Boolean SuffixIsNullable(){
				    return true;
				}
				public Boolean SuffixIsKey(){
				    return false;
				}
				public Integer SuffixLength(){
				    return 40;
				}
				public Integer SuffixPrecision(){
				    return null;
				}
				public String SuffixDefault(){
				
					return null;
				
				}
				public String SuffixComment(){
				
				    return "";
				
				}
				public String SuffixPattern(){
				
					return "";
				
				}
				public String SuffixOriginalDbColumnName(){
				
					return "Suffix";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return false;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 121;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String RecordTypeId;

				public String getRecordTypeId () {
					return this.RecordTypeId;
				}

				public Boolean RecordTypeIdIsNullable(){
				    return true;
				}
				public Boolean RecordTypeIdIsKey(){
				    return false;
				}
				public Integer RecordTypeIdLength(){
				    return 18;
				}
				public Integer RecordTypeIdPrecision(){
				    return null;
				}
				public String RecordTypeIdDefault(){
				
					return null;
				
				}
				public String RecordTypeIdComment(){
				
				    return "";
				
				}
				public String RecordTypeIdPattern(){
				
					return "";
				
				}
				public String RecordTypeIdOriginalDbColumnName(){
				
					return "RecordTypeId";
				
				}

				
			    public String MailingStreet;

				public String getMailingStreet () {
					return this.MailingStreet;
				}

				public Boolean MailingStreetIsNullable(){
				    return true;
				}
				public Boolean MailingStreetIsKey(){
				    return false;
				}
				public Integer MailingStreetLength(){
				    return 255;
				}
				public Integer MailingStreetPrecision(){
				    return null;
				}
				public String MailingStreetDefault(){
				
					return null;
				
				}
				public String MailingStreetComment(){
				
				    return "";
				
				}
				public String MailingStreetPattern(){
				
					return "";
				
				}
				public String MailingStreetOriginalDbColumnName(){
				
					return "MailingStreet";
				
				}

				
			    public String MailingCity;

				public String getMailingCity () {
					return this.MailingCity;
				}

				public Boolean MailingCityIsNullable(){
				    return true;
				}
				public Boolean MailingCityIsKey(){
				    return false;
				}
				public Integer MailingCityLength(){
				    return 40;
				}
				public Integer MailingCityPrecision(){
				    return null;
				}
				public String MailingCityDefault(){
				
					return null;
				
				}
				public String MailingCityComment(){
				
				    return "";
				
				}
				public String MailingCityPattern(){
				
					return "";
				
				}
				public String MailingCityOriginalDbColumnName(){
				
					return "MailingCity";
				
				}

				
			    public String MailingState;

				public String getMailingState () {
					return this.MailingState;
				}

				public Boolean MailingStateIsNullable(){
				    return true;
				}
				public Boolean MailingStateIsKey(){
				    return false;
				}
				public Integer MailingStateLength(){
				    return 80;
				}
				public Integer MailingStatePrecision(){
				    return null;
				}
				public String MailingStateDefault(){
				
					return null;
				
				}
				public String MailingStateComment(){
				
				    return "";
				
				}
				public String MailingStatePattern(){
				
					return "";
				
				}
				public String MailingStateOriginalDbColumnName(){
				
					return "MailingState";
				
				}

				
			    public String MailingPostalCode;

				public String getMailingPostalCode () {
					return this.MailingPostalCode;
				}

				public Boolean MailingPostalCodeIsNullable(){
				    return true;
				}
				public Boolean MailingPostalCodeIsKey(){
				    return false;
				}
				public Integer MailingPostalCodeLength(){
				    return 20;
				}
				public Integer MailingPostalCodePrecision(){
				    return null;
				}
				public String MailingPostalCodeDefault(){
				
					return null;
				
				}
				public String MailingPostalCodeComment(){
				
				    return "";
				
				}
				public String MailingPostalCodePattern(){
				
					return "";
				
				}
				public String MailingPostalCodeOriginalDbColumnName(){
				
					return "MailingPostalCode";
				
				}

				
			    public String MailingCountry;

				public String getMailingCountry () {
					return this.MailingCountry;
				}

				public Boolean MailingCountryIsNullable(){
				    return true;
				}
				public Boolean MailingCountryIsKey(){
				    return false;
				}
				public Integer MailingCountryLength(){
				    return 80;
				}
				public Integer MailingCountryPrecision(){
				    return null;
				}
				public String MailingCountryDefault(){
				
					return null;
				
				}
				public String MailingCountryComment(){
				
				    return "";
				
				}
				public String MailingCountryPattern(){
				
					return "";
				
				}
				public String MailingCountryOriginalDbColumnName(){
				
					return "MailingCountry";
				
				}

				
			    public Double MailingLatitude;

				public Double getMailingLatitude () {
					return this.MailingLatitude;
				}

				public Boolean MailingLatitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLatitudeIsKey(){
				    return false;
				}
				public Integer MailingLatitudeLength(){
				    return 18;
				}
				public Integer MailingLatitudePrecision(){
				    return 15;
				}
				public String MailingLatitudeDefault(){
				
					return null;
				
				}
				public String MailingLatitudeComment(){
				
				    return "";
				
				}
				public String MailingLatitudePattern(){
				
					return "";
				
				}
				public String MailingLatitudeOriginalDbColumnName(){
				
					return "MailingLatitude";
				
				}

				
			    public Double MailingLongitude;

				public Double getMailingLongitude () {
					return this.MailingLongitude;
				}

				public Boolean MailingLongitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLongitudeIsKey(){
				    return false;
				}
				public Integer MailingLongitudeLength(){
				    return 18;
				}
				public Integer MailingLongitudePrecision(){
				    return 15;
				}
				public String MailingLongitudeDefault(){
				
					return null;
				
				}
				public String MailingLongitudeComment(){
				
				    return "";
				
				}
				public String MailingLongitudePattern(){
				
					return "";
				
				}
				public String MailingLongitudeOriginalDbColumnName(){
				
					return "MailingLongitude";
				
				}

				
			    public String MailingGeocodeAccuracy;

				public String getMailingGeocodeAccuracy () {
					return this.MailingGeocodeAccuracy;
				}

				public Boolean MailingGeocodeAccuracyIsNullable(){
				    return true;
				}
				public Boolean MailingGeocodeAccuracyIsKey(){
				    return false;
				}
				public Integer MailingGeocodeAccuracyLength(){
				    return 40;
				}
				public Integer MailingGeocodeAccuracyPrecision(){
				    return null;
				}
				public String MailingGeocodeAccuracyDefault(){
				
					return null;
				
				}
				public String MailingGeocodeAccuracyComment(){
				
				    return "";
				
				}
				public String MailingGeocodeAccuracyPattern(){
				
					return "";
				
				}
				public String MailingGeocodeAccuracyOriginalDbColumnName(){
				
					return "MailingGeocodeAccuracy";
				
				}

				
			    public String MailingAddress;

				public String getMailingAddress () {
					return this.MailingAddress;
				}

				public Boolean MailingAddressIsNullable(){
				    return true;
				}
				public Boolean MailingAddressIsKey(){
				    return false;
				}
				public Integer MailingAddressLength(){
				    return null;
				}
				public Integer MailingAddressPrecision(){
				    return null;
				}
				public String MailingAddressDefault(){
				
					return null;
				
				}
				public String MailingAddressComment(){
				
				    return "";
				
				}
				public String MailingAddressPattern(){
				
					return "";
				
				}
				public String MailingAddressOriginalDbColumnName(){
				
					return "MailingAddress";
				
				}

				
			    public String Phone;

				public String getPhone () {
					return this.Phone;
				}

				public Boolean PhoneIsNullable(){
				    return true;
				}
				public Boolean PhoneIsKey(){
				    return false;
				}
				public Integer PhoneLength(){
				    return 40;
				}
				public Integer PhonePrecision(){
				    return null;
				}
				public String PhoneDefault(){
				
					return null;
				
				}
				public String PhoneComment(){
				
				    return "";
				
				}
				public String PhonePattern(){
				
					return "";
				
				}
				public String PhoneOriginalDbColumnName(){
				
					return "Phone";
				
				}

				
			    public String Fax;

				public String getFax () {
					return this.Fax;
				}

				public Boolean FaxIsNullable(){
				    return true;
				}
				public Boolean FaxIsKey(){
				    return false;
				}
				public Integer FaxLength(){
				    return 40;
				}
				public Integer FaxPrecision(){
				    return null;
				}
				public String FaxDefault(){
				
					return null;
				
				}
				public String FaxComment(){
				
				    return "";
				
				}
				public String FaxPattern(){
				
					return "";
				
				}
				public String FaxOriginalDbColumnName(){
				
					return "Fax";
				
				}

				
			    public String MobilePhone;

				public String getMobilePhone () {
					return this.MobilePhone;
				}

				public Boolean MobilePhoneIsNullable(){
				    return true;
				}
				public Boolean MobilePhoneIsKey(){
				    return false;
				}
				public Integer MobilePhoneLength(){
				    return 40;
				}
				public Integer MobilePhonePrecision(){
				    return null;
				}
				public String MobilePhoneDefault(){
				
					return null;
				
				}
				public String MobilePhoneComment(){
				
				    return "";
				
				}
				public String MobilePhonePattern(){
				
					return "";
				
				}
				public String MobilePhoneOriginalDbColumnName(){
				
					return "MobilePhone";
				
				}

				
			    public String ReportsToId;

				public String getReportsToId () {
					return this.ReportsToId;
				}

				public Boolean ReportsToIdIsNullable(){
				    return true;
				}
				public Boolean ReportsToIdIsKey(){
				    return false;
				}
				public Integer ReportsToIdLength(){
				    return 18;
				}
				public Integer ReportsToIdPrecision(){
				    return null;
				}
				public String ReportsToIdDefault(){
				
					return null;
				
				}
				public String ReportsToIdComment(){
				
				    return "";
				
				}
				public String ReportsToIdPattern(){
				
					return "";
				
				}
				public String ReportsToIdOriginalDbColumnName(){
				
					return "ReportsToId";
				
				}

				
			    public String Email;

				public String getEmail () {
					return this.Email;
				}

				public Boolean EmailIsNullable(){
				    return true;
				}
				public Boolean EmailIsKey(){
				    return false;
				}
				public Integer EmailLength(){
				    return 80;
				}
				public Integer EmailPrecision(){
				    return null;
				}
				public String EmailDefault(){
				
					return null;
				
				}
				public String EmailComment(){
				
				    return "";
				
				}
				public String EmailPattern(){
				
					return "";
				
				}
				public String EmailOriginalDbColumnName(){
				
					return "Email";
				
				}

				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}

				public Boolean TitleIsNullable(){
				    return true;
				}
				public Boolean TitleIsKey(){
				    return false;
				}
				public Integer TitleLength(){
				    return 128;
				}
				public Integer TitlePrecision(){
				    return null;
				}
				public String TitleDefault(){
				
					return null;
				
				}
				public String TitleComment(){
				
				    return "";
				
				}
				public String TitlePattern(){
				
					return "";
				
				}
				public String TitleOriginalDbColumnName(){
				
					return "Title";
				
				}

				
			    public String Department;

				public String getDepartment () {
					return this.Department;
				}

				public Boolean DepartmentIsNullable(){
				    return true;
				}
				public Boolean DepartmentIsKey(){
				    return false;
				}
				public Integer DepartmentLength(){
				    return 80;
				}
				public Integer DepartmentPrecision(){
				    return null;
				}
				public String DepartmentDefault(){
				
					return null;
				
				}
				public String DepartmentComment(){
				
				    return "";
				
				}
				public String DepartmentPattern(){
				
					return "";
				
				}
				public String DepartmentOriginalDbColumnName(){
				
					return "Department";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastActivityDate;

				public java.util.Date getLastActivityDate () {
					return this.LastActivityDate;
				}

				public Boolean LastActivityDateIsNullable(){
				    return true;
				}
				public Boolean LastActivityDateIsKey(){
				    return false;
				}
				public Integer LastActivityDateLength(){
				    return null;
				}
				public Integer LastActivityDatePrecision(){
				    return null;
				}
				public String LastActivityDateDefault(){
				
					return null;
				
				}
				public String LastActivityDateComment(){
				
				    return "";
				
				}
				public String LastActivityDatePattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String LastActivityDateOriginalDbColumnName(){
				
					return "LastActivityDate";
				
				}

				
			    public java.util.Date LastCURequestDate;

				public java.util.Date getLastCURequestDate () {
					return this.LastCURequestDate;
				}

				public Boolean LastCURequestDateIsNullable(){
				    return true;
				}
				public Boolean LastCURequestDateIsKey(){
				    return false;
				}
				public Integer LastCURequestDateLength(){
				    return null;
				}
				public Integer LastCURequestDatePrecision(){
				    return null;
				}
				public String LastCURequestDateDefault(){
				
					return null;
				
				}
				public String LastCURequestDateComment(){
				
				    return "";
				
				}
				public String LastCURequestDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCURequestDateOriginalDbColumnName(){
				
					return "LastCURequestDate";
				
				}

				
			    public java.util.Date LastCUUpdateDate;

				public java.util.Date getLastCUUpdateDate () {
					return this.LastCUUpdateDate;
				}

				public Boolean LastCUUpdateDateIsNullable(){
				    return true;
				}
				public Boolean LastCUUpdateDateIsKey(){
				    return false;
				}
				public Integer LastCUUpdateDateLength(){
				    return null;
				}
				public Integer LastCUUpdateDatePrecision(){
				    return null;
				}
				public String LastCUUpdateDateDefault(){
				
					return null;
				
				}
				public String LastCUUpdateDateComment(){
				
				    return "";
				
				}
				public String LastCUUpdateDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCUUpdateDateOriginalDbColumnName(){
				
					return "LastCUUpdateDate";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public String EmailBouncedReason;

				public String getEmailBouncedReason () {
					return this.EmailBouncedReason;
				}

				public Boolean EmailBouncedReasonIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedReasonIsKey(){
				    return false;
				}
				public Integer EmailBouncedReasonLength(){
				    return 255;
				}
				public Integer EmailBouncedReasonPrecision(){
				    return null;
				}
				public String EmailBouncedReasonDefault(){
				
					return null;
				
				}
				public String EmailBouncedReasonComment(){
				
				    return "";
				
				}
				public String EmailBouncedReasonPattern(){
				
					return "";
				
				}
				public String EmailBouncedReasonOriginalDbColumnName(){
				
					return "EmailBouncedReason";
				
				}

				
			    public java.util.Date EmailBouncedDate;

				public java.util.Date getEmailBouncedDate () {
					return this.EmailBouncedDate;
				}

				public Boolean EmailBouncedDateIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedDateIsKey(){
				    return false;
				}
				public Integer EmailBouncedDateLength(){
				    return null;
				}
				public Integer EmailBouncedDatePrecision(){
				    return null;
				}
				public String EmailBouncedDateDefault(){
				
					return null;
				
				}
				public String EmailBouncedDateComment(){
				
				    return "";
				
				}
				public String EmailBouncedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String EmailBouncedDateOriginalDbColumnName(){
				
					return "EmailBouncedDate";
				
				}

				
			    public boolean IsEmailBounced;

				public boolean getIsEmailBounced () {
					return this.IsEmailBounced;
				}

				public Boolean IsEmailBouncedIsNullable(){
				    return false;
				}
				public Boolean IsEmailBouncedIsKey(){
				    return false;
				}
				public Integer IsEmailBouncedLength(){
				    return null;
				}
				public Integer IsEmailBouncedPrecision(){
				    return null;
				}
				public String IsEmailBouncedDefault(){
				
					return null;
				
				}
				public String IsEmailBouncedComment(){
				
				    return "";
				
				}
				public String IsEmailBouncedPattern(){
				
					return "";
				
				}
				public String IsEmailBouncedOriginalDbColumnName(){
				
					return "IsEmailBounced";
				
				}

				
			    public String PhotoUrl;

				public String getPhotoUrl () {
					return this.PhotoUrl;
				}

				public Boolean PhotoUrlIsNullable(){
				    return true;
				}
				public Boolean PhotoUrlIsKey(){
				    return false;
				}
				public Integer PhotoUrlLength(){
				    return 255;
				}
				public Integer PhotoUrlPrecision(){
				    return null;
				}
				public String PhotoUrlDefault(){
				
					return null;
				
				}
				public String PhotoUrlComment(){
				
				    return "";
				
				}
				public String PhotoUrlPattern(){
				
					return "";
				
				}
				public String PhotoUrlOriginalDbColumnName(){
				
					return "PhotoUrl";
				
				}

				
			    public String Jigsaw;

				public String getJigsaw () {
					return this.Jigsaw;
				}

				public Boolean JigsawIsNullable(){
				    return true;
				}
				public Boolean JigsawIsKey(){
				    return false;
				}
				public Integer JigsawLength(){
				    return 20;
				}
				public Integer JigsawPrecision(){
				    return null;
				}
				public String JigsawDefault(){
				
					return null;
				
				}
				public String JigsawComment(){
				
				    return "";
				
				}
				public String JigsawPattern(){
				
					return "";
				
				}
				public String JigsawOriginalDbColumnName(){
				
					return "Jigsaw";
				
				}

				
			    public String JigsawContactId;

				public String getJigsawContactId () {
					return this.JigsawContactId;
				}

				public Boolean JigsawContactIdIsNullable(){
				    return true;
				}
				public Boolean JigsawContactIdIsKey(){
				    return false;
				}
				public Integer JigsawContactIdLength(){
				    return 20;
				}
				public Integer JigsawContactIdPrecision(){
				    return null;
				}
				public String JigsawContactIdDefault(){
				
					return null;
				
				}
				public String JigsawContactIdComment(){
				
				    return "";
				
				}
				public String JigsawContactIdPattern(){
				
					return "";
				
				}
				public String JigsawContactIdOriginalDbColumnName(){
				
					return "JigsawContactId";
				
				}

				
			    public String RL_AccountingMail__c;

				public String getRL_AccountingMail__c () {
					return this.RL_AccountingMail__c;
				}

				public Boolean RL_AccountingMail__cIsNullable(){
				    return true;
				}
				public Boolean RL_AccountingMail__cIsKey(){
				    return false;
				}
				public Integer RL_AccountingMail__cLength(){
				    return 80;
				}
				public Integer RL_AccountingMail__cPrecision(){
				    return null;
				}
				public String RL_AccountingMail__cDefault(){
				
					return null;
				
				}
				public String RL_AccountingMail__cComment(){
				
				    return "";
				
				}
				public String RL_AccountingMail__cPattern(){
				
					return "";
				
				}
				public String RL_AccountingMail__cOriginalDbColumnName(){
				
					return "RL_AccountingMail__c";
				
				}

				
			    public String RL_Agency__c;

				public String getRL_Agency__c () {
					return this.RL_Agency__c;
				}

				public Boolean RL_Agency__cIsNullable(){
				    return true;
				}
				public Boolean RL_Agency__cIsKey(){
				    return false;
				}
				public Integer RL_Agency__cLength(){
				    return 45;
				}
				public Integer RL_Agency__cPrecision(){
				    return null;
				}
				public String RL_Agency__cDefault(){
				
					return null;
				
				}
				public String RL_Agency__cComment(){
				
				    return "";
				
				}
				public String RL_Agency__cPattern(){
				
					return "";
				
				}
				public String RL_Agency__cOriginalDbColumnName(){
				
					return "RL_Agency__c";
				
				}

				
			    public String RL_BankCode__c;

				public String getRL_BankCode__c () {
					return this.RL_BankCode__c;
				}

				public Boolean RL_BankCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankCode__cIsKey(){
				    return false;
				}
				public Integer RL_BankCode__cLength(){
				    return 45;
				}
				public Integer RL_BankCode__cPrecision(){
				    return null;
				}
				public String RL_BankCode__cDefault(){
				
					return null;
				
				}
				public String RL_BankCode__cComment(){
				
				    return "";
				
				}
				public String RL_BankCode__cPattern(){
				
					return "";
				
				}
				public String RL_BankCode__cOriginalDbColumnName(){
				
					return "RL_BankCode__c";
				
				}

				
			    public String RL_BankKey__c;

				public String getRL_BankKey__c () {
					return this.RL_BankKey__c;
				}

				public Boolean RL_BankKey__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankKey__cIsKey(){
				    return false;
				}
				public Integer RL_BankKey__cLength(){
				    return 45;
				}
				public Integer RL_BankKey__cPrecision(){
				    return null;
				}
				public String RL_BankKey__cDefault(){
				
					return null;
				
				}
				public String RL_BankKey__cComment(){
				
				    return "";
				
				}
				public String RL_BankKey__cPattern(){
				
					return "";
				
				}
				public String RL_BankKey__cOriginalDbColumnName(){
				
					return "RL_BankKey__c";
				
				}

				
			    public String RL_BillingCity__c;

				public String getRL_BillingCity__c () {
					return this.RL_BillingCity__c;
				}

				public Boolean RL_BillingCity__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCity__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCity__cLength(){
				    return 45;
				}
				public Integer RL_BillingCity__cPrecision(){
				    return null;
				}
				public String RL_BillingCity__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCity__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCity__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCity__cOriginalDbColumnName(){
				
					return "RL_BillingCity__c";
				
				}

				
			    public String RL_BillingCountry__c;

				public String getRL_BillingCountry__c () {
					return this.RL_BillingCountry__c;
				}

				public Boolean RL_BillingCountry__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCountry__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCountry__cLength(){
				    return 45;
				}
				public Integer RL_BillingCountry__cPrecision(){
				    return null;
				}
				public String RL_BillingCountry__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCountry__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCountry__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCountry__cOriginalDbColumnName(){
				
					return "RL_BillingCountry__c";
				
				}

				
			    public String RL_BillingName__c;

				public String getRL_BillingName__c () {
					return this.RL_BillingName__c;
				}

				public Boolean RL_BillingName__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingName__cIsKey(){
				    return false;
				}
				public Integer RL_BillingName__cLength(){
				    return 45;
				}
				public Integer RL_BillingName__cPrecision(){
				    return null;
				}
				public String RL_BillingName__cDefault(){
				
					return null;
				
				}
				public String RL_BillingName__cComment(){
				
				    return "";
				
				}
				public String RL_BillingName__cPattern(){
				
					return "";
				
				}
				public String RL_BillingName__cOriginalDbColumnName(){
				
					return "RL_BillingName__c";
				
				}

				
			    public String RL_BillingStreetNumber__c;

				public String getRL_BillingStreetNumber__c () {
					return this.RL_BillingStreetNumber__c;
				}

				public Boolean RL_BillingStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_BillingStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreetNumber__cOriginalDbColumnName(){
				
					return "RL_BillingStreetNumber__c";
				
				}

				
			    public String RL_BillingStreet__c;

				public String getRL_BillingStreet__c () {
					return this.RL_BillingStreet__c;
				}

				public Boolean RL_BillingStreet__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreet__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreet__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreet__cPrecision(){
				    return null;
				}
				public String RL_BillingStreet__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreet__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreet__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreet__cOriginalDbColumnName(){
				
					return "RL_BillingStreet__c";
				
				}

				
			    public String RL_BillingTel1__c;

				public String getRL_BillingTel1__c () {
					return this.RL_BillingTel1__c;
				}

				public Boolean RL_BillingTel1__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel1__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel1__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel1__cPrecision(){
				    return null;
				}
				public String RL_BillingTel1__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel1__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel1__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel1__cOriginalDbColumnName(){
				
					return "RL_BillingTel1__c";
				
				}

				
			    public String RL_BillingTel2__c;

				public String getRL_BillingTel2__c () {
					return this.RL_BillingTel2__c;
				}

				public Boolean RL_BillingTel2__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel2__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel2__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel2__cPrecision(){
				    return null;
				}
				public String RL_BillingTel2__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel2__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel2__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel2__cOriginalDbColumnName(){
				
					return "RL_BillingTel2__c";
				
				}

				
			    public String RL_BillingTel3__c;

				public String getRL_BillingTel3__c () {
					return this.RL_BillingTel3__c;
				}

				public Boolean RL_BillingTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel3__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel3__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel3__cPrecision(){
				    return null;
				}
				public String RL_BillingTel3__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel3__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel3__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel3__cOriginalDbColumnName(){
				
					return "RL_BillingTel3__c";
				
				}

				
			    public Double RL_CodeSettlement__c;

				public Double getRL_CodeSettlement__c () {
					return this.RL_CodeSettlement__c;
				}

				public Boolean RL_CodeSettlement__cIsNullable(){
				    return true;
				}
				public Boolean RL_CodeSettlement__cIsKey(){
				    return false;
				}
				public Integer RL_CodeSettlement__cLength(){
				    return 11;
				}
				public Integer RL_CodeSettlement__cPrecision(){
				    return null;
				}
				public String RL_CodeSettlement__cDefault(){
				
					return null;
				
				}
				public String RL_CodeSettlement__cComment(){
				
				    return "";
				
				}
				public String RL_CodeSettlement__cPattern(){
				
					return "";
				
				}
				public String RL_CodeSettlement__cOriginalDbColumnName(){
				
					return "RL_CodeSettlement__c";
				
				}

				
			    public java.util.Date RL_CreatedAt__c;

				public java.util.Date getRL_CreatedAt__c () {
					return this.RL_CreatedAt__c;
				}

				public Boolean RL_CreatedAt__cIsNullable(){
				    return true;
				}
				public Boolean RL_CreatedAt__cIsKey(){
				    return false;
				}
				public Integer RL_CreatedAt__cLength(){
				    return null;
				}
				public Integer RL_CreatedAt__cPrecision(){
				    return null;
				}
				public String RL_CreatedAt__cDefault(){
				
					return null;
				
				}
				public String RL_CreatedAt__cComment(){
				
				    return "";
				
				}
				public String RL_CreatedAt__cPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String RL_CreatedAt__cOriginalDbColumnName(){
				
					return "RL_CreatedAt__c";
				
				}

				
			    public String RL_Email__c;

				public String getRL_Email__c () {
					return this.RL_Email__c;
				}

				public Boolean RL_Email__cIsNullable(){
				    return true;
				}
				public Boolean RL_Email__cIsKey(){
				    return false;
				}
				public Integer RL_Email__cLength(){
				    return 255;
				}
				public Integer RL_Email__cPrecision(){
				    return null;
				}
				public String RL_Email__cDefault(){
				
					return null;
				
				}
				public String RL_Email__cComment(){
				
				    return "";
				
				}
				public String RL_Email__cPattern(){
				
					return "";
				
				}
				public String RL_Email__cOriginalDbColumnName(){
				
					return "RL_Email__c";
				
				}

				
			    public Double RL_ExternalAccountId__c;

				public Double getRL_ExternalAccountId__c () {
					return this.RL_ExternalAccountId__c;
				}

				public Boolean RL_ExternalAccountId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalAccountId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalAccountId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalAccountId__cPrecision(){
				    return null;
				}
				public String RL_ExternalAccountId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalAccountId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalAccountId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalAccountId__cOriginalDbColumnName(){
				
					return "RL_ExternalAccountId__c";
				
				}

				
			    public Integer RL_ExternalId__c;

				public Integer getRL_ExternalId__c () {
					return this.RL_ExternalId__c;
				}

				public Boolean RL_ExternalId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalId__cPrecision(){
				    return null;
				}
				public String RL_ExternalId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalId__cOriginalDbColumnName(){
				
					return "RL_ExternalId__c";
				
				}

				
			    public Double RL_IsActive__c;

				public Double getRL_IsActive__c () {
					return this.RL_IsActive__c;
				}

				public Boolean RL_IsActive__cIsNullable(){
				    return true;
				}
				public Boolean RL_IsActive__cIsKey(){
				    return false;
				}
				public Integer RL_IsActive__cLength(){
				    return 1;
				}
				public Integer RL_IsActive__cPrecision(){
				    return null;
				}
				public String RL_IsActive__cDefault(){
				
					return null;
				
				}
				public String RL_IsActive__cComment(){
				
				    return "";
				
				}
				public String RL_IsActive__cPattern(){
				
					return "";
				
				}
				public String RL_IsActive__cOriginalDbColumnName(){
				
					return "RL_IsActive__c";
				
				}

				
			    public String RL_RecoveryPostalCode__c;

				public String getRL_RecoveryPostalCode__c () {
					return this.RL_RecoveryPostalCode__c;
				}

				public Boolean RL_RecoveryPostalCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_RecoveryPostalCode__cIsKey(){
				    return false;
				}
				public Integer RL_RecoveryPostalCode__cLength(){
				    return 255;
				}
				public Integer RL_RecoveryPostalCode__cPrecision(){
				    return null;
				}
				public String RL_RecoveryPostalCode__cDefault(){
				
					return null;
				
				}
				public String RL_RecoveryPostalCode__cComment(){
				
				    return "";
				
				}
				public String RL_RecoveryPostalCode__cPattern(){
				
					return "";
				
				}
				public String RL_RecoveryPostalCode__cOriginalDbColumnName(){
				
					return "RL_RecoveryPostalCode__c";
				
				}

				
			    public String RL_RemovalStreetNumber__c;

				public String getRL_RemovalStreetNumber__c () {
					return this.RL_RemovalStreetNumber__c;
				}

				public Boolean RL_RemovalStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_RemovalStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_RemovalStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalStreetNumber__cOriginalDbColumnName(){
				
					return "RL_RemovalStreetNumber__c";
				
				}

				
			    public String RL_RemovalTel3__c;

				public String getRL_RemovalTel3__c () {
					return this.RL_RemovalTel3__c;
				}

				public Boolean RL_RemovalTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalTel3__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalTel3__cLength(){
				    return 40;
				}
				public Integer RL_RemovalTel3__cPrecision(){
				    return null;
				}
				public String RL_RemovalTel3__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalTel3__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalTel3__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalTel3__cOriginalDbColumnName(){
				
					return "RL_RemovalTel3__c";
				
				}

				
			    public String Code_Client__c;

				public String getCode_Client__c () {
					return this.Code_Client__c;
				}

				public Boolean Code_Client__cIsNullable(){
				    return true;
				}
				public Boolean Code_Client__cIsKey(){
				    return false;
				}
				public Integer Code_Client__cLength(){
				    return 30;
				}
				public Integer Code_Client__cPrecision(){
				    return null;
				}
				public String Code_Client__cDefault(){
				
					return null;
				
				}
				public String Code_Client__cComment(){
				
				    return "";
				
				}
				public String Code_Client__cPattern(){
				
					return "";
				
				}
				public String Code_Client__cOriginalDbColumnName(){
				
					return "Code_Client__c";
				
				}

				
			    public String Data_Quality_Description__c;

				public String getData_Quality_Description__c () {
					return this.Data_Quality_Description__c;
				}

				public Boolean Data_Quality_Description__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Description__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Description__cLength(){
				    return 1300;
				}
				public Integer Data_Quality_Description__cPrecision(){
				    return null;
				}
				public String Data_Quality_Description__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Description__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Description__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Description__cOriginalDbColumnName(){
				
					return "Data_Quality_Description__c";
				
				}

				
			    public Double Data_Quality_Score__c;

				public Double getData_Quality_Score__c () {
					return this.Data_Quality_Score__c;
				}

				public Boolean Data_Quality_Score__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Score__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Score__cLength(){
				    return 18;
				}
				public Integer Data_Quality_Score__cPrecision(){
				    return null;
				}
				public String Data_Quality_Score__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Score__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Score__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Score__cOriginalDbColumnName(){
				
					return "Data_Quality_Score__c";
				
				}

				
			    public String RL_Company__c;

				public String getRL_Company__c () {
					return this.RL_Company__c;
				}

				public Boolean RL_Company__cIsNullable(){
				    return true;
				}
				public Boolean RL_Company__cIsKey(){
				    return false;
				}
				public Integer RL_Company__cLength(){
				    return 45;
				}
				public Integer RL_Company__cPrecision(){
				    return null;
				}
				public String RL_Company__cDefault(){
				
					return null;
				
				}
				public String RL_Company__cComment(){
				
				    return "";
				
				}
				public String RL_Company__cPattern(){
				
					return "";
				
				}
				public String RL_Company__cOriginalDbColumnName(){
				
					return "RL_Company__c";
				
				}

				
			    public String RL_Removal_iso3_country__c;

				public String getRL_Removal_iso3_country__c () {
					return this.RL_Removal_iso3_country__c;
				}

				public Boolean RL_Removal_iso3_country__cIsNullable(){
				    return true;
				}
				public Boolean RL_Removal_iso3_country__cIsKey(){
				    return false;
				}
				public Integer RL_Removal_iso3_country__cLength(){
				    return 45;
				}
				public Integer RL_Removal_iso3_country__cPrecision(){
				    return null;
				}
				public String RL_Removal_iso3_country__cDefault(){
				
					return null;
				
				}
				public String RL_Removal_iso3_country__cComment(){
				
				    return "";
				
				}
				public String RL_Removal_iso3_country__cPattern(){
				
					return "";
				
				}
				public String RL_Removal_iso3_country__cOriginalDbColumnName(){
				
					return "RL_Removal_iso3_country__c";
				
				}

				
			    public boolean RL_Archived__c;

				public boolean getRL_Archived__c () {
					return this.RL_Archived__c;
				}

				public Boolean RL_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Archived__cLength(){
				    return null;
				}
				public Integer RL_Archived__cPrecision(){
				    return null;
				}
				public String RL_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Archived__cOriginalDbColumnName(){
				
					return "RL_Archived__c";
				
				}

				
			    public boolean RL_Tarification_par_palier__c;

				public boolean getRL_Tarification_par_palier__c () {
					return this.RL_Tarification_par_palier__c;
				}

				public Boolean RL_Tarification_par_palier__cIsNullable(){
				    return false;
				}
				public Boolean RL_Tarification_par_palier__cIsKey(){
				    return false;
				}
				public Integer RL_Tarification_par_palier__cLength(){
				    return null;
				}
				public Integer RL_Tarification_par_palier__cPrecision(){
				    return null;
				}
				public String RL_Tarification_par_palier__cDefault(){
				
					return null;
				
				}
				public String RL_Tarification_par_palier__cComment(){
				
				    return "";
				
				}
				public String RL_Tarification_par_palier__cPattern(){
				
					return "";
				
				}
				public String RL_Tarification_par_palier__cOriginalDbColumnName(){
				
					return "RL_Tarification_par_palier__c";
				
				}

				
			    public String Contact_Commercial__c;

				public String getContact_Commercial__c () {
					return this.Contact_Commercial__c;
				}

				public Boolean Contact_Commercial__cIsNullable(){
				    return true;
				}
				public Boolean Contact_Commercial__cIsKey(){
				    return false;
				}
				public Integer Contact_Commercial__cLength(){
				    return 255;
				}
				public Integer Contact_Commercial__cPrecision(){
				    return null;
				}
				public String Contact_Commercial__cDefault(){
				
					return null;
				
				}
				public String Contact_Commercial__cComment(){
				
				    return "";
				
				}
				public String Contact_Commercial__cPattern(){
				
					return "";
				
				}
				public String Contact_Commercial__cOriginalDbColumnName(){
				
					return "Contact_Commercial__c";
				
				}

				
			    public String SocieteInfo__Id__c;

				public String getSocieteInfo__Id__c () {
					return this.SocieteInfo__Id__c;
				}

				public Boolean SocieteInfo__Id__cIsNullable(){
				    return true;
				}
				public Boolean SocieteInfo__Id__cIsKey(){
				    return false;
				}
				public Integer SocieteInfo__Id__cLength(){
				    return 80;
				}
				public Integer SocieteInfo__Id__cPrecision(){
				    return null;
				}
				public String SocieteInfo__Id__cDefault(){
				
					return null;
				
				}
				public String SocieteInfo__Id__cComment(){
				
				    return "";
				
				}
				public String SocieteInfo__Id__cPattern(){
				
					return "";
				
				}
				public String SocieteInfo__Id__cOriginalDbColumnName(){
				
					return "SocieteInfo__Id__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Integer
				
						writeInteger(this.RL_ExternalId__c,dos);
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Integer
				
						writeInteger(this.RL_ExternalId__c,dos);
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",MasterRecordId="+MasterRecordId);
		sb.append(",AccountId="+AccountId);
		sb.append(",LastName="+LastName);
		sb.append(",FirstName="+FirstName);
		sb.append(",Salutation="+Salutation);
		sb.append(",MiddleName="+MiddleName);
		sb.append(",Suffix="+Suffix);
		sb.append(",Name="+Name);
		sb.append(",RecordTypeId="+RecordTypeId);
		sb.append(",MailingStreet="+MailingStreet);
		sb.append(",MailingCity="+MailingCity);
		sb.append(",MailingState="+MailingState);
		sb.append(",MailingPostalCode="+MailingPostalCode);
		sb.append(",MailingCountry="+MailingCountry);
		sb.append(",MailingLatitude="+String.valueOf(MailingLatitude));
		sb.append(",MailingLongitude="+String.valueOf(MailingLongitude));
		sb.append(",MailingGeocodeAccuracy="+MailingGeocodeAccuracy);
		sb.append(",MailingAddress="+MailingAddress);
		sb.append(",Phone="+Phone);
		sb.append(",Fax="+Fax);
		sb.append(",MobilePhone="+MobilePhone);
		sb.append(",ReportsToId="+ReportsToId);
		sb.append(",Email="+Email);
		sb.append(",Title="+Title);
		sb.append(",Department="+Department);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastActivityDate="+String.valueOf(LastActivityDate));
		sb.append(",LastCURequestDate="+String.valueOf(LastCURequestDate));
		sb.append(",LastCUUpdateDate="+String.valueOf(LastCUUpdateDate));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",EmailBouncedReason="+EmailBouncedReason);
		sb.append(",EmailBouncedDate="+String.valueOf(EmailBouncedDate));
		sb.append(",IsEmailBounced="+String.valueOf(IsEmailBounced));
		sb.append(",PhotoUrl="+PhotoUrl);
		sb.append(",Jigsaw="+Jigsaw);
		sb.append(",JigsawContactId="+JigsawContactId);
		sb.append(",RL_AccountingMail__c="+RL_AccountingMail__c);
		sb.append(",RL_Agency__c="+RL_Agency__c);
		sb.append(",RL_BankCode__c="+RL_BankCode__c);
		sb.append(",RL_BankKey__c="+RL_BankKey__c);
		sb.append(",RL_BillingCity__c="+RL_BillingCity__c);
		sb.append(",RL_BillingCountry__c="+RL_BillingCountry__c);
		sb.append(",RL_BillingName__c="+RL_BillingName__c);
		sb.append(",RL_BillingStreetNumber__c="+RL_BillingStreetNumber__c);
		sb.append(",RL_BillingStreet__c="+RL_BillingStreet__c);
		sb.append(",RL_BillingTel1__c="+RL_BillingTel1__c);
		sb.append(",RL_BillingTel2__c="+RL_BillingTel2__c);
		sb.append(",RL_BillingTel3__c="+RL_BillingTel3__c);
		sb.append(",RL_CodeSettlement__c="+String.valueOf(RL_CodeSettlement__c));
		sb.append(",RL_CreatedAt__c="+String.valueOf(RL_CreatedAt__c));
		sb.append(",RL_Email__c="+RL_Email__c);
		sb.append(",RL_ExternalAccountId__c="+String.valueOf(RL_ExternalAccountId__c));
		sb.append(",RL_ExternalId__c="+String.valueOf(RL_ExternalId__c));
		sb.append(",RL_IsActive__c="+String.valueOf(RL_IsActive__c));
		sb.append(",RL_RecoveryPostalCode__c="+RL_RecoveryPostalCode__c);
		sb.append(",RL_RemovalStreetNumber__c="+RL_RemovalStreetNumber__c);
		sb.append(",RL_RemovalTel3__c="+RL_RemovalTel3__c);
		sb.append(",Code_Client__c="+Code_Client__c);
		sb.append(",Data_Quality_Description__c="+Data_Quality_Description__c);
		sb.append(",Data_Quality_Score__c="+String.valueOf(Data_Quality_Score__c));
		sb.append(",RL_Company__c="+RL_Company__c);
		sb.append(",RL_Removal_iso3_country__c="+RL_Removal_iso3_country__c);
		sb.append(",RL_Archived__c="+String.valueOf(RL_Archived__c));
		sb.append(",RL_Tarification_par_palier__c="+String.valueOf(RL_Tarification_par_palier__c));
		sb.append(",Contact_Commercial__c="+Contact_Commercial__c);
		sb.append(",SocieteInfo__Id__c="+SocieteInfo__Id__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(MasterRecordId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MasterRecordId);
            			}
            		
        			sb.append("|");
        		
        				if(AccountId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccountId);
            			}
            		
        			sb.append("|");
        		
        				if(LastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastName);
            			}
            		
        			sb.append("|");
        		
        				if(FirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FirstName);
            			}
            		
        			sb.append("|");
        		
        				if(Salutation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Salutation);
            			}
            		
        			sb.append("|");
        		
        				if(MiddleName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MiddleName);
            			}
            		
        			sb.append("|");
        		
        				if(Suffix == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Suffix);
            			}
            		
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(RecordTypeId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RecordTypeId);
            			}
            		
        			sb.append("|");
        		
        				if(MailingStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingStreet);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCity);
            			}
            		
        			sb.append("|");
        		
        				if(MailingState == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingState);
            			}
            		
        			sb.append("|");
        		
        				if(MailingPostalCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingPostalCode);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCountry);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLatitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLatitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLongitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLongitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingGeocodeAccuracy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingGeocodeAccuracy);
            			}
            		
        			sb.append("|");
        		
        				if(MailingAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingAddress);
            			}
            		
        			sb.append("|");
        		
        				if(Phone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Phone);
            			}
            		
        			sb.append("|");
        		
        				if(Fax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Fax);
            			}
            		
        			sb.append("|");
        		
        				if(MobilePhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MobilePhone);
            			}
            		
        			sb.append("|");
        		
        				if(ReportsToId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ReportsToId);
            			}
            		
        			sb.append("|");
        		
        				if(Email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Email);
            			}
            		
        			sb.append("|");
        		
        				if(Title == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Title);
            			}
            		
        			sb.append("|");
        		
        				if(Department == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Department);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastActivityDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastActivityDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCURequestDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCURequestDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCUUpdateDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCUUpdateDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedReason);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsEmailBounced);
        			
        			sb.append("|");
        		
        				if(PhotoUrl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoUrl);
            			}
            		
        			sb.append("|");
        		
        				if(Jigsaw == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jigsaw);
            			}
            		
        			sb.append("|");
        		
        				if(JigsawContactId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JigsawContactId);
            			}
            		
        			sb.append("|");
        		
        				if(RL_AccountingMail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_AccountingMail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Agency__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Agency__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankKey__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankKey__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCountry__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCountry__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingName__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingName__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreet__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreet__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel1__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel1__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel2__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel2__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CodeSettlement__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CodeSettlement__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CreatedAt__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CreatedAt__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Email__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Email__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalAccountId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalAccountId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_IsActive__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_IsActive__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RecoveryPostalCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RecoveryPostalCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(Code_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Description__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Description__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Score__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Score__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Company__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Company__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Removal_iso3_country__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Removal_iso3_country__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Archived__c);
        			
        			sb.append("|");
        		
        				sb.append(RL_Tarification_par_palier__c);
        			
        			sb.append("|");
        		
        				if(Contact_Commercial__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact_Commercial__c);
            			}
            		
        			sb.append("|");
        		
        				if(SocieteInfo__Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SocieteInfo__Id__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String MasterRecordId;

				public String getMasterRecordId () {
					return this.MasterRecordId;
				}

				public Boolean MasterRecordIdIsNullable(){
				    return true;
				}
				public Boolean MasterRecordIdIsKey(){
				    return false;
				}
				public Integer MasterRecordIdLength(){
				    return 18;
				}
				public Integer MasterRecordIdPrecision(){
				    return null;
				}
				public String MasterRecordIdDefault(){
				
					return null;
				
				}
				public String MasterRecordIdComment(){
				
				    return "";
				
				}
				public String MasterRecordIdPattern(){
				
					return "";
				
				}
				public String MasterRecordIdOriginalDbColumnName(){
				
					return "MasterRecordId";
				
				}

				
			    public String AccountId;

				public String getAccountId () {
					return this.AccountId;
				}

				public Boolean AccountIdIsNullable(){
				    return true;
				}
				public Boolean AccountIdIsKey(){
				    return false;
				}
				public Integer AccountIdLength(){
				    return 18;
				}
				public Integer AccountIdPrecision(){
				    return null;
				}
				public String AccountIdDefault(){
				
					return null;
				
				}
				public String AccountIdComment(){
				
				    return "";
				
				}
				public String AccountIdPattern(){
				
					return "";
				
				}
				public String AccountIdOriginalDbColumnName(){
				
					return "AccountId";
				
				}

				
			    public String LastName;

				public String getLastName () {
					return this.LastName;
				}

				public Boolean LastNameIsNullable(){
				    return false;
				}
				public Boolean LastNameIsKey(){
				    return false;
				}
				public Integer LastNameLength(){
				    return 80;
				}
				public Integer LastNamePrecision(){
				    return null;
				}
				public String LastNameDefault(){
				
					return null;
				
				}
				public String LastNameComment(){
				
				    return "";
				
				}
				public String LastNamePattern(){
				
					return "";
				
				}
				public String LastNameOriginalDbColumnName(){
				
					return "LastName";
				
				}

				
			    public String FirstName;

				public String getFirstName () {
					return this.FirstName;
				}

				public Boolean FirstNameIsNullable(){
				    return true;
				}
				public Boolean FirstNameIsKey(){
				    return false;
				}
				public Integer FirstNameLength(){
				    return 40;
				}
				public Integer FirstNamePrecision(){
				    return null;
				}
				public String FirstNameDefault(){
				
					return null;
				
				}
				public String FirstNameComment(){
				
				    return "";
				
				}
				public String FirstNamePattern(){
				
					return "";
				
				}
				public String FirstNameOriginalDbColumnName(){
				
					return "FirstName";
				
				}

				
			    public String Salutation;

				public String getSalutation () {
					return this.Salutation;
				}

				public Boolean SalutationIsNullable(){
				    return true;
				}
				public Boolean SalutationIsKey(){
				    return false;
				}
				public Integer SalutationLength(){
				    return 40;
				}
				public Integer SalutationPrecision(){
				    return null;
				}
				public String SalutationDefault(){
				
					return null;
				
				}
				public String SalutationComment(){
				
				    return "";
				
				}
				public String SalutationPattern(){
				
					return "";
				
				}
				public String SalutationOriginalDbColumnName(){
				
					return "Salutation";
				
				}

				
			    public String MiddleName;

				public String getMiddleName () {
					return this.MiddleName;
				}

				public Boolean MiddleNameIsNullable(){
				    return true;
				}
				public Boolean MiddleNameIsKey(){
				    return false;
				}
				public Integer MiddleNameLength(){
				    return 40;
				}
				public Integer MiddleNamePrecision(){
				    return null;
				}
				public String MiddleNameDefault(){
				
					return null;
				
				}
				public String MiddleNameComment(){
				
				    return "";
				
				}
				public String MiddleNamePattern(){
				
					return "";
				
				}
				public String MiddleNameOriginalDbColumnName(){
				
					return "MiddleName";
				
				}

				
			    public String Suffix;

				public String getSuffix () {
					return this.Suffix;
				}

				public Boolean SuffixIsNullable(){
				    return true;
				}
				public Boolean SuffixIsKey(){
				    return false;
				}
				public Integer SuffixLength(){
				    return 40;
				}
				public Integer SuffixPrecision(){
				    return null;
				}
				public String SuffixDefault(){
				
					return null;
				
				}
				public String SuffixComment(){
				
				    return "";
				
				}
				public String SuffixPattern(){
				
					return "";
				
				}
				public String SuffixOriginalDbColumnName(){
				
					return "Suffix";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return false;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 121;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String RecordTypeId;

				public String getRecordTypeId () {
					return this.RecordTypeId;
				}

				public Boolean RecordTypeIdIsNullable(){
				    return true;
				}
				public Boolean RecordTypeIdIsKey(){
				    return false;
				}
				public Integer RecordTypeIdLength(){
				    return 18;
				}
				public Integer RecordTypeIdPrecision(){
				    return null;
				}
				public String RecordTypeIdDefault(){
				
					return null;
				
				}
				public String RecordTypeIdComment(){
				
				    return "";
				
				}
				public String RecordTypeIdPattern(){
				
					return "";
				
				}
				public String RecordTypeIdOriginalDbColumnName(){
				
					return "RecordTypeId";
				
				}

				
			    public String MailingStreet;

				public String getMailingStreet () {
					return this.MailingStreet;
				}

				public Boolean MailingStreetIsNullable(){
				    return true;
				}
				public Boolean MailingStreetIsKey(){
				    return false;
				}
				public Integer MailingStreetLength(){
				    return 255;
				}
				public Integer MailingStreetPrecision(){
				    return null;
				}
				public String MailingStreetDefault(){
				
					return null;
				
				}
				public String MailingStreetComment(){
				
				    return "";
				
				}
				public String MailingStreetPattern(){
				
					return "";
				
				}
				public String MailingStreetOriginalDbColumnName(){
				
					return "MailingStreet";
				
				}

				
			    public String MailingCity;

				public String getMailingCity () {
					return this.MailingCity;
				}

				public Boolean MailingCityIsNullable(){
				    return true;
				}
				public Boolean MailingCityIsKey(){
				    return false;
				}
				public Integer MailingCityLength(){
				    return 40;
				}
				public Integer MailingCityPrecision(){
				    return null;
				}
				public String MailingCityDefault(){
				
					return null;
				
				}
				public String MailingCityComment(){
				
				    return "";
				
				}
				public String MailingCityPattern(){
				
					return "";
				
				}
				public String MailingCityOriginalDbColumnName(){
				
					return "MailingCity";
				
				}

				
			    public String MailingState;

				public String getMailingState () {
					return this.MailingState;
				}

				public Boolean MailingStateIsNullable(){
				    return true;
				}
				public Boolean MailingStateIsKey(){
				    return false;
				}
				public Integer MailingStateLength(){
				    return 80;
				}
				public Integer MailingStatePrecision(){
				    return null;
				}
				public String MailingStateDefault(){
				
					return null;
				
				}
				public String MailingStateComment(){
				
				    return "";
				
				}
				public String MailingStatePattern(){
				
					return "";
				
				}
				public String MailingStateOriginalDbColumnName(){
				
					return "MailingState";
				
				}

				
			    public String MailingPostalCode;

				public String getMailingPostalCode () {
					return this.MailingPostalCode;
				}

				public Boolean MailingPostalCodeIsNullable(){
				    return true;
				}
				public Boolean MailingPostalCodeIsKey(){
				    return false;
				}
				public Integer MailingPostalCodeLength(){
				    return 20;
				}
				public Integer MailingPostalCodePrecision(){
				    return null;
				}
				public String MailingPostalCodeDefault(){
				
					return null;
				
				}
				public String MailingPostalCodeComment(){
				
				    return "";
				
				}
				public String MailingPostalCodePattern(){
				
					return "";
				
				}
				public String MailingPostalCodeOriginalDbColumnName(){
				
					return "MailingPostalCode";
				
				}

				
			    public String MailingCountry;

				public String getMailingCountry () {
					return this.MailingCountry;
				}

				public Boolean MailingCountryIsNullable(){
				    return true;
				}
				public Boolean MailingCountryIsKey(){
				    return false;
				}
				public Integer MailingCountryLength(){
				    return 80;
				}
				public Integer MailingCountryPrecision(){
				    return null;
				}
				public String MailingCountryDefault(){
				
					return null;
				
				}
				public String MailingCountryComment(){
				
				    return "";
				
				}
				public String MailingCountryPattern(){
				
					return "";
				
				}
				public String MailingCountryOriginalDbColumnName(){
				
					return "MailingCountry";
				
				}

				
			    public Double MailingLatitude;

				public Double getMailingLatitude () {
					return this.MailingLatitude;
				}

				public Boolean MailingLatitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLatitudeIsKey(){
				    return false;
				}
				public Integer MailingLatitudeLength(){
				    return 18;
				}
				public Integer MailingLatitudePrecision(){
				    return 15;
				}
				public String MailingLatitudeDefault(){
				
					return null;
				
				}
				public String MailingLatitudeComment(){
				
				    return "";
				
				}
				public String MailingLatitudePattern(){
				
					return "";
				
				}
				public String MailingLatitudeOriginalDbColumnName(){
				
					return "MailingLatitude";
				
				}

				
			    public Double MailingLongitude;

				public Double getMailingLongitude () {
					return this.MailingLongitude;
				}

				public Boolean MailingLongitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLongitudeIsKey(){
				    return false;
				}
				public Integer MailingLongitudeLength(){
				    return 18;
				}
				public Integer MailingLongitudePrecision(){
				    return 15;
				}
				public String MailingLongitudeDefault(){
				
					return null;
				
				}
				public String MailingLongitudeComment(){
				
				    return "";
				
				}
				public String MailingLongitudePattern(){
				
					return "";
				
				}
				public String MailingLongitudeOriginalDbColumnName(){
				
					return "MailingLongitude";
				
				}

				
			    public String MailingGeocodeAccuracy;

				public String getMailingGeocodeAccuracy () {
					return this.MailingGeocodeAccuracy;
				}

				public Boolean MailingGeocodeAccuracyIsNullable(){
				    return true;
				}
				public Boolean MailingGeocodeAccuracyIsKey(){
				    return false;
				}
				public Integer MailingGeocodeAccuracyLength(){
				    return 40;
				}
				public Integer MailingGeocodeAccuracyPrecision(){
				    return null;
				}
				public String MailingGeocodeAccuracyDefault(){
				
					return null;
				
				}
				public String MailingGeocodeAccuracyComment(){
				
				    return "";
				
				}
				public String MailingGeocodeAccuracyPattern(){
				
					return "";
				
				}
				public String MailingGeocodeAccuracyOriginalDbColumnName(){
				
					return "MailingGeocodeAccuracy";
				
				}

				
			    public String MailingAddress;

				public String getMailingAddress () {
					return this.MailingAddress;
				}

				public Boolean MailingAddressIsNullable(){
				    return true;
				}
				public Boolean MailingAddressIsKey(){
				    return false;
				}
				public Integer MailingAddressLength(){
				    return null;
				}
				public Integer MailingAddressPrecision(){
				    return null;
				}
				public String MailingAddressDefault(){
				
					return null;
				
				}
				public String MailingAddressComment(){
				
				    return "";
				
				}
				public String MailingAddressPattern(){
				
					return "";
				
				}
				public String MailingAddressOriginalDbColumnName(){
				
					return "MailingAddress";
				
				}

				
			    public String Phone;

				public String getPhone () {
					return this.Phone;
				}

				public Boolean PhoneIsNullable(){
				    return true;
				}
				public Boolean PhoneIsKey(){
				    return false;
				}
				public Integer PhoneLength(){
				    return 40;
				}
				public Integer PhonePrecision(){
				    return null;
				}
				public String PhoneDefault(){
				
					return null;
				
				}
				public String PhoneComment(){
				
				    return "";
				
				}
				public String PhonePattern(){
				
					return "";
				
				}
				public String PhoneOriginalDbColumnName(){
				
					return "Phone";
				
				}

				
			    public String Fax;

				public String getFax () {
					return this.Fax;
				}

				public Boolean FaxIsNullable(){
				    return true;
				}
				public Boolean FaxIsKey(){
				    return false;
				}
				public Integer FaxLength(){
				    return 40;
				}
				public Integer FaxPrecision(){
				    return null;
				}
				public String FaxDefault(){
				
					return null;
				
				}
				public String FaxComment(){
				
				    return "";
				
				}
				public String FaxPattern(){
				
					return "";
				
				}
				public String FaxOriginalDbColumnName(){
				
					return "Fax";
				
				}

				
			    public String MobilePhone;

				public String getMobilePhone () {
					return this.MobilePhone;
				}

				public Boolean MobilePhoneIsNullable(){
				    return true;
				}
				public Boolean MobilePhoneIsKey(){
				    return false;
				}
				public Integer MobilePhoneLength(){
				    return 40;
				}
				public Integer MobilePhonePrecision(){
				    return null;
				}
				public String MobilePhoneDefault(){
				
					return null;
				
				}
				public String MobilePhoneComment(){
				
				    return "";
				
				}
				public String MobilePhonePattern(){
				
					return "";
				
				}
				public String MobilePhoneOriginalDbColumnName(){
				
					return "MobilePhone";
				
				}

				
			    public String ReportsToId;

				public String getReportsToId () {
					return this.ReportsToId;
				}

				public Boolean ReportsToIdIsNullable(){
				    return true;
				}
				public Boolean ReportsToIdIsKey(){
				    return false;
				}
				public Integer ReportsToIdLength(){
				    return 18;
				}
				public Integer ReportsToIdPrecision(){
				    return null;
				}
				public String ReportsToIdDefault(){
				
					return null;
				
				}
				public String ReportsToIdComment(){
				
				    return "";
				
				}
				public String ReportsToIdPattern(){
				
					return "";
				
				}
				public String ReportsToIdOriginalDbColumnName(){
				
					return "ReportsToId";
				
				}

				
			    public String Email;

				public String getEmail () {
					return this.Email;
				}

				public Boolean EmailIsNullable(){
				    return true;
				}
				public Boolean EmailIsKey(){
				    return false;
				}
				public Integer EmailLength(){
				    return 80;
				}
				public Integer EmailPrecision(){
				    return null;
				}
				public String EmailDefault(){
				
					return null;
				
				}
				public String EmailComment(){
				
				    return "";
				
				}
				public String EmailPattern(){
				
					return "";
				
				}
				public String EmailOriginalDbColumnName(){
				
					return "Email";
				
				}

				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}

				public Boolean TitleIsNullable(){
				    return true;
				}
				public Boolean TitleIsKey(){
				    return false;
				}
				public Integer TitleLength(){
				    return 128;
				}
				public Integer TitlePrecision(){
				    return null;
				}
				public String TitleDefault(){
				
					return null;
				
				}
				public String TitleComment(){
				
				    return "";
				
				}
				public String TitlePattern(){
				
					return "";
				
				}
				public String TitleOriginalDbColumnName(){
				
					return "Title";
				
				}

				
			    public String Department;

				public String getDepartment () {
					return this.Department;
				}

				public Boolean DepartmentIsNullable(){
				    return true;
				}
				public Boolean DepartmentIsKey(){
				    return false;
				}
				public Integer DepartmentLength(){
				    return 80;
				}
				public Integer DepartmentPrecision(){
				    return null;
				}
				public String DepartmentDefault(){
				
					return null;
				
				}
				public String DepartmentComment(){
				
				    return "";
				
				}
				public String DepartmentPattern(){
				
					return "";
				
				}
				public String DepartmentOriginalDbColumnName(){
				
					return "Department";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastActivityDate;

				public java.util.Date getLastActivityDate () {
					return this.LastActivityDate;
				}

				public Boolean LastActivityDateIsNullable(){
				    return true;
				}
				public Boolean LastActivityDateIsKey(){
				    return false;
				}
				public Integer LastActivityDateLength(){
				    return null;
				}
				public Integer LastActivityDatePrecision(){
				    return null;
				}
				public String LastActivityDateDefault(){
				
					return null;
				
				}
				public String LastActivityDateComment(){
				
				    return "";
				
				}
				public String LastActivityDatePattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String LastActivityDateOriginalDbColumnName(){
				
					return "LastActivityDate";
				
				}

				
			    public java.util.Date LastCURequestDate;

				public java.util.Date getLastCURequestDate () {
					return this.LastCURequestDate;
				}

				public Boolean LastCURequestDateIsNullable(){
				    return true;
				}
				public Boolean LastCURequestDateIsKey(){
				    return false;
				}
				public Integer LastCURequestDateLength(){
				    return null;
				}
				public Integer LastCURequestDatePrecision(){
				    return null;
				}
				public String LastCURequestDateDefault(){
				
					return null;
				
				}
				public String LastCURequestDateComment(){
				
				    return "";
				
				}
				public String LastCURequestDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCURequestDateOriginalDbColumnName(){
				
					return "LastCURequestDate";
				
				}

				
			    public java.util.Date LastCUUpdateDate;

				public java.util.Date getLastCUUpdateDate () {
					return this.LastCUUpdateDate;
				}

				public Boolean LastCUUpdateDateIsNullable(){
				    return true;
				}
				public Boolean LastCUUpdateDateIsKey(){
				    return false;
				}
				public Integer LastCUUpdateDateLength(){
				    return null;
				}
				public Integer LastCUUpdateDatePrecision(){
				    return null;
				}
				public String LastCUUpdateDateDefault(){
				
					return null;
				
				}
				public String LastCUUpdateDateComment(){
				
				    return "";
				
				}
				public String LastCUUpdateDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCUUpdateDateOriginalDbColumnName(){
				
					return "LastCUUpdateDate";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public String EmailBouncedReason;

				public String getEmailBouncedReason () {
					return this.EmailBouncedReason;
				}

				public Boolean EmailBouncedReasonIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedReasonIsKey(){
				    return false;
				}
				public Integer EmailBouncedReasonLength(){
				    return 255;
				}
				public Integer EmailBouncedReasonPrecision(){
				    return null;
				}
				public String EmailBouncedReasonDefault(){
				
					return null;
				
				}
				public String EmailBouncedReasonComment(){
				
				    return "";
				
				}
				public String EmailBouncedReasonPattern(){
				
					return "";
				
				}
				public String EmailBouncedReasonOriginalDbColumnName(){
				
					return "EmailBouncedReason";
				
				}

				
			    public java.util.Date EmailBouncedDate;

				public java.util.Date getEmailBouncedDate () {
					return this.EmailBouncedDate;
				}

				public Boolean EmailBouncedDateIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedDateIsKey(){
				    return false;
				}
				public Integer EmailBouncedDateLength(){
				    return null;
				}
				public Integer EmailBouncedDatePrecision(){
				    return null;
				}
				public String EmailBouncedDateDefault(){
				
					return null;
				
				}
				public String EmailBouncedDateComment(){
				
				    return "";
				
				}
				public String EmailBouncedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String EmailBouncedDateOriginalDbColumnName(){
				
					return "EmailBouncedDate";
				
				}

				
			    public boolean IsEmailBounced;

				public boolean getIsEmailBounced () {
					return this.IsEmailBounced;
				}

				public Boolean IsEmailBouncedIsNullable(){
				    return false;
				}
				public Boolean IsEmailBouncedIsKey(){
				    return false;
				}
				public Integer IsEmailBouncedLength(){
				    return null;
				}
				public Integer IsEmailBouncedPrecision(){
				    return null;
				}
				public String IsEmailBouncedDefault(){
				
					return null;
				
				}
				public String IsEmailBouncedComment(){
				
				    return "";
				
				}
				public String IsEmailBouncedPattern(){
				
					return "";
				
				}
				public String IsEmailBouncedOriginalDbColumnName(){
				
					return "IsEmailBounced";
				
				}

				
			    public String PhotoUrl;

				public String getPhotoUrl () {
					return this.PhotoUrl;
				}

				public Boolean PhotoUrlIsNullable(){
				    return true;
				}
				public Boolean PhotoUrlIsKey(){
				    return false;
				}
				public Integer PhotoUrlLength(){
				    return 255;
				}
				public Integer PhotoUrlPrecision(){
				    return null;
				}
				public String PhotoUrlDefault(){
				
					return null;
				
				}
				public String PhotoUrlComment(){
				
				    return "";
				
				}
				public String PhotoUrlPattern(){
				
					return "";
				
				}
				public String PhotoUrlOriginalDbColumnName(){
				
					return "PhotoUrl";
				
				}

				
			    public String Jigsaw;

				public String getJigsaw () {
					return this.Jigsaw;
				}

				public Boolean JigsawIsNullable(){
				    return true;
				}
				public Boolean JigsawIsKey(){
				    return false;
				}
				public Integer JigsawLength(){
				    return 20;
				}
				public Integer JigsawPrecision(){
				    return null;
				}
				public String JigsawDefault(){
				
					return null;
				
				}
				public String JigsawComment(){
				
				    return "";
				
				}
				public String JigsawPattern(){
				
					return "";
				
				}
				public String JigsawOriginalDbColumnName(){
				
					return "Jigsaw";
				
				}

				
			    public String JigsawContactId;

				public String getJigsawContactId () {
					return this.JigsawContactId;
				}

				public Boolean JigsawContactIdIsNullable(){
				    return true;
				}
				public Boolean JigsawContactIdIsKey(){
				    return false;
				}
				public Integer JigsawContactIdLength(){
				    return 20;
				}
				public Integer JigsawContactIdPrecision(){
				    return null;
				}
				public String JigsawContactIdDefault(){
				
					return null;
				
				}
				public String JigsawContactIdComment(){
				
				    return "";
				
				}
				public String JigsawContactIdPattern(){
				
					return "";
				
				}
				public String JigsawContactIdOriginalDbColumnName(){
				
					return "JigsawContactId";
				
				}

				
			    public String RL_AccountingMail__c;

				public String getRL_AccountingMail__c () {
					return this.RL_AccountingMail__c;
				}

				public Boolean RL_AccountingMail__cIsNullable(){
				    return true;
				}
				public Boolean RL_AccountingMail__cIsKey(){
				    return false;
				}
				public Integer RL_AccountingMail__cLength(){
				    return 80;
				}
				public Integer RL_AccountingMail__cPrecision(){
				    return null;
				}
				public String RL_AccountingMail__cDefault(){
				
					return null;
				
				}
				public String RL_AccountingMail__cComment(){
				
				    return "";
				
				}
				public String RL_AccountingMail__cPattern(){
				
					return "";
				
				}
				public String RL_AccountingMail__cOriginalDbColumnName(){
				
					return "RL_AccountingMail__c";
				
				}

				
			    public String RL_Agency__c;

				public String getRL_Agency__c () {
					return this.RL_Agency__c;
				}

				public Boolean RL_Agency__cIsNullable(){
				    return true;
				}
				public Boolean RL_Agency__cIsKey(){
				    return false;
				}
				public Integer RL_Agency__cLength(){
				    return 45;
				}
				public Integer RL_Agency__cPrecision(){
				    return null;
				}
				public String RL_Agency__cDefault(){
				
					return null;
				
				}
				public String RL_Agency__cComment(){
				
				    return "";
				
				}
				public String RL_Agency__cPattern(){
				
					return "";
				
				}
				public String RL_Agency__cOriginalDbColumnName(){
				
					return "RL_Agency__c";
				
				}

				
			    public String RL_BankCode__c;

				public String getRL_BankCode__c () {
					return this.RL_BankCode__c;
				}

				public Boolean RL_BankCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankCode__cIsKey(){
				    return false;
				}
				public Integer RL_BankCode__cLength(){
				    return 45;
				}
				public Integer RL_BankCode__cPrecision(){
				    return null;
				}
				public String RL_BankCode__cDefault(){
				
					return null;
				
				}
				public String RL_BankCode__cComment(){
				
				    return "";
				
				}
				public String RL_BankCode__cPattern(){
				
					return "";
				
				}
				public String RL_BankCode__cOriginalDbColumnName(){
				
					return "RL_BankCode__c";
				
				}

				
			    public String RL_BankKey__c;

				public String getRL_BankKey__c () {
					return this.RL_BankKey__c;
				}

				public Boolean RL_BankKey__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankKey__cIsKey(){
				    return false;
				}
				public Integer RL_BankKey__cLength(){
				    return 45;
				}
				public Integer RL_BankKey__cPrecision(){
				    return null;
				}
				public String RL_BankKey__cDefault(){
				
					return null;
				
				}
				public String RL_BankKey__cComment(){
				
				    return "";
				
				}
				public String RL_BankKey__cPattern(){
				
					return "";
				
				}
				public String RL_BankKey__cOriginalDbColumnName(){
				
					return "RL_BankKey__c";
				
				}

				
			    public String RL_BillingCity__c;

				public String getRL_BillingCity__c () {
					return this.RL_BillingCity__c;
				}

				public Boolean RL_BillingCity__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCity__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCity__cLength(){
				    return 45;
				}
				public Integer RL_BillingCity__cPrecision(){
				    return null;
				}
				public String RL_BillingCity__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCity__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCity__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCity__cOriginalDbColumnName(){
				
					return "RL_BillingCity__c";
				
				}

				
			    public String RL_BillingCountry__c;

				public String getRL_BillingCountry__c () {
					return this.RL_BillingCountry__c;
				}

				public Boolean RL_BillingCountry__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCountry__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCountry__cLength(){
				    return 45;
				}
				public Integer RL_BillingCountry__cPrecision(){
				    return null;
				}
				public String RL_BillingCountry__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCountry__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCountry__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCountry__cOriginalDbColumnName(){
				
					return "RL_BillingCountry__c";
				
				}

				
			    public String RL_BillingName__c;

				public String getRL_BillingName__c () {
					return this.RL_BillingName__c;
				}

				public Boolean RL_BillingName__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingName__cIsKey(){
				    return false;
				}
				public Integer RL_BillingName__cLength(){
				    return 45;
				}
				public Integer RL_BillingName__cPrecision(){
				    return null;
				}
				public String RL_BillingName__cDefault(){
				
					return null;
				
				}
				public String RL_BillingName__cComment(){
				
				    return "";
				
				}
				public String RL_BillingName__cPattern(){
				
					return "";
				
				}
				public String RL_BillingName__cOriginalDbColumnName(){
				
					return "RL_BillingName__c";
				
				}

				
			    public String RL_BillingStreetNumber__c;

				public String getRL_BillingStreetNumber__c () {
					return this.RL_BillingStreetNumber__c;
				}

				public Boolean RL_BillingStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_BillingStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreetNumber__cOriginalDbColumnName(){
				
					return "RL_BillingStreetNumber__c";
				
				}

				
			    public String RL_BillingStreet__c;

				public String getRL_BillingStreet__c () {
					return this.RL_BillingStreet__c;
				}

				public Boolean RL_BillingStreet__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreet__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreet__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreet__cPrecision(){
				    return null;
				}
				public String RL_BillingStreet__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreet__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreet__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreet__cOriginalDbColumnName(){
				
					return "RL_BillingStreet__c";
				
				}

				
			    public String RL_BillingTel1__c;

				public String getRL_BillingTel1__c () {
					return this.RL_BillingTel1__c;
				}

				public Boolean RL_BillingTel1__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel1__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel1__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel1__cPrecision(){
				    return null;
				}
				public String RL_BillingTel1__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel1__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel1__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel1__cOriginalDbColumnName(){
				
					return "RL_BillingTel1__c";
				
				}

				
			    public String RL_BillingTel2__c;

				public String getRL_BillingTel2__c () {
					return this.RL_BillingTel2__c;
				}

				public Boolean RL_BillingTel2__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel2__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel2__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel2__cPrecision(){
				    return null;
				}
				public String RL_BillingTel2__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel2__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel2__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel2__cOriginalDbColumnName(){
				
					return "RL_BillingTel2__c";
				
				}

				
			    public String RL_BillingTel3__c;

				public String getRL_BillingTel3__c () {
					return this.RL_BillingTel3__c;
				}

				public Boolean RL_BillingTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel3__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel3__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel3__cPrecision(){
				    return null;
				}
				public String RL_BillingTel3__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel3__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel3__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel3__cOriginalDbColumnName(){
				
					return "RL_BillingTel3__c";
				
				}

				
			    public Double RL_CodeSettlement__c;

				public Double getRL_CodeSettlement__c () {
					return this.RL_CodeSettlement__c;
				}

				public Boolean RL_CodeSettlement__cIsNullable(){
				    return true;
				}
				public Boolean RL_CodeSettlement__cIsKey(){
				    return false;
				}
				public Integer RL_CodeSettlement__cLength(){
				    return 11;
				}
				public Integer RL_CodeSettlement__cPrecision(){
				    return null;
				}
				public String RL_CodeSettlement__cDefault(){
				
					return null;
				
				}
				public String RL_CodeSettlement__cComment(){
				
				    return "";
				
				}
				public String RL_CodeSettlement__cPattern(){
				
					return "";
				
				}
				public String RL_CodeSettlement__cOriginalDbColumnName(){
				
					return "RL_CodeSettlement__c";
				
				}

				
			    public java.util.Date RL_CreatedAt__c;

				public java.util.Date getRL_CreatedAt__c () {
					return this.RL_CreatedAt__c;
				}

				public Boolean RL_CreatedAt__cIsNullable(){
				    return true;
				}
				public Boolean RL_CreatedAt__cIsKey(){
				    return false;
				}
				public Integer RL_CreatedAt__cLength(){
				    return null;
				}
				public Integer RL_CreatedAt__cPrecision(){
				    return null;
				}
				public String RL_CreatedAt__cDefault(){
				
					return null;
				
				}
				public String RL_CreatedAt__cComment(){
				
				    return "";
				
				}
				public String RL_CreatedAt__cPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String RL_CreatedAt__cOriginalDbColumnName(){
				
					return "RL_CreatedAt__c";
				
				}

				
			    public String RL_Email__c;

				public String getRL_Email__c () {
					return this.RL_Email__c;
				}

				public Boolean RL_Email__cIsNullable(){
				    return true;
				}
				public Boolean RL_Email__cIsKey(){
				    return false;
				}
				public Integer RL_Email__cLength(){
				    return 255;
				}
				public Integer RL_Email__cPrecision(){
				    return null;
				}
				public String RL_Email__cDefault(){
				
					return null;
				
				}
				public String RL_Email__cComment(){
				
				    return "";
				
				}
				public String RL_Email__cPattern(){
				
					return "";
				
				}
				public String RL_Email__cOriginalDbColumnName(){
				
					return "RL_Email__c";
				
				}

				
			    public Double RL_ExternalAccountId__c;

				public Double getRL_ExternalAccountId__c () {
					return this.RL_ExternalAccountId__c;
				}

				public Boolean RL_ExternalAccountId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalAccountId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalAccountId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalAccountId__cPrecision(){
				    return null;
				}
				public String RL_ExternalAccountId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalAccountId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalAccountId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalAccountId__cOriginalDbColumnName(){
				
					return "RL_ExternalAccountId__c";
				
				}

				
			    public Integer RL_ExternalId__c;

				public Integer getRL_ExternalId__c () {
					return this.RL_ExternalId__c;
				}

				public Boolean RL_ExternalId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalId__cPrecision(){
				    return null;
				}
				public String RL_ExternalId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalId__cOriginalDbColumnName(){
				
					return "RL_ExternalId__c";
				
				}

				
			    public Double RL_IsActive__c;

				public Double getRL_IsActive__c () {
					return this.RL_IsActive__c;
				}

				public Boolean RL_IsActive__cIsNullable(){
				    return true;
				}
				public Boolean RL_IsActive__cIsKey(){
				    return false;
				}
				public Integer RL_IsActive__cLength(){
				    return 1;
				}
				public Integer RL_IsActive__cPrecision(){
				    return null;
				}
				public String RL_IsActive__cDefault(){
				
					return null;
				
				}
				public String RL_IsActive__cComment(){
				
				    return "";
				
				}
				public String RL_IsActive__cPattern(){
				
					return "";
				
				}
				public String RL_IsActive__cOriginalDbColumnName(){
				
					return "RL_IsActive__c";
				
				}

				
			    public String RL_RecoveryPostalCode__c;

				public String getRL_RecoveryPostalCode__c () {
					return this.RL_RecoveryPostalCode__c;
				}

				public Boolean RL_RecoveryPostalCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_RecoveryPostalCode__cIsKey(){
				    return false;
				}
				public Integer RL_RecoveryPostalCode__cLength(){
				    return 255;
				}
				public Integer RL_RecoveryPostalCode__cPrecision(){
				    return null;
				}
				public String RL_RecoveryPostalCode__cDefault(){
				
					return null;
				
				}
				public String RL_RecoveryPostalCode__cComment(){
				
				    return "";
				
				}
				public String RL_RecoveryPostalCode__cPattern(){
				
					return "";
				
				}
				public String RL_RecoveryPostalCode__cOriginalDbColumnName(){
				
					return "RL_RecoveryPostalCode__c";
				
				}

				
			    public String RL_RemovalStreetNumber__c;

				public String getRL_RemovalStreetNumber__c () {
					return this.RL_RemovalStreetNumber__c;
				}

				public Boolean RL_RemovalStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_RemovalStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_RemovalStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalStreetNumber__cOriginalDbColumnName(){
				
					return "RL_RemovalStreetNumber__c";
				
				}

				
			    public String RL_RemovalTel3__c;

				public String getRL_RemovalTel3__c () {
					return this.RL_RemovalTel3__c;
				}

				public Boolean RL_RemovalTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalTel3__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalTel3__cLength(){
				    return 40;
				}
				public Integer RL_RemovalTel3__cPrecision(){
				    return null;
				}
				public String RL_RemovalTel3__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalTel3__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalTel3__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalTel3__cOriginalDbColumnName(){
				
					return "RL_RemovalTel3__c";
				
				}

				
			    public String Code_Client__c;

				public String getCode_Client__c () {
					return this.Code_Client__c;
				}

				public Boolean Code_Client__cIsNullable(){
				    return true;
				}
				public Boolean Code_Client__cIsKey(){
				    return false;
				}
				public Integer Code_Client__cLength(){
				    return 30;
				}
				public Integer Code_Client__cPrecision(){
				    return null;
				}
				public String Code_Client__cDefault(){
				
					return null;
				
				}
				public String Code_Client__cComment(){
				
				    return "";
				
				}
				public String Code_Client__cPattern(){
				
					return "";
				
				}
				public String Code_Client__cOriginalDbColumnName(){
				
					return "Code_Client__c";
				
				}

				
			    public String Data_Quality_Description__c;

				public String getData_Quality_Description__c () {
					return this.Data_Quality_Description__c;
				}

				public Boolean Data_Quality_Description__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Description__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Description__cLength(){
				    return 1300;
				}
				public Integer Data_Quality_Description__cPrecision(){
				    return null;
				}
				public String Data_Quality_Description__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Description__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Description__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Description__cOriginalDbColumnName(){
				
					return "Data_Quality_Description__c";
				
				}

				
			    public Double Data_Quality_Score__c;

				public Double getData_Quality_Score__c () {
					return this.Data_Quality_Score__c;
				}

				public Boolean Data_Quality_Score__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Score__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Score__cLength(){
				    return 18;
				}
				public Integer Data_Quality_Score__cPrecision(){
				    return null;
				}
				public String Data_Quality_Score__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Score__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Score__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Score__cOriginalDbColumnName(){
				
					return "Data_Quality_Score__c";
				
				}

				
			    public String RL_Company__c;

				public String getRL_Company__c () {
					return this.RL_Company__c;
				}

				public Boolean RL_Company__cIsNullable(){
				    return true;
				}
				public Boolean RL_Company__cIsKey(){
				    return false;
				}
				public Integer RL_Company__cLength(){
				    return 45;
				}
				public Integer RL_Company__cPrecision(){
				    return null;
				}
				public String RL_Company__cDefault(){
				
					return null;
				
				}
				public String RL_Company__cComment(){
				
				    return "";
				
				}
				public String RL_Company__cPattern(){
				
					return "";
				
				}
				public String RL_Company__cOriginalDbColumnName(){
				
					return "RL_Company__c";
				
				}

				
			    public String RL_Removal_iso3_country__c;

				public String getRL_Removal_iso3_country__c () {
					return this.RL_Removal_iso3_country__c;
				}

				public Boolean RL_Removal_iso3_country__cIsNullable(){
				    return true;
				}
				public Boolean RL_Removal_iso3_country__cIsKey(){
				    return false;
				}
				public Integer RL_Removal_iso3_country__cLength(){
				    return 45;
				}
				public Integer RL_Removal_iso3_country__cPrecision(){
				    return null;
				}
				public String RL_Removal_iso3_country__cDefault(){
				
					return null;
				
				}
				public String RL_Removal_iso3_country__cComment(){
				
				    return "";
				
				}
				public String RL_Removal_iso3_country__cPattern(){
				
					return "";
				
				}
				public String RL_Removal_iso3_country__cOriginalDbColumnName(){
				
					return "RL_Removal_iso3_country__c";
				
				}

				
			    public boolean RL_Archived__c;

				public boolean getRL_Archived__c () {
					return this.RL_Archived__c;
				}

				public Boolean RL_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Archived__cLength(){
				    return null;
				}
				public Integer RL_Archived__cPrecision(){
				    return null;
				}
				public String RL_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Archived__cOriginalDbColumnName(){
				
					return "RL_Archived__c";
				
				}

				
			    public boolean RL_Tarification_par_palier__c;

				public boolean getRL_Tarification_par_palier__c () {
					return this.RL_Tarification_par_palier__c;
				}

				public Boolean RL_Tarification_par_palier__cIsNullable(){
				    return false;
				}
				public Boolean RL_Tarification_par_palier__cIsKey(){
				    return false;
				}
				public Integer RL_Tarification_par_palier__cLength(){
				    return null;
				}
				public Integer RL_Tarification_par_palier__cPrecision(){
				    return null;
				}
				public String RL_Tarification_par_palier__cDefault(){
				
					return null;
				
				}
				public String RL_Tarification_par_palier__cComment(){
				
				    return "";
				
				}
				public String RL_Tarification_par_palier__cPattern(){
				
					return "";
				
				}
				public String RL_Tarification_par_palier__cOriginalDbColumnName(){
				
					return "RL_Tarification_par_palier__c";
				
				}

				
			    public String Contact_Commercial__c;

				public String getContact_Commercial__c () {
					return this.Contact_Commercial__c;
				}

				public Boolean Contact_Commercial__cIsNullable(){
				    return true;
				}
				public Boolean Contact_Commercial__cIsKey(){
				    return false;
				}
				public Integer Contact_Commercial__cLength(){
				    return 255;
				}
				public Integer Contact_Commercial__cPrecision(){
				    return null;
				}
				public String Contact_Commercial__cDefault(){
				
					return null;
				
				}
				public String Contact_Commercial__cComment(){
				
				    return "";
				
				}
				public String Contact_Commercial__cPattern(){
				
					return "";
				
				}
				public String Contact_Commercial__cOriginalDbColumnName(){
				
					return "Contact_Commercial__c";
				
				}

				
			    public String SocieteInfo__Id__c;

				public String getSocieteInfo__Id__c () {
					return this.SocieteInfo__Id__c;
				}

				public Boolean SocieteInfo__Id__cIsNullable(){
				    return true;
				}
				public Boolean SocieteInfo__Id__cIsKey(){
				    return false;
				}
				public Integer SocieteInfo__Id__cLength(){
				    return 80;
				}
				public Integer SocieteInfo__Id__cPrecision(){
				    return null;
				}
				public String SocieteInfo__Id__cDefault(){
				
					return null;
				
				}
				public String SocieteInfo__Id__cComment(){
				
				    return "";
				
				}
				public String SocieteInfo__Id__cPattern(){
				
					return "";
				
				}
				public String SocieteInfo__Id__cOriginalDbColumnName(){
				
					return "SocieteInfo__Id__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
						this.RL_ExternalId__c = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Integer
				
						writeInteger(this.RL_ExternalId__c,dos);
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Integer
				
						writeInteger(this.RL_ExternalId__c,dos);
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",MasterRecordId="+MasterRecordId);
		sb.append(",AccountId="+AccountId);
		sb.append(",LastName="+LastName);
		sb.append(",FirstName="+FirstName);
		sb.append(",Salutation="+Salutation);
		sb.append(",MiddleName="+MiddleName);
		sb.append(",Suffix="+Suffix);
		sb.append(",Name="+Name);
		sb.append(",RecordTypeId="+RecordTypeId);
		sb.append(",MailingStreet="+MailingStreet);
		sb.append(",MailingCity="+MailingCity);
		sb.append(",MailingState="+MailingState);
		sb.append(",MailingPostalCode="+MailingPostalCode);
		sb.append(",MailingCountry="+MailingCountry);
		sb.append(",MailingLatitude="+String.valueOf(MailingLatitude));
		sb.append(",MailingLongitude="+String.valueOf(MailingLongitude));
		sb.append(",MailingGeocodeAccuracy="+MailingGeocodeAccuracy);
		sb.append(",MailingAddress="+MailingAddress);
		sb.append(",Phone="+Phone);
		sb.append(",Fax="+Fax);
		sb.append(",MobilePhone="+MobilePhone);
		sb.append(",ReportsToId="+ReportsToId);
		sb.append(",Email="+Email);
		sb.append(",Title="+Title);
		sb.append(",Department="+Department);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastActivityDate="+String.valueOf(LastActivityDate));
		sb.append(",LastCURequestDate="+String.valueOf(LastCURequestDate));
		sb.append(",LastCUUpdateDate="+String.valueOf(LastCUUpdateDate));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",EmailBouncedReason="+EmailBouncedReason);
		sb.append(",EmailBouncedDate="+String.valueOf(EmailBouncedDate));
		sb.append(",IsEmailBounced="+String.valueOf(IsEmailBounced));
		sb.append(",PhotoUrl="+PhotoUrl);
		sb.append(",Jigsaw="+Jigsaw);
		sb.append(",JigsawContactId="+JigsawContactId);
		sb.append(",RL_AccountingMail__c="+RL_AccountingMail__c);
		sb.append(",RL_Agency__c="+RL_Agency__c);
		sb.append(",RL_BankCode__c="+RL_BankCode__c);
		sb.append(",RL_BankKey__c="+RL_BankKey__c);
		sb.append(",RL_BillingCity__c="+RL_BillingCity__c);
		sb.append(",RL_BillingCountry__c="+RL_BillingCountry__c);
		sb.append(",RL_BillingName__c="+RL_BillingName__c);
		sb.append(",RL_BillingStreetNumber__c="+RL_BillingStreetNumber__c);
		sb.append(",RL_BillingStreet__c="+RL_BillingStreet__c);
		sb.append(",RL_BillingTel1__c="+RL_BillingTel1__c);
		sb.append(",RL_BillingTel2__c="+RL_BillingTel2__c);
		sb.append(",RL_BillingTel3__c="+RL_BillingTel3__c);
		sb.append(",RL_CodeSettlement__c="+String.valueOf(RL_CodeSettlement__c));
		sb.append(",RL_CreatedAt__c="+String.valueOf(RL_CreatedAt__c));
		sb.append(",RL_Email__c="+RL_Email__c);
		sb.append(",RL_ExternalAccountId__c="+String.valueOf(RL_ExternalAccountId__c));
		sb.append(",RL_ExternalId__c="+String.valueOf(RL_ExternalId__c));
		sb.append(",RL_IsActive__c="+String.valueOf(RL_IsActive__c));
		sb.append(",RL_RecoveryPostalCode__c="+RL_RecoveryPostalCode__c);
		sb.append(",RL_RemovalStreetNumber__c="+RL_RemovalStreetNumber__c);
		sb.append(",RL_RemovalTel3__c="+RL_RemovalTel3__c);
		sb.append(",Code_Client__c="+Code_Client__c);
		sb.append(",Data_Quality_Description__c="+Data_Quality_Description__c);
		sb.append(",Data_Quality_Score__c="+String.valueOf(Data_Quality_Score__c));
		sb.append(",RL_Company__c="+RL_Company__c);
		sb.append(",RL_Removal_iso3_country__c="+RL_Removal_iso3_country__c);
		sb.append(",RL_Archived__c="+String.valueOf(RL_Archived__c));
		sb.append(",RL_Tarification_par_palier__c="+String.valueOf(RL_Tarification_par_palier__c));
		sb.append(",Contact_Commercial__c="+Contact_Commercial__c);
		sb.append(",SocieteInfo__Id__c="+SocieteInfo__Id__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(MasterRecordId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MasterRecordId);
            			}
            		
        			sb.append("|");
        		
        				if(AccountId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccountId);
            			}
            		
        			sb.append("|");
        		
        				if(LastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastName);
            			}
            		
        			sb.append("|");
        		
        				if(FirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FirstName);
            			}
            		
        			sb.append("|");
        		
        				if(Salutation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Salutation);
            			}
            		
        			sb.append("|");
        		
        				if(MiddleName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MiddleName);
            			}
            		
        			sb.append("|");
        		
        				if(Suffix == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Suffix);
            			}
            		
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(RecordTypeId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RecordTypeId);
            			}
            		
        			sb.append("|");
        		
        				if(MailingStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingStreet);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCity);
            			}
            		
        			sb.append("|");
        		
        				if(MailingState == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingState);
            			}
            		
        			sb.append("|");
        		
        				if(MailingPostalCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingPostalCode);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCountry);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLatitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLatitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLongitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLongitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingGeocodeAccuracy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingGeocodeAccuracy);
            			}
            		
        			sb.append("|");
        		
        				if(MailingAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingAddress);
            			}
            		
        			sb.append("|");
        		
        				if(Phone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Phone);
            			}
            		
        			sb.append("|");
        		
        				if(Fax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Fax);
            			}
            		
        			sb.append("|");
        		
        				if(MobilePhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MobilePhone);
            			}
            		
        			sb.append("|");
        		
        				if(ReportsToId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ReportsToId);
            			}
            		
        			sb.append("|");
        		
        				if(Email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Email);
            			}
            		
        			sb.append("|");
        		
        				if(Title == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Title);
            			}
            		
        			sb.append("|");
        		
        				if(Department == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Department);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastActivityDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastActivityDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCURequestDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCURequestDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCUUpdateDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCUUpdateDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedReason);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsEmailBounced);
        			
        			sb.append("|");
        		
        				if(PhotoUrl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoUrl);
            			}
            		
        			sb.append("|");
        		
        				if(Jigsaw == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jigsaw);
            			}
            		
        			sb.append("|");
        		
        				if(JigsawContactId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JigsawContactId);
            			}
            		
        			sb.append("|");
        		
        				if(RL_AccountingMail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_AccountingMail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Agency__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Agency__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankKey__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankKey__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCountry__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCountry__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingName__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingName__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreet__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreet__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel1__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel1__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel2__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel2__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CodeSettlement__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CodeSettlement__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CreatedAt__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CreatedAt__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Email__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Email__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalAccountId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalAccountId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_IsActive__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_IsActive__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RecoveryPostalCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RecoveryPostalCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(Code_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Description__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Description__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Score__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Score__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Company__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Company__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Removal_iso3_country__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Removal_iso3_country__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Archived__c);
        			
        			sb.append("|");
        		
        				sb.append(RL_Tarification_par_palier__c);
        			
        			sb.append("|");
        		
        				if(Contact_Commercial__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact_Commercial__c);
            			}
            		
        			sb.append("|");
        		
        				if(SocieteInfo__Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SocieteInfo__Id__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String MasterRecordId;

				public String getMasterRecordId () {
					return this.MasterRecordId;
				}

				public Boolean MasterRecordIdIsNullable(){
				    return true;
				}
				public Boolean MasterRecordIdIsKey(){
				    return false;
				}
				public Integer MasterRecordIdLength(){
				    return 18;
				}
				public Integer MasterRecordIdPrecision(){
				    return null;
				}
				public String MasterRecordIdDefault(){
				
					return null;
				
				}
				public String MasterRecordIdComment(){
				
				    return "";
				
				}
				public String MasterRecordIdPattern(){
				
					return "";
				
				}
				public String MasterRecordIdOriginalDbColumnName(){
				
					return "MasterRecordId";
				
				}

				
			    public String AccountId;

				public String getAccountId () {
					return this.AccountId;
				}

				public Boolean AccountIdIsNullable(){
				    return true;
				}
				public Boolean AccountIdIsKey(){
				    return false;
				}
				public Integer AccountIdLength(){
				    return 18;
				}
				public Integer AccountIdPrecision(){
				    return null;
				}
				public String AccountIdDefault(){
				
					return null;
				
				}
				public String AccountIdComment(){
				
				    return "";
				
				}
				public String AccountIdPattern(){
				
					return "";
				
				}
				public String AccountIdOriginalDbColumnName(){
				
					return "AccountId";
				
				}

				
			    public String LastName;

				public String getLastName () {
					return this.LastName;
				}

				public Boolean LastNameIsNullable(){
				    return false;
				}
				public Boolean LastNameIsKey(){
				    return false;
				}
				public Integer LastNameLength(){
				    return 80;
				}
				public Integer LastNamePrecision(){
				    return null;
				}
				public String LastNameDefault(){
				
					return null;
				
				}
				public String LastNameComment(){
				
				    return "";
				
				}
				public String LastNamePattern(){
				
					return "";
				
				}
				public String LastNameOriginalDbColumnName(){
				
					return "LastName";
				
				}

				
			    public String FirstName;

				public String getFirstName () {
					return this.FirstName;
				}

				public Boolean FirstNameIsNullable(){
				    return true;
				}
				public Boolean FirstNameIsKey(){
				    return false;
				}
				public Integer FirstNameLength(){
				    return 40;
				}
				public Integer FirstNamePrecision(){
				    return null;
				}
				public String FirstNameDefault(){
				
					return null;
				
				}
				public String FirstNameComment(){
				
				    return "";
				
				}
				public String FirstNamePattern(){
				
					return "";
				
				}
				public String FirstNameOriginalDbColumnName(){
				
					return "FirstName";
				
				}

				
			    public String Salutation;

				public String getSalutation () {
					return this.Salutation;
				}

				public Boolean SalutationIsNullable(){
				    return true;
				}
				public Boolean SalutationIsKey(){
				    return false;
				}
				public Integer SalutationLength(){
				    return 40;
				}
				public Integer SalutationPrecision(){
				    return null;
				}
				public String SalutationDefault(){
				
					return null;
				
				}
				public String SalutationComment(){
				
				    return "";
				
				}
				public String SalutationPattern(){
				
					return "";
				
				}
				public String SalutationOriginalDbColumnName(){
				
					return "Salutation";
				
				}

				
			    public String MiddleName;

				public String getMiddleName () {
					return this.MiddleName;
				}

				public Boolean MiddleNameIsNullable(){
				    return true;
				}
				public Boolean MiddleNameIsKey(){
				    return false;
				}
				public Integer MiddleNameLength(){
				    return 40;
				}
				public Integer MiddleNamePrecision(){
				    return null;
				}
				public String MiddleNameDefault(){
				
					return null;
				
				}
				public String MiddleNameComment(){
				
				    return "";
				
				}
				public String MiddleNamePattern(){
				
					return "";
				
				}
				public String MiddleNameOriginalDbColumnName(){
				
					return "MiddleName";
				
				}

				
			    public String Suffix;

				public String getSuffix () {
					return this.Suffix;
				}

				public Boolean SuffixIsNullable(){
				    return true;
				}
				public Boolean SuffixIsKey(){
				    return false;
				}
				public Integer SuffixLength(){
				    return 40;
				}
				public Integer SuffixPrecision(){
				    return null;
				}
				public String SuffixDefault(){
				
					return null;
				
				}
				public String SuffixComment(){
				
				    return "";
				
				}
				public String SuffixPattern(){
				
					return "";
				
				}
				public String SuffixOriginalDbColumnName(){
				
					return "Suffix";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return false;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 121;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String RecordTypeId;

				public String getRecordTypeId () {
					return this.RecordTypeId;
				}

				public Boolean RecordTypeIdIsNullable(){
				    return true;
				}
				public Boolean RecordTypeIdIsKey(){
				    return false;
				}
				public Integer RecordTypeIdLength(){
				    return 18;
				}
				public Integer RecordTypeIdPrecision(){
				    return null;
				}
				public String RecordTypeIdDefault(){
				
					return null;
				
				}
				public String RecordTypeIdComment(){
				
				    return "";
				
				}
				public String RecordTypeIdPattern(){
				
					return "";
				
				}
				public String RecordTypeIdOriginalDbColumnName(){
				
					return "RecordTypeId";
				
				}

				
			    public String MailingStreet;

				public String getMailingStreet () {
					return this.MailingStreet;
				}

				public Boolean MailingStreetIsNullable(){
				    return true;
				}
				public Boolean MailingStreetIsKey(){
				    return false;
				}
				public Integer MailingStreetLength(){
				    return 255;
				}
				public Integer MailingStreetPrecision(){
				    return null;
				}
				public String MailingStreetDefault(){
				
					return null;
				
				}
				public String MailingStreetComment(){
				
				    return "";
				
				}
				public String MailingStreetPattern(){
				
					return "";
				
				}
				public String MailingStreetOriginalDbColumnName(){
				
					return "MailingStreet";
				
				}

				
			    public String MailingCity;

				public String getMailingCity () {
					return this.MailingCity;
				}

				public Boolean MailingCityIsNullable(){
				    return true;
				}
				public Boolean MailingCityIsKey(){
				    return false;
				}
				public Integer MailingCityLength(){
				    return 40;
				}
				public Integer MailingCityPrecision(){
				    return null;
				}
				public String MailingCityDefault(){
				
					return null;
				
				}
				public String MailingCityComment(){
				
				    return "";
				
				}
				public String MailingCityPattern(){
				
					return "";
				
				}
				public String MailingCityOriginalDbColumnName(){
				
					return "MailingCity";
				
				}

				
			    public String MailingState;

				public String getMailingState () {
					return this.MailingState;
				}

				public Boolean MailingStateIsNullable(){
				    return true;
				}
				public Boolean MailingStateIsKey(){
				    return false;
				}
				public Integer MailingStateLength(){
				    return 80;
				}
				public Integer MailingStatePrecision(){
				    return null;
				}
				public String MailingStateDefault(){
				
					return null;
				
				}
				public String MailingStateComment(){
				
				    return "";
				
				}
				public String MailingStatePattern(){
				
					return "";
				
				}
				public String MailingStateOriginalDbColumnName(){
				
					return "MailingState";
				
				}

				
			    public String MailingPostalCode;

				public String getMailingPostalCode () {
					return this.MailingPostalCode;
				}

				public Boolean MailingPostalCodeIsNullable(){
				    return true;
				}
				public Boolean MailingPostalCodeIsKey(){
				    return false;
				}
				public Integer MailingPostalCodeLength(){
				    return 20;
				}
				public Integer MailingPostalCodePrecision(){
				    return null;
				}
				public String MailingPostalCodeDefault(){
				
					return null;
				
				}
				public String MailingPostalCodeComment(){
				
				    return "";
				
				}
				public String MailingPostalCodePattern(){
				
					return "";
				
				}
				public String MailingPostalCodeOriginalDbColumnName(){
				
					return "MailingPostalCode";
				
				}

				
			    public String MailingCountry;

				public String getMailingCountry () {
					return this.MailingCountry;
				}

				public Boolean MailingCountryIsNullable(){
				    return true;
				}
				public Boolean MailingCountryIsKey(){
				    return false;
				}
				public Integer MailingCountryLength(){
				    return 80;
				}
				public Integer MailingCountryPrecision(){
				    return null;
				}
				public String MailingCountryDefault(){
				
					return null;
				
				}
				public String MailingCountryComment(){
				
				    return "";
				
				}
				public String MailingCountryPattern(){
				
					return "";
				
				}
				public String MailingCountryOriginalDbColumnName(){
				
					return "MailingCountry";
				
				}

				
			    public Double MailingLatitude;

				public Double getMailingLatitude () {
					return this.MailingLatitude;
				}

				public Boolean MailingLatitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLatitudeIsKey(){
				    return false;
				}
				public Integer MailingLatitudeLength(){
				    return 18;
				}
				public Integer MailingLatitudePrecision(){
				    return 15;
				}
				public String MailingLatitudeDefault(){
				
					return null;
				
				}
				public String MailingLatitudeComment(){
				
				    return "";
				
				}
				public String MailingLatitudePattern(){
				
					return "";
				
				}
				public String MailingLatitudeOriginalDbColumnName(){
				
					return "MailingLatitude";
				
				}

				
			    public Double MailingLongitude;

				public Double getMailingLongitude () {
					return this.MailingLongitude;
				}

				public Boolean MailingLongitudeIsNullable(){
				    return true;
				}
				public Boolean MailingLongitudeIsKey(){
				    return false;
				}
				public Integer MailingLongitudeLength(){
				    return 18;
				}
				public Integer MailingLongitudePrecision(){
				    return 15;
				}
				public String MailingLongitudeDefault(){
				
					return null;
				
				}
				public String MailingLongitudeComment(){
				
				    return "";
				
				}
				public String MailingLongitudePattern(){
				
					return "";
				
				}
				public String MailingLongitudeOriginalDbColumnName(){
				
					return "MailingLongitude";
				
				}

				
			    public String MailingGeocodeAccuracy;

				public String getMailingGeocodeAccuracy () {
					return this.MailingGeocodeAccuracy;
				}

				public Boolean MailingGeocodeAccuracyIsNullable(){
				    return true;
				}
				public Boolean MailingGeocodeAccuracyIsKey(){
				    return false;
				}
				public Integer MailingGeocodeAccuracyLength(){
				    return 40;
				}
				public Integer MailingGeocodeAccuracyPrecision(){
				    return null;
				}
				public String MailingGeocodeAccuracyDefault(){
				
					return null;
				
				}
				public String MailingGeocodeAccuracyComment(){
				
				    return "";
				
				}
				public String MailingGeocodeAccuracyPattern(){
				
					return "";
				
				}
				public String MailingGeocodeAccuracyOriginalDbColumnName(){
				
					return "MailingGeocodeAccuracy";
				
				}

				
			    public String MailingAddress;

				public String getMailingAddress () {
					return this.MailingAddress;
				}

				public Boolean MailingAddressIsNullable(){
				    return true;
				}
				public Boolean MailingAddressIsKey(){
				    return false;
				}
				public Integer MailingAddressLength(){
				    return null;
				}
				public Integer MailingAddressPrecision(){
				    return null;
				}
				public String MailingAddressDefault(){
				
					return null;
				
				}
				public String MailingAddressComment(){
				
				    return "";
				
				}
				public String MailingAddressPattern(){
				
					return "";
				
				}
				public String MailingAddressOriginalDbColumnName(){
				
					return "MailingAddress";
				
				}

				
			    public String Phone;

				public String getPhone () {
					return this.Phone;
				}

				public Boolean PhoneIsNullable(){
				    return true;
				}
				public Boolean PhoneIsKey(){
				    return false;
				}
				public Integer PhoneLength(){
				    return 40;
				}
				public Integer PhonePrecision(){
				    return null;
				}
				public String PhoneDefault(){
				
					return null;
				
				}
				public String PhoneComment(){
				
				    return "";
				
				}
				public String PhonePattern(){
				
					return "";
				
				}
				public String PhoneOriginalDbColumnName(){
				
					return "Phone";
				
				}

				
			    public String Fax;

				public String getFax () {
					return this.Fax;
				}

				public Boolean FaxIsNullable(){
				    return true;
				}
				public Boolean FaxIsKey(){
				    return false;
				}
				public Integer FaxLength(){
				    return 40;
				}
				public Integer FaxPrecision(){
				    return null;
				}
				public String FaxDefault(){
				
					return null;
				
				}
				public String FaxComment(){
				
				    return "";
				
				}
				public String FaxPattern(){
				
					return "";
				
				}
				public String FaxOriginalDbColumnName(){
				
					return "Fax";
				
				}

				
			    public String MobilePhone;

				public String getMobilePhone () {
					return this.MobilePhone;
				}

				public Boolean MobilePhoneIsNullable(){
				    return true;
				}
				public Boolean MobilePhoneIsKey(){
				    return false;
				}
				public Integer MobilePhoneLength(){
				    return 40;
				}
				public Integer MobilePhonePrecision(){
				    return null;
				}
				public String MobilePhoneDefault(){
				
					return null;
				
				}
				public String MobilePhoneComment(){
				
				    return "";
				
				}
				public String MobilePhonePattern(){
				
					return "";
				
				}
				public String MobilePhoneOriginalDbColumnName(){
				
					return "MobilePhone";
				
				}

				
			    public String ReportsToId;

				public String getReportsToId () {
					return this.ReportsToId;
				}

				public Boolean ReportsToIdIsNullable(){
				    return true;
				}
				public Boolean ReportsToIdIsKey(){
				    return false;
				}
				public Integer ReportsToIdLength(){
				    return 18;
				}
				public Integer ReportsToIdPrecision(){
				    return null;
				}
				public String ReportsToIdDefault(){
				
					return null;
				
				}
				public String ReportsToIdComment(){
				
				    return "";
				
				}
				public String ReportsToIdPattern(){
				
					return "";
				
				}
				public String ReportsToIdOriginalDbColumnName(){
				
					return "ReportsToId";
				
				}

				
			    public String Email;

				public String getEmail () {
					return this.Email;
				}

				public Boolean EmailIsNullable(){
				    return true;
				}
				public Boolean EmailIsKey(){
				    return false;
				}
				public Integer EmailLength(){
				    return 80;
				}
				public Integer EmailPrecision(){
				    return null;
				}
				public String EmailDefault(){
				
					return null;
				
				}
				public String EmailComment(){
				
				    return "";
				
				}
				public String EmailPattern(){
				
					return "";
				
				}
				public String EmailOriginalDbColumnName(){
				
					return "Email";
				
				}

				
			    public String Title;

				public String getTitle () {
					return this.Title;
				}

				public Boolean TitleIsNullable(){
				    return true;
				}
				public Boolean TitleIsKey(){
				    return false;
				}
				public Integer TitleLength(){
				    return 128;
				}
				public Integer TitlePrecision(){
				    return null;
				}
				public String TitleDefault(){
				
					return null;
				
				}
				public String TitleComment(){
				
				    return "";
				
				}
				public String TitlePattern(){
				
					return "";
				
				}
				public String TitleOriginalDbColumnName(){
				
					return "Title";
				
				}

				
			    public String Department;

				public String getDepartment () {
					return this.Department;
				}

				public Boolean DepartmentIsNullable(){
				    return true;
				}
				public Boolean DepartmentIsKey(){
				    return false;
				}
				public Integer DepartmentLength(){
				    return 80;
				}
				public Integer DepartmentPrecision(){
				    return null;
				}
				public String DepartmentDefault(){
				
					return null;
				
				}
				public String DepartmentComment(){
				
				    return "";
				
				}
				public String DepartmentPattern(){
				
					return "";
				
				}
				public String DepartmentOriginalDbColumnName(){
				
					return "Department";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastActivityDate;

				public java.util.Date getLastActivityDate () {
					return this.LastActivityDate;
				}

				public Boolean LastActivityDateIsNullable(){
				    return true;
				}
				public Boolean LastActivityDateIsKey(){
				    return false;
				}
				public Integer LastActivityDateLength(){
				    return null;
				}
				public Integer LastActivityDatePrecision(){
				    return null;
				}
				public String LastActivityDateDefault(){
				
					return null;
				
				}
				public String LastActivityDateComment(){
				
				    return "";
				
				}
				public String LastActivityDatePattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String LastActivityDateOriginalDbColumnName(){
				
					return "LastActivityDate";
				
				}

				
			    public java.util.Date LastCURequestDate;

				public java.util.Date getLastCURequestDate () {
					return this.LastCURequestDate;
				}

				public Boolean LastCURequestDateIsNullable(){
				    return true;
				}
				public Boolean LastCURequestDateIsKey(){
				    return false;
				}
				public Integer LastCURequestDateLength(){
				    return null;
				}
				public Integer LastCURequestDatePrecision(){
				    return null;
				}
				public String LastCURequestDateDefault(){
				
					return null;
				
				}
				public String LastCURequestDateComment(){
				
				    return "";
				
				}
				public String LastCURequestDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCURequestDateOriginalDbColumnName(){
				
					return "LastCURequestDate";
				
				}

				
			    public java.util.Date LastCUUpdateDate;

				public java.util.Date getLastCUUpdateDate () {
					return this.LastCUUpdateDate;
				}

				public Boolean LastCUUpdateDateIsNullable(){
				    return true;
				}
				public Boolean LastCUUpdateDateIsKey(){
				    return false;
				}
				public Integer LastCUUpdateDateLength(){
				    return null;
				}
				public Integer LastCUUpdateDatePrecision(){
				    return null;
				}
				public String LastCUUpdateDateDefault(){
				
					return null;
				
				}
				public String LastCUUpdateDateComment(){
				
				    return "";
				
				}
				public String LastCUUpdateDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastCUUpdateDateOriginalDbColumnName(){
				
					return "LastCUUpdateDate";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public String EmailBouncedReason;

				public String getEmailBouncedReason () {
					return this.EmailBouncedReason;
				}

				public Boolean EmailBouncedReasonIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedReasonIsKey(){
				    return false;
				}
				public Integer EmailBouncedReasonLength(){
				    return 255;
				}
				public Integer EmailBouncedReasonPrecision(){
				    return null;
				}
				public String EmailBouncedReasonDefault(){
				
					return null;
				
				}
				public String EmailBouncedReasonComment(){
				
				    return "";
				
				}
				public String EmailBouncedReasonPattern(){
				
					return "";
				
				}
				public String EmailBouncedReasonOriginalDbColumnName(){
				
					return "EmailBouncedReason";
				
				}

				
			    public java.util.Date EmailBouncedDate;

				public java.util.Date getEmailBouncedDate () {
					return this.EmailBouncedDate;
				}

				public Boolean EmailBouncedDateIsNullable(){
				    return true;
				}
				public Boolean EmailBouncedDateIsKey(){
				    return false;
				}
				public Integer EmailBouncedDateLength(){
				    return null;
				}
				public Integer EmailBouncedDatePrecision(){
				    return null;
				}
				public String EmailBouncedDateDefault(){
				
					return null;
				
				}
				public String EmailBouncedDateComment(){
				
				    return "";
				
				}
				public String EmailBouncedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String EmailBouncedDateOriginalDbColumnName(){
				
					return "EmailBouncedDate";
				
				}

				
			    public boolean IsEmailBounced;

				public boolean getIsEmailBounced () {
					return this.IsEmailBounced;
				}

				public Boolean IsEmailBouncedIsNullable(){
				    return false;
				}
				public Boolean IsEmailBouncedIsKey(){
				    return false;
				}
				public Integer IsEmailBouncedLength(){
				    return null;
				}
				public Integer IsEmailBouncedPrecision(){
				    return null;
				}
				public String IsEmailBouncedDefault(){
				
					return null;
				
				}
				public String IsEmailBouncedComment(){
				
				    return "";
				
				}
				public String IsEmailBouncedPattern(){
				
					return "";
				
				}
				public String IsEmailBouncedOriginalDbColumnName(){
				
					return "IsEmailBounced";
				
				}

				
			    public String PhotoUrl;

				public String getPhotoUrl () {
					return this.PhotoUrl;
				}

				public Boolean PhotoUrlIsNullable(){
				    return true;
				}
				public Boolean PhotoUrlIsKey(){
				    return false;
				}
				public Integer PhotoUrlLength(){
				    return 255;
				}
				public Integer PhotoUrlPrecision(){
				    return null;
				}
				public String PhotoUrlDefault(){
				
					return null;
				
				}
				public String PhotoUrlComment(){
				
				    return "";
				
				}
				public String PhotoUrlPattern(){
				
					return "";
				
				}
				public String PhotoUrlOriginalDbColumnName(){
				
					return "PhotoUrl";
				
				}

				
			    public String Jigsaw;

				public String getJigsaw () {
					return this.Jigsaw;
				}

				public Boolean JigsawIsNullable(){
				    return true;
				}
				public Boolean JigsawIsKey(){
				    return false;
				}
				public Integer JigsawLength(){
				    return 20;
				}
				public Integer JigsawPrecision(){
				    return null;
				}
				public String JigsawDefault(){
				
					return null;
				
				}
				public String JigsawComment(){
				
				    return "";
				
				}
				public String JigsawPattern(){
				
					return "";
				
				}
				public String JigsawOriginalDbColumnName(){
				
					return "Jigsaw";
				
				}

				
			    public String JigsawContactId;

				public String getJigsawContactId () {
					return this.JigsawContactId;
				}

				public Boolean JigsawContactIdIsNullable(){
				    return true;
				}
				public Boolean JigsawContactIdIsKey(){
				    return false;
				}
				public Integer JigsawContactIdLength(){
				    return 20;
				}
				public Integer JigsawContactIdPrecision(){
				    return null;
				}
				public String JigsawContactIdDefault(){
				
					return null;
				
				}
				public String JigsawContactIdComment(){
				
				    return "";
				
				}
				public String JigsawContactIdPattern(){
				
					return "";
				
				}
				public String JigsawContactIdOriginalDbColumnName(){
				
					return "JigsawContactId";
				
				}

				
			    public String RL_AccountingMail__c;

				public String getRL_AccountingMail__c () {
					return this.RL_AccountingMail__c;
				}

				public Boolean RL_AccountingMail__cIsNullable(){
				    return true;
				}
				public Boolean RL_AccountingMail__cIsKey(){
				    return false;
				}
				public Integer RL_AccountingMail__cLength(){
				    return 80;
				}
				public Integer RL_AccountingMail__cPrecision(){
				    return null;
				}
				public String RL_AccountingMail__cDefault(){
				
					return null;
				
				}
				public String RL_AccountingMail__cComment(){
				
				    return "";
				
				}
				public String RL_AccountingMail__cPattern(){
				
					return "";
				
				}
				public String RL_AccountingMail__cOriginalDbColumnName(){
				
					return "RL_AccountingMail__c";
				
				}

				
			    public String RL_Agency__c;

				public String getRL_Agency__c () {
					return this.RL_Agency__c;
				}

				public Boolean RL_Agency__cIsNullable(){
				    return true;
				}
				public Boolean RL_Agency__cIsKey(){
				    return false;
				}
				public Integer RL_Agency__cLength(){
				    return 45;
				}
				public Integer RL_Agency__cPrecision(){
				    return null;
				}
				public String RL_Agency__cDefault(){
				
					return null;
				
				}
				public String RL_Agency__cComment(){
				
				    return "";
				
				}
				public String RL_Agency__cPattern(){
				
					return "";
				
				}
				public String RL_Agency__cOriginalDbColumnName(){
				
					return "RL_Agency__c";
				
				}

				
			    public String RL_BankCode__c;

				public String getRL_BankCode__c () {
					return this.RL_BankCode__c;
				}

				public Boolean RL_BankCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankCode__cIsKey(){
				    return false;
				}
				public Integer RL_BankCode__cLength(){
				    return 45;
				}
				public Integer RL_BankCode__cPrecision(){
				    return null;
				}
				public String RL_BankCode__cDefault(){
				
					return null;
				
				}
				public String RL_BankCode__cComment(){
				
				    return "";
				
				}
				public String RL_BankCode__cPattern(){
				
					return "";
				
				}
				public String RL_BankCode__cOriginalDbColumnName(){
				
					return "RL_BankCode__c";
				
				}

				
			    public String RL_BankKey__c;

				public String getRL_BankKey__c () {
					return this.RL_BankKey__c;
				}

				public Boolean RL_BankKey__cIsNullable(){
				    return true;
				}
				public Boolean RL_BankKey__cIsKey(){
				    return false;
				}
				public Integer RL_BankKey__cLength(){
				    return 45;
				}
				public Integer RL_BankKey__cPrecision(){
				    return null;
				}
				public String RL_BankKey__cDefault(){
				
					return null;
				
				}
				public String RL_BankKey__cComment(){
				
				    return "";
				
				}
				public String RL_BankKey__cPattern(){
				
					return "";
				
				}
				public String RL_BankKey__cOriginalDbColumnName(){
				
					return "RL_BankKey__c";
				
				}

				
			    public String RL_BillingCity__c;

				public String getRL_BillingCity__c () {
					return this.RL_BillingCity__c;
				}

				public Boolean RL_BillingCity__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCity__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCity__cLength(){
				    return 45;
				}
				public Integer RL_BillingCity__cPrecision(){
				    return null;
				}
				public String RL_BillingCity__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCity__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCity__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCity__cOriginalDbColumnName(){
				
					return "RL_BillingCity__c";
				
				}

				
			    public String RL_BillingCountry__c;

				public String getRL_BillingCountry__c () {
					return this.RL_BillingCountry__c;
				}

				public Boolean RL_BillingCountry__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingCountry__cIsKey(){
				    return false;
				}
				public Integer RL_BillingCountry__cLength(){
				    return 45;
				}
				public Integer RL_BillingCountry__cPrecision(){
				    return null;
				}
				public String RL_BillingCountry__cDefault(){
				
					return null;
				
				}
				public String RL_BillingCountry__cComment(){
				
				    return "";
				
				}
				public String RL_BillingCountry__cPattern(){
				
					return "";
				
				}
				public String RL_BillingCountry__cOriginalDbColumnName(){
				
					return "RL_BillingCountry__c";
				
				}

				
			    public String RL_BillingName__c;

				public String getRL_BillingName__c () {
					return this.RL_BillingName__c;
				}

				public Boolean RL_BillingName__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingName__cIsKey(){
				    return false;
				}
				public Integer RL_BillingName__cLength(){
				    return 45;
				}
				public Integer RL_BillingName__cPrecision(){
				    return null;
				}
				public String RL_BillingName__cDefault(){
				
					return null;
				
				}
				public String RL_BillingName__cComment(){
				
				    return "";
				
				}
				public String RL_BillingName__cPattern(){
				
					return "";
				
				}
				public String RL_BillingName__cOriginalDbColumnName(){
				
					return "RL_BillingName__c";
				
				}

				
			    public String RL_BillingStreetNumber__c;

				public String getRL_BillingStreetNumber__c () {
					return this.RL_BillingStreetNumber__c;
				}

				public Boolean RL_BillingStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_BillingStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreetNumber__cOriginalDbColumnName(){
				
					return "RL_BillingStreetNumber__c";
				
				}

				
			    public String RL_BillingStreet__c;

				public String getRL_BillingStreet__c () {
					return this.RL_BillingStreet__c;
				}

				public Boolean RL_BillingStreet__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingStreet__cIsKey(){
				    return false;
				}
				public Integer RL_BillingStreet__cLength(){
				    return 45;
				}
				public Integer RL_BillingStreet__cPrecision(){
				    return null;
				}
				public String RL_BillingStreet__cDefault(){
				
					return null;
				
				}
				public String RL_BillingStreet__cComment(){
				
				    return "";
				
				}
				public String RL_BillingStreet__cPattern(){
				
					return "";
				
				}
				public String RL_BillingStreet__cOriginalDbColumnName(){
				
					return "RL_BillingStreet__c";
				
				}

				
			    public String RL_BillingTel1__c;

				public String getRL_BillingTel1__c () {
					return this.RL_BillingTel1__c;
				}

				public Boolean RL_BillingTel1__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel1__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel1__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel1__cPrecision(){
				    return null;
				}
				public String RL_BillingTel1__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel1__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel1__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel1__cOriginalDbColumnName(){
				
					return "RL_BillingTel1__c";
				
				}

				
			    public String RL_BillingTel2__c;

				public String getRL_BillingTel2__c () {
					return this.RL_BillingTel2__c;
				}

				public Boolean RL_BillingTel2__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel2__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel2__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel2__cPrecision(){
				    return null;
				}
				public String RL_BillingTel2__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel2__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel2__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel2__cOriginalDbColumnName(){
				
					return "RL_BillingTel2__c";
				
				}

				
			    public String RL_BillingTel3__c;

				public String getRL_BillingTel3__c () {
					return this.RL_BillingTel3__c;
				}

				public Boolean RL_BillingTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_BillingTel3__cIsKey(){
				    return false;
				}
				public Integer RL_BillingTel3__cLength(){
				    return 45;
				}
				public Integer RL_BillingTel3__cPrecision(){
				    return null;
				}
				public String RL_BillingTel3__cDefault(){
				
					return null;
				
				}
				public String RL_BillingTel3__cComment(){
				
				    return "";
				
				}
				public String RL_BillingTel3__cPattern(){
				
					return "";
				
				}
				public String RL_BillingTel3__cOriginalDbColumnName(){
				
					return "RL_BillingTel3__c";
				
				}

				
			    public Double RL_CodeSettlement__c;

				public Double getRL_CodeSettlement__c () {
					return this.RL_CodeSettlement__c;
				}

				public Boolean RL_CodeSettlement__cIsNullable(){
				    return true;
				}
				public Boolean RL_CodeSettlement__cIsKey(){
				    return false;
				}
				public Integer RL_CodeSettlement__cLength(){
				    return 11;
				}
				public Integer RL_CodeSettlement__cPrecision(){
				    return null;
				}
				public String RL_CodeSettlement__cDefault(){
				
					return null;
				
				}
				public String RL_CodeSettlement__cComment(){
				
				    return "";
				
				}
				public String RL_CodeSettlement__cPattern(){
				
					return "";
				
				}
				public String RL_CodeSettlement__cOriginalDbColumnName(){
				
					return "RL_CodeSettlement__c";
				
				}

				
			    public java.util.Date RL_CreatedAt__c;

				public java.util.Date getRL_CreatedAt__c () {
					return this.RL_CreatedAt__c;
				}

				public Boolean RL_CreatedAt__cIsNullable(){
				    return true;
				}
				public Boolean RL_CreatedAt__cIsKey(){
				    return false;
				}
				public Integer RL_CreatedAt__cLength(){
				    return null;
				}
				public Integer RL_CreatedAt__cPrecision(){
				    return null;
				}
				public String RL_CreatedAt__cDefault(){
				
					return null;
				
				}
				public String RL_CreatedAt__cComment(){
				
				    return "";
				
				}
				public String RL_CreatedAt__cPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String RL_CreatedAt__cOriginalDbColumnName(){
				
					return "RL_CreatedAt__c";
				
				}

				
			    public String RL_Email__c;

				public String getRL_Email__c () {
					return this.RL_Email__c;
				}

				public Boolean RL_Email__cIsNullable(){
				    return true;
				}
				public Boolean RL_Email__cIsKey(){
				    return false;
				}
				public Integer RL_Email__cLength(){
				    return 255;
				}
				public Integer RL_Email__cPrecision(){
				    return null;
				}
				public String RL_Email__cDefault(){
				
					return null;
				
				}
				public String RL_Email__cComment(){
				
				    return "";
				
				}
				public String RL_Email__cPattern(){
				
					return "";
				
				}
				public String RL_Email__cOriginalDbColumnName(){
				
					return "RL_Email__c";
				
				}

				
			    public Double RL_ExternalAccountId__c;

				public Double getRL_ExternalAccountId__c () {
					return this.RL_ExternalAccountId__c;
				}

				public Boolean RL_ExternalAccountId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalAccountId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalAccountId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalAccountId__cPrecision(){
				    return null;
				}
				public String RL_ExternalAccountId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalAccountId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalAccountId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalAccountId__cOriginalDbColumnName(){
				
					return "RL_ExternalAccountId__c";
				
				}

				
			    public Double RL_ExternalId__c;

				public Double getRL_ExternalId__c () {
					return this.RL_ExternalId__c;
				}

				public Boolean RL_ExternalId__cIsNullable(){
				    return true;
				}
				public Boolean RL_ExternalId__cIsKey(){
				    return false;
				}
				public Integer RL_ExternalId__cLength(){
				    return 18;
				}
				public Integer RL_ExternalId__cPrecision(){
				    return null;
				}
				public String RL_ExternalId__cDefault(){
				
					return null;
				
				}
				public String RL_ExternalId__cComment(){
				
				    return "";
				
				}
				public String RL_ExternalId__cPattern(){
				
					return "";
				
				}
				public String RL_ExternalId__cOriginalDbColumnName(){
				
					return "RL_ExternalId__c";
				
				}

				
			    public Double RL_IsActive__c;

				public Double getRL_IsActive__c () {
					return this.RL_IsActive__c;
				}

				public Boolean RL_IsActive__cIsNullable(){
				    return true;
				}
				public Boolean RL_IsActive__cIsKey(){
				    return false;
				}
				public Integer RL_IsActive__cLength(){
				    return 1;
				}
				public Integer RL_IsActive__cPrecision(){
				    return null;
				}
				public String RL_IsActive__cDefault(){
				
					return null;
				
				}
				public String RL_IsActive__cComment(){
				
				    return "";
				
				}
				public String RL_IsActive__cPattern(){
				
					return "";
				
				}
				public String RL_IsActive__cOriginalDbColumnName(){
				
					return "RL_IsActive__c";
				
				}

				
			    public String RL_RecoveryPostalCode__c;

				public String getRL_RecoveryPostalCode__c () {
					return this.RL_RecoveryPostalCode__c;
				}

				public Boolean RL_RecoveryPostalCode__cIsNullable(){
				    return true;
				}
				public Boolean RL_RecoveryPostalCode__cIsKey(){
				    return false;
				}
				public Integer RL_RecoveryPostalCode__cLength(){
				    return 255;
				}
				public Integer RL_RecoveryPostalCode__cPrecision(){
				    return null;
				}
				public String RL_RecoveryPostalCode__cDefault(){
				
					return null;
				
				}
				public String RL_RecoveryPostalCode__cComment(){
				
				    return "";
				
				}
				public String RL_RecoveryPostalCode__cPattern(){
				
					return "";
				
				}
				public String RL_RecoveryPostalCode__cOriginalDbColumnName(){
				
					return "RL_RecoveryPostalCode__c";
				
				}

				
			    public String RL_RemovalStreetNumber__c;

				public String getRL_RemovalStreetNumber__c () {
					return this.RL_RemovalStreetNumber__c;
				}

				public Boolean RL_RemovalStreetNumber__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalStreetNumber__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalStreetNumber__cLength(){
				    return 45;
				}
				public Integer RL_RemovalStreetNumber__cPrecision(){
				    return null;
				}
				public String RL_RemovalStreetNumber__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalStreetNumber__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalStreetNumber__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalStreetNumber__cOriginalDbColumnName(){
				
					return "RL_RemovalStreetNumber__c";
				
				}

				
			    public String RL_RemovalTel3__c;

				public String getRL_RemovalTel3__c () {
					return this.RL_RemovalTel3__c;
				}

				public Boolean RL_RemovalTel3__cIsNullable(){
				    return true;
				}
				public Boolean RL_RemovalTel3__cIsKey(){
				    return false;
				}
				public Integer RL_RemovalTel3__cLength(){
				    return 40;
				}
				public Integer RL_RemovalTel3__cPrecision(){
				    return null;
				}
				public String RL_RemovalTel3__cDefault(){
				
					return null;
				
				}
				public String RL_RemovalTel3__cComment(){
				
				    return "";
				
				}
				public String RL_RemovalTel3__cPattern(){
				
					return "";
				
				}
				public String RL_RemovalTel3__cOriginalDbColumnName(){
				
					return "RL_RemovalTel3__c";
				
				}

				
			    public String Code_Client__c;

				public String getCode_Client__c () {
					return this.Code_Client__c;
				}

				public Boolean Code_Client__cIsNullable(){
				    return true;
				}
				public Boolean Code_Client__cIsKey(){
				    return false;
				}
				public Integer Code_Client__cLength(){
				    return 30;
				}
				public Integer Code_Client__cPrecision(){
				    return null;
				}
				public String Code_Client__cDefault(){
				
					return null;
				
				}
				public String Code_Client__cComment(){
				
				    return "";
				
				}
				public String Code_Client__cPattern(){
				
					return "";
				
				}
				public String Code_Client__cOriginalDbColumnName(){
				
					return "Code_Client__c";
				
				}

				
			    public String Data_Quality_Description__c;

				public String getData_Quality_Description__c () {
					return this.Data_Quality_Description__c;
				}

				public Boolean Data_Quality_Description__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Description__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Description__cLength(){
				    return 1300;
				}
				public Integer Data_Quality_Description__cPrecision(){
				    return null;
				}
				public String Data_Quality_Description__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Description__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Description__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Description__cOriginalDbColumnName(){
				
					return "Data_Quality_Description__c";
				
				}

				
			    public Double Data_Quality_Score__c;

				public Double getData_Quality_Score__c () {
					return this.Data_Quality_Score__c;
				}

				public Boolean Data_Quality_Score__cIsNullable(){
				    return true;
				}
				public Boolean Data_Quality_Score__cIsKey(){
				    return false;
				}
				public Integer Data_Quality_Score__cLength(){
				    return 18;
				}
				public Integer Data_Quality_Score__cPrecision(){
				    return null;
				}
				public String Data_Quality_Score__cDefault(){
				
					return null;
				
				}
				public String Data_Quality_Score__cComment(){
				
				    return "";
				
				}
				public String Data_Quality_Score__cPattern(){
				
					return "";
				
				}
				public String Data_Quality_Score__cOriginalDbColumnName(){
				
					return "Data_Quality_Score__c";
				
				}

				
			    public String RL_Company__c;

				public String getRL_Company__c () {
					return this.RL_Company__c;
				}

				public Boolean RL_Company__cIsNullable(){
				    return true;
				}
				public Boolean RL_Company__cIsKey(){
				    return false;
				}
				public Integer RL_Company__cLength(){
				    return 45;
				}
				public Integer RL_Company__cPrecision(){
				    return null;
				}
				public String RL_Company__cDefault(){
				
					return null;
				
				}
				public String RL_Company__cComment(){
				
				    return "";
				
				}
				public String RL_Company__cPattern(){
				
					return "";
				
				}
				public String RL_Company__cOriginalDbColumnName(){
				
					return "RL_Company__c";
				
				}

				
			    public String RL_Removal_iso3_country__c;

				public String getRL_Removal_iso3_country__c () {
					return this.RL_Removal_iso3_country__c;
				}

				public Boolean RL_Removal_iso3_country__cIsNullable(){
				    return true;
				}
				public Boolean RL_Removal_iso3_country__cIsKey(){
				    return false;
				}
				public Integer RL_Removal_iso3_country__cLength(){
				    return 45;
				}
				public Integer RL_Removal_iso3_country__cPrecision(){
				    return null;
				}
				public String RL_Removal_iso3_country__cDefault(){
				
					return null;
				
				}
				public String RL_Removal_iso3_country__cComment(){
				
				    return "";
				
				}
				public String RL_Removal_iso3_country__cPattern(){
				
					return "";
				
				}
				public String RL_Removal_iso3_country__cOriginalDbColumnName(){
				
					return "RL_Removal_iso3_country__c";
				
				}

				
			    public boolean RL_Archived__c;

				public boolean getRL_Archived__c () {
					return this.RL_Archived__c;
				}

				public Boolean RL_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Archived__cLength(){
				    return null;
				}
				public Integer RL_Archived__cPrecision(){
				    return null;
				}
				public String RL_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Archived__cOriginalDbColumnName(){
				
					return "RL_Archived__c";
				
				}

				
			    public boolean RL_Tarification_par_palier__c;

				public boolean getRL_Tarification_par_palier__c () {
					return this.RL_Tarification_par_palier__c;
				}

				public Boolean RL_Tarification_par_palier__cIsNullable(){
				    return false;
				}
				public Boolean RL_Tarification_par_palier__cIsKey(){
				    return false;
				}
				public Integer RL_Tarification_par_palier__cLength(){
				    return null;
				}
				public Integer RL_Tarification_par_palier__cPrecision(){
				    return null;
				}
				public String RL_Tarification_par_palier__cDefault(){
				
					return null;
				
				}
				public String RL_Tarification_par_palier__cComment(){
				
				    return "";
				
				}
				public String RL_Tarification_par_palier__cPattern(){
				
					return "";
				
				}
				public String RL_Tarification_par_palier__cOriginalDbColumnName(){
				
					return "RL_Tarification_par_palier__c";
				
				}

				
			    public String Contact_Commercial__c;

				public String getContact_Commercial__c () {
					return this.Contact_Commercial__c;
				}

				public Boolean Contact_Commercial__cIsNullable(){
				    return true;
				}
				public Boolean Contact_Commercial__cIsKey(){
				    return false;
				}
				public Integer Contact_Commercial__cLength(){
				    return 255;
				}
				public Integer Contact_Commercial__cPrecision(){
				    return null;
				}
				public String Contact_Commercial__cDefault(){
				
					return null;
				
				}
				public String Contact_Commercial__cComment(){
				
				    return "";
				
				}
				public String Contact_Commercial__cPattern(){
				
					return "";
				
				}
				public String Contact_Commercial__cOriginalDbColumnName(){
				
					return "Contact_Commercial__c";
				
				}

				
			    public String SocieteInfo__Id__c;

				public String getSocieteInfo__Id__c () {
					return this.SocieteInfo__Id__c;
				}

				public Boolean SocieteInfo__Id__cIsNullable(){
				    return true;
				}
				public Boolean SocieteInfo__Id__cIsKey(){
				    return false;
				}
				public Integer SocieteInfo__Id__cLength(){
				    return 80;
				}
				public Integer SocieteInfo__Id__cPrecision(){
				    return null;
				}
				public String SocieteInfo__Id__cDefault(){
				
					return null;
				
				}
				public String SocieteInfo__Id__cComment(){
				
				    return "";
				
				}
				public String SocieteInfo__Id__cPattern(){
				
					return "";
				
				}
				public String SocieteInfo__Id__cOriginalDbColumnName(){
				
					return "SocieteInfo__Id__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalId__c = null;
           				} else {
           			    	this.RL_ExternalId__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.MasterRecordId = readString(dis);
					
					this.AccountId = readString(dis);
					
					this.LastName = readString(dis);
					
					this.FirstName = readString(dis);
					
					this.Salutation = readString(dis);
					
					this.MiddleName = readString(dis);
					
					this.Suffix = readString(dis);
					
					this.Name = readString(dis);
					
					this.RecordTypeId = readString(dis);
					
					this.MailingStreet = readString(dis);
					
					this.MailingCity = readString(dis);
					
					this.MailingState = readString(dis);
					
					this.MailingPostalCode = readString(dis);
					
					this.MailingCountry = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLatitude = null;
           				} else {
           			    	this.MailingLatitude = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MailingLongitude = null;
           				} else {
           			    	this.MailingLongitude = dis.readDouble();
           				}
					
					this.MailingGeocodeAccuracy = readString(dis);
					
					this.MailingAddress = readString(dis);
					
					this.Phone = readString(dis);
					
					this.Fax = readString(dis);
					
					this.MobilePhone = readString(dis);
					
					this.ReportsToId = readString(dis);
					
					this.Email = readString(dis);
					
					this.Title = readString(dis);
					
					this.Department = readString(dis);
					
					this.OwnerId = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastActivityDate = readDate(dis);
					
					this.LastCURequestDate = readDate(dis);
					
					this.LastCUUpdateDate = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
					this.EmailBouncedReason = readString(dis);
					
					this.EmailBouncedDate = readDate(dis);
					
			        this.IsEmailBounced = dis.readBoolean();
					
					this.PhotoUrl = readString(dis);
					
					this.Jigsaw = readString(dis);
					
					this.JigsawContactId = readString(dis);
					
					this.RL_AccountingMail__c = readString(dis);
					
					this.RL_Agency__c = readString(dis);
					
					this.RL_BankCode__c = readString(dis);
					
					this.RL_BankKey__c = readString(dis);
					
					this.RL_BillingCity__c = readString(dis);
					
					this.RL_BillingCountry__c = readString(dis);
					
					this.RL_BillingName__c = readString(dis);
					
					this.RL_BillingStreetNumber__c = readString(dis);
					
					this.RL_BillingStreet__c = readString(dis);
					
					this.RL_BillingTel1__c = readString(dis);
					
					this.RL_BillingTel2__c = readString(dis);
					
					this.RL_BillingTel3__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_CodeSettlement__c = null;
           				} else {
           			    	this.RL_CodeSettlement__c = dis.readDouble();
           				}
					
					this.RL_CreatedAt__c = readDate(dis);
					
					this.RL_Email__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalAccountId__c = null;
           				} else {
           			    	this.RL_ExternalAccountId__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_ExternalId__c = null;
           				} else {
           			    	this.RL_ExternalId__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_IsActive__c = null;
           				} else {
           			    	this.RL_IsActive__c = dis.readDouble();
           				}
					
					this.RL_RecoveryPostalCode__c = readString(dis);
					
					this.RL_RemovalStreetNumber__c = readString(dis);
					
					this.RL_RemovalTel3__c = readString(dis);
					
					this.Code_Client__c = readString(dis);
					
					this.Data_Quality_Description__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Data_Quality_Score__c = null;
           				} else {
           			    	this.Data_Quality_Score__c = dis.readDouble();
           				}
					
					this.RL_Company__c = readString(dis);
					
					this.RL_Removal_iso3_country__c = readString(dis);
					
			        this.RL_Archived__c = dis.readBoolean();
					
			        this.RL_Tarification_par_palier__c = dis.readBoolean();
					
					this.Contact_Commercial__c = readString(dis);
					
					this.SocieteInfo__Id__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Double
				
						if(this.RL_ExternalId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalId__c);
		            	}
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.MasterRecordId,dos);
					
					// String
				
						writeString(this.AccountId,dos);
					
					// String
				
						writeString(this.LastName,dos);
					
					// String
				
						writeString(this.FirstName,dos);
					
					// String
				
						writeString(this.Salutation,dos);
					
					// String
				
						writeString(this.MiddleName,dos);
					
					// String
				
						writeString(this.Suffix,dos);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.RecordTypeId,dos);
					
					// String
				
						writeString(this.MailingStreet,dos);
					
					// String
				
						writeString(this.MailingCity,dos);
					
					// String
				
						writeString(this.MailingState,dos);
					
					// String
				
						writeString(this.MailingPostalCode,dos);
					
					// String
				
						writeString(this.MailingCountry,dos);
					
					// Double
				
						if(this.MailingLatitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLatitude);
		            	}
					
					// Double
				
						if(this.MailingLongitude == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.MailingLongitude);
		            	}
					
					// String
				
						writeString(this.MailingGeocodeAccuracy,dos);
					
					// String
				
						writeString(this.MailingAddress,dos);
					
					// String
				
						writeString(this.Phone,dos);
					
					// String
				
						writeString(this.Fax,dos);
					
					// String
				
						writeString(this.MobilePhone,dos);
					
					// String
				
						writeString(this.ReportsToId,dos);
					
					// String
				
						writeString(this.Email,dos);
					
					// String
				
						writeString(this.Title,dos);
					
					// String
				
						writeString(this.Department,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastActivityDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCURequestDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastCUUpdateDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// String
				
						writeString(this.EmailBouncedReason,dos);
					
					// java.util.Date
				
						writeDate(this.EmailBouncedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsEmailBounced);
					
					// String
				
						writeString(this.PhotoUrl,dos);
					
					// String
				
						writeString(this.Jigsaw,dos);
					
					// String
				
						writeString(this.JigsawContactId,dos);
					
					// String
				
						writeString(this.RL_AccountingMail__c,dos);
					
					// String
				
						writeString(this.RL_Agency__c,dos);
					
					// String
				
						writeString(this.RL_BankCode__c,dos);
					
					// String
				
						writeString(this.RL_BankKey__c,dos);
					
					// String
				
						writeString(this.RL_BillingCity__c,dos);
					
					// String
				
						writeString(this.RL_BillingCountry__c,dos);
					
					// String
				
						writeString(this.RL_BillingName__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_BillingStreet__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel1__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel2__c,dos);
					
					// String
				
						writeString(this.RL_BillingTel3__c,dos);
					
					// Double
				
						if(this.RL_CodeSettlement__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_CodeSettlement__c);
		            	}
					
					// java.util.Date
				
						writeDate(this.RL_CreatedAt__c,dos);
					
					// String
				
						writeString(this.RL_Email__c,dos);
					
					// Double
				
						if(this.RL_ExternalAccountId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalAccountId__c);
		            	}
					
					// Double
				
						if(this.RL_ExternalId__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_ExternalId__c);
		            	}
					
					// Double
				
						if(this.RL_IsActive__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_IsActive__c);
		            	}
					
					// String
				
						writeString(this.RL_RecoveryPostalCode__c,dos);
					
					// String
				
						writeString(this.RL_RemovalStreetNumber__c,dos);
					
					// String
				
						writeString(this.RL_RemovalTel3__c,dos);
					
					// String
				
						writeString(this.Code_Client__c,dos);
					
					// String
				
						writeString(this.Data_Quality_Description__c,dos);
					
					// Double
				
						if(this.Data_Quality_Score__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Data_Quality_Score__c);
		            	}
					
					// String
				
						writeString(this.RL_Company__c,dos);
					
					// String
				
						writeString(this.RL_Removal_iso3_country__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Archived__c);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Tarification_par_palier__c);
					
					// String
				
						writeString(this.Contact_Commercial__c,dos);
					
					// String
				
						writeString(this.SocieteInfo__Id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",MasterRecordId="+MasterRecordId);
		sb.append(",AccountId="+AccountId);
		sb.append(",LastName="+LastName);
		sb.append(",FirstName="+FirstName);
		sb.append(",Salutation="+Salutation);
		sb.append(",MiddleName="+MiddleName);
		sb.append(",Suffix="+Suffix);
		sb.append(",Name="+Name);
		sb.append(",RecordTypeId="+RecordTypeId);
		sb.append(",MailingStreet="+MailingStreet);
		sb.append(",MailingCity="+MailingCity);
		sb.append(",MailingState="+MailingState);
		sb.append(",MailingPostalCode="+MailingPostalCode);
		sb.append(",MailingCountry="+MailingCountry);
		sb.append(",MailingLatitude="+String.valueOf(MailingLatitude));
		sb.append(",MailingLongitude="+String.valueOf(MailingLongitude));
		sb.append(",MailingGeocodeAccuracy="+MailingGeocodeAccuracy);
		sb.append(",MailingAddress="+MailingAddress);
		sb.append(",Phone="+Phone);
		sb.append(",Fax="+Fax);
		sb.append(",MobilePhone="+MobilePhone);
		sb.append(",ReportsToId="+ReportsToId);
		sb.append(",Email="+Email);
		sb.append(",Title="+Title);
		sb.append(",Department="+Department);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastActivityDate="+String.valueOf(LastActivityDate));
		sb.append(",LastCURequestDate="+String.valueOf(LastCURequestDate));
		sb.append(",LastCUUpdateDate="+String.valueOf(LastCUUpdateDate));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",EmailBouncedReason="+EmailBouncedReason);
		sb.append(",EmailBouncedDate="+String.valueOf(EmailBouncedDate));
		sb.append(",IsEmailBounced="+String.valueOf(IsEmailBounced));
		sb.append(",PhotoUrl="+PhotoUrl);
		sb.append(",Jigsaw="+Jigsaw);
		sb.append(",JigsawContactId="+JigsawContactId);
		sb.append(",RL_AccountingMail__c="+RL_AccountingMail__c);
		sb.append(",RL_Agency__c="+RL_Agency__c);
		sb.append(",RL_BankCode__c="+RL_BankCode__c);
		sb.append(",RL_BankKey__c="+RL_BankKey__c);
		sb.append(",RL_BillingCity__c="+RL_BillingCity__c);
		sb.append(",RL_BillingCountry__c="+RL_BillingCountry__c);
		sb.append(",RL_BillingName__c="+RL_BillingName__c);
		sb.append(",RL_BillingStreetNumber__c="+RL_BillingStreetNumber__c);
		sb.append(",RL_BillingStreet__c="+RL_BillingStreet__c);
		sb.append(",RL_BillingTel1__c="+RL_BillingTel1__c);
		sb.append(",RL_BillingTel2__c="+RL_BillingTel2__c);
		sb.append(",RL_BillingTel3__c="+RL_BillingTel3__c);
		sb.append(",RL_CodeSettlement__c="+String.valueOf(RL_CodeSettlement__c));
		sb.append(",RL_CreatedAt__c="+String.valueOf(RL_CreatedAt__c));
		sb.append(",RL_Email__c="+RL_Email__c);
		sb.append(",RL_ExternalAccountId__c="+String.valueOf(RL_ExternalAccountId__c));
		sb.append(",RL_ExternalId__c="+String.valueOf(RL_ExternalId__c));
		sb.append(",RL_IsActive__c="+String.valueOf(RL_IsActive__c));
		sb.append(",RL_RecoveryPostalCode__c="+RL_RecoveryPostalCode__c);
		sb.append(",RL_RemovalStreetNumber__c="+RL_RemovalStreetNumber__c);
		sb.append(",RL_RemovalTel3__c="+RL_RemovalTel3__c);
		sb.append(",Code_Client__c="+Code_Client__c);
		sb.append(",Data_Quality_Description__c="+Data_Quality_Description__c);
		sb.append(",Data_Quality_Score__c="+String.valueOf(Data_Quality_Score__c));
		sb.append(",RL_Company__c="+RL_Company__c);
		sb.append(",RL_Removal_iso3_country__c="+RL_Removal_iso3_country__c);
		sb.append(",RL_Archived__c="+String.valueOf(RL_Archived__c));
		sb.append(",RL_Tarification_par_palier__c="+String.valueOf(RL_Tarification_par_palier__c));
		sb.append(",Contact_Commercial__c="+Contact_Commercial__c);
		sb.append(",SocieteInfo__Id__c="+SocieteInfo__Id__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(MasterRecordId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MasterRecordId);
            			}
            		
        			sb.append("|");
        		
        				if(AccountId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccountId);
            			}
            		
        			sb.append("|");
        		
        				if(LastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastName);
            			}
            		
        			sb.append("|");
        		
        				if(FirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FirstName);
            			}
            		
        			sb.append("|");
        		
        				if(Salutation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Salutation);
            			}
            		
        			sb.append("|");
        		
        				if(MiddleName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MiddleName);
            			}
            		
        			sb.append("|");
        		
        				if(Suffix == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Suffix);
            			}
            		
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(RecordTypeId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RecordTypeId);
            			}
            		
        			sb.append("|");
        		
        				if(MailingStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingStreet);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCity);
            			}
            		
        			sb.append("|");
        		
        				if(MailingState == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingState);
            			}
            		
        			sb.append("|");
        		
        				if(MailingPostalCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingPostalCode);
            			}
            		
        			sb.append("|");
        		
        				if(MailingCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingCountry);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLatitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLatitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingLongitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingLongitude);
            			}
            		
        			sb.append("|");
        		
        				if(MailingGeocodeAccuracy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingGeocodeAccuracy);
            			}
            		
        			sb.append("|");
        		
        				if(MailingAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MailingAddress);
            			}
            		
        			sb.append("|");
        		
        				if(Phone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Phone);
            			}
            		
        			sb.append("|");
        		
        				if(Fax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Fax);
            			}
            		
        			sb.append("|");
        		
        				if(MobilePhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MobilePhone);
            			}
            		
        			sb.append("|");
        		
        				if(ReportsToId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ReportsToId);
            			}
            		
        			sb.append("|");
        		
        				if(Email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Email);
            			}
            		
        			sb.append("|");
        		
        				if(Title == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Title);
            			}
            		
        			sb.append("|");
        		
        				if(Department == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Department);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastActivityDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastActivityDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCURequestDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCURequestDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastCUUpdateDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastCUUpdateDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedReason);
            			}
            		
        			sb.append("|");
        		
        				if(EmailBouncedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailBouncedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsEmailBounced);
        			
        			sb.append("|");
        		
        				if(PhotoUrl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoUrl);
            			}
            		
        			sb.append("|");
        		
        				if(Jigsaw == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jigsaw);
            			}
            		
        			sb.append("|");
        		
        				if(JigsawContactId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JigsawContactId);
            			}
            		
        			sb.append("|");
        		
        				if(RL_AccountingMail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_AccountingMail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Agency__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Agency__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BankKey__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BankKey__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingCountry__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingCountry__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingName__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingName__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingStreet__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingStreet__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel1__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel1__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel2__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel2__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_BillingTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_BillingTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CodeSettlement__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CodeSettlement__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_CreatedAt__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_CreatedAt__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Email__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Email__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalAccountId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalAccountId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_ExternalId__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_ExternalId__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_IsActive__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_IsActive__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RecoveryPostalCode__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RecoveryPostalCode__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalStreetNumber__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalStreetNumber__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_RemovalTel3__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_RemovalTel3__c);
            			}
            		
        			sb.append("|");
        		
        				if(Code_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Description__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Description__c);
            			}
            		
        			sb.append("|");
        		
        				if(Data_Quality_Score__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data_Quality_Score__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Company__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Company__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Removal_iso3_country__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Removal_iso3_country__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Archived__c);
        			
        			sb.append("|");
        		
        				sb.append(RL_Tarification_par_palier__c);
        			
        			sb.append("|");
        		
        				if(Contact_Commercial__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact_Commercial__c);
            			}
            		
        			sb.append("|");
        		
        				if(SocieteInfo__Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SocieteInfo__Id__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tSalesforceInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceInput_2");
		org.slf4j.MDC.put("_subJobPid", "o2LmA8_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();
row8Struct row8 = new row8Struct();







	
	/**
	 * [tAdvancedHash_row8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row8", false);
		start_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row8";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tAdvancedHash_row8 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row8", "tAdvancedHash_row8", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row8
			   		// source node:tUniqRow_2 - inputs:(row6) outputs:(row8,row8) | target node:tAdvancedHash_row8 - inputs:(row8) outputs:()
			   		// linked node: tMap_1 - inputs:(service,row8) outputs:(service_detail)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row8 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row8Struct>getLookup(matchingModeEnum_row8);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row8 begin ] stop
 */



	
	/**
	 * [tUniqRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_2", false);
		start_Hash.put("tUniqRow_2", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tUniqRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
                    log4jParamters_tUniqRow_2.append("Parameters:");
                            log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Id")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("IsDeleted")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MasterRecordId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("AccountId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastName")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("FirstName")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Salutation")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MiddleName")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Suffix")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RecordTypeId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingStreet")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingCity")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingState")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingPostalCode")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingCountry")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingLatitude")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingLongitude")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingGeocodeAccuracy")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MailingAddress")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Phone")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Fax")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("MobilePhone")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("ReportsToId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Email")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Title")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Department")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("OwnerId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("SystemModstamp")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastActivityDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastCURequestDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastCUUpdateDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastViewedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastReferencedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("EmailBouncedReason")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("EmailBouncedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("IsEmailBounced")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("PhotoUrl")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Jigsaw")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("JigsawContactId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_AccountingMail__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Agency__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BankCode__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BankKey__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingCity__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingCountry__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingName__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingStreetNumber__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingStreet__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingTel1__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingTel2__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_BillingTel3__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_CodeSettlement__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_CreatedAt__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Email__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_ExternalAccountId__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_ExternalId__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_IsActive__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_RecoveryPostalCode__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_RemovalStreetNumber__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_RemovalTel3__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Code_Client__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Data_Quality_Description__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Data_Quality_Score__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Company__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Removal_iso3_country__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Archived__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Tarification_par_palier__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Contact_Commercial__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("SocieteInfo__Id__c")+"}]");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + (log4jParamters_tUniqRow_2) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_uniques_tUniqRow_2 = 0;
int nb_duplicates_tUniqRow_2 = 0;
	log.debug("tUniqRow_2 - Start to process the data from datasource."); 

 



/**
 * [tUniqRow_2 begin ] stop
 */



	
	/**
	 * [tFilterRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_12", false);
		start_Hash.put("tFilterRow_12", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_12";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tFilterRow_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_12{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_12 = new StringBuilder();
                    log4jParamters_tFilterRow_12.append("Parameters:");
                            log4jParamters_tFilterRow_12.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_12.append(" | ");
                            log4jParamters_tFilterRow_12.append("CONDITIONS" + " = " + "[]");
                        log4jParamters_tFilterRow_12.append(" | ");
                            log4jParamters_tFilterRow_12.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + (log4jParamters_tFilterRow_12) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_12().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_12", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_12 = 0;
    int nb_line_ok_tFilterRow_12 = 0;
    int nb_line_reject_tFilterRow_12 = 0;

    class Operator_tFilterRow_12 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_12(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_12 begin ] stop
 */



	
	/**
	 * [tConvertType_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_2", false);
		start_Hash.put("tConvertType_2", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tConvertType_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_2", "tConvertType_2", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_2 = 0;  
 



/**
 * [tConvertType_2 begin ] stop
 */



	
	/**
	 * [tSalesforceInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceInput_2", false);
		start_Hash.put("tSalesforceInput_2", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		
		int tos_count_tSalesforceInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceInput_2", "Contact", "tSalesforceInput");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceInput_2 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceInput_2 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceInput_2 = (String)(restRequest_tSalesforceInput_2 != null ? restRequest_tSalesforceInput_2.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceInput_2 =
        new org.talend.components.salesforce.tsalesforceinput.TSalesforceInputDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceInput_2 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceInput_2 = null;


org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties props_tSalesforceInput_2 =
        (org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties) def_tSalesforceInput_2.createRuntimeProperties();
 		                    props_tSalesforceInput_2.setValue("queryMode",
 		                        org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties.QueryMode.Query);
 		                    
 		                    props_tSalesforceInput_2.setValue("condition",
 		                    "");
 		                    
 		                    props_tSalesforceInput_2.setValue("manualQuery",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.setValue("includeDeleted",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.setValue("batchSize",
 		                    250);
 		                    
 		                    props_tSalesforceInput_2.setValue("normalizeDelimiter",
 		                    ";");
 		                    
 		                    props_tSalesforceInput_2.setValue("columnNameDelimiter",
 		                    "_");
 		                    
 		                    props_tSalesforceInput_2.setValue("dataTimeUTC",
 		                    true);
 		                    
 		                    props_tSalesforceInput_2.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    props_tSalesforceInput_2.module.setValue("moduleName",
 		                    "Contact");
 		                    
 		                    props_tSalesforceInput_2.module.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.module.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    class SchemaSettingTool_tSalesforceInput_2_1_fisrt {
 		                    		
 		                    		String getSchemaValue() {
 		                    				
 		                    						StringBuilder s = new StringBuilder();
                    						
     		                    						a("{\"type\":\"record\",",s);
     		                    						
     		                    						a("\"name\":\"Contact\",\"fields\":[{",s);
     		                    						
     		                    						a("\"name\":\"Id\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Id\",\"talend.field.dbColumnName\":\"Id\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Id\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"IsDeleted\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"IsDeleted\",\"talend.field.dbColumnName\":\"IsDeleted\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"IsDeleted\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MasterRecordId\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MasterRecordId\",\"talend.field.dbColumnName\":\"MasterRecordId\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MasterRecordId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"AccountId\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"AccountId\",\"talend.field.dbColumnName\":\"AccountId\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"AccountId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastName\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"LastName\",\"talend.field.dbColumnName\":\"LastName\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastName\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"FirstName\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"FirstName\",\"talend.field.dbColumnName\":\"FirstName\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"FirstName\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Salutation\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Salutation\",\"talend.field.dbColumnName\":\"Salutation\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Salutation\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MiddleName\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MiddleName\",\"talend.field.dbColumnName\":\"MiddleName\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MiddleName\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Suffix\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Suffix\",\"talend.field.dbColumnName\":\"Suffix\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Suffix\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Name\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Name\",\"talend.field.dbColumnName\":\"Name\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"121\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Name\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RecordTypeId\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RecordTypeId\",\"talend.field.dbColumnName\":\"RecordTypeId\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RecordTypeId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingStreet\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingStreet\",\"talend.field.dbColumnName\":\"MailingStreet\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingStreet\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingCity\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingCity\",\"talend.field.dbColumnName\":\"MailingCity\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingCity\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingState\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingState\",\"talend.field.dbColumnName\":\"MailingState\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingState\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingPostalCode\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingPostalCode\",\"talend.field.dbColumnName\":\"MailingPostalCode\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"20\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingPostalCode\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingCountry\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingCountry\",\"talend.field.dbColumnName\":\"MailingCountry\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingCountry\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingLatitude\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingLatitude\",\"talend.field.dbColumnName\":\"MailingLatitude\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingLatitude\",\"talend.field.precision\":\"15\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingLongitude\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingLongitude\",\"talend.field.dbColumnName\":\"MailingLongitude\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingLongitude\",\"talend.field.precision\":\"15\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingGeocodeAccuracy\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingGeocodeAccuracy\",\"talend.field.dbColumnName\":\"MailingGeocodeAccuracy\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingGeocodeAccuracy\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MailingAddress\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MailingAddress\",\"talend.field.dbColumnName\":\"MailingAddress\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MailingAddress\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Phone\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Phone\",\"talend.field.dbColumnName\":\"Phone\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Phone\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Fax\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Fax\",\"talend.field.dbColumnName\":\"Fax\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Fax\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"MobilePhone\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"MobilePhone\",\"talend.field.dbColumnName\":\"MobilePhone\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"MobilePhone\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"ReportsToId\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"ReportsToId\",\"talend.field.dbColumnName\":\"ReportsToId\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"ReportsToId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Email\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Email\",\"talend.field.dbColumnName\":\"Email\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Email\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Title\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Title\",\"talend.field.dbColumnName\":\"Title\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"128\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Title\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Department\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Department\",\"talend.field.dbColumnName\":\"Department\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Department\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"OwnerId\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"OwnerId\",\"talend.field.dbColumnName\":\"OwnerId\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"OwnerId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"CreatedDate\",\"talend.field.dbColumnName\":\"CreatedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"CreatedById\",\"talend.field.dbColumnName\":\"CreatedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedDate\",\"talend.field.dbColumnName\":\"LastModifiedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedById\",\"talend.field.dbColumnName\":\"LastModifiedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"SystemModstamp\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"SystemModstamp\",\"talend.field.dbColumnName\":\"SystemModstamp\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"SystemModstamp\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastActivityDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastActivityDate\",\"talend.field.dbColumnName\":\"LastActivityDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastActivityDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastCURequestDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastCURequestDate\",\"talend.field.dbColumnName\":\"LastCURequestDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastCURequestDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastCUUpdateDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastCUUpdateDate\",\"talend.field.dbColumnName\":\"LastCUUpdateDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastCUUpdateDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastViewedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastViewedDate\",\"talend.field.dbColumnName\":\"LastViewedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastViewedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastReferencedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastReferencedDate\",\"talend.field.dbColumnName\":\"LastReferencedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastReferencedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"EmailBouncedReason\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"EmailBouncedReason\",\"talend.field.dbColumnName\":\"EmailBouncedReason\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"EmailBouncedReason\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"EmailBouncedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"EmailBouncedDate\",\"talend.field.dbColumnName\":\"EmailBouncedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"EmailBouncedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"IsEmailBounced\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"IsEmailBounced\",\"talend.field.dbColumnName\":\"IsEmailBounced\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"IsEmailBounced\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"PhotoUrl\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"PhotoUrl\",\"talend.field.dbColumnName\":\"PhotoUrl\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"PhotoUrl\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Jigsaw\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Jigsaw\",\"talend.field.dbColumnName\":\"Jigsaw\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"20\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Jigsaw\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"JigsawContactId\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"JigsawContactId\",\"talend.field.dbColumnName\":\"JigsawContactId\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"20\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"JigsawContactId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_AccountingMail__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_AccountingMail__c\",\"talend.field.dbColumnName\":\"RL_AccountingMail__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_AccountingMail__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Agency__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Agency__c\",\"talend.field.dbColumnName\":\"RL_Agency__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Agency__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BankCode__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BankCode__c\",\"talend.field.dbColumnName\":\"RL_BankCode__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BankCode__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BankKey__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BankKey__c\",\"talend.field.dbColumnName\":\"RL_BankKey__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BankKey__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingCity__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingCity__c\",\"talend.field.dbColumnName\":\"RL_BillingCity__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingCity__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingCountry__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingCountry__c\",\"talend.field.dbColumnName\":\"RL_BillingCountry__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingCountry__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingName__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingName__c\",\"talend.field.dbColumnName\":\"RL_BillingName__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingName__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingStreetNumber__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingStreetNumber__c\",\"talend.field.dbColumnName\":\"RL_BillingStreetNumber__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingStreetNumber__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingStreet__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingStreet__c\",\"talend.field.dbColumnName\":\"RL_BillingStreet__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingStreet__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingTel1__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingTel1__c\",\"talend.field.dbColumnName\":\"RL_BillingTel1__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingTel1__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingTel2__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingTel2__c\",\"talend.field.dbColumnName\":\"RL_BillingTel2__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingTel2__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_BillingTel3__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_BillingTel3__c\",\"talend.field.dbColumnName\":\"RL_BillingTel3__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_BillingTel3__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_CodeSettlement__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_CodeSettlement__c\",\"talend.field.dbColumnName\":\"RL_CodeSettlement__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"11\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_CodeSettlement__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_CreatedAt__c\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"RL_CreatedAt__c\",\"talend.field.dbColumnName\":\"RL_CreatedAt__c\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_CreatedAt__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Email__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Email__c\",\"talend.field.dbColumnName\":\"RL_Email__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Email__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_ExternalAccountId__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_ExternalAccountId__c\",\"talend.field.dbColumnName\":\"RL_ExternalAccountId__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_ExternalAccountId__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_ExternalId__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_ExternalId__c\",\"talend.field.dbColumnName\":\"RL_ExternalId__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_ExternalId__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_IsActive__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_IsActive__c\",\"talend.field.dbColumnName\":\"RL_IsActive__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"1\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_IsActive__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_RecoveryPostalCode__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_RecoveryPostalCode__c\",\"talend.field.dbColumnName\":\"RL_RecoveryPostalCode__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_RecoveryPostalCode__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_RemovalStreetNumber__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_RemovalStreetNumber__c\",\"talend.field.dbColumnName\":\"RL_RemovalStreetNumber__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_RemovalStreetNumber__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_RemovalTel3__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_RemovalTel3__c\",\"talend.field.dbColumnName\":\"RL_RemovalTel3__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"40\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_RemovalTel3__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Code_Client__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Code_Client__c\",\"talend.field.dbColumnName\":\"Code_Client__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"30\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Code_Client__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Data_Quality_Description__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Data_Quality_Description__c\",\"talend.field.dbColumnName\":\"Data_Quality_Description__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"1300\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Data_Quality_Description__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Data_Quality_Score__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Data_Quality_Score__c\",\"talend.field.dbColumnName\":\"Data_Quality_Score__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Data_Quality_Score__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Company__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Company__c\",\"talend.field.dbColumnName\":\"RL_Company__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Company__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Removal_iso3_country__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Removal_iso3_country__c\",\"talend.field.dbColumnName\":\"RL_Removal_iso3_country__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"45\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Removal_iso3_country__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Archived__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Archived__c\",\"talend.field.dbColumnName\":\"RL_Archived__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Archived__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Tarification_par_palier__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Tarification_par_palier__c\",\"talend.field.dbColumnName\":\"RL_Tarification_par_palier__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Tarification_par_palier__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Contact_Commercial__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Contact_Commercial__c\",\"talend.field.dbColumnName\":\"Contact_Commercial__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Contact_Commercial__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"SocieteInfo__Id__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"SocieteInfo__Id__c\",\"talend.field.dbColumnName\":\"SocieteInfo__Id__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"SocieteInfo__Id__c\",\"di.column.relatedEntity\":\"\"}],\"di.table.name\":\"MAIN\",\"di.table.label\":\"Contact\"}",s);
     		                    						
     		                    				return s.toString();
     		                    		
 		                    		}
 		                    		
 		                    		void a(String part, StringBuilder strB) {
 		                    				strB.append(part);
 		                    		}
 		                    		
 		                    }
 		                    
 		                    SchemaSettingTool_tSalesforceInput_2_1_fisrt sst_tSalesforceInput_2_1_fisrt = new SchemaSettingTool_tSalesforceInput_2_1_fisrt();
 		                    
 		                    props_tSalesforceInput_2.module.main.setValue("schema",
 		                        new org.apache.avro.Schema.Parser().setValidateDefaults(false).parse(sst_tSalesforceInput_2_1_fisrt.getSchemaValue()));
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_2.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_2 = props_tSalesforceInput_2.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_2 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_2 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_2 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_2.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_2);
        }
    }
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_2.module.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_2 = props_tSalesforceInput_2.module.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_2 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_2 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_2 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_2.module.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_2);
        }
    }
globalMap.put("tSalesforceInput_2_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceInput_2);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceInput_2= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceInput_2_MAPPINGS_URL", mappings_url_tSalesforceInput_2);

org.talend.components.api.container.RuntimeContainer container_tSalesforceInput_2 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceInput_2";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceInput_2 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceInput_2 = null;
topology_tSalesforceInput_2 = org.talend.components.api.component.ConnectorTopology.OUTGOING;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceInput_2 = def_tSalesforceInput_2.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceInput_2, topology_tSalesforceInput_2);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceInput_2 = def_tSalesforceInput_2.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceInput_2 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceInput_2.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceInput_2 = componentRuntime_tSalesforceInput_2.initialize(container_tSalesforceInput_2, props_tSalesforceInput_2);

if (initVr_tSalesforceInput_2.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceInput_2.getMessage());
}

if(componentRuntime_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceInput_2 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceInput_2;
	compDriverInitialization_tSalesforceInput_2.runAtDriver(container_tSalesforceInput_2);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceInput_2 = null;
if(componentRuntime_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceInput_2 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceInput_2;
	if (doesNodeBelongToRequest_tSalesforceInput_2) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceInput_2 = sourceOrSink_tSalesforceInput_2.validate(container_tSalesforceInput_2);
        if (vr_tSalesforceInput_2.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceInput_2.getMessage());
        }
	}
}

    if (sourceOrSink_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.Source) {
        org.talend.components.api.component.runtime.Source source_tSalesforceInput_2 =
                (org.talend.components.api.component.runtime.Source)sourceOrSink_tSalesforceInput_2;
        reader_tSalesforceInput_2 = source_tSalesforceInput_2.createReader(container_tSalesforceInput_2);
	    reader_tSalesforceInput_2 = new org.talend.codegen.flowvariables.runtime.FlowVariablesReader(reader_tSalesforceInput_2, container_tSalesforceInput_2);

            boolean multi_output_is_allowed_tSalesforceInput_2 = false;
            org.talend.components.api.component.Connector c_tSalesforceInput_2 = null;
            for (org.talend.components.api.component.Connector currentConnector : props_tSalesforceInput_2.getAvailableConnectors(null, true)) {
                if (currentConnector.getName().equals("MAIN")) {
                    c_tSalesforceInput_2 = currentConnector;
                }

                if (currentConnector.getName().equals("REJECT")) {//it's better to move the code to javajet
                    multi_output_is_allowed_tSalesforceInput_2 = true;
                }
            }
            org.apache.avro.Schema schema_tSalesforceInput_2 = props_tSalesforceInput_2.getSchema(c_tSalesforceInput_2, true);

        org.talend.codegen.enforcer.OutgoingSchemaEnforcer outgoingEnforcer_tSalesforceInput_2 = org.talend.codegen.enforcer.EnforcerCreator.createOutgoingEnforcer(schema_tSalesforceInput_2, false);

        // Create a reusable factory that converts the output of the reader to an IndexedRecord.
        org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord> factory_tSalesforceInput_2 = null;

        // Iterate through the incoming data.
        boolean available_tSalesforceInput_2 = reader_tSalesforceInput_2.start();

        resourceMap.put("reader_tSalesforceInput_2", reader_tSalesforceInput_2);

        for (; available_tSalesforceInput_2; available_tSalesforceInput_2 = reader_tSalesforceInput_2.advance()) {
			nb_line_tSalesforceInput_2++;

			
			if (multi_output_is_allowed_tSalesforceInput_2) {
				
					row2 = null;
				

				
			}
			

			try {
				Object data_tSalesforceInput_2 = reader_tSalesforceInput_2.getCurrent();
				

					if(multi_output_is_allowed_tSalesforceInput_2) {
						row2 = new row2Struct();
					}

					
        // Construct the factory once when the first data arrives.
        if (factory_tSalesforceInput_2 == null) {
            factory_tSalesforceInput_2 = (org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord>)
                    new org.talend.daikon.avro.AvroRegistry()
                            .createIndexedRecordConverter(data_tSalesforceInput_2.getClass());
        }

        // Enforce the outgoing schema on the input.
        outgoingEnforcer_tSalesforceInput_2.setWrapped(factory_tSalesforceInput_2.convertToAvro(data_tSalesforceInput_2));
                Object columnValue_0_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(0);
                        row2.Id = (String) (columnValue_0_tSalesforceInput_2);
                Object columnValue_1_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(1);
                    if (columnValue_1_tSalesforceInput_2 == null) {
                        row2.IsDeleted = false;
                    } else {
                            row2.IsDeleted = (boolean) (columnValue_1_tSalesforceInput_2);
                    }
                Object columnValue_2_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(2);
                        row2.MasterRecordId = (String) (columnValue_2_tSalesforceInput_2);
                Object columnValue_3_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(3);
                        row2.AccountId = (String) (columnValue_3_tSalesforceInput_2);
                Object columnValue_4_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(4);
                        row2.LastName = (String) (columnValue_4_tSalesforceInput_2);
                Object columnValue_5_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(5);
                        row2.FirstName = (String) (columnValue_5_tSalesforceInput_2);
                Object columnValue_6_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(6);
                        row2.Salutation = (String) (columnValue_6_tSalesforceInput_2);
                Object columnValue_7_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(7);
                        row2.MiddleName = (String) (columnValue_7_tSalesforceInput_2);
                Object columnValue_8_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(8);
                        row2.Suffix = (String) (columnValue_8_tSalesforceInput_2);
                Object columnValue_9_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(9);
                        row2.Name = (String) (columnValue_9_tSalesforceInput_2);
                Object columnValue_10_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(10);
                        row2.RecordTypeId = (String) (columnValue_10_tSalesforceInput_2);
                Object columnValue_11_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(11);
                        row2.MailingStreet = (String) (columnValue_11_tSalesforceInput_2);
                Object columnValue_12_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(12);
                        row2.MailingCity = (String) (columnValue_12_tSalesforceInput_2);
                Object columnValue_13_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(13);
                        row2.MailingState = (String) (columnValue_13_tSalesforceInput_2);
                Object columnValue_14_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(14);
                        row2.MailingPostalCode = (String) (columnValue_14_tSalesforceInput_2);
                Object columnValue_15_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(15);
                        row2.MailingCountry = (String) (columnValue_15_tSalesforceInput_2);
                Object columnValue_16_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(16);
                        row2.MailingLatitude = (Double) (columnValue_16_tSalesforceInput_2);
                Object columnValue_17_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(17);
                        row2.MailingLongitude = (Double) (columnValue_17_tSalesforceInput_2);
                Object columnValue_18_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(18);
                        row2.MailingGeocodeAccuracy = (String) (columnValue_18_tSalesforceInput_2);
                Object columnValue_19_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(19);
                        row2.MailingAddress = (String) (columnValue_19_tSalesforceInput_2);
                Object columnValue_20_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(20);
                        row2.Phone = (String) (columnValue_20_tSalesforceInput_2);
                Object columnValue_21_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(21);
                        row2.Fax = (String) (columnValue_21_tSalesforceInput_2);
                Object columnValue_22_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(22);
                        row2.MobilePhone = (String) (columnValue_22_tSalesforceInput_2);
                Object columnValue_23_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(23);
                        row2.ReportsToId = (String) (columnValue_23_tSalesforceInput_2);
                Object columnValue_24_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(24);
                        row2.Email = (String) (columnValue_24_tSalesforceInput_2);
                Object columnValue_25_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(25);
                        row2.Title = (String) (columnValue_25_tSalesforceInput_2);
                Object columnValue_26_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(26);
                        row2.Department = (String) (columnValue_26_tSalesforceInput_2);
                Object columnValue_27_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(27);
                        row2.OwnerId = (String) (columnValue_27_tSalesforceInput_2);
                Object columnValue_28_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(28);
                        row2.CreatedDate = (java.util.Date) (columnValue_28_tSalesforceInput_2);
                Object columnValue_29_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(29);
                        row2.CreatedById = (String) (columnValue_29_tSalesforceInput_2);
                Object columnValue_30_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(30);
                        row2.LastModifiedDate = (java.util.Date) (columnValue_30_tSalesforceInput_2);
                Object columnValue_31_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(31);
                        row2.LastModifiedById = (String) (columnValue_31_tSalesforceInput_2);
                Object columnValue_32_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(32);
                        row2.SystemModstamp = (java.util.Date) (columnValue_32_tSalesforceInput_2);
                Object columnValue_33_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(33);
                        row2.LastActivityDate = (java.util.Date) (columnValue_33_tSalesforceInput_2);
                Object columnValue_34_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(34);
                        row2.LastCURequestDate = (java.util.Date) (columnValue_34_tSalesforceInput_2);
                Object columnValue_35_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(35);
                        row2.LastCUUpdateDate = (java.util.Date) (columnValue_35_tSalesforceInput_2);
                Object columnValue_36_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(36);
                        row2.LastViewedDate = (java.util.Date) (columnValue_36_tSalesforceInput_2);
                Object columnValue_37_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(37);
                        row2.LastReferencedDate = (java.util.Date) (columnValue_37_tSalesforceInput_2);
                Object columnValue_38_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(38);
                        row2.EmailBouncedReason = (String) (columnValue_38_tSalesforceInput_2);
                Object columnValue_39_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(39);
                        row2.EmailBouncedDate = (java.util.Date) (columnValue_39_tSalesforceInput_2);
                Object columnValue_40_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(40);
                    if (columnValue_40_tSalesforceInput_2 == null) {
                        row2.IsEmailBounced = false;
                    } else {
                            row2.IsEmailBounced = (boolean) (columnValue_40_tSalesforceInput_2);
                    }
                Object columnValue_41_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(41);
                        row2.PhotoUrl = (String) (columnValue_41_tSalesforceInput_2);
                Object columnValue_42_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(42);
                        row2.Jigsaw = (String) (columnValue_42_tSalesforceInput_2);
                Object columnValue_43_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(43);
                        row2.JigsawContactId = (String) (columnValue_43_tSalesforceInput_2);
                Object columnValue_44_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(44);
                        row2.RL_AccountingMail__c = (String) (columnValue_44_tSalesforceInput_2);
                Object columnValue_45_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(45);
                        row2.RL_Agency__c = (String) (columnValue_45_tSalesforceInput_2);
                Object columnValue_46_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(46);
                        row2.RL_BankCode__c = (String) (columnValue_46_tSalesforceInput_2);
                Object columnValue_47_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(47);
                        row2.RL_BankKey__c = (String) (columnValue_47_tSalesforceInput_2);
                Object columnValue_48_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(48);
                        row2.RL_BillingCity__c = (String) (columnValue_48_tSalesforceInput_2);
                Object columnValue_49_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(49);
                        row2.RL_BillingCountry__c = (String) (columnValue_49_tSalesforceInput_2);
                Object columnValue_50_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(50);
                        row2.RL_BillingName__c = (String) (columnValue_50_tSalesforceInput_2);
                Object columnValue_51_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(51);
                        row2.RL_BillingStreetNumber__c = (String) (columnValue_51_tSalesforceInput_2);
                Object columnValue_52_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(52);
                        row2.RL_BillingStreet__c = (String) (columnValue_52_tSalesforceInput_2);
                Object columnValue_53_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(53);
                        row2.RL_BillingTel1__c = (String) (columnValue_53_tSalesforceInput_2);
                Object columnValue_54_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(54);
                        row2.RL_BillingTel2__c = (String) (columnValue_54_tSalesforceInput_2);
                Object columnValue_55_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(55);
                        row2.RL_BillingTel3__c = (String) (columnValue_55_tSalesforceInput_2);
                Object columnValue_56_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(56);
                        row2.RL_CodeSettlement__c = (Double) (columnValue_56_tSalesforceInput_2);
                Object columnValue_57_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(57);
                        row2.RL_CreatedAt__c = (java.util.Date) (columnValue_57_tSalesforceInput_2);
                Object columnValue_58_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(58);
                        row2.RL_Email__c = (String) (columnValue_58_tSalesforceInput_2);
                Object columnValue_59_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(59);
                        row2.RL_ExternalAccountId__c = (Double) (columnValue_59_tSalesforceInput_2);
                Object columnValue_60_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(60);
                        row2.RL_ExternalId__c = (Double) (columnValue_60_tSalesforceInput_2);
                Object columnValue_61_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(61);
                        row2.RL_IsActive__c = (Double) (columnValue_61_tSalesforceInput_2);
                Object columnValue_62_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(62);
                        row2.RL_RecoveryPostalCode__c = (String) (columnValue_62_tSalesforceInput_2);
                Object columnValue_63_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(63);
                        row2.RL_RemovalStreetNumber__c = (String) (columnValue_63_tSalesforceInput_2);
                Object columnValue_64_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(64);
                        row2.RL_RemovalTel3__c = (String) (columnValue_64_tSalesforceInput_2);
                Object columnValue_65_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(65);
                        row2.Code_Client__c = (String) (columnValue_65_tSalesforceInput_2);
                Object columnValue_66_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(66);
                        row2.Data_Quality_Description__c = (String) (columnValue_66_tSalesforceInput_2);
                Object columnValue_67_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(67);
                        row2.Data_Quality_Score__c = (Double) (columnValue_67_tSalesforceInput_2);
                Object columnValue_68_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(68);
                        row2.RL_Company__c = (String) (columnValue_68_tSalesforceInput_2);
                Object columnValue_69_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(69);
                        row2.RL_Removal_iso3_country__c = (String) (columnValue_69_tSalesforceInput_2);
                Object columnValue_70_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(70);
                    if (columnValue_70_tSalesforceInput_2 == null) {
                        row2.RL_Archived__c = false;
                    } else {
                            row2.RL_Archived__c = (boolean) (columnValue_70_tSalesforceInput_2);
                    }
                Object columnValue_71_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(71);
                    if (columnValue_71_tSalesforceInput_2 == null) {
                        row2.RL_Tarification_par_palier__c = false;
                    } else {
                            row2.RL_Tarification_par_palier__c = (boolean) (columnValue_71_tSalesforceInput_2);
                    }
                Object columnValue_72_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(72);
                        row2.Contact_Commercial__c = (String) (columnValue_72_tSalesforceInput_2);
                Object columnValue_73_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(73);
                        row2.SocieteInfo__Id__c = (String) (columnValue_73_tSalesforceInput_2);
			} catch (org.talend.components.api.exception.DataRejectException e_tSalesforceInput_2) {
				java.util.Map<String,Object> info_tSalesforceInput_2 = e_tSalesforceInput_2.getRejectInfo();
				
					//TODO use a method instead of getting method by the special key "error/errorMessage"
					Object errorMessage_tSalesforceInput_2 = null;
					if(info_tSalesforceInput_2.containsKey("error")){
						errorMessage_tSalesforceInput_2 = info_tSalesforceInput_2.get("error");
					}else if(info_tSalesforceInput_2.containsKey("errorMessage")){
						errorMessage_tSalesforceInput_2 = info_tSalesforceInput_2.get("errorMessage");
					}else{
						errorMessage_tSalesforceInput_2 = "Rejected but error message missing";
					}
					errorMessage_tSalesforceInput_2 = "Row "+ nb_line_tSalesforceInput_2 + ": "+errorMessage_tSalesforceInput_2;
					System.err.println(errorMessage_tSalesforceInput_2);
				
					// If the record is reject, the main line record should put NULL
					row2 = null;
				
			} // end of catch

                java.lang.Iterable<?> outgoingMainRecordsList_tSalesforceInput_2 = new java.util.ArrayList<Object>();
                java.util.Iterator outgoingMainRecordsIt_tSalesforceInput_2 = null;


 



/**
 * [tSalesforceInput_2 begin ] stop
 */
	
	/**
	 * [tSalesforceInput_2 main ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		


 


	tos_count_tSalesforceInput_2++;

/**
 * [tSalesforceInput_2 main ] stop
 */
	
	/**
	 * [tSalesforceInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		


 



/**
 * [tSalesforceInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tConvertType_2 main ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tSalesforceInput_2","Contact","tSalesforceInput","tConvertType_2","tConvertType_2","tConvertType"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		


  row5 = new row5Struct();
  boolean bHasError_tConvertType_2 = false;             
          try {
              if ("".equals(row2.Id)){  
                row2.Id = null;
              }
              row5.Id=TypeConvert.String2String(row2.Id);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.IsDeleted=TypeConvert.boolean2boolean(row2.IsDeleted);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MasterRecordId)){  
                row2.MasterRecordId = null;
              }
              row5.MasterRecordId=TypeConvert.String2String(row2.MasterRecordId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.AccountId)){  
                row2.AccountId = null;
              }
              row5.AccountId=TypeConvert.String2String(row2.AccountId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.LastName)){  
                row2.LastName = null;
              }
              row5.LastName=TypeConvert.String2String(row2.LastName);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.FirstName)){  
                row2.FirstName = null;
              }
              row5.FirstName=TypeConvert.String2String(row2.FirstName);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Salutation)){  
                row2.Salutation = null;
              }
              row5.Salutation=TypeConvert.String2String(row2.Salutation);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MiddleName)){  
                row2.MiddleName = null;
              }
              row5.MiddleName=TypeConvert.String2String(row2.MiddleName);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Suffix)){  
                row2.Suffix = null;
              }
              row5.Suffix=TypeConvert.String2String(row2.Suffix);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Name)){  
                row2.Name = null;
              }
              row5.Name=TypeConvert.String2String(row2.Name);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RecordTypeId)){  
                row2.RecordTypeId = null;
              }
              row5.RecordTypeId=TypeConvert.String2String(row2.RecordTypeId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingStreet)){  
                row2.MailingStreet = null;
              }
              row5.MailingStreet=TypeConvert.String2String(row2.MailingStreet);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingCity)){  
                row2.MailingCity = null;
              }
              row5.MailingCity=TypeConvert.String2String(row2.MailingCity);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingState)){  
                row2.MailingState = null;
              }
              row5.MailingState=TypeConvert.String2String(row2.MailingState);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingPostalCode)){  
                row2.MailingPostalCode = null;
              }
              row5.MailingPostalCode=TypeConvert.String2String(row2.MailingPostalCode);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingCountry)){  
                row2.MailingCountry = null;
              }
              row5.MailingCountry=TypeConvert.String2String(row2.MailingCountry);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.MailingLatitude=TypeConvert.Double2Double(row2.MailingLatitude);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.MailingLongitude=TypeConvert.Double2Double(row2.MailingLongitude);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingGeocodeAccuracy)){  
                row2.MailingGeocodeAccuracy = null;
              }
              row5.MailingGeocodeAccuracy=TypeConvert.String2String(row2.MailingGeocodeAccuracy);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MailingAddress)){  
                row2.MailingAddress = null;
              }
              row5.MailingAddress=TypeConvert.String2String(row2.MailingAddress);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Phone)){  
                row2.Phone = null;
              }
              row5.Phone=TypeConvert.String2String(row2.Phone);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Fax)){  
                row2.Fax = null;
              }
              row5.Fax=TypeConvert.String2String(row2.Fax);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.MobilePhone)){  
                row2.MobilePhone = null;
              }
              row5.MobilePhone=TypeConvert.String2String(row2.MobilePhone);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.ReportsToId)){  
                row2.ReportsToId = null;
              }
              row5.ReportsToId=TypeConvert.String2String(row2.ReportsToId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Email)){  
                row2.Email = null;
              }
              row5.Email=TypeConvert.String2String(row2.Email);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Title)){  
                row2.Title = null;
              }
              row5.Title=TypeConvert.String2String(row2.Title);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Department)){  
                row2.Department = null;
              }
              row5.Department=TypeConvert.String2String(row2.Department);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.OwnerId)){  
                row2.OwnerId = null;
              }
              row5.OwnerId=TypeConvert.String2String(row2.OwnerId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.CreatedDate=TypeConvert.Date2Date(row2.CreatedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.CreatedById)){  
                row2.CreatedById = null;
              }
              row5.CreatedById=TypeConvert.String2String(row2.CreatedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastModifiedDate=TypeConvert.Date2Date(row2.LastModifiedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.LastModifiedById)){  
                row2.LastModifiedById = null;
              }
              row5.LastModifiedById=TypeConvert.String2String(row2.LastModifiedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.SystemModstamp=TypeConvert.Date2Date(row2.SystemModstamp);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastActivityDate=TypeConvert.Date2Date(row2.LastActivityDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastCURequestDate=TypeConvert.Date2Date(row2.LastCURequestDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastCUUpdateDate=TypeConvert.Date2Date(row2.LastCUUpdateDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastViewedDate=TypeConvert.Date2Date(row2.LastViewedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastReferencedDate=TypeConvert.Date2Date(row2.LastReferencedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.EmailBouncedReason)){  
                row2.EmailBouncedReason = null;
              }
              row5.EmailBouncedReason=TypeConvert.String2String(row2.EmailBouncedReason);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.EmailBouncedDate=TypeConvert.Date2Date(row2.EmailBouncedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.IsEmailBounced=TypeConvert.boolean2boolean(row2.IsEmailBounced);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.PhotoUrl)){  
                row2.PhotoUrl = null;
              }
              row5.PhotoUrl=TypeConvert.String2String(row2.PhotoUrl);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Jigsaw)){  
                row2.Jigsaw = null;
              }
              row5.Jigsaw=TypeConvert.String2String(row2.Jigsaw);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.JigsawContactId)){  
                row2.JigsawContactId = null;
              }
              row5.JigsawContactId=TypeConvert.String2String(row2.JigsawContactId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_AccountingMail__c)){  
                row2.RL_AccountingMail__c = null;
              }
              row5.RL_AccountingMail__c=TypeConvert.String2String(row2.RL_AccountingMail__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Agency__c)){  
                row2.RL_Agency__c = null;
              }
              row5.RL_Agency__c=TypeConvert.String2String(row2.RL_Agency__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BankCode__c)){  
                row2.RL_BankCode__c = null;
              }
              row5.RL_BankCode__c=TypeConvert.String2String(row2.RL_BankCode__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BankKey__c)){  
                row2.RL_BankKey__c = null;
              }
              row5.RL_BankKey__c=TypeConvert.String2String(row2.RL_BankKey__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingCity__c)){  
                row2.RL_BillingCity__c = null;
              }
              row5.RL_BillingCity__c=TypeConvert.String2String(row2.RL_BillingCity__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingCountry__c)){  
                row2.RL_BillingCountry__c = null;
              }
              row5.RL_BillingCountry__c=TypeConvert.String2String(row2.RL_BillingCountry__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingName__c)){  
                row2.RL_BillingName__c = null;
              }
              row5.RL_BillingName__c=TypeConvert.String2String(row2.RL_BillingName__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingStreetNumber__c)){  
                row2.RL_BillingStreetNumber__c = null;
              }
              row5.RL_BillingStreetNumber__c=TypeConvert.String2String(row2.RL_BillingStreetNumber__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingStreet__c)){  
                row2.RL_BillingStreet__c = null;
              }
              row5.RL_BillingStreet__c=TypeConvert.String2String(row2.RL_BillingStreet__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingTel1__c)){  
                row2.RL_BillingTel1__c = null;
              }
              row5.RL_BillingTel1__c=TypeConvert.String2String(row2.RL_BillingTel1__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingTel2__c)){  
                row2.RL_BillingTel2__c = null;
              }
              row5.RL_BillingTel2__c=TypeConvert.String2String(row2.RL_BillingTel2__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_BillingTel3__c)){  
                row2.RL_BillingTel3__c = null;
              }
              row5.RL_BillingTel3__c=TypeConvert.String2String(row2.RL_BillingTel3__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_CodeSettlement__c=TypeConvert.Double2Double(row2.RL_CodeSettlement__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_CreatedAt__c=TypeConvert.Date2Date(row2.RL_CreatedAt__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Email__c)){  
                row2.RL_Email__c = null;
              }
              row5.RL_Email__c=TypeConvert.String2String(row2.RL_Email__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_ExternalAccountId__c=TypeConvert.Double2Double(row2.RL_ExternalAccountId__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_ExternalId__c=TypeConvert.Double2Integer(row2.RL_ExternalId__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_IsActive__c=TypeConvert.Double2Double(row2.RL_IsActive__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_RecoveryPostalCode__c)){  
                row2.RL_RecoveryPostalCode__c = null;
              }
              row5.RL_RecoveryPostalCode__c=TypeConvert.String2String(row2.RL_RecoveryPostalCode__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_RemovalStreetNumber__c)){  
                row2.RL_RemovalStreetNumber__c = null;
              }
              row5.RL_RemovalStreetNumber__c=TypeConvert.String2String(row2.RL_RemovalStreetNumber__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_RemovalTel3__c)){  
                row2.RL_RemovalTel3__c = null;
              }
              row5.RL_RemovalTel3__c=TypeConvert.String2String(row2.RL_RemovalTel3__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Code_Client__c)){  
                row2.Code_Client__c = null;
              }
              row5.Code_Client__c=TypeConvert.String2String(row2.Code_Client__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Data_Quality_Description__c)){  
                row2.Data_Quality_Description__c = null;
              }
              row5.Data_Quality_Description__c=TypeConvert.String2String(row2.Data_Quality_Description__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.Data_Quality_Score__c=TypeConvert.Double2Double(row2.Data_Quality_Score__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Company__c)){  
                row2.RL_Company__c = null;
              }
              row5.RL_Company__c=TypeConvert.String2String(row2.RL_Company__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Removal_iso3_country__c)){  
                row2.RL_Removal_iso3_country__c = null;
              }
              row5.RL_Removal_iso3_country__c=TypeConvert.String2String(row2.RL_Removal_iso3_country__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_Archived__c=TypeConvert.boolean2boolean(row2.RL_Archived__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_Tarification_par_palier__c=TypeConvert.boolean2boolean(row2.RL_Tarification_par_palier__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Contact_Commercial__c)){  
                row2.Contact_Commercial__c = null;
              }
              row5.Contact_Commercial__c=TypeConvert.String2String(row2.Contact_Commercial__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.SocieteInfo__Id__c)){  
                row2.SocieteInfo__Id__c = null;
              }
              row5.SocieteInfo__Id__c=TypeConvert.String2String(row2.SocieteInfo__Id__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_2) {row5 = null;}

  nb_line_tConvertType_2 ++ ;

 


	tos_count_tConvertType_2++;

/**
 * [tConvertType_2 main ] stop
 */
	
	/**
	 * [tConvertType_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tFilterRow_12 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tConvertType_2","tConvertType_2","tConvertType","tFilterRow_12","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

          row6 = null;
    Operator_tFilterRow_12 ope_tFilterRow_12 = new Operator_tFilterRow_12("&&");
    
    if (ope_tFilterRow_12.getMatchFlag()) {
              if(row6 == null){ 
                row6 = new row6Struct();
              }
               row6.Id = row5.Id;
               row6.IsDeleted = row5.IsDeleted;
               row6.MasterRecordId = row5.MasterRecordId;
               row6.AccountId = row5.AccountId;
               row6.LastName = row5.LastName;
               row6.FirstName = row5.FirstName;
               row6.Salutation = row5.Salutation;
               row6.MiddleName = row5.MiddleName;
               row6.Suffix = row5.Suffix;
               row6.Name = row5.Name;
               row6.RecordTypeId = row5.RecordTypeId;
               row6.MailingStreet = row5.MailingStreet;
               row6.MailingCity = row5.MailingCity;
               row6.MailingState = row5.MailingState;
               row6.MailingPostalCode = row5.MailingPostalCode;
               row6.MailingCountry = row5.MailingCountry;
               row6.MailingLatitude = row5.MailingLatitude;
               row6.MailingLongitude = row5.MailingLongitude;
               row6.MailingGeocodeAccuracy = row5.MailingGeocodeAccuracy;
               row6.MailingAddress = row5.MailingAddress;
               row6.Phone = row5.Phone;
               row6.Fax = row5.Fax;
               row6.MobilePhone = row5.MobilePhone;
               row6.ReportsToId = row5.ReportsToId;
               row6.Email = row5.Email;
               row6.Title = row5.Title;
               row6.Department = row5.Department;
               row6.OwnerId = row5.OwnerId;
               row6.CreatedDate = row5.CreatedDate;
               row6.CreatedById = row5.CreatedById;
               row6.LastModifiedDate = row5.LastModifiedDate;
               row6.LastModifiedById = row5.LastModifiedById;
               row6.SystemModstamp = row5.SystemModstamp;
               row6.LastActivityDate = row5.LastActivityDate;
               row6.LastCURequestDate = row5.LastCURequestDate;
               row6.LastCUUpdateDate = row5.LastCUUpdateDate;
               row6.LastViewedDate = row5.LastViewedDate;
               row6.LastReferencedDate = row5.LastReferencedDate;
               row6.EmailBouncedReason = row5.EmailBouncedReason;
               row6.EmailBouncedDate = row5.EmailBouncedDate;
               row6.IsEmailBounced = row5.IsEmailBounced;
               row6.PhotoUrl = row5.PhotoUrl;
               row6.Jigsaw = row5.Jigsaw;
               row6.JigsawContactId = row5.JigsawContactId;
               row6.RL_AccountingMail__c = row5.RL_AccountingMail__c;
               row6.RL_Agency__c = row5.RL_Agency__c;
               row6.RL_BankCode__c = row5.RL_BankCode__c;
               row6.RL_BankKey__c = row5.RL_BankKey__c;
               row6.RL_BillingCity__c = row5.RL_BillingCity__c;
               row6.RL_BillingCountry__c = row5.RL_BillingCountry__c;
               row6.RL_BillingName__c = row5.RL_BillingName__c;
               row6.RL_BillingStreetNumber__c = row5.RL_BillingStreetNumber__c;
               row6.RL_BillingStreet__c = row5.RL_BillingStreet__c;
               row6.RL_BillingTel1__c = row5.RL_BillingTel1__c;
               row6.RL_BillingTel2__c = row5.RL_BillingTel2__c;
               row6.RL_BillingTel3__c = row5.RL_BillingTel3__c;
               row6.RL_CodeSettlement__c = row5.RL_CodeSettlement__c;
               row6.RL_CreatedAt__c = row5.RL_CreatedAt__c;
               row6.RL_Email__c = row5.RL_Email__c;
               row6.RL_ExternalAccountId__c = row5.RL_ExternalAccountId__c;
               row6.RL_ExternalId__c = row5.RL_ExternalId__c;
               row6.RL_IsActive__c = row5.RL_IsActive__c;
               row6.RL_RecoveryPostalCode__c = row5.RL_RecoveryPostalCode__c;
               row6.RL_RemovalStreetNumber__c = row5.RL_RemovalStreetNumber__c;
               row6.RL_RemovalTel3__c = row5.RL_RemovalTel3__c;
               row6.Code_Client__c = row5.Code_Client__c;
               row6.Data_Quality_Description__c = row5.Data_Quality_Description__c;
               row6.Data_Quality_Score__c = row5.Data_Quality_Score__c;
               row6.RL_Company__c = row5.RL_Company__c;
               row6.RL_Removal_iso3_country__c = row5.RL_Removal_iso3_country__c;
               row6.RL_Archived__c = row5.RL_Archived__c;
               row6.RL_Tarification_par_palier__c = row5.RL_Tarification_par_palier__c;
               row6.Contact_Commercial__c = row5.Contact_Commercial__c;
               row6.SocieteInfo__Id__c = row5.SocieteInfo__Id__c;
					log.debug("tFilterRow_12 - Process the record " + (nb_line_tFilterRow_12+1) + ".");
					    
      nb_line_ok_tFilterRow_12++;
    } else {
      nb_line_reject_tFilterRow_12++;
    }

nb_line_tFilterRow_12++;

 


	tos_count_tFilterRow_12++;

/**
 * [tFilterRow_12 main ] stop
 */
	
	/**
	 * [tFilterRow_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tUniqRow_2 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tFilterRow_12","tFilterRow_1","tFilterRow","tUniqRow_2","tUniqRow_2","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		
row8.Id = row6.Id;			row8.IsDeleted = row6.IsDeleted;			row8.MasterRecordId = row6.MasterRecordId;			row8.AccountId = row6.AccountId;			row8.LastName = row6.LastName;			row8.FirstName = row6.FirstName;			row8.Salutation = row6.Salutation;			row8.MiddleName = row6.MiddleName;			row8.Suffix = row6.Suffix;			row8.Name = row6.Name;			row8.RecordTypeId = row6.RecordTypeId;			row8.MailingStreet = row6.MailingStreet;			row8.MailingCity = row6.MailingCity;			row8.MailingState = row6.MailingState;			row8.MailingPostalCode = row6.MailingPostalCode;			row8.MailingCountry = row6.MailingCountry;			row8.MailingLatitude = row6.MailingLatitude;			row8.MailingLongitude = row6.MailingLongitude;			row8.MailingGeocodeAccuracy = row6.MailingGeocodeAccuracy;			row8.MailingAddress = row6.MailingAddress;			row8.Phone = row6.Phone;			row8.Fax = row6.Fax;			row8.MobilePhone = row6.MobilePhone;			row8.ReportsToId = row6.ReportsToId;			row8.Email = row6.Email;			row8.Title = row6.Title;			row8.Department = row6.Department;			row8.OwnerId = row6.OwnerId;			row8.CreatedDate = row6.CreatedDate;			row8.CreatedById = row6.CreatedById;			row8.LastModifiedDate = row6.LastModifiedDate;			row8.LastModifiedById = row6.LastModifiedById;			row8.SystemModstamp = row6.SystemModstamp;			row8.LastActivityDate = row6.LastActivityDate;			row8.LastCURequestDate = row6.LastCURequestDate;			row8.LastCUUpdateDate = row6.LastCUUpdateDate;			row8.LastViewedDate = row6.LastViewedDate;			row8.LastReferencedDate = row6.LastReferencedDate;			row8.EmailBouncedReason = row6.EmailBouncedReason;			row8.EmailBouncedDate = row6.EmailBouncedDate;			row8.IsEmailBounced = row6.IsEmailBounced;			row8.PhotoUrl = row6.PhotoUrl;			row8.Jigsaw = row6.Jigsaw;			row8.JigsawContactId = row6.JigsawContactId;			row8.RL_AccountingMail__c = row6.RL_AccountingMail__c;			row8.RL_Agency__c = row6.RL_Agency__c;			row8.RL_BankCode__c = row6.RL_BankCode__c;			row8.RL_BankKey__c = row6.RL_BankKey__c;			row8.RL_BillingCity__c = row6.RL_BillingCity__c;			row8.RL_BillingCountry__c = row6.RL_BillingCountry__c;			row8.RL_BillingName__c = row6.RL_BillingName__c;			row8.RL_BillingStreetNumber__c = row6.RL_BillingStreetNumber__c;			row8.RL_BillingStreet__c = row6.RL_BillingStreet__c;			row8.RL_BillingTel1__c = row6.RL_BillingTel1__c;			row8.RL_BillingTel2__c = row6.RL_BillingTel2__c;			row8.RL_BillingTel3__c = row6.RL_BillingTel3__c;			row8.RL_CodeSettlement__c = row6.RL_CodeSettlement__c;			row8.RL_CreatedAt__c = row6.RL_CreatedAt__c;			row8.RL_Email__c = row6.RL_Email__c;			row8.RL_ExternalAccountId__c = row6.RL_ExternalAccountId__c;			row8.RL_ExternalId__c = row6.RL_ExternalId__c;			row8.RL_IsActive__c = row6.RL_IsActive__c;			row8.RL_RecoveryPostalCode__c = row6.RL_RecoveryPostalCode__c;			row8.RL_RemovalStreetNumber__c = row6.RL_RemovalStreetNumber__c;			row8.RL_RemovalTel3__c = row6.RL_RemovalTel3__c;			row8.Code_Client__c = row6.Code_Client__c;			row8.Data_Quality_Description__c = row6.Data_Quality_Description__c;			row8.Data_Quality_Score__c = row6.Data_Quality_Score__c;			row8.RL_Company__c = row6.RL_Company__c;			row8.RL_Removal_iso3_country__c = row6.RL_Removal_iso3_country__c;			row8.RL_Archived__c = row6.RL_Archived__c;			row8.RL_Tarification_par_palier__c = row6.RL_Tarification_par_palier__c;			row8.Contact_Commercial__c = row6.Contact_Commercial__c;			row8.SocieteInfo__Id__c = row6.SocieteInfo__Id__c;			row8.Id = row6.Id;			row8.IsDeleted = row6.IsDeleted;			row8.MasterRecordId = row6.MasterRecordId;			row8.AccountId = row6.AccountId;			row8.LastName = row6.LastName;			row8.FirstName = row6.FirstName;			row8.Salutation = row6.Salutation;			row8.MiddleName = row6.MiddleName;			row8.Suffix = row6.Suffix;			row8.Name = row6.Name;			row8.RecordTypeId = row6.RecordTypeId;			row8.MailingStreet = row6.MailingStreet;			row8.MailingCity = row6.MailingCity;			row8.MailingState = row6.MailingState;			row8.MailingPostalCode = row6.MailingPostalCode;			row8.MailingCountry = row6.MailingCountry;			row8.MailingLatitude = row6.MailingLatitude;			row8.MailingLongitude = row6.MailingLongitude;			row8.MailingGeocodeAccuracy = row6.MailingGeocodeAccuracy;			row8.MailingAddress = row6.MailingAddress;			row8.Phone = row6.Phone;			row8.Fax = row6.Fax;			row8.MobilePhone = row6.MobilePhone;			row8.ReportsToId = row6.ReportsToId;			row8.Email = row6.Email;			row8.Title = row6.Title;			row8.Department = row6.Department;			row8.OwnerId = row6.OwnerId;			row8.CreatedDate = row6.CreatedDate;			row8.CreatedById = row6.CreatedById;			row8.LastModifiedDate = row6.LastModifiedDate;			row8.LastModifiedById = row6.LastModifiedById;			row8.SystemModstamp = row6.SystemModstamp;			row8.LastActivityDate = row6.LastActivityDate;			row8.LastCURequestDate = row6.LastCURequestDate;			row8.LastCUUpdateDate = row6.LastCUUpdateDate;			row8.LastViewedDate = row6.LastViewedDate;			row8.LastReferencedDate = row6.LastReferencedDate;			row8.EmailBouncedReason = row6.EmailBouncedReason;			row8.EmailBouncedDate = row6.EmailBouncedDate;			row8.IsEmailBounced = row6.IsEmailBounced;			row8.PhotoUrl = row6.PhotoUrl;			row8.Jigsaw = row6.Jigsaw;			row8.JigsawContactId = row6.JigsawContactId;			row8.RL_AccountingMail__c = row6.RL_AccountingMail__c;			row8.RL_Agency__c = row6.RL_Agency__c;			row8.RL_BankCode__c = row6.RL_BankCode__c;			row8.RL_BankKey__c = row6.RL_BankKey__c;			row8.RL_BillingCity__c = row6.RL_BillingCity__c;			row8.RL_BillingCountry__c = row6.RL_BillingCountry__c;			row8.RL_BillingName__c = row6.RL_BillingName__c;			row8.RL_BillingStreetNumber__c = row6.RL_BillingStreetNumber__c;			row8.RL_BillingStreet__c = row6.RL_BillingStreet__c;			row8.RL_BillingTel1__c = row6.RL_BillingTel1__c;			row8.RL_BillingTel2__c = row6.RL_BillingTel2__c;			row8.RL_BillingTel3__c = row6.RL_BillingTel3__c;			row8.RL_CodeSettlement__c = row6.RL_CodeSettlement__c;			row8.RL_CreatedAt__c = row6.RL_CreatedAt__c;			row8.RL_Email__c = row6.RL_Email__c;			row8.RL_ExternalAccountId__c = row6.RL_ExternalAccountId__c;			row8.RL_ExternalId__c = row6.RL_ExternalId__c;			row8.RL_IsActive__c = row6.RL_IsActive__c;			row8.RL_RecoveryPostalCode__c = row6.RL_RecoveryPostalCode__c;			row8.RL_RemovalStreetNumber__c = row6.RL_RemovalStreetNumber__c;			row8.RL_RemovalTel3__c = row6.RL_RemovalTel3__c;			row8.Code_Client__c = row6.Code_Client__c;			row8.Data_Quality_Description__c = row6.Data_Quality_Description__c;			row8.Data_Quality_Score__c = row6.Data_Quality_Score__c;			row8.RL_Company__c = row6.RL_Company__c;			row8.RL_Removal_iso3_country__c = row6.RL_Removal_iso3_country__c;			row8.RL_Archived__c = row6.RL_Archived__c;			row8.RL_Tarification_par_palier__c = row6.RL_Tarification_par_palier__c;			row8.Contact_Commercial__c = row6.Contact_Commercial__c;			row8.SocieteInfo__Id__c = row6.SocieteInfo__Id__c;			

 


	tos_count_tUniqRow_2++;

/**
 * [tUniqRow_2 main ] stop
 */
	
	/**
	 * [tUniqRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tAdvancedHash_row8 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tUniqRow_2","tUniqRow_2","tUniqRow","tAdvancedHash_row8","tAdvancedHash_row8","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		


			   
			   

					row8Struct row8_HashRow = new row8Struct();
		   	   	   
				
				row8_HashRow.Id = row8.Id;
				
				row8_HashRow.IsDeleted = row8.IsDeleted;
				
				row8_HashRow.MasterRecordId = row8.MasterRecordId;
				
				row8_HashRow.AccountId = row8.AccountId;
				
				row8_HashRow.LastName = row8.LastName;
				
				row8_HashRow.FirstName = row8.FirstName;
				
				row8_HashRow.Salutation = row8.Salutation;
				
				row8_HashRow.MiddleName = row8.MiddleName;
				
				row8_HashRow.Suffix = row8.Suffix;
				
				row8_HashRow.Name = row8.Name;
				
				row8_HashRow.RecordTypeId = row8.RecordTypeId;
				
				row8_HashRow.MailingStreet = row8.MailingStreet;
				
				row8_HashRow.MailingCity = row8.MailingCity;
				
				row8_HashRow.MailingState = row8.MailingState;
				
				row8_HashRow.MailingPostalCode = row8.MailingPostalCode;
				
				row8_HashRow.MailingCountry = row8.MailingCountry;
				
				row8_HashRow.MailingLatitude = row8.MailingLatitude;
				
				row8_HashRow.MailingLongitude = row8.MailingLongitude;
				
				row8_HashRow.MailingGeocodeAccuracy = row8.MailingGeocodeAccuracy;
				
				row8_HashRow.MailingAddress = row8.MailingAddress;
				
				row8_HashRow.Phone = row8.Phone;
				
				row8_HashRow.Fax = row8.Fax;
				
				row8_HashRow.MobilePhone = row8.MobilePhone;
				
				row8_HashRow.ReportsToId = row8.ReportsToId;
				
				row8_HashRow.Email = row8.Email;
				
				row8_HashRow.Title = row8.Title;
				
				row8_HashRow.Department = row8.Department;
				
				row8_HashRow.OwnerId = row8.OwnerId;
				
				row8_HashRow.CreatedDate = row8.CreatedDate;
				
				row8_HashRow.CreatedById = row8.CreatedById;
				
				row8_HashRow.LastModifiedDate = row8.LastModifiedDate;
				
				row8_HashRow.LastModifiedById = row8.LastModifiedById;
				
				row8_HashRow.SystemModstamp = row8.SystemModstamp;
				
				row8_HashRow.LastActivityDate = row8.LastActivityDate;
				
				row8_HashRow.LastCURequestDate = row8.LastCURequestDate;
				
				row8_HashRow.LastCUUpdateDate = row8.LastCUUpdateDate;
				
				row8_HashRow.LastViewedDate = row8.LastViewedDate;
				
				row8_HashRow.LastReferencedDate = row8.LastReferencedDate;
				
				row8_HashRow.EmailBouncedReason = row8.EmailBouncedReason;
				
				row8_HashRow.EmailBouncedDate = row8.EmailBouncedDate;
				
				row8_HashRow.IsEmailBounced = row8.IsEmailBounced;
				
				row8_HashRow.PhotoUrl = row8.PhotoUrl;
				
				row8_HashRow.Jigsaw = row8.Jigsaw;
				
				row8_HashRow.JigsawContactId = row8.JigsawContactId;
				
				row8_HashRow.RL_AccountingMail__c = row8.RL_AccountingMail__c;
				
				row8_HashRow.RL_Agency__c = row8.RL_Agency__c;
				
				row8_HashRow.RL_BankCode__c = row8.RL_BankCode__c;
				
				row8_HashRow.RL_BankKey__c = row8.RL_BankKey__c;
				
				row8_HashRow.RL_BillingCity__c = row8.RL_BillingCity__c;
				
				row8_HashRow.RL_BillingCountry__c = row8.RL_BillingCountry__c;
				
				row8_HashRow.RL_BillingName__c = row8.RL_BillingName__c;
				
				row8_HashRow.RL_BillingStreetNumber__c = row8.RL_BillingStreetNumber__c;
				
				row8_HashRow.RL_BillingStreet__c = row8.RL_BillingStreet__c;
				
				row8_HashRow.RL_BillingTel1__c = row8.RL_BillingTel1__c;
				
				row8_HashRow.RL_BillingTel2__c = row8.RL_BillingTel2__c;
				
				row8_HashRow.RL_BillingTel3__c = row8.RL_BillingTel3__c;
				
				row8_HashRow.RL_CodeSettlement__c = row8.RL_CodeSettlement__c;
				
				row8_HashRow.RL_CreatedAt__c = row8.RL_CreatedAt__c;
				
				row8_HashRow.RL_Email__c = row8.RL_Email__c;
				
				row8_HashRow.RL_ExternalAccountId__c = row8.RL_ExternalAccountId__c;
				
				row8_HashRow.RL_ExternalId__c = row8.RL_ExternalId__c;
				
				row8_HashRow.RL_IsActive__c = row8.RL_IsActive__c;
				
				row8_HashRow.RL_RecoveryPostalCode__c = row8.RL_RecoveryPostalCode__c;
				
				row8_HashRow.RL_RemovalStreetNumber__c = row8.RL_RemovalStreetNumber__c;
				
				row8_HashRow.RL_RemovalTel3__c = row8.RL_RemovalTel3__c;
				
				row8_HashRow.Code_Client__c = row8.Code_Client__c;
				
				row8_HashRow.Data_Quality_Description__c = row8.Data_Quality_Description__c;
				
				row8_HashRow.Data_Quality_Score__c = row8.Data_Quality_Score__c;
				
				row8_HashRow.RL_Company__c = row8.RL_Company__c;
				
				row8_HashRow.RL_Removal_iso3_country__c = row8.RL_Removal_iso3_country__c;
				
				row8_HashRow.RL_Archived__c = row8.RL_Archived__c;
				
				row8_HashRow.RL_Tarification_par_palier__c = row8.RL_Tarification_par_palier__c;
				
				row8_HashRow.Contact_Commercial__c = row8.Contact_Commercial__c;
				
				row8_HashRow.SocieteInfo__Id__c = row8.SocieteInfo__Id__c;
				
			tHash_Lookup_row8.put(row8_HashRow);
			
            




 


	tos_count_tAdvancedHash_row8++;

/**
 * [tAdvancedHash_row8 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tUniqRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tFilterRow_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tConvertType_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 process_data_end ] stop
 */



	
	/**
	 * [tSalesforceInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		


 



/**
 * [tSalesforceInput_2 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceInput_2 end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		
// end of generic


resourceMap.put("finish_tSalesforceInput_2", Boolean.TRUE);

    } // while  
    } // end of "if (sourceOrSink_tSalesforceInput_2 instanceof ...Source)"
    java.util.Map<String, Object> resultMap_tSalesforceInput_2 = null;
    if (reader_tSalesforceInput_2 != null) {
        reader_tSalesforceInput_2.close();
        resultMap_tSalesforceInput_2 = reader_tSalesforceInput_2.getReturnValues();
    }
if(resultMap_tSalesforceInput_2!=null) {
	for(java.util.Map.Entry<String,Object> entry_tSalesforceInput_2 : resultMap_tSalesforceInput_2.entrySet()) {
		switch(entry_tSalesforceInput_2.getKey()) {
		case org.talend.components.api.component.ComponentDefinition.RETURN_ERROR_MESSAGE :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "ERROR_MESSAGE", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_TOTAL_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_LINE", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_SUCCESS_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_SUCCESS", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_REJECT_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_REJECT", entry_tSalesforceInput_2.getValue());
			break;
		default :
            StringBuilder studio_key_tSalesforceInput_2 = new StringBuilder();
            for (int i_tSalesforceInput_2 = 0; i_tSalesforceInput_2 < entry_tSalesforceInput_2.getKey().length(); i_tSalesforceInput_2++) {
                char ch_tSalesforceInput_2 = entry_tSalesforceInput_2.getKey().charAt(i_tSalesforceInput_2);
                if(Character.isUpperCase(ch_tSalesforceInput_2) && i_tSalesforceInput_2> 0) {
                	studio_key_tSalesforceInput_2.append('_');
                }
                studio_key_tSalesforceInput_2.append(ch_tSalesforceInput_2);
            }
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", studio_key_tSalesforceInput_2.toString().toUpperCase(java.util.Locale.ENGLISH), entry_tSalesforceInput_2.getValue());
			break;
		}
	}
}

 

ok_Hash.put("tSalesforceInput_2", true);
end_Hash.put("tSalesforceInput_2", System.currentTimeMillis());




/**
 * [tSalesforceInput_2 end ] stop
 */

	
	/**
	 * [tConvertType_2 end ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	
      globalMap.put("tConvertType_2_NB_LINE", nb_line_tConvertType_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tSalesforceInput_2","Contact","tSalesforceInput","tConvertType_2","tConvertType_2","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_2", true);
end_Hash.put("tConvertType_2", System.currentTimeMillis());




/**
 * [tConvertType_2 end ] stop
 */

	
	/**
	 * [tFilterRow_12 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	
    globalMap.put("tFilterRow_12_NB_LINE", nb_line_tFilterRow_12);
    globalMap.put("tFilterRow_12_NB_LINE_OK", nb_line_ok_tFilterRow_12);
    globalMap.put("tFilterRow_12_NB_LINE_REJECT", nb_line_reject_tFilterRow_12);
    
    	log.info("tFilterRow_12 - Processed records count:" + nb_line_tFilterRow_12 + ". Matched records count:" + nb_line_ok_tFilterRow_12 + ". Rejected records count:" + nb_line_reject_tFilterRow_12 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tConvertType_2","tConvertType_2","tConvertType","tFilterRow_12","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + ("Done.") );

ok_Hash.put("tFilterRow_12", true);
end_Hash.put("tFilterRow_12", System.currentTimeMillis());




/**
 * [tFilterRow_12 end ] stop
 */

	
	/**
	 * [tUniqRow_2 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

globalMap.put("tUniqRow_2_NB_UNIQUES",nb_uniques_tUniqRow_2);
globalMap.put("tUniqRow_2_NB_DUPLICATES",nb_duplicates_tUniqRow_2);
	log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2)+" .");
	log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tFilterRow_12","tFilterRow_1","tFilterRow","tUniqRow_2","tUniqRow_2","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Done.") );

ok_Hash.put("tUniqRow_2", true);
end_Hash.put("tUniqRow_2", System.currentTimeMillis());




/**
 * [tUniqRow_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

tHash_Lookup_row8.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tUniqRow_2","tUniqRow_2","tUniqRow","tAdvancedHash_row8","tAdvancedHash_row8","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row8", true);
end_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());




/**
 * [tAdvancedHash_row8 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSalesforceInput_2 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="Contact";
		
// finally of generic


if(resourceMap.get("finish_tSalesforceInput_2")==null){
    if(resourceMap.get("reader_tSalesforceInput_2")!=null){
		try {
			((org.talend.components.api.component.runtime.Reader)resourceMap.get("reader_tSalesforceInput_2")).close();
		} catch (java.io.IOException e_tSalesforceInput_2) {
			String errorMessage_tSalesforceInput_2 = "failed to release the resource in tSalesforceInput_2 :" + e_tSalesforceInput_2.getMessage();
			System.err.println(errorMessage_tSalesforceInput_2);
		}
	}
}
 



/**
 * [tSalesforceInput_2 finally ] stop
 */

	
	/**
	 * [tConvertType_2 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_12 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 finally ] stop
 */

	
	/**
	 * [tUniqRow_2 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceInput_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "NRWhAj_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tWarn_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_2");
		org.slf4j.MDC.put("_subJobPid", "cG0jix_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";
	
	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
                    log4jParamters_tWarn_2.append("Parameters:");
                            log4jParamters_tWarn_2.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
                    } 
                } 
            new BytesLimit65535_tWarn_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_2", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_2 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_2_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_2_WARN_PRIORITY", 4);
	globalMap.put("tWarn_2_WARN_CODE", 42);
	
} catch (Exception e_tWarn_2) {
globalMap.put("tWarn_2_ERROR_MESSAGE",e_tWarn_2.getMessage());
	logIgnoredError(String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2), e_tWarn_2);
}


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_end ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "9MbY3P_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    private final org.talend.components.common.runtime.SharedConnectionsPool connectionPool = new org.talend.components.common.runtime.SharedConnectionsPool() {
    	public java.sql.Connection getDBConnection(String dbDriver, String url, String userName, String password, String dbConnectionName)
            throws ClassNotFoundException, java.sql.SQLException {
            return SharedDBConnection.getDBConnection(dbDriver, url, userName, password, dbConnectionName);
        }

    	public java.sql.Connection getDBConnection(String dbDriver, String url, String dbConnectionName)
            throws ClassNotFoundException, java.sql.SQLException {
            return SharedDBConnection.getDBConnection(dbDriver, url, dbConnectionName);
        }
    };
    
    private static final String GLOBAL_CONNECTION_POOL_KEY = "GLOBAL_CONNECTION_POOL";
    
    {
    	globalMap.put(GLOBAL_CONNECTION_POOL_KEY, connectionPool);
    }
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORTClass = new ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT();

        int exitCode = ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_omMvcNboEe6yzsZuOmbiYw");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-03-05T13:26:47.251743300Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.class.getClassLoader().getResourceAsStream("atelier_facturation/ecolotrans_salesforce_service_detail_import_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("ODS_Database", "id_String");
                        if(context.getStringValue("ODS_Database") == null) {
                            context.ODS_Database = null;
                        } else {
                            context.ODS_Database=(String) context.getProperty("ODS_Database");
                        }
                        context.setContextType("PBI_Database", "id_String");
                        if(context.getStringValue("PBI_Database") == null) {
                            context.PBI_Database = null;
                        } else {
                            context.PBI_Database=(String) context.getProperty("PBI_Database");
                        }
                        context.setContextType("PBI_PC_Database", "id_String");
                        if(context.getStringValue("PBI_PC_Database") == null) {
                            context.PBI_PC_Database = null;
                        } else {
                            context.PBI_PC_Database=(String) context.getProperty("PBI_PC_Database");
                        }
                        context.setContextType("PBI_RT_Database", "id_String");
                        if(context.getStringValue("PBI_RT_Database") == null) {
                            context.PBI_RT_Database = null;
                        } else {
                            context.PBI_RT_Database=(String) context.getProperty("PBI_RT_Database");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("Salesforce_Name", "id_String");
                        if(context.getStringValue("Salesforce_Name") == null) {
                            context.Salesforce_Name = null;
                        } else {
                            context.Salesforce_Name=(String) context.getProperty("Salesforce_Name");
                        }
                        context.setContextType("Salesforce_Password", "id_Password");
                        if(context.getStringValue("Salesforce_Password") == null) {
                            context.Salesforce_Password = null;
                        } else {
                            String pwd_Salesforce_Password_value = context.getProperty("Salesforce_Password");
                            context.Salesforce_Password = null;
                            if(pwd_Salesforce_Password_value!=null) {
                                if(context_param.containsKey("Salesforce_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Password = pwd_Salesforce_Password_value;
                                } else if (!pwd_Salesforce_Password_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Password_value);
                                        context.put("Salesforce_Password",context.Salesforce_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_Security_Token", "id_Password");
                        if(context.getStringValue("Salesforce_Security_Token") == null) {
                            context.Salesforce_Security_Token = null;
                        } else {
                            String pwd_Salesforce_Security_Token_value = context.getProperty("Salesforce_Security_Token");
                            context.Salesforce_Security_Token = null;
                            if(pwd_Salesforce_Security_Token_value!=null) {
                                if(context_param.containsKey("Salesforce_Security_Token")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Security_Token = pwd_Salesforce_Security_Token_value;
                                } else if (!pwd_Salesforce_Security_Token_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Security_Token = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Security_Token_value);
                                        context.put("Salesforce_Security_Token",context.Salesforce_Security_Token);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_User_ID", "id_String");
                        if(context.getStringValue("Salesforce_User_ID") == null) {
                            context.Salesforce_User_ID = null;
                        } else {
                            context.Salesforce_User_ID=(String) context.getProperty("Salesforce_User_ID");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("ODS_Database")) {
                context.ODS_Database = (String) parentContextMap.get("ODS_Database");
            }if (parentContextMap.containsKey("PBI_Database")) {
                context.PBI_Database = (String) parentContextMap.get("PBI_Database");
            }if (parentContextMap.containsKey("PBI_PC_Database")) {
                context.PBI_PC_Database = (String) parentContextMap.get("PBI_PC_Database");
            }if (parentContextMap.containsKey("PBI_RT_Database")) {
                context.PBI_RT_Database = (String) parentContextMap.get("PBI_RT_Database");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("Salesforce_Name")) {
                context.Salesforce_Name = (String) parentContextMap.get("Salesforce_Name");
            }if (parentContextMap.containsKey("Salesforce_Password")) {
                context.Salesforce_Password = (java.lang.String) parentContextMap.get("Salesforce_Password");
            }if (parentContextMap.containsKey("Salesforce_Security_Token")) {
                context.Salesforce_Security_Token = (java.lang.String) parentContextMap.get("Salesforce_Security_Token");
            }if (parentContextMap.containsKey("Salesforce_User_ID")) {
                context.Salesforce_User_ID = (String) parentContextMap.get("Salesforce_User_ID");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("Salesforce_Password");
			parametersToEncrypt.add("Salesforce_Security_Token");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs


this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_SERVICE_DETAIL_IMPORT' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));




            connections.put("tSalesforceConnection_1_connection", globalMap.get("tSalesforceConnection_1_connection"));
            connections.put("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES", globalMap.get("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES"));


        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     978638 characters generated by Talend Cloud Data Integration 
 *     on the 5 mars 2024 à 14:26:47 WAT
 ************************************************************************************************/

package atelier_facturation.ecolotrans_salesforce_pricing_import_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: ECOLOTRANS_SALESFORCE_PRICING_IMPORT Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ECOLOTRANS_SALESFORCE_PRICING_IMPORT implements TalendJob {
	static {System.setProperty("TalendJob.log", "ECOLOTRANS_SALESFORCE_PRICING_IMPORT.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ECOLOTRANS_SALESFORCE_PRICING_IMPORT.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(ODS_Database != null){
				
					this.setProperty("ODS_Database", ODS_Database.toString());
				
			}
			
			if(PBI_Database != null){
				
					this.setProperty("PBI_Database", PBI_Database.toString());
				
			}
			
			if(PBI_PC_Database != null){
				
					this.setProperty("PBI_PC_Database", PBI_PC_Database.toString());
				
			}
			
			if(PBI_RT_Database != null){
				
					this.setProperty("PBI_RT_Database", PBI_RT_Database.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(Salesforce_Name != null){
				
					this.setProperty("Salesforce_Name", Salesforce_Name.toString());
				
			}
			
			if(Salesforce_Password != null){
				
					this.setProperty("Salesforce_Password", Salesforce_Password.toString());
				
			}
			
			if(Salesforce_Security_Token != null){
				
					this.setProperty("Salesforce_Security_Token", Salesforce_Security_Token.toString());
				
			}
			
			if(Salesforce_User_ID != null){
				
					this.setProperty("Salesforce_User_ID", Salesforce_User_ID.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String ODS_Database;
public String getODS_Database(){
	return this.ODS_Database;
}
public String PBI_Database;
public String getPBI_Database(){
	return this.PBI_Database;
}
public String PBI_PC_Database;
public String getPBI_PC_Database(){
	return this.PBI_PC_Database;
}
public String PBI_RT_Database;
public String getPBI_RT_Database(){
	return this.PBI_RT_Database;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String Salesforce_Name;
public String getSalesforce_Name(){
	return this.Salesforce_Name;
}
public java.lang.String Salesforce_Password;
public java.lang.String getSalesforce_Password(){
	return this.Salesforce_Password;
}
public java.lang.String Salesforce_Security_Token;
public java.lang.String getSalesforce_Security_Token(){
	return this.Salesforce_Security_Token;
}
public String Salesforce_User_ID;
public String getSalesforce_User_ID(){
	return this.Salesforce_User_ID;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ECOLOTRANS_SALESFORCE_PRICING_IMPORT";
	private final String projectName = "ATELIER_FACTURATION";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_IMXkgNewEe6aSY3JqFxI6w", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ECOLOTRANS_SALESFORCE_PRICING_IMPORT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ECOLOTRANS_SALESFORCE_PRICING_IMPORT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSalesforceInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSalesforceInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSalesforceInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "749yCm_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tWarn_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "8kSE3Z_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tSalesforceConnection_1Process(globalMap);



/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void tSalesforceConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceConnection_1");
		org.slf4j.MDC.put("_subJobPid", "v496pr_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSalesforceConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceConnection_1", false);
		start_Hash.put("tSalesforceConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
		int tos_count_tSalesforceConnection_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceConnection_1", "Salesforce_connexion", "tSalesforceConnection");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceConnection_1 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceConnection_1 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceConnection_1 = (String)(restRequest_tSalesforceConnection_1 != null ? restRequest_tSalesforceConnection_1.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceConnection_1 =
        new org.talend.components.salesforce.tsalesforceconnection.TSalesforceConnectionDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceConnection_1 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceConnection_1 = null;


org.talend.components.salesforce.SalesforceConnectionProperties props_tSalesforceConnection_1 =
        (org.talend.components.salesforce.SalesforceConnectionProperties) def_tSalesforceConnection_1.createRuntimeProperties();
 		                    props_tSalesforceConnection_1.setValue("endpoint",
 		                    "https://login.salesforce.com/services/Soap/u/45.0");
 		                    
 		                    props_tSalesforceConnection_1.setValue("loginType",
 		                        org.talend.components.salesforce.SalesforceConnectionProperties.LoginType.Basic);
 		                    
 		                    props_tSalesforceConnection_1.setValue("bulkConnection",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("reuseSession",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("needCompression",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.setValue("timeout",
 		                    60000);
 		                    
 		                    props_tSalesforceConnection_1.setValue("httpChunked",
 		                    true);
 		                    
 		                    props_tSalesforceConnection_1.setValue("clientId",
 		                    "");
 		                    
 		                        props_tSalesforceConnection_1.userPassword.setValue("securityKey",
 		                        routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:p4pekeX7QzN8ZIBQ8HmOyMZLBCCNNbes2vq5sep8A9LVb2h/Jm4M9AIJEQEPgHtNoNA4LYg="));
 		                        
 		                    props_tSalesforceConnection_1.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.userPassword.setValue("userId",
 		                    "admin_sf@ecolotrans.com");
 		                    
 		                        props_tSalesforceConnection_1.userPassword.setValue("password",
 		                        routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:6xBiuR3Nk7DQX7pMW5SR3woY1icMckC3nHfi5DGF0c9ssLIiwzV5aajUXg=="));
 		                        
 		                    props_tSalesforceConnection_1.sslProperties.setValue("mutualAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.proxy.setValue("useProxy",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceConnection_1.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceConnection_1.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceConnection_1 = props_tSalesforceConnection_1.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceConnection_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceConnection_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceConnection_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceConnection_1.referencedComponent.setReference(referencedComponentProperties_tSalesforceConnection_1);
        }
    }
globalMap.put("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceConnection_1);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceConnection_1= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceConnection_1_MAPPINGS_URL", mappings_url_tSalesforceConnection_1);

org.talend.components.api.container.RuntimeContainer container_tSalesforceConnection_1 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceConnection_1";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceConnection_1 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceConnection_1 = null;
topology_tSalesforceConnection_1 = org.talend.components.api.component.ConnectorTopology.NONE;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceConnection_1 = def_tSalesforceConnection_1.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceConnection_1, topology_tSalesforceConnection_1);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceConnection_1 = def_tSalesforceConnection_1.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceConnection_1.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceConnection_1 = componentRuntime_tSalesforceConnection_1.initialize(container_tSalesforceConnection_1, props_tSalesforceConnection_1);

if (initVr_tSalesforceConnection_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceConnection_1.getMessage());
}

if(componentRuntime_tSalesforceConnection_1 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceConnection_1;
	compDriverInitialization_tSalesforceConnection_1.runAtDriver(container_tSalesforceConnection_1);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceConnection_1 = null;
if(componentRuntime_tSalesforceConnection_1 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceConnection_1 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceConnection_1;
	if (doesNodeBelongToRequest_tSalesforceConnection_1) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceConnection_1 = sourceOrSink_tSalesforceConnection_1.validate(container_tSalesforceConnection_1);
        if (vr_tSalesforceConnection_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceConnection_1.getMessage());
        }
	}
}

 



/**
 * [tSalesforceConnection_1 begin ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 main ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 


	tos_count_tSalesforceConnection_1++;

/**
 * [tSalesforceConnection_1 main ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 



/**
 * [tSalesforceConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		


 



/**
 * [tSalesforceConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceConnection_1 end ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
// end of generic

 

ok_Hash.put("tSalesforceConnection_1", true);
end_Hash.put("tSalesforceConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tSalesforceConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSalesforceConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceConnection_1";
	
	
			cLabel="Salesforce_connexion";
		
// finally of generic

 



/**
 * [tSalesforceConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "XmYseh_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tSalesforceInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class pricingStruct implements routines.system.IPersistableRow<pricingStruct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public int id_detail;

				public int getId_detail () {
					return this.id_detail;
				}

				public Boolean id_detailIsNullable(){
				    return false;
				}
				public Boolean id_detailIsKey(){
				    return false;
				}
				public Integer id_detailLength(){
				    return 10;
				}
				public Integer id_detailPrecision(){
				    return 0;
				}
				public String id_detailDefault(){
				
					return null;
				
				}
				public String id_detailComment(){
				
				    return "";
				
				}
				public String id_detailPattern(){
				
					return "";
				
				}
				public String id_detailOriginalDbColumnName(){
				
					return "id_detail";
				
				}

				
			    public String day;

				public String getDay () {
					return this.day;
				}

				public Boolean dayIsNullable(){
				    return true;
				}
				public Boolean dayIsKey(){
				    return false;
				}
				public Integer dayLength(){
				    return 45;
				}
				public Integer dayPrecision(){
				    return 0;
				}
				public String dayDefault(){
				
					return null;
				
				}
				public String dayComment(){
				
				    return "";
				
				}
				public String dayPattern(){
				
					return "";
				
				}
				public String dayOriginalDbColumnName(){
				
					return "day";
				
				}

				
			    public float price;

				public float getPrice () {
					return this.price;
				}

				public Boolean priceIsNullable(){
				    return false;
				}
				public Boolean priceIsKey(){
				    return false;
				}
				public Integer priceLength(){
				    return 12;
				}
				public Integer pricePrecision(){
				    return 0;
				}
				public String priceDefault(){
				
					return null;
				
				}
				public String priceComment(){
				
				    return "";
				
				}
				public String pricePattern(){
				
					return "";
				
				}
				public String priceOriginalDbColumnName(){
				
					return "price";
				
				}

				
			    public Float unit_specification;

				public Float getUnit_specification () {
					return this.unit_specification;
				}

				public Boolean unit_specificationIsNullable(){
				    return true;
				}
				public Boolean unit_specificationIsKey(){
				    return false;
				}
				public Integer unit_specificationLength(){
				    return 12;
				}
				public Integer unit_specificationPrecision(){
				    return 0;
				}
				public String unit_specificationDefault(){
				
					return null;
				
				}
				public String unit_specificationComment(){
				
				    return "";
				
				}
				public String unit_specificationPattern(){
				
					return "";
				
				}
				public String unit_specificationOriginalDbColumnName(){
				
					return "unit_specification";
				
				}

				
			    public Float scale_min;

				public Float getScale_min () {
					return this.scale_min;
				}

				public Boolean scale_minIsNullable(){
				    return true;
				}
				public Boolean scale_minIsKey(){
				    return false;
				}
				public Integer scale_minLength(){
				    return 12;
				}
				public Integer scale_minPrecision(){
				    return 0;
				}
				public String scale_minDefault(){
				
					return null;
				
				}
				public String scale_minComment(){
				
				    return "";
				
				}
				public String scale_minPattern(){
				
					return "";
				
				}
				public String scale_minOriginalDbColumnName(){
				
					return "scale_min";
				
				}

				
			    public Float scale_max;

				public Float getScale_max () {
					return this.scale_max;
				}

				public Boolean scale_maxIsNullable(){
				    return true;
				}
				public Boolean scale_maxIsKey(){
				    return false;
				}
				public Integer scale_maxLength(){
				    return 12;
				}
				public Integer scale_maxPrecision(){
				    return 0;
				}
				public String scale_maxDefault(){
				
					return null;
				
				}
				public String scale_maxComment(){
				
				    return "";
				
				}
				public String scale_maxPattern(){
				
					return "";
				
				}
				public String scale_maxOriginalDbColumnName(){
				
					return "scale_max";
				
				}

				
			    public Float additional_quantity;

				public Float getAdditional_quantity () {
					return this.additional_quantity;
				}

				public Boolean additional_quantityIsNullable(){
				    return true;
				}
				public Boolean additional_quantityIsKey(){
				    return false;
				}
				public Integer additional_quantityLength(){
				    return 12;
				}
				public Integer additional_quantityPrecision(){
				    return 0;
				}
				public String additional_quantityDefault(){
				
					return null;
				
				}
				public String additional_quantityComment(){
				
				    return "";
				
				}
				public String additional_quantityPattern(){
				
					return "";
				
				}
				public String additional_quantityOriginalDbColumnName(){
				
					return "additional_quantity";
				
				}

				
			    public String delivery_postal_code;

				public String getDelivery_postal_code () {
					return this.delivery_postal_code;
				}

				public Boolean delivery_postal_codeIsNullable(){
				    return true;
				}
				public Boolean delivery_postal_codeIsKey(){
				    return false;
				}
				public Integer delivery_postal_codeLength(){
				    return 255;
				}
				public Integer delivery_postal_codePrecision(){
				    return 0;
				}
				public String delivery_postal_codeDefault(){
				
					return null;
				
				}
				public String delivery_postal_codeComment(){
				
				    return "";
				
				}
				public String delivery_postal_codePattern(){
				
					return "";
				
				}
				public String delivery_postal_codeOriginalDbColumnName(){
				
					return "delivery_postal_code";
				
				}

				
			    public String recovery_postal_code;

				public String getRecovery_postal_code () {
					return this.recovery_postal_code;
				}

				public Boolean recovery_postal_codeIsNullable(){
				    return true;
				}
				public Boolean recovery_postal_codeIsKey(){
				    return false;
				}
				public Integer recovery_postal_codeLength(){
				    return 255;
				}
				public Integer recovery_postal_codePrecision(){
				    return 0;
				}
				public String recovery_postal_codeDefault(){
				
					return null;
				
				}
				public String recovery_postal_codeComment(){
				
				    return "";
				
				}
				public String recovery_postal_codePattern(){
				
					return "";
				
				}
				public String recovery_postal_codeOriginalDbColumnName(){
				
					return "recovery_postal_code";
				
				}

				
			    public String round_name;

				public String getRound_name () {
					return this.round_name;
				}

				public Boolean round_nameIsNullable(){
				    return true;
				}
				public Boolean round_nameIsKey(){
				    return false;
				}
				public Integer round_nameLength(){
				    return 255;
				}
				public Integer round_namePrecision(){
				    return 0;
				}
				public String round_nameDefault(){
				
					return null;
				
				}
				public String round_nameComment(){
				
				    return "";
				
				}
				public String round_namePattern(){
				
					return "";
				
				}
				public String round_nameOriginalDbColumnName(){
				
					return "round_name";
				
				}

				
			    public Integer madRoundIndex;

				public Integer getMadRoundIndex () {
					return this.madRoundIndex;
				}

				public Boolean madRoundIndexIsNullable(){
				    return true;
				}
				public Boolean madRoundIndexIsKey(){
				    return false;
				}
				public Integer madRoundIndexLength(){
				    return 10;
				}
				public Integer madRoundIndexPrecision(){
				    return 0;
				}
				public String madRoundIndexDefault(){
				
					return null;
				
				}
				public String madRoundIndexComment(){
				
				    return "";
				
				}
				public String madRoundIndexPattern(){
				
					return "";
				
				}
				public String madRoundIndexOriginalDbColumnName(){
				
					return "madRoundIndex";
				
				}

				
			    public java.util.Date created_at;

				public java.util.Date getCreated_at () {
					return this.created_at;
				}

				public Boolean created_atIsNullable(){
				    return true;
				}
				public Boolean created_atIsKey(){
				    return false;
				}
				public Integer created_atLength(){
				    return 19;
				}
				public Integer created_atPrecision(){
				    return 0;
				}
				public String created_atDefault(){
				
					return null;
				
				}
				public String created_atComment(){
				
				    return "";
				
				}
				public String created_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_atOriginalDbColumnName(){
				
					return "created_at";
				
				}

				
			    public java.util.Date updated_at;

				public java.util.Date getUpdated_at () {
					return this.updated_at;
				}

				public Boolean updated_atIsNullable(){
				    return true;
				}
				public Boolean updated_atIsKey(){
				    return false;
				}
				public Integer updated_atLength(){
				    return 19;
				}
				public Integer updated_atPrecision(){
				    return 0;
				}
				public String updated_atDefault(){
				
					return "'current_timestamp()'";
				
				}
				public String updated_atComment(){
				
				    return "";
				
				}
				public String updated_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_atOriginalDbColumnName(){
				
					return "updated_at";
				
				}

				
			    public String id_salesforce;

				public String getId_salesforce () {
					return this.id_salesforce;
				}

				public Boolean id_salesforceIsNullable(){
				    return true;
				}
				public Boolean id_salesforceIsKey(){
				    return false;
				}
				public Integer id_salesforceLength(){
				    return 150;
				}
				public Integer id_salesforcePrecision(){
				    return 0;
				}
				public String id_salesforceDefault(){
				
					return null;
				
				}
				public String id_salesforceComment(){
				
				    return "";
				
				}
				public String id_salesforcePattern(){
				
					return "";
				
				}
				public String id_salesforceOriginalDbColumnName(){
				
					return "id_salesforce";
				
				}

				
			    public int is_activated;

				public int getIs_activated () {
					return this.is_activated;
				}

				public Boolean is_activatedIsNullable(){
				    return false;
				}
				public Boolean is_activatedIsKey(){
				    return false;
				}
				public Integer is_activatedLength(){
				    return 10;
				}
				public Integer is_activatedPrecision(){
				    return 0;
				}
				public String is_activatedDefault(){
				
					return "1";
				
				}
				public String is_activatedComment(){
				
				    return "";
				
				}
				public String is_activatedPattern(){
				
					return "";
				
				}
				public String is_activatedOriginalDbColumnName(){
				
					return "is_activated";
				
				}

				
			    public int is_archived;

				public int getIs_archived () {
					return this.is_archived;
				}

				public Boolean is_archivedIsNullable(){
				    return false;
				}
				public Boolean is_archivedIsKey(){
				    return false;
				}
				public Integer is_archivedLength(){
				    return 10;
				}
				public Integer is_archivedPrecision(){
				    return 0;
				}
				public String is_archivedDefault(){
				
					return "0";
				
				}
				public String is_archivedComment(){
				
				    return "";
				
				}
				public String is_archivedPattern(){
				
					return "";
				
				}
				public String is_archivedOriginalDbColumnName(){
				
					return "is_archived";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pricingStruct other = (pricingStruct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pricingStruct other) {

		other.id = this.id;
	            other.id_detail = this.id_detail;
	            other.day = this.day;
	            other.price = this.price;
	            other.unit_specification = this.unit_specification;
	            other.scale_min = this.scale_min;
	            other.scale_max = this.scale_max;
	            other.additional_quantity = this.additional_quantity;
	            other.delivery_postal_code = this.delivery_postal_code;
	            other.recovery_postal_code = this.recovery_postal_code;
	            other.round_name = this.round_name;
	            other.madRoundIndex = this.madRoundIndex;
	            other.created_at = this.created_at;
	            other.updated_at = this.updated_at;
	            other.id_salesforce = this.id_salesforce;
	            other.is_activated = this.is_activated;
	            other.is_archived = this.is_archived;
	            
	}

	public void copyKeysDataTo(pricingStruct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.id_detail = dis.readInt();
					
					this.day = readString(dis);
					
			        this.price = dis.readFloat();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.unit_specification = null;
           				} else {
           			    	this.unit_specification = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.scale_min = null;
           				} else {
           			    	this.scale_min = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.scale_max = null;
           				} else {
           			    	this.scale_max = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.additional_quantity = null;
           				} else {
           			    	this.additional_quantity = dis.readFloat();
           				}
					
					this.delivery_postal_code = readString(dis);
					
					this.recovery_postal_code = readString(dis);
					
					this.round_name = readString(dis);
					
						this.madRoundIndex = readInteger(dis);
					
					this.created_at = readDate(dis);
					
					this.updated_at = readDate(dis);
					
					this.id_salesforce = readString(dis);
					
			        this.is_activated = dis.readInt();
					
			        this.is_archived = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.id_detail = dis.readInt();
					
					this.day = readString(dis);
					
			        this.price = dis.readFloat();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.unit_specification = null;
           				} else {
           			    	this.unit_specification = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.scale_min = null;
           				} else {
           			    	this.scale_min = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.scale_max = null;
           				} else {
           			    	this.scale_max = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.additional_quantity = null;
           				} else {
           			    	this.additional_quantity = dis.readFloat();
           				}
					
					this.delivery_postal_code = readString(dis);
					
					this.recovery_postal_code = readString(dis);
					
					this.round_name = readString(dis);
					
						this.madRoundIndex = readInteger(dis);
					
					this.created_at = readDate(dis);
					
					this.updated_at = readDate(dis);
					
					this.id_salesforce = readString(dis);
					
			        this.is_activated = dis.readInt();
					
			        this.is_archived = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.id_detail);
					
					// String
				
						writeString(this.day,dos);
					
					// float
				
		            	dos.writeFloat(this.price);
					
					// Float
				
						if(this.unit_specification == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.unit_specification);
		            	}
					
					// Float
				
						if(this.scale_min == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.scale_min);
		            	}
					
					// Float
				
						if(this.scale_max == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.scale_max);
		            	}
					
					// Float
				
						if(this.additional_quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.additional_quantity);
		            	}
					
					// String
				
						writeString(this.delivery_postal_code,dos);
					
					// String
				
						writeString(this.recovery_postal_code,dos);
					
					// String
				
						writeString(this.round_name,dos);
					
					// Integer
				
						writeInteger(this.madRoundIndex,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
					// java.util.Date
				
						writeDate(this.updated_at,dos);
					
					// String
				
						writeString(this.id_salesforce,dos);
					
					// int
				
		            	dos.writeInt(this.is_activated);
					
					// int
				
		            	dos.writeInt(this.is_archived);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.id_detail);
					
					// String
				
						writeString(this.day,dos);
					
					// float
				
		            	dos.writeFloat(this.price);
					
					// Float
				
						if(this.unit_specification == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.unit_specification);
		            	}
					
					// Float
				
						if(this.scale_min == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.scale_min);
		            	}
					
					// Float
				
						if(this.scale_max == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.scale_max);
		            	}
					
					// Float
				
						if(this.additional_quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.additional_quantity);
		            	}
					
					// String
				
						writeString(this.delivery_postal_code,dos);
					
					// String
				
						writeString(this.recovery_postal_code,dos);
					
					// String
				
						writeString(this.round_name,dos);
					
					// Integer
				
						writeInteger(this.madRoundIndex,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
					// java.util.Date
				
						writeDate(this.updated_at,dos);
					
					// String
				
						writeString(this.id_salesforce,dos);
					
					// int
				
		            	dos.writeInt(this.is_activated);
					
					// int
				
		            	dos.writeInt(this.is_archived);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",id_detail="+String.valueOf(id_detail));
		sb.append(",day="+day);
		sb.append(",price="+String.valueOf(price));
		sb.append(",unit_specification="+String.valueOf(unit_specification));
		sb.append(",scale_min="+String.valueOf(scale_min));
		sb.append(",scale_max="+String.valueOf(scale_max));
		sb.append(",additional_quantity="+String.valueOf(additional_quantity));
		sb.append(",delivery_postal_code="+delivery_postal_code);
		sb.append(",recovery_postal_code="+recovery_postal_code);
		sb.append(",round_name="+round_name);
		sb.append(",madRoundIndex="+String.valueOf(madRoundIndex));
		sb.append(",created_at="+String.valueOf(created_at));
		sb.append(",updated_at="+String.valueOf(updated_at));
		sb.append(",id_salesforce="+id_salesforce);
		sb.append(",is_activated="+String.valueOf(is_activated));
		sb.append(",is_archived="+String.valueOf(is_archived));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				sb.append(id_detail);
        			
        			sb.append("|");
        		
        				if(day == null){
        					sb.append("<null>");
        				}else{
            				sb.append(day);
            			}
            		
        			sb.append("|");
        		
        				sb.append(price);
        			
        			sb.append("|");
        		
        				if(unit_specification == null){
        					sb.append("<null>");
        				}else{
            				sb.append(unit_specification);
            			}
            		
        			sb.append("|");
        		
        				if(scale_min == null){
        					sb.append("<null>");
        				}else{
            				sb.append(scale_min);
            			}
            		
        			sb.append("|");
        		
        				if(scale_max == null){
        					sb.append("<null>");
        				}else{
            				sb.append(scale_max);
            			}
            		
        			sb.append("|");
        		
        				if(additional_quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(additional_quantity);
            			}
            		
        			sb.append("|");
        		
        				if(delivery_postal_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(delivery_postal_code);
            			}
            		
        			sb.append("|");
        		
        				if(recovery_postal_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(recovery_postal_code);
            			}
            		
        			sb.append("|");
        		
        				if(round_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(round_name);
            			}
            		
        			sb.append("|");
        		
        				if(madRoundIndex == null){
        					sb.append("<null>");
        				}else{
            				sb.append(madRoundIndex);
            			}
            		
        			sb.append("|");
        		
        				if(created_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_at);
            			}
            		
        			sb.append("|");
        		
        				if(updated_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_at);
            			}
            		
        			sb.append("|");
        		
        				if(id_salesforce == null){
        					sb.append("<null>");
        				}else{
            				sb.append(id_salesforce);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_activated);
        			
        			sb.append("|");
        		
        				sb.append(is_archived);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pricingStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public Float RL_Additional_quantity__c;

				public Float getRL_Additional_quantity__c () {
					return this.RL_Additional_quantity__c;
				}

				public Boolean RL_Additional_quantity__cIsNullable(){
				    return true;
				}
				public Boolean RL_Additional_quantity__cIsKey(){
				    return false;
				}
				public Integer RL_Additional_quantity__cLength(){
				    return 12;
				}
				public Integer RL_Additional_quantity__cPrecision(){
				    return 2;
				}
				public String RL_Additional_quantity__cDefault(){
				
					return null;
				
				}
				public String RL_Additional_quantity__cComment(){
				
				    return "";
				
				}
				public String RL_Additional_quantity__cPattern(){
				
					return "";
				
				}
				public String RL_Additional_quantity__cOriginalDbColumnName(){
				
					return "RL_Additional_quantity__c";
				
				}

				
			    public String RL_Day__c;

				public String getRL_Day__c () {
					return this.RL_Day__c;
				}

				public Boolean RL_Day__cIsNullable(){
				    return true;
				}
				public Boolean RL_Day__cIsKey(){
				    return false;
				}
				public Integer RL_Day__cLength(){
				    return 255;
				}
				public Integer RL_Day__cPrecision(){
				    return null;
				}
				public String RL_Day__cDefault(){
				
					return null;
				
				}
				public String RL_Day__cComment(){
				
				    return "";
				
				}
				public String RL_Day__cPattern(){
				
					return "";
				
				}
				public String RL_Day__cOriginalDbColumnName(){
				
					return "RL_Day__c";
				
				}

				
			    public String RL_Delivery_postal_codes__c;

				public String getRL_Delivery_postal_codes__c () {
					return this.RL_Delivery_postal_codes__c;
				}

				public Boolean RL_Delivery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Delivery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Delivery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Delivery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Delivery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Delivery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Delivery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Delivery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Delivery_postal_codes__c";
				
				}

				
			    public Integer RL_External_Service_Detail_Id__c;

				public Integer getRL_External_Service_Detail_Id__c () {
					return this.RL_External_Service_Detail_Id__c;
				}

				public Boolean RL_External_Service_Detail_Id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_Service_Detail_Id__cIsKey(){
				    return false;
				}
				public Integer RL_External_Service_Detail_Id__cLength(){
				    return 18;
				}
				public Integer RL_External_Service_Detail_Id__cPrecision(){
				    return null;
				}
				public String RL_External_Service_Detail_Id__cDefault(){
				
					return null;
				
				}
				public String RL_External_Service_Detail_Id__cComment(){
				
				    return "";
				
				}
				public String RL_External_Service_Detail_Id__cPattern(){
				
					return "";
				
				}
				public String RL_External_Service_Detail_Id__cOriginalDbColumnName(){
				
					return "RL_External_Service_Detail_Id__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public Float RL_Price__c;

				public Float getRL_Price__c () {
					return this.RL_Price__c;
				}

				public Boolean RL_Price__cIsNullable(){
				    return true;
				}
				public Boolean RL_Price__cIsKey(){
				    return false;
				}
				public Integer RL_Price__cLength(){
				    return 12;
				}
				public Integer RL_Price__cPrecision(){
				    return 2;
				}
				public String RL_Price__cDefault(){
				
					return null;
				
				}
				public String RL_Price__cComment(){
				
				    return "";
				
				}
				public String RL_Price__cPattern(){
				
					return "";
				
				}
				public String RL_Price__cOriginalDbColumnName(){
				
					return "RL_Price__c";
				
				}

				
			    public String RL_Recovery_postal_codes__c;

				public String getRL_Recovery_postal_codes__c () {
					return this.RL_Recovery_postal_codes__c;
				}

				public Boolean RL_Recovery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Recovery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Recovery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Recovery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Recovery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Recovery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Recovery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Recovery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Recovery_postal_codes__c";
				
				}

				
			    public Float RL_Scale_max__c;

				public Float getRL_Scale_max__c () {
					return this.RL_Scale_max__c;
				}

				public Boolean RL_Scale_max__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_max__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_max__cLength(){
				    return 12;
				}
				public Integer RL_Scale_max__cPrecision(){
				    return 2;
				}
				public String RL_Scale_max__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_max__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_max__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_max__cOriginalDbColumnName(){
				
					return "RL_Scale_max__c";
				
				}

				
			    public Float RL_Scale_min__c;

				public Float getRL_Scale_min__c () {
					return this.RL_Scale_min__c;
				}

				public Boolean RL_Scale_min__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_min__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_min__cLength(){
				    return 12;
				}
				public Integer RL_Scale_min__cPrecision(){
				    return 2;
				}
				public String RL_Scale_min__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_min__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_min__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_min__cOriginalDbColumnName(){
				
					return "RL_Scale_min__c";
				
				}

				
			    public String RL_Service_Detail__c;

				public String getRL_Service_Detail__c () {
					return this.RL_Service_Detail__c;
				}

				public Boolean RL_Service_Detail__cIsNullable(){
				    return true;
				}
				public Boolean RL_Service_Detail__cIsKey(){
				    return false;
				}
				public Integer RL_Service_Detail__cLength(){
				    return 18;
				}
				public Integer RL_Service_Detail__cPrecision(){
				    return null;
				}
				public String RL_Service_Detail__cDefault(){
				
					return null;
				
				}
				public String RL_Service_Detail__cComment(){
				
				    return "";
				
				}
				public String RL_Service_Detail__cPattern(){
				
					return "";
				
				}
				public String RL_Service_Detail__cOriginalDbColumnName(){
				
					return "RL_Service_Detail__c";
				
				}

				
			    public Float RL_Unit__c;

				public Float getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return true;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 12;
				}
				public Integer RL_Unit__cPrecision(){
				    return 2;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public String RL_Round_Name__c;

				public String getRL_Round_Name__c () {
					return this.RL_Round_Name__c;
				}

				public Boolean RL_Round_Name__cIsNullable(){
				    return true;
				}
				public Boolean RL_Round_Name__cIsKey(){
				    return false;
				}
				public Integer RL_Round_Name__cLength(){
				    return 255;
				}
				public Integer RL_Round_Name__cPrecision(){
				    return null;
				}
				public String RL_Round_Name__cDefault(){
				
					return null;
				
				}
				public String RL_Round_Name__cComment(){
				
				    return "";
				
				}
				public String RL_Round_Name__cPattern(){
				
					return "";
				
				}
				public String RL_Round_Name__cOriginalDbColumnName(){
				
					return "RL_Round_Name__c";
				
				}

				
			    public Integer RL_MAD_Round_Index__c;

				public Integer getRL_MAD_Round_Index__c () {
					return this.RL_MAD_Round_Index__c;
				}

				public Boolean RL_MAD_Round_Index__cIsNullable(){
				    return true;
				}
				public Boolean RL_MAD_Round_Index__cIsKey(){
				    return false;
				}
				public Integer RL_MAD_Round_Index__cLength(){
				    return 18;
				}
				public Integer RL_MAD_Round_Index__cPrecision(){
				    return null;
				}
				public String RL_MAD_Round_Index__cDefault(){
				
					return null;
				
				}
				public String RL_MAD_Round_Index__cComment(){
				
				    return "";
				
				}
				public String RL_MAD_Round_Index__cPattern(){
				
					return "";
				
				}
				public String RL_MAD_Round_Index__cOriginalDbColumnName(){
				
					return "RL_MAD_Round_Index__c";
				
				}

				
			    public boolean RL_Is_Archived__c;

				public boolean getRL_Is_Archived__c () {
					return this.RL_Is_Archived__c;
				}

				public Boolean RL_Is_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Archived__cLength(){
				    return null;
				}
				public Integer RL_Is_Archived__cPrecision(){
				    return null;
				}
				public String RL_Is_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Archived__cOriginalDbColumnName(){
				
					return "RL_Is_Archived__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Additional_quantity__c="+String.valueOf(RL_Additional_quantity__c));
		sb.append(",RL_Day__c="+RL_Day__c);
		sb.append(",RL_Delivery_postal_codes__c="+RL_Delivery_postal_codes__c);
		sb.append(",RL_External_Service_Detail_Id__c="+String.valueOf(RL_External_Service_Detail_Id__c));
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Price__c="+String.valueOf(RL_Price__c));
		sb.append(",RL_Recovery_postal_codes__c="+RL_Recovery_postal_codes__c);
		sb.append(",RL_Scale_max__c="+String.valueOf(RL_Scale_max__c));
		sb.append(",RL_Scale_min__c="+String.valueOf(RL_Scale_min__c));
		sb.append(",RL_Service_Detail__c="+RL_Service_Detail__c);
		sb.append(",RL_Unit__c="+String.valueOf(RL_Unit__c));
		sb.append(",RL_Round_Name__c="+RL_Round_Name__c);
		sb.append(",RL_MAD_Round_Index__c="+String.valueOf(RL_MAD_Round_Index__c));
		sb.append(",RL_Is_Archived__c="+String.valueOf(RL_Is_Archived__c));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Additional_quantity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Additional_quantity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Day__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Day__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Delivery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Delivery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_Service_Detail_Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_Service_Detail_Id__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Price__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Price__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Recovery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Recovery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_max__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_max__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_min__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_min__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Service_Detail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service_Detail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Round_Name__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Round_Name__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_MAD_Round_Index__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_MAD_Round_Index__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Archived__c);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public Float RL_Additional_quantity__c;

				public Float getRL_Additional_quantity__c () {
					return this.RL_Additional_quantity__c;
				}

				public Boolean RL_Additional_quantity__cIsNullable(){
				    return true;
				}
				public Boolean RL_Additional_quantity__cIsKey(){
				    return false;
				}
				public Integer RL_Additional_quantity__cLength(){
				    return 12;
				}
				public Integer RL_Additional_quantity__cPrecision(){
				    return 2;
				}
				public String RL_Additional_quantity__cDefault(){
				
					return null;
				
				}
				public String RL_Additional_quantity__cComment(){
				
				    return "";
				
				}
				public String RL_Additional_quantity__cPattern(){
				
					return "";
				
				}
				public String RL_Additional_quantity__cOriginalDbColumnName(){
				
					return "RL_Additional_quantity__c";
				
				}

				
			    public String RL_Day__c;

				public String getRL_Day__c () {
					return this.RL_Day__c;
				}

				public Boolean RL_Day__cIsNullable(){
				    return true;
				}
				public Boolean RL_Day__cIsKey(){
				    return false;
				}
				public Integer RL_Day__cLength(){
				    return 255;
				}
				public Integer RL_Day__cPrecision(){
				    return null;
				}
				public String RL_Day__cDefault(){
				
					return null;
				
				}
				public String RL_Day__cComment(){
				
				    return "";
				
				}
				public String RL_Day__cPattern(){
				
					return "";
				
				}
				public String RL_Day__cOriginalDbColumnName(){
				
					return "RL_Day__c";
				
				}

				
			    public String RL_Delivery_postal_codes__c;

				public String getRL_Delivery_postal_codes__c () {
					return this.RL_Delivery_postal_codes__c;
				}

				public Boolean RL_Delivery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Delivery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Delivery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Delivery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Delivery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Delivery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Delivery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Delivery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Delivery_postal_codes__c";
				
				}

				
			    public Integer RL_External_Service_Detail_Id__c;

				public Integer getRL_External_Service_Detail_Id__c () {
					return this.RL_External_Service_Detail_Id__c;
				}

				public Boolean RL_External_Service_Detail_Id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_Service_Detail_Id__cIsKey(){
				    return false;
				}
				public Integer RL_External_Service_Detail_Id__cLength(){
				    return 18;
				}
				public Integer RL_External_Service_Detail_Id__cPrecision(){
				    return null;
				}
				public String RL_External_Service_Detail_Id__cDefault(){
				
					return null;
				
				}
				public String RL_External_Service_Detail_Id__cComment(){
				
				    return "";
				
				}
				public String RL_External_Service_Detail_Id__cPattern(){
				
					return "";
				
				}
				public String RL_External_Service_Detail_Id__cOriginalDbColumnName(){
				
					return "RL_External_Service_Detail_Id__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public Float RL_Price__c;

				public Float getRL_Price__c () {
					return this.RL_Price__c;
				}

				public Boolean RL_Price__cIsNullable(){
				    return true;
				}
				public Boolean RL_Price__cIsKey(){
				    return false;
				}
				public Integer RL_Price__cLength(){
				    return 12;
				}
				public Integer RL_Price__cPrecision(){
				    return 2;
				}
				public String RL_Price__cDefault(){
				
					return null;
				
				}
				public String RL_Price__cComment(){
				
				    return "";
				
				}
				public String RL_Price__cPattern(){
				
					return "";
				
				}
				public String RL_Price__cOriginalDbColumnName(){
				
					return "RL_Price__c";
				
				}

				
			    public String RL_Recovery_postal_codes__c;

				public String getRL_Recovery_postal_codes__c () {
					return this.RL_Recovery_postal_codes__c;
				}

				public Boolean RL_Recovery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Recovery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Recovery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Recovery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Recovery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Recovery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Recovery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Recovery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Recovery_postal_codes__c";
				
				}

				
			    public Float RL_Scale_max__c;

				public Float getRL_Scale_max__c () {
					return this.RL_Scale_max__c;
				}

				public Boolean RL_Scale_max__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_max__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_max__cLength(){
				    return 12;
				}
				public Integer RL_Scale_max__cPrecision(){
				    return 2;
				}
				public String RL_Scale_max__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_max__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_max__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_max__cOriginalDbColumnName(){
				
					return "RL_Scale_max__c";
				
				}

				
			    public Float RL_Scale_min__c;

				public Float getRL_Scale_min__c () {
					return this.RL_Scale_min__c;
				}

				public Boolean RL_Scale_min__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_min__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_min__cLength(){
				    return 12;
				}
				public Integer RL_Scale_min__cPrecision(){
				    return 2;
				}
				public String RL_Scale_min__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_min__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_min__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_min__cOriginalDbColumnName(){
				
					return "RL_Scale_min__c";
				
				}

				
			    public String RL_Service_Detail__c;

				public String getRL_Service_Detail__c () {
					return this.RL_Service_Detail__c;
				}

				public Boolean RL_Service_Detail__cIsNullable(){
				    return true;
				}
				public Boolean RL_Service_Detail__cIsKey(){
				    return false;
				}
				public Integer RL_Service_Detail__cLength(){
				    return 18;
				}
				public Integer RL_Service_Detail__cPrecision(){
				    return null;
				}
				public String RL_Service_Detail__cDefault(){
				
					return null;
				
				}
				public String RL_Service_Detail__cComment(){
				
				    return "";
				
				}
				public String RL_Service_Detail__cPattern(){
				
					return "";
				
				}
				public String RL_Service_Detail__cOriginalDbColumnName(){
				
					return "RL_Service_Detail__c";
				
				}

				
			    public Float RL_Unit__c;

				public Float getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return true;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 12;
				}
				public Integer RL_Unit__cPrecision(){
				    return 2;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public String RL_Round_Name__c;

				public String getRL_Round_Name__c () {
					return this.RL_Round_Name__c;
				}

				public Boolean RL_Round_Name__cIsNullable(){
				    return true;
				}
				public Boolean RL_Round_Name__cIsKey(){
				    return false;
				}
				public Integer RL_Round_Name__cLength(){
				    return 255;
				}
				public Integer RL_Round_Name__cPrecision(){
				    return null;
				}
				public String RL_Round_Name__cDefault(){
				
					return null;
				
				}
				public String RL_Round_Name__cComment(){
				
				    return "";
				
				}
				public String RL_Round_Name__cPattern(){
				
					return "";
				
				}
				public String RL_Round_Name__cOriginalDbColumnName(){
				
					return "RL_Round_Name__c";
				
				}

				
			    public Integer RL_MAD_Round_Index__c;

				public Integer getRL_MAD_Round_Index__c () {
					return this.RL_MAD_Round_Index__c;
				}

				public Boolean RL_MAD_Round_Index__cIsNullable(){
				    return true;
				}
				public Boolean RL_MAD_Round_Index__cIsKey(){
				    return false;
				}
				public Integer RL_MAD_Round_Index__cLength(){
				    return 18;
				}
				public Integer RL_MAD_Round_Index__cPrecision(){
				    return null;
				}
				public String RL_MAD_Round_Index__cDefault(){
				
					return null;
				
				}
				public String RL_MAD_Round_Index__cComment(){
				
				    return "";
				
				}
				public String RL_MAD_Round_Index__cPattern(){
				
					return "";
				
				}
				public String RL_MAD_Round_Index__cOriginalDbColumnName(){
				
					return "RL_MAD_Round_Index__c";
				
				}

				
			    public boolean RL_Is_Archived__c;

				public boolean getRL_Is_Archived__c () {
					return this.RL_Is_Archived__c;
				}

				public Boolean RL_Is_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Archived__cLength(){
				    return null;
				}
				public Integer RL_Is_Archived__cPrecision(){
				    return null;
				}
				public String RL_Is_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Archived__cOriginalDbColumnName(){
				
					return "RL_Is_Archived__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Additional_quantity__c="+String.valueOf(RL_Additional_quantity__c));
		sb.append(",RL_Day__c="+RL_Day__c);
		sb.append(",RL_Delivery_postal_codes__c="+RL_Delivery_postal_codes__c);
		sb.append(",RL_External_Service_Detail_Id__c="+String.valueOf(RL_External_Service_Detail_Id__c));
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Price__c="+String.valueOf(RL_Price__c));
		sb.append(",RL_Recovery_postal_codes__c="+RL_Recovery_postal_codes__c);
		sb.append(",RL_Scale_max__c="+String.valueOf(RL_Scale_max__c));
		sb.append(",RL_Scale_min__c="+String.valueOf(RL_Scale_min__c));
		sb.append(",RL_Service_Detail__c="+RL_Service_Detail__c);
		sb.append(",RL_Unit__c="+String.valueOf(RL_Unit__c));
		sb.append(",RL_Round_Name__c="+RL_Round_Name__c);
		sb.append(",RL_MAD_Round_Index__c="+String.valueOf(RL_MAD_Round_Index__c));
		sb.append(",RL_Is_Archived__c="+String.valueOf(RL_Is_Archived__c));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Additional_quantity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Additional_quantity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Day__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Day__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Delivery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Delivery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_Service_Detail_Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_Service_Detail_Id__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Price__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Price__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Recovery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Recovery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_max__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_max__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_min__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_min__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Service_Detail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service_Detail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Round_Name__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Round_Name__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_MAD_Round_Index__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_MAD_Round_Index__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Archived__c);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String CreatedDate;

				public String getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public Float RL_Additional_quantity__c;

				public Float getRL_Additional_quantity__c () {
					return this.RL_Additional_quantity__c;
				}

				public Boolean RL_Additional_quantity__cIsNullable(){
				    return true;
				}
				public Boolean RL_Additional_quantity__cIsKey(){
				    return false;
				}
				public Integer RL_Additional_quantity__cLength(){
				    return 12;
				}
				public Integer RL_Additional_quantity__cPrecision(){
				    return 2;
				}
				public String RL_Additional_quantity__cDefault(){
				
					return null;
				
				}
				public String RL_Additional_quantity__cComment(){
				
				    return "";
				
				}
				public String RL_Additional_quantity__cPattern(){
				
					return "";
				
				}
				public String RL_Additional_quantity__cOriginalDbColumnName(){
				
					return "RL_Additional_quantity__c";
				
				}

				
			    public String RL_Day__c;

				public String getRL_Day__c () {
					return this.RL_Day__c;
				}

				public Boolean RL_Day__cIsNullable(){
				    return true;
				}
				public Boolean RL_Day__cIsKey(){
				    return false;
				}
				public Integer RL_Day__cLength(){
				    return 255;
				}
				public Integer RL_Day__cPrecision(){
				    return null;
				}
				public String RL_Day__cDefault(){
				
					return null;
				
				}
				public String RL_Day__cComment(){
				
				    return "";
				
				}
				public String RL_Day__cPattern(){
				
					return "";
				
				}
				public String RL_Day__cOriginalDbColumnName(){
				
					return "RL_Day__c";
				
				}

				
			    public String RL_Delivery_postal_codes__c;

				public String getRL_Delivery_postal_codes__c () {
					return this.RL_Delivery_postal_codes__c;
				}

				public Boolean RL_Delivery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Delivery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Delivery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Delivery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Delivery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Delivery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Delivery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Delivery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Delivery_postal_codes__c";
				
				}

				
			    public Integer RL_External_Service_Detail_Id__c;

				public Integer getRL_External_Service_Detail_Id__c () {
					return this.RL_External_Service_Detail_Id__c;
				}

				public Boolean RL_External_Service_Detail_Id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_Service_Detail_Id__cIsKey(){
				    return false;
				}
				public Integer RL_External_Service_Detail_Id__cLength(){
				    return 18;
				}
				public Integer RL_External_Service_Detail_Id__cPrecision(){
				    return null;
				}
				public String RL_External_Service_Detail_Id__cDefault(){
				
					return null;
				
				}
				public String RL_External_Service_Detail_Id__cComment(){
				
				    return "";
				
				}
				public String RL_External_Service_Detail_Id__cPattern(){
				
					return "";
				
				}
				public String RL_External_Service_Detail_Id__cOriginalDbColumnName(){
				
					return "RL_External_Service_Detail_Id__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public Float RL_Price__c;

				public Float getRL_Price__c () {
					return this.RL_Price__c;
				}

				public Boolean RL_Price__cIsNullable(){
				    return true;
				}
				public Boolean RL_Price__cIsKey(){
				    return false;
				}
				public Integer RL_Price__cLength(){
				    return 12;
				}
				public Integer RL_Price__cPrecision(){
				    return 2;
				}
				public String RL_Price__cDefault(){
				
					return null;
				
				}
				public String RL_Price__cComment(){
				
				    return "";
				
				}
				public String RL_Price__cPattern(){
				
					return "";
				
				}
				public String RL_Price__cOriginalDbColumnName(){
				
					return "RL_Price__c";
				
				}

				
			    public String RL_Recovery_postal_codes__c;

				public String getRL_Recovery_postal_codes__c () {
					return this.RL_Recovery_postal_codes__c;
				}

				public Boolean RL_Recovery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Recovery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Recovery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Recovery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Recovery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Recovery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Recovery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Recovery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Recovery_postal_codes__c";
				
				}

				
			    public Float RL_Scale_max__c;

				public Float getRL_Scale_max__c () {
					return this.RL_Scale_max__c;
				}

				public Boolean RL_Scale_max__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_max__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_max__cLength(){
				    return 12;
				}
				public Integer RL_Scale_max__cPrecision(){
				    return 2;
				}
				public String RL_Scale_max__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_max__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_max__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_max__cOriginalDbColumnName(){
				
					return "RL_Scale_max__c";
				
				}

				
			    public Float RL_Scale_min__c;

				public Float getRL_Scale_min__c () {
					return this.RL_Scale_min__c;
				}

				public Boolean RL_Scale_min__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_min__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_min__cLength(){
				    return 12;
				}
				public Integer RL_Scale_min__cPrecision(){
				    return 2;
				}
				public String RL_Scale_min__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_min__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_min__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_min__cOriginalDbColumnName(){
				
					return "RL_Scale_min__c";
				
				}

				
			    public String RL_Service_Detail__c;

				public String getRL_Service_Detail__c () {
					return this.RL_Service_Detail__c;
				}

				public Boolean RL_Service_Detail__cIsNullable(){
				    return true;
				}
				public Boolean RL_Service_Detail__cIsKey(){
				    return false;
				}
				public Integer RL_Service_Detail__cLength(){
				    return 18;
				}
				public Integer RL_Service_Detail__cPrecision(){
				    return null;
				}
				public String RL_Service_Detail__cDefault(){
				
					return null;
				
				}
				public String RL_Service_Detail__cComment(){
				
				    return "";
				
				}
				public String RL_Service_Detail__cPattern(){
				
					return "";
				
				}
				public String RL_Service_Detail__cOriginalDbColumnName(){
				
					return "RL_Service_Detail__c";
				
				}

				
			    public Float RL_Unit__c;

				public Float getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return true;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 12;
				}
				public Integer RL_Unit__cPrecision(){
				    return 2;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public String RL_Round_Name__c;

				public String getRL_Round_Name__c () {
					return this.RL_Round_Name__c;
				}

				public Boolean RL_Round_Name__cIsNullable(){
				    return true;
				}
				public Boolean RL_Round_Name__cIsKey(){
				    return false;
				}
				public Integer RL_Round_Name__cLength(){
				    return 255;
				}
				public Integer RL_Round_Name__cPrecision(){
				    return null;
				}
				public String RL_Round_Name__cDefault(){
				
					return null;
				
				}
				public String RL_Round_Name__cComment(){
				
				    return "";
				
				}
				public String RL_Round_Name__cPattern(){
				
					return "";
				
				}
				public String RL_Round_Name__cOriginalDbColumnName(){
				
					return "RL_Round_Name__c";
				
				}

				
			    public Integer RL_MAD_Round_Index__c;

				public Integer getRL_MAD_Round_Index__c () {
					return this.RL_MAD_Round_Index__c;
				}

				public Boolean RL_MAD_Round_Index__cIsNullable(){
				    return true;
				}
				public Boolean RL_MAD_Round_Index__cIsKey(){
				    return false;
				}
				public Integer RL_MAD_Round_Index__cLength(){
				    return 18;
				}
				public Integer RL_MAD_Round_Index__cPrecision(){
				    return null;
				}
				public String RL_MAD_Round_Index__cDefault(){
				
					return null;
				
				}
				public String RL_MAD_Round_Index__cComment(){
				
				    return "";
				
				}
				public String RL_MAD_Round_Index__cPattern(){
				
					return "";
				
				}
				public String RL_MAD_Round_Index__cOriginalDbColumnName(){
				
					return "RL_MAD_Round_Index__c";
				
				}

				
			    public boolean RL_Is_Archived__c;

				public boolean getRL_Is_Archived__c () {
					return this.RL_Is_Archived__c;
				}

				public Boolean RL_Is_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Archived__cLength(){
				    return null;
				}
				public Integer RL_Is_Archived__cPrecision(){
				    return null;
				}
				public String RL_Is_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Archived__cOriginalDbColumnName(){
				
					return "RL_Is_Archived__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readString(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readFloat();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
						this.RL_External_Service_Detail_Id__c = readInteger(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Price__c = null;
           				} else {
           			    	this.RL_Price__c = dis.readFloat();
           				}
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readFloat();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readFloat();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
						this.RL_MAD_Round_Index__c = readInteger(dis);
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Float
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_Service_Detail_Id__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// Float
				
						if(this.RL_Price__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Price__c);
		            	}
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Float
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_max__c);
		            	}
					
					// Float
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Float
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Integer
				
						writeInteger(this.RL_MAD_Round_Index__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+CreatedDate);
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Additional_quantity__c="+String.valueOf(RL_Additional_quantity__c));
		sb.append(",RL_Day__c="+RL_Day__c);
		sb.append(",RL_Delivery_postal_codes__c="+RL_Delivery_postal_codes__c);
		sb.append(",RL_External_Service_Detail_Id__c="+String.valueOf(RL_External_Service_Detail_Id__c));
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Price__c="+String.valueOf(RL_Price__c));
		sb.append(",RL_Recovery_postal_codes__c="+RL_Recovery_postal_codes__c);
		sb.append(",RL_Scale_max__c="+String.valueOf(RL_Scale_max__c));
		sb.append(",RL_Scale_min__c="+String.valueOf(RL_Scale_min__c));
		sb.append(",RL_Service_Detail__c="+RL_Service_Detail__c);
		sb.append(",RL_Unit__c="+String.valueOf(RL_Unit__c));
		sb.append(",RL_Round_Name__c="+RL_Round_Name__c);
		sb.append(",RL_MAD_Round_Index__c="+String.valueOf(RL_MAD_Round_Index__c));
		sb.append(",RL_Is_Archived__c="+String.valueOf(RL_Is_Archived__c));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Additional_quantity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Additional_quantity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Day__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Day__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Delivery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Delivery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_Service_Detail_Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_Service_Detail_Id__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Price__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Price__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Recovery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Recovery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_max__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_max__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_min__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_min__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Service_Detail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service_Detail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Round_Name__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Round_Name__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_MAD_Round_Index__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_MAD_Round_Index__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Archived__c);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public Double RL_Additional_quantity__c;

				public Double getRL_Additional_quantity__c () {
					return this.RL_Additional_quantity__c;
				}

				public Boolean RL_Additional_quantity__cIsNullable(){
				    return true;
				}
				public Boolean RL_Additional_quantity__cIsKey(){
				    return false;
				}
				public Integer RL_Additional_quantity__cLength(){
				    return 12;
				}
				public Integer RL_Additional_quantity__cPrecision(){
				    return 2;
				}
				public String RL_Additional_quantity__cDefault(){
				
					return null;
				
				}
				public String RL_Additional_quantity__cComment(){
				
				    return "";
				
				}
				public String RL_Additional_quantity__cPattern(){
				
					return "";
				
				}
				public String RL_Additional_quantity__cOriginalDbColumnName(){
				
					return "RL_Additional_quantity__c";
				
				}

				
			    public String RL_Day__c;

				public String getRL_Day__c () {
					return this.RL_Day__c;
				}

				public Boolean RL_Day__cIsNullable(){
				    return true;
				}
				public Boolean RL_Day__cIsKey(){
				    return false;
				}
				public Integer RL_Day__cLength(){
				    return 255;
				}
				public Integer RL_Day__cPrecision(){
				    return null;
				}
				public String RL_Day__cDefault(){
				
					return null;
				
				}
				public String RL_Day__cComment(){
				
				    return "";
				
				}
				public String RL_Day__cPattern(){
				
					return "";
				
				}
				public String RL_Day__cOriginalDbColumnName(){
				
					return "RL_Day__c";
				
				}

				
			    public String RL_Delivery_postal_codes__c;

				public String getRL_Delivery_postal_codes__c () {
					return this.RL_Delivery_postal_codes__c;
				}

				public Boolean RL_Delivery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Delivery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Delivery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Delivery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Delivery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Delivery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Delivery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Delivery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Delivery_postal_codes__c";
				
				}

				
			    public Double RL_External_Service_Detail_Id__c;

				public Double getRL_External_Service_Detail_Id__c () {
					return this.RL_External_Service_Detail_Id__c;
				}

				public Boolean RL_External_Service_Detail_Id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_Service_Detail_Id__cIsKey(){
				    return false;
				}
				public Integer RL_External_Service_Detail_Id__cLength(){
				    return 18;
				}
				public Integer RL_External_Service_Detail_Id__cPrecision(){
				    return null;
				}
				public String RL_External_Service_Detail_Id__cDefault(){
				
					return null;
				
				}
				public String RL_External_Service_Detail_Id__cComment(){
				
				    return "";
				
				}
				public String RL_External_Service_Detail_Id__cPattern(){
				
					return "";
				
				}
				public String RL_External_Service_Detail_Id__cOriginalDbColumnName(){
				
					return "RL_External_Service_Detail_Id__c";
				
				}

				
			    public Double RL_External_id__c;

				public Double getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public BigDecimal RL_Price__c;

				public BigDecimal getRL_Price__c () {
					return this.RL_Price__c;
				}

				public Boolean RL_Price__cIsNullable(){
				    return true;
				}
				public Boolean RL_Price__cIsKey(){
				    return false;
				}
				public Integer RL_Price__cLength(){
				    return 12;
				}
				public Integer RL_Price__cPrecision(){
				    return 2;
				}
				public String RL_Price__cDefault(){
				
					return null;
				
				}
				public String RL_Price__cComment(){
				
				    return "";
				
				}
				public String RL_Price__cPattern(){
				
					return "";
				
				}
				public String RL_Price__cOriginalDbColumnName(){
				
					return "RL_Price__c";
				
				}

				
			    public String RL_Recovery_postal_codes__c;

				public String getRL_Recovery_postal_codes__c () {
					return this.RL_Recovery_postal_codes__c;
				}

				public Boolean RL_Recovery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Recovery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Recovery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Recovery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Recovery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Recovery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Recovery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Recovery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Recovery_postal_codes__c";
				
				}

				
			    public Double RL_Scale_max__c;

				public Double getRL_Scale_max__c () {
					return this.RL_Scale_max__c;
				}

				public Boolean RL_Scale_max__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_max__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_max__cLength(){
				    return 12;
				}
				public Integer RL_Scale_max__cPrecision(){
				    return 2;
				}
				public String RL_Scale_max__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_max__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_max__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_max__cOriginalDbColumnName(){
				
					return "RL_Scale_max__c";
				
				}

				
			    public Double RL_Scale_min__c;

				public Double getRL_Scale_min__c () {
					return this.RL_Scale_min__c;
				}

				public Boolean RL_Scale_min__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_min__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_min__cLength(){
				    return 12;
				}
				public Integer RL_Scale_min__cPrecision(){
				    return 2;
				}
				public String RL_Scale_min__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_min__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_min__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_min__cOriginalDbColumnName(){
				
					return "RL_Scale_min__c";
				
				}

				
			    public String RL_Service_Detail__c;

				public String getRL_Service_Detail__c () {
					return this.RL_Service_Detail__c;
				}

				public Boolean RL_Service_Detail__cIsNullable(){
				    return true;
				}
				public Boolean RL_Service_Detail__cIsKey(){
				    return false;
				}
				public Integer RL_Service_Detail__cLength(){
				    return 18;
				}
				public Integer RL_Service_Detail__cPrecision(){
				    return null;
				}
				public String RL_Service_Detail__cDefault(){
				
					return null;
				
				}
				public String RL_Service_Detail__cComment(){
				
				    return "";
				
				}
				public String RL_Service_Detail__cPattern(){
				
					return "";
				
				}
				public String RL_Service_Detail__cOriginalDbColumnName(){
				
					return "RL_Service_Detail__c";
				
				}

				
			    public Double RL_Unit__c;

				public Double getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return true;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 12;
				}
				public Integer RL_Unit__cPrecision(){
				    return 2;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public String RL_Round_Name__c;

				public String getRL_Round_Name__c () {
					return this.RL_Round_Name__c;
				}

				public Boolean RL_Round_Name__cIsNullable(){
				    return true;
				}
				public Boolean RL_Round_Name__cIsKey(){
				    return false;
				}
				public Integer RL_Round_Name__cLength(){
				    return 255;
				}
				public Integer RL_Round_Name__cPrecision(){
				    return null;
				}
				public String RL_Round_Name__cDefault(){
				
					return null;
				
				}
				public String RL_Round_Name__cComment(){
				
				    return "";
				
				}
				public String RL_Round_Name__cPattern(){
				
					return "";
				
				}
				public String RL_Round_Name__cOriginalDbColumnName(){
				
					return "RL_Round_Name__c";
				
				}

				
			    public Double RL_MAD_Round_Index__c;

				public Double getRL_MAD_Round_Index__c () {
					return this.RL_MAD_Round_Index__c;
				}

				public Boolean RL_MAD_Round_Index__cIsNullable(){
				    return true;
				}
				public Boolean RL_MAD_Round_Index__cIsKey(){
				    return false;
				}
				public Integer RL_MAD_Round_Index__cLength(){
				    return 18;
				}
				public Integer RL_MAD_Round_Index__cPrecision(){
				    return null;
				}
				public String RL_MAD_Round_Index__cDefault(){
				
					return null;
				
				}
				public String RL_MAD_Round_Index__cComment(){
				
				    return "";
				
				}
				public String RL_MAD_Round_Index__cPattern(){
				
					return "";
				
				}
				public String RL_MAD_Round_Index__cOriginalDbColumnName(){
				
					return "RL_MAD_Round_Index__c";
				
				}

				
			    public boolean RL_Is_Archived__c;

				public boolean getRL_Is_Archived__c () {
					return this.RL_Is_Archived__c;
				}

				public Boolean RL_Is_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Archived__cLength(){
				    return null;
				}
				public Integer RL_Is_Archived__cPrecision(){
				    return null;
				}
				public String RL_Is_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Archived__cOriginalDbColumnName(){
				
					return "RL_Is_Archived__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readDouble();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_Service_Detail_Id__c = null;
           				} else {
           			    	this.RL_External_Service_Detail_Id__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
						this.RL_Price__c = (BigDecimal) dis.readObject();
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readDouble();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readDouble();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_MAD_Round_Index__c = null;
           				} else {
           			    	this.RL_MAD_Round_Index__c = dis.readDouble();
           				}
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readDouble();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_Service_Detail_Id__c = null;
           				} else {
           			    	this.RL_External_Service_Detail_Id__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
						this.RL_Price__c = (BigDecimal) dis.readObject();
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readDouble();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readDouble();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_MAD_Round_Index__c = null;
           				} else {
           			    	this.RL_MAD_Round_Index__c = dis.readDouble();
           				}
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Double
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_External_Service_Detail_Id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_Service_Detail_Id__c);
		            	}
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// BigDecimal
				
       			    	dos.writeObject(this.RL_Price__c);
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_max__c);
		            	}
					
					// Double
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Double
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Double
				
						if(this.RL_MAD_Round_Index__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_MAD_Round_Index__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Double
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_External_Service_Detail_Id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_Service_Detail_Id__c);
		            	}
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.RL_Price__c);
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_max__c);
		            	}
					
					// Double
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Double
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Double
				
						if(this.RL_MAD_Round_Index__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_MAD_Round_Index__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Additional_quantity__c="+String.valueOf(RL_Additional_quantity__c));
		sb.append(",RL_Day__c="+RL_Day__c);
		sb.append(",RL_Delivery_postal_codes__c="+RL_Delivery_postal_codes__c);
		sb.append(",RL_External_Service_Detail_Id__c="+String.valueOf(RL_External_Service_Detail_Id__c));
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Price__c="+String.valueOf(RL_Price__c));
		sb.append(",RL_Recovery_postal_codes__c="+RL_Recovery_postal_codes__c);
		sb.append(",RL_Scale_max__c="+String.valueOf(RL_Scale_max__c));
		sb.append(",RL_Scale_min__c="+String.valueOf(RL_Scale_min__c));
		sb.append(",RL_Service_Detail__c="+RL_Service_Detail__c);
		sb.append(",RL_Unit__c="+String.valueOf(RL_Unit__c));
		sb.append(",RL_Round_Name__c="+RL_Round_Name__c);
		sb.append(",RL_MAD_Round_Index__c="+String.valueOf(RL_MAD_Round_Index__c));
		sb.append(",RL_Is_Archived__c="+String.valueOf(RL_Is_Archived__c));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Additional_quantity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Additional_quantity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Day__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Day__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Delivery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Delivery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_Service_Detail_Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_Service_Detail_Id__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Price__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Price__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Recovery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Recovery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_max__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_max__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_min__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_min__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Service_Detail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service_Detail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Round_Name__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Round_Name__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_MAD_Round_Index__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_MAD_Round_Index__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Archived__c);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tSalesforceInput_1Struct implements routines.system.IPersistableRow<after_tSalesforceInput_1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public Double RL_Additional_quantity__c;

				public Double getRL_Additional_quantity__c () {
					return this.RL_Additional_quantity__c;
				}

				public Boolean RL_Additional_quantity__cIsNullable(){
				    return true;
				}
				public Boolean RL_Additional_quantity__cIsKey(){
				    return false;
				}
				public Integer RL_Additional_quantity__cLength(){
				    return 12;
				}
				public Integer RL_Additional_quantity__cPrecision(){
				    return 2;
				}
				public String RL_Additional_quantity__cDefault(){
				
					return null;
				
				}
				public String RL_Additional_quantity__cComment(){
				
				    return "";
				
				}
				public String RL_Additional_quantity__cPattern(){
				
					return "";
				
				}
				public String RL_Additional_quantity__cOriginalDbColumnName(){
				
					return "RL_Additional_quantity__c";
				
				}

				
			    public String RL_Day__c;

				public String getRL_Day__c () {
					return this.RL_Day__c;
				}

				public Boolean RL_Day__cIsNullable(){
				    return true;
				}
				public Boolean RL_Day__cIsKey(){
				    return false;
				}
				public Integer RL_Day__cLength(){
				    return 255;
				}
				public Integer RL_Day__cPrecision(){
				    return null;
				}
				public String RL_Day__cDefault(){
				
					return null;
				
				}
				public String RL_Day__cComment(){
				
				    return "";
				
				}
				public String RL_Day__cPattern(){
				
					return "";
				
				}
				public String RL_Day__cOriginalDbColumnName(){
				
					return "RL_Day__c";
				
				}

				
			    public String RL_Delivery_postal_codes__c;

				public String getRL_Delivery_postal_codes__c () {
					return this.RL_Delivery_postal_codes__c;
				}

				public Boolean RL_Delivery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Delivery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Delivery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Delivery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Delivery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Delivery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Delivery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Delivery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Delivery_postal_codes__c";
				
				}

				
			    public Double RL_External_Service_Detail_Id__c;

				public Double getRL_External_Service_Detail_Id__c () {
					return this.RL_External_Service_Detail_Id__c;
				}

				public Boolean RL_External_Service_Detail_Id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_Service_Detail_Id__cIsKey(){
				    return false;
				}
				public Integer RL_External_Service_Detail_Id__cLength(){
				    return 18;
				}
				public Integer RL_External_Service_Detail_Id__cPrecision(){
				    return null;
				}
				public String RL_External_Service_Detail_Id__cDefault(){
				
					return null;
				
				}
				public String RL_External_Service_Detail_Id__cComment(){
				
				    return "";
				
				}
				public String RL_External_Service_Detail_Id__cPattern(){
				
					return "";
				
				}
				public String RL_External_Service_Detail_Id__cOriginalDbColumnName(){
				
					return "RL_External_Service_Detail_Id__c";
				
				}

				
			    public Double RL_External_id__c;

				public Double getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public BigDecimal RL_Price__c;

				public BigDecimal getRL_Price__c () {
					return this.RL_Price__c;
				}

				public Boolean RL_Price__cIsNullable(){
				    return true;
				}
				public Boolean RL_Price__cIsKey(){
				    return false;
				}
				public Integer RL_Price__cLength(){
				    return 12;
				}
				public Integer RL_Price__cPrecision(){
				    return 2;
				}
				public String RL_Price__cDefault(){
				
					return null;
				
				}
				public String RL_Price__cComment(){
				
				    return "";
				
				}
				public String RL_Price__cPattern(){
				
					return "";
				
				}
				public String RL_Price__cOriginalDbColumnName(){
				
					return "RL_Price__c";
				
				}

				
			    public String RL_Recovery_postal_codes__c;

				public String getRL_Recovery_postal_codes__c () {
					return this.RL_Recovery_postal_codes__c;
				}

				public Boolean RL_Recovery_postal_codes__cIsNullable(){
				    return true;
				}
				public Boolean RL_Recovery_postal_codes__cIsKey(){
				    return false;
				}
				public Integer RL_Recovery_postal_codes__cLength(){
				    return 255;
				}
				public Integer RL_Recovery_postal_codes__cPrecision(){
				    return null;
				}
				public String RL_Recovery_postal_codes__cDefault(){
				
					return null;
				
				}
				public String RL_Recovery_postal_codes__cComment(){
				
				    return "";
				
				}
				public String RL_Recovery_postal_codes__cPattern(){
				
					return "";
				
				}
				public String RL_Recovery_postal_codes__cOriginalDbColumnName(){
				
					return "RL_Recovery_postal_codes__c";
				
				}

				
			    public Double RL_Scale_max__c;

				public Double getRL_Scale_max__c () {
					return this.RL_Scale_max__c;
				}

				public Boolean RL_Scale_max__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_max__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_max__cLength(){
				    return 12;
				}
				public Integer RL_Scale_max__cPrecision(){
				    return 2;
				}
				public String RL_Scale_max__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_max__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_max__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_max__cOriginalDbColumnName(){
				
					return "RL_Scale_max__c";
				
				}

				
			    public Double RL_Scale_min__c;

				public Double getRL_Scale_min__c () {
					return this.RL_Scale_min__c;
				}

				public Boolean RL_Scale_min__cIsNullable(){
				    return true;
				}
				public Boolean RL_Scale_min__cIsKey(){
				    return false;
				}
				public Integer RL_Scale_min__cLength(){
				    return 12;
				}
				public Integer RL_Scale_min__cPrecision(){
				    return 2;
				}
				public String RL_Scale_min__cDefault(){
				
					return null;
				
				}
				public String RL_Scale_min__cComment(){
				
				    return "";
				
				}
				public String RL_Scale_min__cPattern(){
				
					return "";
				
				}
				public String RL_Scale_min__cOriginalDbColumnName(){
				
					return "RL_Scale_min__c";
				
				}

				
			    public String RL_Service_Detail__c;

				public String getRL_Service_Detail__c () {
					return this.RL_Service_Detail__c;
				}

				public Boolean RL_Service_Detail__cIsNullable(){
				    return true;
				}
				public Boolean RL_Service_Detail__cIsKey(){
				    return false;
				}
				public Integer RL_Service_Detail__cLength(){
				    return 18;
				}
				public Integer RL_Service_Detail__cPrecision(){
				    return null;
				}
				public String RL_Service_Detail__cDefault(){
				
					return null;
				
				}
				public String RL_Service_Detail__cComment(){
				
				    return "";
				
				}
				public String RL_Service_Detail__cPattern(){
				
					return "";
				
				}
				public String RL_Service_Detail__cOriginalDbColumnName(){
				
					return "RL_Service_Detail__c";
				
				}

				
			    public Double RL_Unit__c;

				public Double getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return true;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 12;
				}
				public Integer RL_Unit__cPrecision(){
				    return 2;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public String RL_Round_Name__c;

				public String getRL_Round_Name__c () {
					return this.RL_Round_Name__c;
				}

				public Boolean RL_Round_Name__cIsNullable(){
				    return true;
				}
				public Boolean RL_Round_Name__cIsKey(){
				    return false;
				}
				public Integer RL_Round_Name__cLength(){
				    return 255;
				}
				public Integer RL_Round_Name__cPrecision(){
				    return null;
				}
				public String RL_Round_Name__cDefault(){
				
					return null;
				
				}
				public String RL_Round_Name__cComment(){
				
				    return "";
				
				}
				public String RL_Round_Name__cPattern(){
				
					return "";
				
				}
				public String RL_Round_Name__cOriginalDbColumnName(){
				
					return "RL_Round_Name__c";
				
				}

				
			    public Double RL_MAD_Round_Index__c;

				public Double getRL_MAD_Round_Index__c () {
					return this.RL_MAD_Round_Index__c;
				}

				public Boolean RL_MAD_Round_Index__cIsNullable(){
				    return true;
				}
				public Boolean RL_MAD_Round_Index__cIsKey(){
				    return false;
				}
				public Integer RL_MAD_Round_Index__cLength(){
				    return 18;
				}
				public Integer RL_MAD_Round_Index__cPrecision(){
				    return null;
				}
				public String RL_MAD_Round_Index__cDefault(){
				
					return null;
				
				}
				public String RL_MAD_Round_Index__cComment(){
				
				    return "";
				
				}
				public String RL_MAD_Round_Index__cPattern(){
				
					return "";
				
				}
				public String RL_MAD_Round_Index__cOriginalDbColumnName(){
				
					return "RL_MAD_Round_Index__c";
				
				}

				
			    public boolean RL_Is_Archived__c;

				public boolean getRL_Is_Archived__c () {
					return this.RL_Is_Archived__c;
				}

				public Boolean RL_Is_Archived__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Archived__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Archived__cLength(){
				    return null;
				}
				public Integer RL_Is_Archived__cPrecision(){
				    return null;
				}
				public String RL_Is_Archived__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Archived__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Archived__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Archived__cOriginalDbColumnName(){
				
					return "RL_Is_Archived__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readDouble();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_Service_Detail_Id__c = null;
           				} else {
           			    	this.RL_External_Service_Detail_Id__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
						this.RL_Price__c = (BigDecimal) dis.readObject();
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readDouble();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readDouble();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_MAD_Round_Index__c = null;
           				} else {
           			    	this.RL_MAD_Round_Index__c = dis.readDouble();
           				}
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Additional_quantity__c = null;
           				} else {
           			    	this.RL_Additional_quantity__c = dis.readDouble();
           				}
					
					this.RL_Day__c = readString(dis);
					
					this.RL_Delivery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_Service_Detail_Id__c = null;
           				} else {
           			    	this.RL_External_Service_Detail_Id__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
						this.RL_Price__c = (BigDecimal) dis.readObject();
					
					this.RL_Recovery_postal_codes__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_max__c = null;
           				} else {
           			    	this.RL_Scale_max__c = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Scale_min__c = null;
           				} else {
           			    	this.RL_Scale_min__c = dis.readDouble();
           				}
					
					this.RL_Service_Detail__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_Unit__c = null;
           				} else {
           			    	this.RL_Unit__c = dis.readDouble();
           				}
					
					this.RL_Round_Name__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_MAD_Round_Index__c = null;
           				} else {
           			    	this.RL_MAD_Round_Index__c = dis.readDouble();
           				}
					
			        this.RL_Is_Archived__c = dis.readBoolean();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Double
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_External_Service_Detail_Id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_Service_Detail_Id__c);
		            	}
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// BigDecimal
				
       			    	dos.writeObject(this.RL_Price__c);
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_max__c);
		            	}
					
					// Double
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Double
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Double
				
						if(this.RL_MAD_Round_Index__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_MAD_Round_Index__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// Double
				
						if(this.RL_Additional_quantity__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Additional_quantity__c);
		            	}
					
					// String
				
						writeString(this.RL_Day__c,dos);
					
					// String
				
						writeString(this.RL_Delivery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_External_Service_Detail_Id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_Service_Detail_Id__c);
		            	}
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.RL_Price__c);
					
					// String
				
						writeString(this.RL_Recovery_postal_codes__c,dos);
					
					// Double
				
						if(this.RL_Scale_max__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_max__c);
		            	}
					
					// Double
				
						if(this.RL_Scale_min__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Scale_min__c);
		            	}
					
					// String
				
						writeString(this.RL_Service_Detail__c,dos);
					
					// Double
				
						if(this.RL_Unit__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_Unit__c);
		            	}
					
					// String
				
						writeString(this.RL_Round_Name__c,dos);
					
					// Double
				
						if(this.RL_MAD_Round_Index__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_MAD_Round_Index__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Archived__c);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Additional_quantity__c="+String.valueOf(RL_Additional_quantity__c));
		sb.append(",RL_Day__c="+RL_Day__c);
		sb.append(",RL_Delivery_postal_codes__c="+RL_Delivery_postal_codes__c);
		sb.append(",RL_External_Service_Detail_Id__c="+String.valueOf(RL_External_Service_Detail_Id__c));
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Price__c="+String.valueOf(RL_Price__c));
		sb.append(",RL_Recovery_postal_codes__c="+RL_Recovery_postal_codes__c);
		sb.append(",RL_Scale_max__c="+String.valueOf(RL_Scale_max__c));
		sb.append(",RL_Scale_min__c="+String.valueOf(RL_Scale_min__c));
		sb.append(",RL_Service_Detail__c="+RL_Service_Detail__c);
		sb.append(",RL_Unit__c="+String.valueOf(RL_Unit__c));
		sb.append(",RL_Round_Name__c="+RL_Round_Name__c);
		sb.append(",RL_MAD_Round_Index__c="+String.valueOf(RL_MAD_Round_Index__c));
		sb.append(",RL_Is_Archived__c="+String.valueOf(RL_Is_Archived__c));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Additional_quantity__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Additional_quantity__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Day__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Day__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Delivery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Delivery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_Service_Detail_Id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_Service_Detail_Id__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Price__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Price__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Recovery_postal_codes__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Recovery_postal_codes__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_max__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_max__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Scale_min__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Scale_min__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Service_Detail__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service_Detail__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Round_Name__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Round_Name__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_MAD_Round_Index__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_MAD_Round_Index__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Archived__c);
        			
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tSalesforceInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tSalesforceInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceInput_1");
		org.slf4j.MDC.put("_subJobPid", "1ymwPR_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tSalesforceInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
row3Struct row3 = new row3Struct();
row4Struct row4 = new row4Struct();
row7Struct row7 = new row7Struct();
pricingStruct pricing = new pricingStruct();








	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pricing");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"pricing\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "tDBOutput_1", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
         if (updateKeyCount_tDBOutput_1 == 17 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "pricing";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "pricing" + "` (`id`,`id_detail`,`day`,`price`,`unit_specification`,`scale_min`,`scale_max`,`additional_quantity`,`delivery_postal_code`,`recovery_postal_code`,`round_name`,`madRoundIndex`,`created_at`,`updated_at`,`id_salesforce`,`is_activated`,`is_archived`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `id_detail` = ?,`day` = ?,`price` = ?,`unit_specification` = ?,`scale_min` = ?,`scale_max` = ?,`additional_quantity` = ?,`delivery_postal_code` = ?,`recovery_postal_code` = ?,`round_name` = ?,`madRoundIndex` = ?,`created_at` = ?,`updated_at` = ?,`id_salesforce` = ?,`is_activated` = ?,`is_archived` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row7_tMap_1 = 0;
		
		int count_row8_tMap_1 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
					globalMap.get( "tHash_Lookup_row8" ))
					;					
					
	

row8Struct row8HashKey = new row8Struct();
row8Struct row8Default = new row8Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
	String var1;
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_pricing_tMap_1 = 0;
				
pricingStruct pricing_tmp = new pricingStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tUniqRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
                    log4jParamters_tUniqRow_1.append("Parameters:");
                            log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Id")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("OwnerId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("IsDeleted")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("SystemModstamp")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastViewedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastReferencedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Is_Modified__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Additional_quantity__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Day__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Delivery_postal_codes__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_External_Service_Detail_Id__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_External_id__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Deleted__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Price__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Recovery_postal_codes__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Scale_max__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Scale_min__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Service_Detail__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Unit__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Round_Name__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_MAD_Round_Index__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Archived__c")+"}]");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + (log4jParamters_tUniqRow_1) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
	log.debug("tUniqRow_1 - Start to process the data from datasource."); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tFilterRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_11", false);
		start_Hash.put("tFilterRow_11", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_11";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tFilterRow_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_11{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_11 = new StringBuilder();
                    log4jParamters_tFilterRow_11.append("Parameters:");
                            log4jParamters_tFilterRow_11.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_11.append(" | ");
                            log4jParamters_tFilterRow_11.append("CONDITIONS" + " = " + "[{OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("RL_External_id__c")+", FUNCTION="+("")+"}, {OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("RL_External_Service_Detail_Id__c")+", FUNCTION="+("")+"}]");
                        log4jParamters_tFilterRow_11.append(" | ");
                            log4jParamters_tFilterRow_11.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + (log4jParamters_tFilterRow_11) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_11().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_11", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_11 = 0;
    int nb_line_ok_tFilterRow_11 = 0;
    int nb_line_reject_tFilterRow_11 = 0;

    class Operator_tFilterRow_11 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_11(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_11 begin ] stop
 */



	
	/**
	 * [tConvertType_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_1", false);
		start_Hash.put("tConvertType_1", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tConvertType_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_1", "tConvertType_1", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_1 = 0;  
 



/**
 * [tConvertType_1 begin ] stop
 */



	
	/**
	 * [tSalesforceInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceInput_1", false);
		start_Hash.put("tSalesforceInput_1", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		
		int tos_count_tSalesforceInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceInput_1", "RL_Pricing__c", "tSalesforceInput");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceInput_1 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceInput_1 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceInput_1 = (String)(restRequest_tSalesforceInput_1 != null ? restRequest_tSalesforceInput_1.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceInput_1 =
        new org.talend.components.salesforce.tsalesforceinput.TSalesforceInputDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceInput_1 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceInput_1 = null;


org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties props_tSalesforceInput_1 =
        (org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties) def_tSalesforceInput_1.createRuntimeProperties();
 		                    props_tSalesforceInput_1.setValue("queryMode",
 		                        org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties.QueryMode.Query);
 		                    
 		                    props_tSalesforceInput_1.setValue("condition",
 		                    "");
 		                    
 		                    props_tSalesforceInput_1.setValue("manualQuery",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.setValue("includeDeleted",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.setValue("batchSize",
 		                    250);
 		                    
 		                    props_tSalesforceInput_1.setValue("normalizeDelimiter",
 		                    ";");
 		                    
 		                    props_tSalesforceInput_1.setValue("columnNameDelimiter",
 		                    "_");
 		                    
 		                    props_tSalesforceInput_1.setValue("dataTimeUTC",
 		                    true);
 		                    
 		                    props_tSalesforceInput_1.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_1.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    props_tSalesforceInput_1.module.setValue("moduleName",
 		                    "RL_Pricing__c");
 		                    
 		                    props_tSalesforceInput_1.module.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.module.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_1.module.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    class SchemaSettingTool_tSalesforceInput_1_1_fisrt {
 		                    		
 		                    		String getSchemaValue() {
 		                    				
 		                    						StringBuilder s = new StringBuilder();
                    						
     		                    						a("{\"type\":\"record\",",s);
     		                    						
     		                    						a("\"name\":\"RL_Pricing__c\",\"fields\":[{",s);
     		                    						
     		                    						a("\"name\":\"Id\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Id\",\"talend.field.dbColumnName\":\"Id\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Id\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"OwnerId\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"OwnerId\",\"talend.field.dbColumnName\":\"OwnerId\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"OwnerId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"IsDeleted\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"IsDeleted\",\"talend.field.dbColumnName\":\"IsDeleted\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"IsDeleted\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Name\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Name\",\"talend.field.dbColumnName\":\"Name\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Name\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"CreatedDate\",\"talend.field.dbColumnName\":\"CreatedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"CreatedById\",\"talend.field.dbColumnName\":\"CreatedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedDate\",\"talend.field.dbColumnName\":\"LastModifiedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedById\",\"talend.field.dbColumnName\":\"LastModifiedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"SystemModstamp\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"SystemModstamp\",\"talend.field.dbColumnName\":\"SystemModstamp\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"SystemModstamp\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastViewedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastViewedDate\",\"talend.field.dbColumnName\":\"LastViewedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastViewedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastReferencedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastReferencedDate\",\"talend.field.dbColumnName\":\"LastReferencedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastReferencedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Is_Modified__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Is_Modified__c\",\"talend.field.dbColumnName\":\"Is_Modified__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Is_Modified__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Additional_quantity__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Additional_quantity__c\",\"talend.field.dbColumnName\":\"RL_Additional_quantity__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"12\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Additional_quantity__c\",\"talend.field.precision\":\"2\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Day__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Day__c\",\"talend.field.dbColumnName\":\"RL_Day__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Day__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Delivery_postal_codes__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Delivery_postal_codes__c\",\"talend.field.dbColumnName\":\"RL_Delivery_postal_codes__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Delivery_postal_codes__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_External_Service_Detail_Id__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_External_Service_Detail_Id__c\",\"talend.field.dbColumnName\":\"RL_External_Service_Detail_Id__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_External_Service_Detail_Id__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_External_id__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_External_id__c\",\"talend.field.dbColumnName\":\"RL_External_id__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"16\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_External_id__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Deleted__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Deleted__c\",\"talend.field.dbColumnName\":\"RL_Is_Deleted__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Deleted__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Price__c\",\"type\":[{\"type\":\"string\",\"java-class\":\"java.math.BigDecimal\"},\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Price__c\",\"talend.field.dbColumnName\":\"RL_Price__c\",\"di.column.talendType\":\"id_BigDecimal\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"12\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Price__c\",\"talend.field.precision\":\"2\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Recovery_postal_codes__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Recovery_postal_codes__c\",\"talend.field.dbColumnName\":\"RL_Recovery_postal_codes__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Recovery_postal_codes__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Scale_max__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Scale_max__c\",\"talend.field.dbColumnName\":\"RL_Scale_max__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"12\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Scale_max__c\",\"talend.field.precision\":\"2\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Scale_min__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Scale_min__c\",\"talend.field.dbColumnName\":\"RL_Scale_min__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"12\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Scale_min__c\",\"talend.field.precision\":\"2\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Service_Detail__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Service_Detail__c\",\"talend.field.dbColumnName\":\"RL_Service_Detail__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Service_Detail__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Unit__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Unit__c\",\"talend.field.dbColumnName\":\"RL_Unit__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"12\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Unit__c\",\"talend.field.precision\":\"2\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Round_Name__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Round_Name__c\",\"talend.field.dbColumnName\":\"RL_Round_Name__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Round_Name__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_MAD_Round_Index__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_MAD_Round_Index__c\",\"talend.field.dbColumnName\":\"RL_MAD_Round_Index__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_MAD_Round_Index__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Archived__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Archived__c\",\"talend.field.dbColumnName\":\"RL_Is_Archived__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Archived__c\",\"di.column.relatedEntity\":\"\"}],\"di.table.name\":\"MAIN\",\"di.table.label\":\"RL_Pricing__c\"}",s);
     		                    						
     		                    				return s.toString();
     		                    		
 		                    		}
 		                    		
 		                    		void a(String part, StringBuilder strB) {
 		                    				strB.append(part);
 		                    		}
 		                    		
 		                    }
 		                    
 		                    SchemaSettingTool_tSalesforceInput_1_1_fisrt sst_tSalesforceInput_1_1_fisrt = new SchemaSettingTool_tSalesforceInput_1_1_fisrt();
 		                    
 		                    props_tSalesforceInput_1.module.main.setValue("schema",
 		                        new org.apache.avro.Schema.Parser().setValidateDefaults(false).parse(sst_tSalesforceInput_1_1_fisrt.getSchemaValue()));
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_1.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_1 = props_tSalesforceInput_1.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_1.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_1);
        }
    }
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_1.module.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_1 = props_tSalesforceInput_1.module.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_1 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_1 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_1 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_1.module.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_1);
        }
    }
globalMap.put("tSalesforceInput_1_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceInput_1);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceInput_1= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceInput_1_MAPPINGS_URL", mappings_url_tSalesforceInput_1);

org.talend.components.api.container.RuntimeContainer container_tSalesforceInput_1 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceInput_1";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceInput_1 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceInput_1 = null;
topology_tSalesforceInput_1 = org.talend.components.api.component.ConnectorTopology.OUTGOING;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceInput_1 = def_tSalesforceInput_1.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceInput_1, topology_tSalesforceInput_1);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceInput_1 = def_tSalesforceInput_1.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceInput_1 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceInput_1.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceInput_1 = componentRuntime_tSalesforceInput_1.initialize(container_tSalesforceInput_1, props_tSalesforceInput_1);

if (initVr_tSalesforceInput_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceInput_1.getMessage());
}

if(componentRuntime_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceInput_1 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceInput_1;
	compDriverInitialization_tSalesforceInput_1.runAtDriver(container_tSalesforceInput_1);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceInput_1 = null;
if(componentRuntime_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceInput_1 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceInput_1;
	if (doesNodeBelongToRequest_tSalesforceInput_1) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceInput_1 = sourceOrSink_tSalesforceInput_1.validate(container_tSalesforceInput_1);
        if (vr_tSalesforceInput_1.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceInput_1.getMessage());
        }
	}
}

    if (sourceOrSink_tSalesforceInput_1 instanceof org.talend.components.api.component.runtime.Source) {
        org.talend.components.api.component.runtime.Source source_tSalesforceInput_1 =
                (org.talend.components.api.component.runtime.Source)sourceOrSink_tSalesforceInput_1;
        reader_tSalesforceInput_1 = source_tSalesforceInput_1.createReader(container_tSalesforceInput_1);
	    reader_tSalesforceInput_1 = new org.talend.codegen.flowvariables.runtime.FlowVariablesReader(reader_tSalesforceInput_1, container_tSalesforceInput_1);

            boolean multi_output_is_allowed_tSalesforceInput_1 = false;
            org.talend.components.api.component.Connector c_tSalesforceInput_1 = null;
            for (org.talend.components.api.component.Connector currentConnector : props_tSalesforceInput_1.getAvailableConnectors(null, true)) {
                if (currentConnector.getName().equals("MAIN")) {
                    c_tSalesforceInput_1 = currentConnector;
                }

                if (currentConnector.getName().equals("REJECT")) {//it's better to move the code to javajet
                    multi_output_is_allowed_tSalesforceInput_1 = true;
                }
            }
            org.apache.avro.Schema schema_tSalesforceInput_1 = props_tSalesforceInput_1.getSchema(c_tSalesforceInput_1, true);

        org.talend.codegen.enforcer.OutgoingSchemaEnforcer outgoingEnforcer_tSalesforceInput_1 = org.talend.codegen.enforcer.EnforcerCreator.createOutgoingEnforcer(schema_tSalesforceInput_1, false);

        // Create a reusable factory that converts the output of the reader to an IndexedRecord.
        org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord> factory_tSalesforceInput_1 = null;

        // Iterate through the incoming data.
        boolean available_tSalesforceInput_1 = reader_tSalesforceInput_1.start();

        resourceMap.put("reader_tSalesforceInput_1", reader_tSalesforceInput_1);

        for (; available_tSalesforceInput_1; available_tSalesforceInput_1 = reader_tSalesforceInput_1.advance()) {
			nb_line_tSalesforceInput_1++;

			
			if (multi_output_is_allowed_tSalesforceInput_1) {
				
					row1 = null;
				

				
			}
			

			try {
				Object data_tSalesforceInput_1 = reader_tSalesforceInput_1.getCurrent();
				

					if(multi_output_is_allowed_tSalesforceInput_1) {
						row1 = new row1Struct();
					}

					
        // Construct the factory once when the first data arrives.
        if (factory_tSalesforceInput_1 == null) {
            factory_tSalesforceInput_1 = (org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord>)
                    new org.talend.daikon.avro.AvroRegistry()
                            .createIndexedRecordConverter(data_tSalesforceInput_1.getClass());
        }

        // Enforce the outgoing schema on the input.
        outgoingEnforcer_tSalesforceInput_1.setWrapped(factory_tSalesforceInput_1.convertToAvro(data_tSalesforceInput_1));
                Object columnValue_0_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(0);
                        row1.Id = (String) (columnValue_0_tSalesforceInput_1);
                Object columnValue_1_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(1);
                        row1.OwnerId = (String) (columnValue_1_tSalesforceInput_1);
                Object columnValue_2_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(2);
                    if (columnValue_2_tSalesforceInput_1 == null) {
                        row1.IsDeleted = false;
                    } else {
                            row1.IsDeleted = (boolean) (columnValue_2_tSalesforceInput_1);
                    }
                Object columnValue_3_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(3);
                        row1.Name = (String) (columnValue_3_tSalesforceInput_1);
                Object columnValue_4_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(4);
                        row1.CreatedDate = (java.util.Date) (columnValue_4_tSalesforceInput_1);
                Object columnValue_5_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(5);
                        row1.CreatedById = (String) (columnValue_5_tSalesforceInput_1);
                Object columnValue_6_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(6);
                        row1.LastModifiedDate = (java.util.Date) (columnValue_6_tSalesforceInput_1);
                Object columnValue_7_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(7);
                        row1.LastModifiedById = (String) (columnValue_7_tSalesforceInput_1);
                Object columnValue_8_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(8);
                        row1.SystemModstamp = (java.util.Date) (columnValue_8_tSalesforceInput_1);
                Object columnValue_9_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(9);
                        row1.LastViewedDate = (java.util.Date) (columnValue_9_tSalesforceInput_1);
                Object columnValue_10_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(10);
                        row1.LastReferencedDate = (java.util.Date) (columnValue_10_tSalesforceInput_1);
                Object columnValue_11_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(11);
                    if (columnValue_11_tSalesforceInput_1 == null) {
                        row1.Is_Modified__c = false;
                    } else {
                            row1.Is_Modified__c = (boolean) (columnValue_11_tSalesforceInput_1);
                    }
                Object columnValue_12_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(12);
                        row1.RL_Additional_quantity__c = (Double) (columnValue_12_tSalesforceInput_1);
                Object columnValue_13_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(13);
                        row1.RL_Day__c = (String) (columnValue_13_tSalesforceInput_1);
                Object columnValue_14_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(14);
                        row1.RL_Delivery_postal_codes__c = (String) (columnValue_14_tSalesforceInput_1);
                Object columnValue_15_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(15);
                        row1.RL_External_Service_Detail_Id__c = (Double) (columnValue_15_tSalesforceInput_1);
                Object columnValue_16_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(16);
                        row1.RL_External_id__c = (Double) (columnValue_16_tSalesforceInput_1);
                Object columnValue_17_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(17);
                    if (columnValue_17_tSalesforceInput_1 == null) {
                        row1.RL_Is_Deleted__c = false;
                    } else {
                            row1.RL_Is_Deleted__c = (boolean) (columnValue_17_tSalesforceInput_1);
                    }
                Object columnValue_18_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(18);
                        row1.RL_Price__c = (BigDecimal) (columnValue_18_tSalesforceInput_1);
                Object columnValue_19_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(19);
                        row1.RL_Recovery_postal_codes__c = (String) (columnValue_19_tSalesforceInput_1);
                Object columnValue_20_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(20);
                        row1.RL_Scale_max__c = (Double) (columnValue_20_tSalesforceInput_1);
                Object columnValue_21_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(21);
                        row1.RL_Scale_min__c = (Double) (columnValue_21_tSalesforceInput_1);
                Object columnValue_22_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(22);
                        row1.RL_Service_Detail__c = (String) (columnValue_22_tSalesforceInput_1);
                Object columnValue_23_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(23);
                        row1.RL_Unit__c = (Double) (columnValue_23_tSalesforceInput_1);
                Object columnValue_24_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(24);
                        row1.RL_Round_Name__c = (String) (columnValue_24_tSalesforceInput_1);
                Object columnValue_25_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(25);
                        row1.RL_MAD_Round_Index__c = (Double) (columnValue_25_tSalesforceInput_1);
                Object columnValue_26_tSalesforceInput_1 = outgoingEnforcer_tSalesforceInput_1.get(26);
                    if (columnValue_26_tSalesforceInput_1 == null) {
                        row1.RL_Is_Archived__c = false;
                    } else {
                            row1.RL_Is_Archived__c = (boolean) (columnValue_26_tSalesforceInput_1);
                    }
			} catch (org.talend.components.api.exception.DataRejectException e_tSalesforceInput_1) {
				java.util.Map<String,Object> info_tSalesforceInput_1 = e_tSalesforceInput_1.getRejectInfo();
				
					//TODO use a method instead of getting method by the special key "error/errorMessage"
					Object errorMessage_tSalesforceInput_1 = null;
					if(info_tSalesforceInput_1.containsKey("error")){
						errorMessage_tSalesforceInput_1 = info_tSalesforceInput_1.get("error");
					}else if(info_tSalesforceInput_1.containsKey("errorMessage")){
						errorMessage_tSalesforceInput_1 = info_tSalesforceInput_1.get("errorMessage");
					}else{
						errorMessage_tSalesforceInput_1 = "Rejected but error message missing";
					}
					errorMessage_tSalesforceInput_1 = "Row "+ nb_line_tSalesforceInput_1 + ": "+errorMessage_tSalesforceInput_1;
					System.err.println(errorMessage_tSalesforceInput_1);
				
					// If the record is reject, the main line record should put NULL
					row1 = null;
				
			} // end of catch

                java.lang.Iterable<?> outgoingMainRecordsList_tSalesforceInput_1 = new java.util.ArrayList<Object>();
                java.util.Iterator outgoingMainRecordsIt_tSalesforceInput_1 = null;


 



/**
 * [tSalesforceInput_1 begin ] stop
 */
	
	/**
	 * [tSalesforceInput_1 main ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		


 


	tos_count_tSalesforceInput_1++;

/**
 * [tSalesforceInput_1 main ] stop
 */
	
	/**
	 * [tSalesforceInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		


 



/**
 * [tSalesforceInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tConvertType_1 main ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tSalesforceInput_1","RL_Pricing__c","tSalesforceInput","tConvertType_1","tConvertType_1","tConvertType"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


  row3 = new row3Struct();
  boolean bHasError_tConvertType_1 = false;             
          try {
              if ("".equals(row1.Id)){  
                row1.Id = null;
              }
              row3.Id=TypeConvert.String2String(row1.Id);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.OwnerId)){  
                row1.OwnerId = null;
              }
              row3.OwnerId=TypeConvert.String2String(row1.OwnerId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.IsDeleted=TypeConvert.boolean2boolean(row1.IsDeleted);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.Name)){  
                row1.Name = null;
              }
              row3.Name=TypeConvert.String2String(row1.Name);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.CreatedDate=TypeConvert.Date2String(row1.CreatedDate, "yyyy-MM-dd'T'HH:mm:ss'.000Z'");
        	            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.CreatedById)){  
                row1.CreatedById = null;
              }
              row3.CreatedById=TypeConvert.String2String(row1.CreatedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastModifiedDate=TypeConvert.Date2Date(row1.LastModifiedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.LastModifiedById)){  
                row1.LastModifiedById = null;
              }
              row3.LastModifiedById=TypeConvert.String2String(row1.LastModifiedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.SystemModstamp=TypeConvert.Date2Date(row1.SystemModstamp);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastViewedDate=TypeConvert.Date2Date(row1.LastViewedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.LastReferencedDate=TypeConvert.Date2Date(row1.LastReferencedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.Is_Modified__c=TypeConvert.boolean2boolean(row1.Is_Modified__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Additional_quantity__c=TypeConvert.Double2Float(row1.RL_Additional_quantity__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Day__c)){  
                row1.RL_Day__c = null;
              }
              row3.RL_Day__c=TypeConvert.String2String(row1.RL_Day__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Delivery_postal_codes__c)){  
                row1.RL_Delivery_postal_codes__c = null;
              }
              row3.RL_Delivery_postal_codes__c=TypeConvert.String2String(row1.RL_Delivery_postal_codes__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_External_Service_Detail_Id__c=TypeConvert.Double2Integer(row1.RL_External_Service_Detail_Id__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_External_id__c=TypeConvert.Double2Integer(row1.RL_External_id__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Is_Deleted__c=TypeConvert.boolean2boolean(row1.RL_Is_Deleted__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Price__c=TypeConvert.BigDecimal2Float(row1.RL_Price__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Recovery_postal_codes__c)){  
                row1.RL_Recovery_postal_codes__c = null;
              }
              row3.RL_Recovery_postal_codes__c=TypeConvert.String2String(row1.RL_Recovery_postal_codes__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Scale_max__c=TypeConvert.Double2Float(row1.RL_Scale_max__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Scale_min__c=TypeConvert.Double2Float(row1.RL_Scale_min__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Service_Detail__c)){  
                row1.RL_Service_Detail__c = null;
              }
              row3.RL_Service_Detail__c=TypeConvert.String2String(row1.RL_Service_Detail__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Unit__c=TypeConvert.Double2Float(row1.RL_Unit__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row1.RL_Round_Name__c)){  
                row1.RL_Round_Name__c = null;
              }
              row3.RL_Round_Name__c=TypeConvert.String2String(row1.RL_Round_Name__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_MAD_Round_Index__c=TypeConvert.Double2Integer(row1.RL_MAD_Round_Index__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row3.RL_Is_Archived__c=TypeConvert.boolean2boolean(row1.RL_Is_Archived__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_1) {row3 = null;}

  nb_line_tConvertType_1 ++ ;

 


	tos_count_tConvertType_1++;

/**
 * [tConvertType_1 main ] stop
 */
	
	/**
	 * [tConvertType_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tFilterRow_11 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tConvertType_1","tConvertType_1","tConvertType","tFilterRow_11","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

          row4 = null;
    Operator_tFilterRow_11 ope_tFilterRow_11 = new Operator_tFilterRow_11("&&");
	        ope_tFilterRow_11.matches((row3.RL_External_id__c != null)
	                       , "RL_External_id__c!=null failed");
	        ope_tFilterRow_11.matches((row3.RL_External_Service_Detail_Id__c != null)
	                       , "RL_External_Service_Detail_Id__c!=null failed");
    
    if (ope_tFilterRow_11.getMatchFlag()) {
              if(row4 == null){ 
                row4 = new row4Struct();
              }
               row4.Id = row3.Id;
               row4.OwnerId = row3.OwnerId;
               row4.IsDeleted = row3.IsDeleted;
               row4.Name = row3.Name;
               row4.CreatedDate = row3.CreatedDate;
               row4.CreatedById = row3.CreatedById;
               row4.LastModifiedDate = row3.LastModifiedDate;
               row4.LastModifiedById = row3.LastModifiedById;
               row4.SystemModstamp = row3.SystemModstamp;
               row4.LastViewedDate = row3.LastViewedDate;
               row4.LastReferencedDate = row3.LastReferencedDate;
               row4.Is_Modified__c = row3.Is_Modified__c;
               row4.RL_Additional_quantity__c = row3.RL_Additional_quantity__c;
               row4.RL_Day__c = row3.RL_Day__c;
               row4.RL_Delivery_postal_codes__c = row3.RL_Delivery_postal_codes__c;
               row4.RL_External_Service_Detail_Id__c = row3.RL_External_Service_Detail_Id__c;
               row4.RL_External_id__c = row3.RL_External_id__c;
               row4.RL_Is_Deleted__c = row3.RL_Is_Deleted__c;
               row4.RL_Price__c = row3.RL_Price__c;
               row4.RL_Recovery_postal_codes__c = row3.RL_Recovery_postal_codes__c;
               row4.RL_Scale_max__c = row3.RL_Scale_max__c;
               row4.RL_Scale_min__c = row3.RL_Scale_min__c;
               row4.RL_Service_Detail__c = row3.RL_Service_Detail__c;
               row4.RL_Unit__c = row3.RL_Unit__c;
               row4.RL_Round_Name__c = row3.RL_Round_Name__c;
               row4.RL_MAD_Round_Index__c = row3.RL_MAD_Round_Index__c;
               row4.RL_Is_Archived__c = row3.RL_Is_Archived__c;
					log.debug("tFilterRow_11 - Process the record " + (nb_line_tFilterRow_11+1) + ".");
					    
      nb_line_ok_tFilterRow_11++;
    } else {
      nb_line_reject_tFilterRow_11++;
    }

nb_line_tFilterRow_11++;

 


	tos_count_tFilterRow_11++;

/**
 * [tFilterRow_11 main ] stop
 */
	
	/**
	 * [tFilterRow_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tFilterRow_11","tFilterRow_1","tFilterRow","tUniqRow_1","tUniqRow_1","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		
row7.Id = row4.Id;			row7.OwnerId = row4.OwnerId;			row7.IsDeleted = row4.IsDeleted;			row7.Name = row4.Name;			row7.CreatedDate = row4.CreatedDate;			row7.CreatedById = row4.CreatedById;			row7.LastModifiedDate = row4.LastModifiedDate;			row7.LastModifiedById = row4.LastModifiedById;			row7.SystemModstamp = row4.SystemModstamp;			row7.LastViewedDate = row4.LastViewedDate;			row7.LastReferencedDate = row4.LastReferencedDate;			row7.Is_Modified__c = row4.Is_Modified__c;			row7.RL_Additional_quantity__c = row4.RL_Additional_quantity__c;			row7.RL_Day__c = row4.RL_Day__c;			row7.RL_Delivery_postal_codes__c = row4.RL_Delivery_postal_codes__c;			row7.RL_External_Service_Detail_Id__c = row4.RL_External_Service_Detail_Id__c;			row7.RL_External_id__c = row4.RL_External_id__c;			row7.RL_Is_Deleted__c = row4.RL_Is_Deleted__c;			row7.RL_Price__c = row4.RL_Price__c;			row7.RL_Recovery_postal_codes__c = row4.RL_Recovery_postal_codes__c;			row7.RL_Scale_max__c = row4.RL_Scale_max__c;			row7.RL_Scale_min__c = row4.RL_Scale_min__c;			row7.RL_Service_Detail__c = row4.RL_Service_Detail__c;			row7.RL_Unit__c = row4.RL_Unit__c;			row7.RL_Round_Name__c = row4.RL_Round_Name__c;			row7.RL_MAD_Round_Index__c = row4.RL_MAD_Round_Index__c;			row7.RL_Is_Archived__c = row4.RL_Is_Archived__c;			

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tUniqRow_1","tUniqRow_1","tUniqRow","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
						row8Struct row8 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row8" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow8 = false;
       		  	    	
       		  	    	
 							row8Struct row8ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row8HashKey.RL_External_id__c = row7.RL_External_Service_Detail_Id__c;
                        		    		

								
		                        	row8HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row8.lookup( row8HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row8.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row8 != null && tHash_Lookup_row8.getCount(row8HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row8' and it contains more one result from keys :  row8.RL_External_id__c = '" + row8HashKey.RL_External_id__c + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row8Struct fromLookup_row8 = null;
							row8 = row8Default;
										 
							
								 
							
							
								if (tHash_Lookup_row8 !=null && tHash_Lookup_row8.hasNext()) { // G 099
								
							
								
								fromLookup_row8 = tHash_Lookup_row8.next();

							
							
								} // G 099
							
							

							if(fromLookup_row8 != null) {
								row8 = fromLookup_row8;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;
Var.var1 = row7.CreatedDate != null ? row7.CreatedDate.split("T")[0]+row7.CreatedDate.split("T")[1] : "2024-01-0100:00:00" ;// ###############################
        // ###############################
        // # Output tables

pricing = null;

if(!rejectedInnerJoin_tMap_1 ) {

// # Output table : 'pricing'
count_pricing_tMap_1++;

pricing_tmp.id = row7.RL_External_id__c ;
pricing_tmp.id_detail = row8.RL_External_id__c ;
pricing_tmp.day = row7.RL_Day__c ;
pricing_tmp.price = row7.RL_Price__c ;
pricing_tmp.unit_specification = row7.RL_Unit__c ;
pricing_tmp.scale_min = row7.RL_Scale_min__c ;
pricing_tmp.scale_max = row7.RL_Scale_max__c ;
pricing_tmp.additional_quantity = row7.RL_Additional_quantity__c ;
pricing_tmp.delivery_postal_code = row7.RL_Delivery_postal_codes__c != null ? (row7.RL_Delivery_postal_codes__c.equals("All") ? "NoPostalCode" : row7.RL_Delivery_postal_codes__c) : null ;
pricing_tmp.recovery_postal_code = row7.RL_Recovery_postal_codes__c != null ?(row7.RL_Recovery_postal_codes__c.equals("All") ? "NoPostalCode" : row7.RL_Recovery_postal_codes__c) : null ;
pricing_tmp.round_name = row7.RL_Round_Name__c ;
pricing_tmp.madRoundIndex = row7.RL_MAD_Round_Index__c ;
pricing_tmp.created_at = TalendDate.parseDate("yyyy-MM-ddHH:mm:ss",Var.var1) ;
pricing_tmp.updated_at = TalendDate.getCurrentDate();
pricing_tmp.id_salesforce = row7.Id ;
pricing_tmp.is_activated = (row8.RL_Is_Active__c   == false) ? 0 : 1 ;
pricing_tmp.is_archived = (row7.RL_Is_Archived__c    == false) ? 0 : 1 ;
pricing = pricing_tmp;
log.debug("tMap_1 - Outputting the record " + count_pricing_tMap_1 + " of the output table 'pricing'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "pricing"
if(pricing != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pricing","tMap_1","tMap_1","tMap","tDBOutput_1","tDBOutput_1","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pricing - " + (pricing==null? "": pricing.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, pricing.id);

                    pstmt_tDBOutput_1.setInt(2, pricing.id_detail);

                    if(pricing.day == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, pricing.day);
}

                    pstmt_tDBOutput_1.setFloat(4, pricing.price);

                    if(pricing.unit_specification == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(5, pricing.unit_specification);
}

                    if(pricing.scale_min == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(6, pricing.scale_min);
}

                    if(pricing.scale_max == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(7, pricing.scale_max);
}

                    if(pricing.additional_quantity == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(8, pricing.additional_quantity);
}

                    if(pricing.delivery_postal_code == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, pricing.delivery_postal_code);
}

                    if(pricing.recovery_postal_code == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, pricing.recovery_postal_code);
}

                    if(pricing.round_name == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, pricing.round_name);
}

                    if(pricing.madRoundIndex == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(12, pricing.madRoundIndex);
}

                    if(pricing.created_at != null) {
date_tDBOutput_1 = pricing.created_at.getTime();
if(date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
pstmt_tDBOutput_1.setString(13, "0000-00-00 00:00:00");
} else {pstmt_tDBOutput_1.setTimestamp(13, new java.sql.Timestamp(date_tDBOutput_1));
}
} else {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.DATE);
}

                    if(pricing.updated_at != null) {
date_tDBOutput_1 = pricing.updated_at.getTime();
if(date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
pstmt_tDBOutput_1.setString(14, "0000-00-00 00:00:00");
} else {pstmt_tDBOutput_1.setTimestamp(14, new java.sql.Timestamp(date_tDBOutput_1));
}
} else {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.DATE);
}

                    if(pricing.id_salesforce == null) {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(15, pricing.id_salesforce);
}

                    pstmt_tDBOutput_1.setInt(16, pricing.is_activated);

                    pstmt_tDBOutput_1.setInt(17, pricing.is_archived);

                    pstmt_tDBOutput_1.setInt(18 + count_tDBOutput_1, pricing.id_detail);

                    if(pricing.day == null) {
pstmt_tDBOutput_1.setNull(19 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(19 + count_tDBOutput_1, pricing.day);
}

                    pstmt_tDBOutput_1.setFloat(20 + count_tDBOutput_1, pricing.price);

                    if(pricing.unit_specification == null) {
pstmt_tDBOutput_1.setNull(21 + count_tDBOutput_1, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(21 + count_tDBOutput_1, pricing.unit_specification);
}

                    if(pricing.scale_min == null) {
pstmt_tDBOutput_1.setNull(22 + count_tDBOutput_1, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(22 + count_tDBOutput_1, pricing.scale_min);
}

                    if(pricing.scale_max == null) {
pstmt_tDBOutput_1.setNull(23 + count_tDBOutput_1, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(23 + count_tDBOutput_1, pricing.scale_max);
}

                    if(pricing.additional_quantity == null) {
pstmt_tDBOutput_1.setNull(24 + count_tDBOutput_1, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(24 + count_tDBOutput_1, pricing.additional_quantity);
}

                    if(pricing.delivery_postal_code == null) {
pstmt_tDBOutput_1.setNull(25 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(25 + count_tDBOutput_1, pricing.delivery_postal_code);
}

                    if(pricing.recovery_postal_code == null) {
pstmt_tDBOutput_1.setNull(26 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(26 + count_tDBOutput_1, pricing.recovery_postal_code);
}

                    if(pricing.round_name == null) {
pstmt_tDBOutput_1.setNull(27 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(27 + count_tDBOutput_1, pricing.round_name);
}

                    if(pricing.madRoundIndex == null) {
pstmt_tDBOutput_1.setNull(28 + count_tDBOutput_1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(28 + count_tDBOutput_1, pricing.madRoundIndex);
}

                    if(pricing.created_at != null) {
pstmt_tDBOutput_1.setTimestamp(29 + count_tDBOutput_1, new java.sql.Timestamp(pricing.created_at.getTime()));
} else {
pstmt_tDBOutput_1.setNull(29 + count_tDBOutput_1, java.sql.Types.TIMESTAMP);
}

                    if(pricing.updated_at != null) {
pstmt_tDBOutput_1.setTimestamp(30 + count_tDBOutput_1, new java.sql.Timestamp(pricing.updated_at.getTime()));
} else {
pstmt_tDBOutput_1.setNull(30 + count_tDBOutput_1, java.sql.Types.TIMESTAMP);
}

                    if(pricing.id_salesforce == null) {
pstmt_tDBOutput_1.setNull(31 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(31 + count_tDBOutput_1, pricing.id_salesforce);
}

                    pstmt_tDBOutput_1.setInt(32 + count_tDBOutput_1, pricing.is_activated);

                    pstmt_tDBOutput_1.setInt(33 + count_tDBOutput_1, pricing.is_archived);

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "pricing"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */

} // End of branch "row4"




	
	/**
	 * [tFilterRow_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tConvertType_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_end ] stop
 */



	
	/**
	 * [tSalesforceInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		


 



/**
 * [tSalesforceInput_1 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceInput_1 end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		
// end of generic


resourceMap.put("finish_tSalesforceInput_1", Boolean.TRUE);

    } // while  
    } // end of "if (sourceOrSink_tSalesforceInput_1 instanceof ...Source)"
    java.util.Map<String, Object> resultMap_tSalesforceInput_1 = null;
    if (reader_tSalesforceInput_1 != null) {
        reader_tSalesforceInput_1.close();
        resultMap_tSalesforceInput_1 = reader_tSalesforceInput_1.getReturnValues();
    }
if(resultMap_tSalesforceInput_1!=null) {
	for(java.util.Map.Entry<String,Object> entry_tSalesforceInput_1 : resultMap_tSalesforceInput_1.entrySet()) {
		switch(entry_tSalesforceInput_1.getKey()) {
		case org.talend.components.api.component.ComponentDefinition.RETURN_ERROR_MESSAGE :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "ERROR_MESSAGE", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_TOTAL_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_LINE", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_SUCCESS_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_SUCCESS", entry_tSalesforceInput_1.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_REJECT_RECORD_COUNT :
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", "NB_REJECT", entry_tSalesforceInput_1.getValue());
			break;
		default :
            StringBuilder studio_key_tSalesforceInput_1 = new StringBuilder();
            for (int i_tSalesforceInput_1 = 0; i_tSalesforceInput_1 < entry_tSalesforceInput_1.getKey().length(); i_tSalesforceInput_1++) {
                char ch_tSalesforceInput_1 = entry_tSalesforceInput_1.getKey().charAt(i_tSalesforceInput_1);
                if(Character.isUpperCase(ch_tSalesforceInput_1) && i_tSalesforceInput_1> 0) {
                	studio_key_tSalesforceInput_1.append('_');
                }
                studio_key_tSalesforceInput_1.append(ch_tSalesforceInput_1);
            }
			container_tSalesforceInput_1.setComponentData("tSalesforceInput_1", studio_key_tSalesforceInput_1.toString().toUpperCase(java.util.Locale.ENGLISH), entry_tSalesforceInput_1.getValue());
			break;
		}
	}
}

 

ok_Hash.put("tSalesforceInput_1", true);
end_Hash.put("tSalesforceInput_1", System.currentTimeMillis());




/**
 * [tSalesforceInput_1 end ] stop
 */

	
	/**
	 * [tConvertType_1 end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
      globalMap.put("tConvertType_1_NB_LINE", nb_line_tConvertType_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tSalesforceInput_1","RL_Pricing__c","tSalesforceInput","tConvertType_1","tConvertType_1","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_1", true);
end_Hash.put("tConvertType_1", System.currentTimeMillis());




/**
 * [tConvertType_1 end ] stop
 */

	
	/**
	 * [tFilterRow_11 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	
    globalMap.put("tFilterRow_11_NB_LINE", nb_line_tFilterRow_11);
    globalMap.put("tFilterRow_11_NB_LINE_OK", nb_line_ok_tFilterRow_11);
    globalMap.put("tFilterRow_11_NB_LINE_REJECT", nb_line_reject_tFilterRow_11);
    
    	log.info("tFilterRow_11 - Processed records count:" + nb_line_tFilterRow_11 + ". Matched records count:" + nb_line_ok_tFilterRow_11 + ". Rejected records count:" + nb_line_reject_tFilterRow_11 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tConvertType_1","tConvertType_1","tConvertType","tFilterRow_11","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_11 - "  + ("Done.") );

ok_Hash.put("tFilterRow_11", true);
end_Hash.put("tFilterRow_11", System.currentTimeMillis());




/**
 * [tFilterRow_11 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);
	log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1)+" .");
	log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tFilterRow_11","tFilterRow_1","tFilterRow","tUniqRow_1","tUniqRow_1","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Done.") );

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());




/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row8 != null) {
						tHash_Lookup_row8.endGet();
					}
					globalMap.remove( "tHash_Lookup_row8" );

					
					
				
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'pricing': " + count_pricing_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tUniqRow_1","tUniqRow_1","tUniqRow","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pricing",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","tDBOutput_1","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row8"); 
				     			
				try{
					
	
	/**
	 * [tSalesforceInput_1 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_1";
	
	
			cLabel="RL_Pricing__c";
		
// finally of generic


if(resourceMap.get("finish_tSalesforceInput_1")==null){
    if(resourceMap.get("reader_tSalesforceInput_1")!=null){
		try {
			((org.talend.components.api.component.runtime.Reader)resourceMap.get("reader_tSalesforceInput_1")).close();
		} catch (java.io.IOException e_tSalesforceInput_1) {
			String errorMessage_tSalesforceInput_1 = "failed to release the resource in tSalesforceInput_1 :" + e_tSalesforceInput_1.getMessage();
			System.err.println(errorMessage_tSalesforceInput_1);
		}
	}
}
 



/**
 * [tSalesforceInput_1 finally ] stop
 */

	
	/**
	 * [tConvertType_1 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_11 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_11";
	
	

 



/**
 * [tFilterRow_11 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableComparableLookupRow<row8Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.RL_External_id__c == null) ? 0 : this.RL_External_id__c.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.RL_External_id__c == null) {
							if (other.RL_External_id__c != null)
								return false;
						
						} else if (!this.RL_External_id__c.equals(other.RL_External_id__c))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.Id = this.Id;
	            other.OwnerId = this.OwnerId;
	            other.IsDeleted = this.IsDeleted;
	            other.Name = this.Name;
	            other.CreatedDate = this.CreatedDate;
	            other.CreatedById = this.CreatedById;
	            other.LastModifiedDate = this.LastModifiedDate;
	            other.LastModifiedById = this.LastModifiedById;
	            other.SystemModstamp = this.SystemModstamp;
	            other.LastViewedDate = this.LastViewedDate;
	            other.LastReferencedDate = this.LastReferencedDate;
	            other.Is_Modified__c = this.Is_Modified__c;
	            other.RL_Billing_type__c = this.RL_Billing_type__c;
	            other.RL_Category__c = this.RL_Category__c;
	            other.RL_Client__c = this.RL_Client__c;
	            other.RL_External_id__c = this.RL_External_id__c;
	            other.RL_Is_Deleted__c = this.RL_Is_Deleted__c;
	            other.RL_Service__c = this.RL_Service__c;
	            other.RL_Sub_category__c = this.RL_Sub_category__c;
	            other.RL_Unit__c = this.RL_Unit__c;
	            other.RL_Is_Active__c = this.RL_Is_Active__c;
	            other.RL_Vehicle__c = this.RL_Vehicle__c;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.RL_External_id__c = this.RL_External_id__c;
	            	
	}



	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

	private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller ) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

	private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
	}
	
	private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
	}
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
						this.RL_External_id__c = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
						this.RL_External_id__c = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.Id = readString(dis,ois);
					
						this.OwnerId = readString(dis,ois);
					
			            this.IsDeleted = dis.readBoolean();
					
						this.Name = readString(dis,ois);
					
						this.CreatedDate = readDate(dis,ois);
					
						this.CreatedById = readString(dis,ois);
					
						this.LastModifiedDate = readDate(dis,ois);
					
						this.LastModifiedById = readString(dis,ois);
					
						this.SystemModstamp = readDate(dis,ois);
					
						this.LastViewedDate = readDate(dis,ois);
					
						this.LastReferencedDate = readDate(dis,ois);
					
			            this.Is_Modified__c = dis.readBoolean();
					
						this.RL_Billing_type__c = readString(dis,ois);
					
						this.RL_Category__c = readString(dis,ois);
					
						this.RL_Client__c = readString(dis,ois);
					
			            this.RL_Is_Deleted__c = dis.readBoolean();
					
						this.RL_Service__c = readString(dis,ois);
					
						this.RL_Sub_category__c = readString(dis,ois);
					
						this.RL_Unit__c = readString(dis,ois);
					
			            this.RL_Is_Active__c = dis.readBoolean();
					
						this.RL_Vehicle__c = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.Id = readString(dis,objectIn);
					
						this.OwnerId = readString(dis,objectIn);
					
			            this.IsDeleted = objectIn.readBoolean();
					
						this.Name = readString(dis,objectIn);
					
						this.CreatedDate = readDate(dis,objectIn);
					
						this.CreatedById = readString(dis,objectIn);
					
						this.LastModifiedDate = readDate(dis,objectIn);
					
						this.LastModifiedById = readString(dis,objectIn);
					
						this.SystemModstamp = readDate(dis,objectIn);
					
						this.LastViewedDate = readDate(dis,objectIn);
					
						this.LastReferencedDate = readDate(dis,objectIn);
					
			            this.Is_Modified__c = objectIn.readBoolean();
					
						this.RL_Billing_type__c = readString(dis,objectIn);
					
						this.RL_Category__c = readString(dis,objectIn);
					
						this.RL_Client__c = readString(dis,objectIn);
					
			            this.RL_Is_Deleted__c = objectIn.readBoolean();
					
						this.RL_Service__c = readString(dis,objectIn);
					
						this.RL_Sub_category__c = readString(dis,objectIn);
					
						this.RL_Unit__c = readString(dis,objectIn);
					
			            this.RL_Is_Active__c = objectIn.readBoolean();
					
						this.RL_Vehicle__c = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.Id, dos, oos);
					
						writeString(this.OwnerId, dos, oos);
					
		            	dos.writeBoolean(this.IsDeleted);
					
						writeString(this.Name, dos, oos);
					
						writeDate(this.CreatedDate, dos, oos);
					
						writeString(this.CreatedById, dos, oos);
					
						writeDate(this.LastModifiedDate, dos, oos);
					
						writeString(this.LastModifiedById, dos, oos);
					
						writeDate(this.SystemModstamp, dos, oos);
					
						writeDate(this.LastViewedDate, dos, oos);
					
						writeDate(this.LastReferencedDate, dos, oos);
					
		            	dos.writeBoolean(this.Is_Modified__c);
					
						writeString(this.RL_Billing_type__c, dos, oos);
					
						writeString(this.RL_Category__c, dos, oos);
					
						writeString(this.RL_Client__c, dos, oos);
					
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
						writeString(this.RL_Service__c, dos, oos);
					
						writeString(this.RL_Sub_category__c, dos, oos);
					
						writeString(this.RL_Unit__c, dos, oos);
					
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
						writeString(this.RL_Vehicle__c, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.Id, dos, objectOut);
					
						writeString(this.OwnerId, dos, objectOut);
					
					objectOut.writeBoolean(this.IsDeleted);
					
						writeString(this.Name, dos, objectOut);
					
						writeDate(this.CreatedDate, dos, objectOut);
					
						writeString(this.CreatedById, dos, objectOut);
					
						writeDate(this.LastModifiedDate, dos, objectOut);
					
						writeString(this.LastModifiedById, dos, objectOut);
					
						writeDate(this.SystemModstamp, dos, objectOut);
					
						writeDate(this.LastViewedDate, dos, objectOut);
					
						writeDate(this.LastReferencedDate, dos, objectOut);
					
					objectOut.writeBoolean(this.Is_Modified__c);
					
						writeString(this.RL_Billing_type__c, dos, objectOut);
					
						writeString(this.RL_Category__c, dos, objectOut);
					
						writeString(this.RL_Client__c, dos, objectOut);
					
					objectOut.writeBoolean(this.RL_Is_Deleted__c);
					
						writeString(this.RL_Service__c, dos, objectOut);
					
						writeString(this.RL_Sub_category__c, dos, objectOut);
					
						writeString(this.RL_Unit__c, dos, objectOut);
					
					objectOut.writeBoolean(this.RL_Is_Active__c);
					
						writeString(this.RL_Vehicle__c, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.RL_External_id__c, other.RL_External_id__c);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Integer RL_External_id__c;

				public Integer getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
						this.RL_External_id__c = readInteger(dis);
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Integer
				
						writeInteger(this.RL_External_id__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[0];

	
			    public String Id;

				public String getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return false;
				}
				public Integer IdLength(){
				    return 18;
				}
				public Integer IdPrecision(){
				    return null;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public String OwnerId;

				public String getOwnerId () {
					return this.OwnerId;
				}

				public Boolean OwnerIdIsNullable(){
				    return false;
				}
				public Boolean OwnerIdIsKey(){
				    return false;
				}
				public Integer OwnerIdLength(){
				    return 18;
				}
				public Integer OwnerIdPrecision(){
				    return null;
				}
				public String OwnerIdDefault(){
				
					return null;
				
				}
				public String OwnerIdComment(){
				
				    return "";
				
				}
				public String OwnerIdPattern(){
				
					return "";
				
				}
				public String OwnerIdOriginalDbColumnName(){
				
					return "OwnerId";
				
				}

				
			    public boolean IsDeleted;

				public boolean getIsDeleted () {
					return this.IsDeleted;
				}

				public Boolean IsDeletedIsNullable(){
				    return false;
				}
				public Boolean IsDeletedIsKey(){
				    return false;
				}
				public Integer IsDeletedLength(){
				    return null;
				}
				public Integer IsDeletedPrecision(){
				    return null;
				}
				public String IsDeletedDefault(){
				
					return null;
				
				}
				public String IsDeletedComment(){
				
				    return "";
				
				}
				public String IsDeletedPattern(){
				
					return "";
				
				}
				public String IsDeletedOriginalDbColumnName(){
				
					return "IsDeleted";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 80;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return null;
				}
				public Integer CreatedDatePrecision(){
				    return null;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public String CreatedById;

				public String getCreatedById () {
					return this.CreatedById;
				}

				public Boolean CreatedByIdIsNullable(){
				    return false;
				}
				public Boolean CreatedByIdIsKey(){
				    return false;
				}
				public Integer CreatedByIdLength(){
				    return 18;
				}
				public Integer CreatedByIdPrecision(){
				    return null;
				}
				public String CreatedByIdDefault(){
				
					return null;
				
				}
				public String CreatedByIdComment(){
				
				    return "";
				
				}
				public String CreatedByIdPattern(){
				
					return "";
				
				}
				public String CreatedByIdOriginalDbColumnName(){
				
					return "CreatedById";
				
				}

				
			    public java.util.Date LastModifiedDate;

				public java.util.Date getLastModifiedDate () {
					return this.LastModifiedDate;
				}

				public Boolean LastModifiedDateIsNullable(){
				    return false;
				}
				public Boolean LastModifiedDateIsKey(){
				    return false;
				}
				public Integer LastModifiedDateLength(){
				    return null;
				}
				public Integer LastModifiedDatePrecision(){
				    return null;
				}
				public String LastModifiedDateDefault(){
				
					return null;
				
				}
				public String LastModifiedDateComment(){
				
				    return "";
				
				}
				public String LastModifiedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastModifiedDateOriginalDbColumnName(){
				
					return "LastModifiedDate";
				
				}

				
			    public String LastModifiedById;

				public String getLastModifiedById () {
					return this.LastModifiedById;
				}

				public Boolean LastModifiedByIdIsNullable(){
				    return false;
				}
				public Boolean LastModifiedByIdIsKey(){
				    return false;
				}
				public Integer LastModifiedByIdLength(){
				    return 18;
				}
				public Integer LastModifiedByIdPrecision(){
				    return null;
				}
				public String LastModifiedByIdDefault(){
				
					return null;
				
				}
				public String LastModifiedByIdComment(){
				
				    return "";
				
				}
				public String LastModifiedByIdPattern(){
				
					return "";
				
				}
				public String LastModifiedByIdOriginalDbColumnName(){
				
					return "LastModifiedById";
				
				}

				
			    public java.util.Date SystemModstamp;

				public java.util.Date getSystemModstamp () {
					return this.SystemModstamp;
				}

				public Boolean SystemModstampIsNullable(){
				    return false;
				}
				public Boolean SystemModstampIsKey(){
				    return false;
				}
				public Integer SystemModstampLength(){
				    return null;
				}
				public Integer SystemModstampPrecision(){
				    return null;
				}
				public String SystemModstampDefault(){
				
					return null;
				
				}
				public String SystemModstampComment(){
				
				    return "";
				
				}
				public String SystemModstampPattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String SystemModstampOriginalDbColumnName(){
				
					return "SystemModstamp";
				
				}

				
			    public java.util.Date LastViewedDate;

				public java.util.Date getLastViewedDate () {
					return this.LastViewedDate;
				}

				public Boolean LastViewedDateIsNullable(){
				    return true;
				}
				public Boolean LastViewedDateIsKey(){
				    return false;
				}
				public Integer LastViewedDateLength(){
				    return null;
				}
				public Integer LastViewedDatePrecision(){
				    return null;
				}
				public String LastViewedDateDefault(){
				
					return null;
				
				}
				public String LastViewedDateComment(){
				
				    return "";
				
				}
				public String LastViewedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastViewedDateOriginalDbColumnName(){
				
					return "LastViewedDate";
				
				}

				
			    public java.util.Date LastReferencedDate;

				public java.util.Date getLastReferencedDate () {
					return this.LastReferencedDate;
				}

				public Boolean LastReferencedDateIsNullable(){
				    return true;
				}
				public Boolean LastReferencedDateIsKey(){
				    return false;
				}
				public Integer LastReferencedDateLength(){
				    return null;
				}
				public Integer LastReferencedDatePrecision(){
				    return null;
				}
				public String LastReferencedDateDefault(){
				
					return null;
				
				}
				public String LastReferencedDateComment(){
				
				    return "";
				
				}
				public String LastReferencedDatePattern(){
				
					return "yyyy-MM-dd'T'HH:mm:ss'.000Z'";
				
				}
				public String LastReferencedDateOriginalDbColumnName(){
				
					return "LastReferencedDate";
				
				}

				
			    public boolean Is_Modified__c;

				public boolean getIs_Modified__c () {
					return this.Is_Modified__c;
				}

				public Boolean Is_Modified__cIsNullable(){
				    return false;
				}
				public Boolean Is_Modified__cIsKey(){
				    return false;
				}
				public Integer Is_Modified__cLength(){
				    return null;
				}
				public Integer Is_Modified__cPrecision(){
				    return null;
				}
				public String Is_Modified__cDefault(){
				
					return null;
				
				}
				public String Is_Modified__cComment(){
				
				    return "";
				
				}
				public String Is_Modified__cPattern(){
				
					return "";
				
				}
				public String Is_Modified__cOriginalDbColumnName(){
				
					return "Is_Modified__c";
				
				}

				
			    public String RL_Billing_type__c;

				public String getRL_Billing_type__c () {
					return this.RL_Billing_type__c;
				}

				public Boolean RL_Billing_type__cIsNullable(){
				    return false;
				}
				public Boolean RL_Billing_type__cIsKey(){
				    return false;
				}
				public Integer RL_Billing_type__cLength(){
				    return 255;
				}
				public Integer RL_Billing_type__cPrecision(){
				    return null;
				}
				public String RL_Billing_type__cDefault(){
				
					return null;
				
				}
				public String RL_Billing_type__cComment(){
				
				    return "";
				
				}
				public String RL_Billing_type__cPattern(){
				
					return "";
				
				}
				public String RL_Billing_type__cOriginalDbColumnName(){
				
					return "RL_Billing_type__c";
				
				}

				
			    public String RL_Category__c;

				public String getRL_Category__c () {
					return this.RL_Category__c;
				}

				public Boolean RL_Category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Category__cIsKey(){
				    return false;
				}
				public Integer RL_Category__cLength(){
				    return 255;
				}
				public Integer RL_Category__cPrecision(){
				    return null;
				}
				public String RL_Category__cDefault(){
				
					return null;
				
				}
				public String RL_Category__cComment(){
				
				    return "";
				
				}
				public String RL_Category__cPattern(){
				
					return "";
				
				}
				public String RL_Category__cOriginalDbColumnName(){
				
					return "RL_Category__c";
				
				}

				
			    public String RL_Client__c;

				public String getRL_Client__c () {
					return this.RL_Client__c;
				}

				public Boolean RL_Client__cIsNullable(){
				    return false;
				}
				public Boolean RL_Client__cIsKey(){
				    return false;
				}
				public Integer RL_Client__cLength(){
				    return 18;
				}
				public Integer RL_Client__cPrecision(){
				    return null;
				}
				public String RL_Client__cDefault(){
				
					return null;
				
				}
				public String RL_Client__cComment(){
				
				    return "";
				
				}
				public String RL_Client__cPattern(){
				
					return "";
				
				}
				public String RL_Client__cOriginalDbColumnName(){
				
					return "RL_Client__c";
				
				}

				
			    public Double RL_External_id__c;

				public Double getRL_External_id__c () {
					return this.RL_External_id__c;
				}

				public Boolean RL_External_id__cIsNullable(){
				    return true;
				}
				public Boolean RL_External_id__cIsKey(){
				    return false;
				}
				public Integer RL_External_id__cLength(){
				    return 16;
				}
				public Integer RL_External_id__cPrecision(){
				    return null;
				}
				public String RL_External_id__cDefault(){
				
					return null;
				
				}
				public String RL_External_id__cComment(){
				
				    return "";
				
				}
				public String RL_External_id__cPattern(){
				
					return "";
				
				}
				public String RL_External_id__cOriginalDbColumnName(){
				
					return "RL_External_id__c";
				
				}

				
			    public boolean RL_Is_Deleted__c;

				public boolean getRL_Is_Deleted__c () {
					return this.RL_Is_Deleted__c;
				}

				public Boolean RL_Is_Deleted__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Deleted__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Deleted__cLength(){
				    return null;
				}
				public Integer RL_Is_Deleted__cPrecision(){
				    return null;
				}
				public String RL_Is_Deleted__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Deleted__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Deleted__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Deleted__cOriginalDbColumnName(){
				
					return "RL_Is_Deleted__c";
				
				}

				
			    public String RL_Service__c;

				public String getRL_Service__c () {
					return this.RL_Service__c;
				}

				public Boolean RL_Service__cIsNullable(){
				    return false;
				}
				public Boolean RL_Service__cIsKey(){
				    return false;
				}
				public Integer RL_Service__cLength(){
				    return 255;
				}
				public Integer RL_Service__cPrecision(){
				    return null;
				}
				public String RL_Service__cDefault(){
				
					return null;
				
				}
				public String RL_Service__cComment(){
				
				    return "";
				
				}
				public String RL_Service__cPattern(){
				
					return "";
				
				}
				public String RL_Service__cOriginalDbColumnName(){
				
					return "RL_Service__c";
				
				}

				
			    public String RL_Sub_category__c;

				public String getRL_Sub_category__c () {
					return this.RL_Sub_category__c;
				}

				public Boolean RL_Sub_category__cIsNullable(){
				    return false;
				}
				public Boolean RL_Sub_category__cIsKey(){
				    return false;
				}
				public Integer RL_Sub_category__cLength(){
				    return 255;
				}
				public Integer RL_Sub_category__cPrecision(){
				    return null;
				}
				public String RL_Sub_category__cDefault(){
				
					return null;
				
				}
				public String RL_Sub_category__cComment(){
				
				    return "";
				
				}
				public String RL_Sub_category__cPattern(){
				
					return "";
				
				}
				public String RL_Sub_category__cOriginalDbColumnName(){
				
					return "RL_Sub_category__c";
				
				}

				
			    public String RL_Unit__c;

				public String getRL_Unit__c () {
					return this.RL_Unit__c;
				}

				public Boolean RL_Unit__cIsNullable(){
				    return false;
				}
				public Boolean RL_Unit__cIsKey(){
				    return false;
				}
				public Integer RL_Unit__cLength(){
				    return 255;
				}
				public Integer RL_Unit__cPrecision(){
				    return null;
				}
				public String RL_Unit__cDefault(){
				
					return null;
				
				}
				public String RL_Unit__cComment(){
				
				    return "";
				
				}
				public String RL_Unit__cPattern(){
				
					return "";
				
				}
				public String RL_Unit__cOriginalDbColumnName(){
				
					return "RL_Unit__c";
				
				}

				
			    public boolean RL_Is_Active__c;

				public boolean getRL_Is_Active__c () {
					return this.RL_Is_Active__c;
				}

				public Boolean RL_Is_Active__cIsNullable(){
				    return false;
				}
				public Boolean RL_Is_Active__cIsKey(){
				    return false;
				}
				public Integer RL_Is_Active__cLength(){
				    return null;
				}
				public Integer RL_Is_Active__cPrecision(){
				    return null;
				}
				public String RL_Is_Active__cDefault(){
				
					return null;
				
				}
				public String RL_Is_Active__cComment(){
				
				    return "";
				
				}
				public String RL_Is_Active__cPattern(){
				
					return "";
				
				}
				public String RL_Is_Active__cOriginalDbColumnName(){
				
					return "RL_Is_Active__c";
				
				}

				
			    public String RL_Vehicle__c;

				public String getRL_Vehicle__c () {
					return this.RL_Vehicle__c;
				}

				public Boolean RL_Vehicle__cIsNullable(){
				    return true;
				}
				public Boolean RL_Vehicle__cIsKey(){
				    return false;
				}
				public Integer RL_Vehicle__cLength(){
				    return 255;
				}
				public Integer RL_Vehicle__cPrecision(){
				    return null;
				}
				public String RL_Vehicle__cDefault(){
				
					return null;
				
				}
				public String RL_Vehicle__cComment(){
				
				    return "";
				
				}
				public String RL_Vehicle__cPattern(){
				
					return "";
				
				}
				public String RL_Vehicle__cOriginalDbColumnName(){
				
					return "RL_Vehicle__c";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_SALESFORCE_PRICING_IMPORT) {

        	try {

        		int length = 0;
		
					this.Id = readString(dis);
					
					this.OwnerId = readString(dis);
					
			        this.IsDeleted = dis.readBoolean();
					
					this.Name = readString(dis);
					
					this.CreatedDate = readDate(dis);
					
					this.CreatedById = readString(dis);
					
					this.LastModifiedDate = readDate(dis);
					
					this.LastModifiedById = readString(dis);
					
					this.SystemModstamp = readDate(dis);
					
					this.LastViewedDate = readDate(dis);
					
					this.LastReferencedDate = readDate(dis);
					
			        this.Is_Modified__c = dis.readBoolean();
					
					this.RL_Billing_type__c = readString(dis);
					
					this.RL_Category__c = readString(dis);
					
					this.RL_Client__c = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.RL_External_id__c = null;
           				} else {
           			    	this.RL_External_id__c = dis.readDouble();
           				}
					
			        this.RL_Is_Deleted__c = dis.readBoolean();
					
					this.RL_Service__c = readString(dis);
					
					this.RL_Sub_category__c = readString(dis);
					
					this.RL_Unit__c = readString(dis);
					
			        this.RL_Is_Active__c = dis.readBoolean();
					
					this.RL_Vehicle__c = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Id,dos);
					
					// String
				
						writeString(this.OwnerId,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.IsDeleted);
					
					// String
				
						writeString(this.Name,dos);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// String
				
						writeString(this.CreatedById,dos);
					
					// java.util.Date
				
						writeDate(this.LastModifiedDate,dos);
					
					// String
				
						writeString(this.LastModifiedById,dos);
					
					// java.util.Date
				
						writeDate(this.SystemModstamp,dos);
					
					// java.util.Date
				
						writeDate(this.LastViewedDate,dos);
					
					// java.util.Date
				
						writeDate(this.LastReferencedDate,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.Is_Modified__c);
					
					// String
				
						writeString(this.RL_Billing_type__c,dos);
					
					// String
				
						writeString(this.RL_Category__c,dos);
					
					// String
				
						writeString(this.RL_Client__c,dos);
					
					// Double
				
						if(this.RL_External_id__c == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.RL_External_id__c);
		            	}
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Deleted__c);
					
					// String
				
						writeString(this.RL_Service__c,dos);
					
					// String
				
						writeString(this.RL_Sub_category__c,dos);
					
					// String
				
						writeString(this.RL_Unit__c,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.RL_Is_Active__c);
					
					// String
				
						writeString(this.RL_Vehicle__c,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+Id);
		sb.append(",OwnerId="+OwnerId);
		sb.append(",IsDeleted="+String.valueOf(IsDeleted));
		sb.append(",Name="+Name);
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",CreatedById="+CreatedById);
		sb.append(",LastModifiedDate="+String.valueOf(LastModifiedDate));
		sb.append(",LastModifiedById="+LastModifiedById);
		sb.append(",SystemModstamp="+String.valueOf(SystemModstamp));
		sb.append(",LastViewedDate="+String.valueOf(LastViewedDate));
		sb.append(",LastReferencedDate="+String.valueOf(LastReferencedDate));
		sb.append(",Is_Modified__c="+String.valueOf(Is_Modified__c));
		sb.append(",RL_Billing_type__c="+RL_Billing_type__c);
		sb.append(",RL_Category__c="+RL_Category__c);
		sb.append(",RL_Client__c="+RL_Client__c);
		sb.append(",RL_External_id__c="+String.valueOf(RL_External_id__c));
		sb.append(",RL_Is_Deleted__c="+String.valueOf(RL_Is_Deleted__c));
		sb.append(",RL_Service__c="+RL_Service__c);
		sb.append(",RL_Sub_category__c="+RL_Sub_category__c);
		sb.append(",RL_Unit__c="+RL_Unit__c);
		sb.append(",RL_Is_Active__c="+String.valueOf(RL_Is_Active__c));
		sb.append(",RL_Vehicle__c="+RL_Vehicle__c);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Id);
            			}
            		
        			sb.append("|");
        		
        				if(OwnerId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OwnerId);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsDeleted);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(CreatedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedById);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastModifiedById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastModifiedById);
            			}
            		
        			sb.append("|");
        		
        				if(SystemModstamp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SystemModstamp);
            			}
            		
        			sb.append("|");
        		
        				if(LastViewedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastViewedDate);
            			}
            		
        			sb.append("|");
        		
        				if(LastReferencedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LastReferencedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Is_Modified__c);
        			
        			sb.append("|");
        		
        				if(RL_Billing_type__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Billing_type__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Client__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Client__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_External_id__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_External_id__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Deleted__c);
        			
        			sb.append("|");
        		
        				if(RL_Service__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Service__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Sub_category__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Sub_category__c);
            			}
            		
        			sb.append("|");
        		
        				if(RL_Unit__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Unit__c);
            			}
            		
        			sb.append("|");
        		
        				sb.append(RL_Is_Active__c);
        			
        			sb.append("|");
        		
        				if(RL_Vehicle__c == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RL_Vehicle__c);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tSalesforceInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSalesforceInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSalesforceInput_2");
		org.slf4j.MDC.put("_subJobPid", "P8Yeo4_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();
row8Struct row8 = new row8Struct();







	
	/**
	 * [tAdvancedHash_row8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row8", false);
		start_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row8";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tAdvancedHash_row8 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row8", "tAdvancedHash_row8", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row8
			   		// source node:tUniqRow_2 - inputs:(row6) outputs:(row8,row8) | target node:tAdvancedHash_row8 - inputs:(row8) outputs:()
			   		// linked node: tMap_1 - inputs:(row7,row8) outputs:(pricing)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row8 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row8Struct>getLookup(matchingModeEnum_row8);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row8 begin ] stop
 */



	
	/**
	 * [tUniqRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_2", false);
		start_Hash.put("tUniqRow_2", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tUniqRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
                    log4jParamters_tUniqRow_2.append("Parameters:");
                            log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Id")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("OwnerId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("IsDeleted")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("CreatedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastModifiedById")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("SystemModstamp")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastViewedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("LastReferencedDate")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("Is_Modified__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Billing_type__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Category__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Client__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_External_id__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Deleted__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Service__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Sub_category__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Unit__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Is_Active__c")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("false")+", SCHEMA_COLUMN="+("RL_Vehicle__c")+"}]");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + (log4jParamters_tUniqRow_2) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_uniques_tUniqRow_2 = 0;
int nb_duplicates_tUniqRow_2 = 0;
	log.debug("tUniqRow_2 - Start to process the data from datasource."); 

 



/**
 * [tUniqRow_2 begin ] stop
 */



	
	/**
	 * [tFilterRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_12", false);
		start_Hash.put("tFilterRow_12", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_12";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tFilterRow_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_12{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_12 = new StringBuilder();
                    log4jParamters_tFilterRow_12.append("Parameters:");
                            log4jParamters_tFilterRow_12.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_12.append(" | ");
                            log4jParamters_tFilterRow_12.append("CONDITIONS" + " = " + "[]");
                        log4jParamters_tFilterRow_12.append(" | ");
                            log4jParamters_tFilterRow_12.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + (log4jParamters_tFilterRow_12) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_12().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_12", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_12 = 0;
    int nb_line_ok_tFilterRow_12 = 0;
    int nb_line_reject_tFilterRow_12 = 0;

    class Operator_tFilterRow_12 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_12(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_12 begin ] stop
 */



	
	/**
	 * [tConvertType_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_2", false);
		start_Hash.put("tConvertType_2", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tConvertType_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_2", "tConvertType_2", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_2 = 0;  
 



/**
 * [tConvertType_2 begin ] stop
 */



	
	/**
	 * [tSalesforceInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSalesforceInput_2", false);
		start_Hash.put("tSalesforceInput_2", System.currentTimeMillis());
		
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		
		int tos_count_tSalesforceInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSalesforceInput_2", "RL_Service_Detail__c", "tSalesforceInput");
				talendJobLogProcess(globalMap);
			}
			

boolean doesNodeBelongToRequest_tSalesforceInput_2 = 0 == 0;
@SuppressWarnings("unchecked")
java.util.Map<String, Object> restRequest_tSalesforceInput_2 = (java.util.Map<String, Object>)globalMap.get("restRequest");
String currentTRestRequestOperation_tSalesforceInput_2 = (String)(restRequest_tSalesforceInput_2 != null ? restRequest_tSalesforceInput_2.get("OPERATION") : null);

org.talend.components.api.component.ComponentDefinition def_tSalesforceInput_2 =
        new org.talend.components.salesforce.tsalesforceinput.TSalesforceInputDefinition();

org.talend.components.api.component.runtime.Writer writer_tSalesforceInput_2 = null;
org.talend.components.api.component.runtime.Reader reader_tSalesforceInput_2 = null;


org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties props_tSalesforceInput_2 =
        (org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties) def_tSalesforceInput_2.createRuntimeProperties();
 		                    props_tSalesforceInput_2.setValue("queryMode",
 		                        org.talend.components.salesforce.tsalesforceinput.TSalesforceInputProperties.QueryMode.Query);
 		                    
 		                    props_tSalesforceInput_2.setValue("condition",
 		                    "");
 		                    
 		                    props_tSalesforceInput_2.setValue("manualQuery",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.setValue("includeDeleted",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.setValue("batchSize",
 		                    250);
 		                    
 		                    props_tSalesforceInput_2.setValue("normalizeDelimiter",
 		                    ";");
 		                    
 		                    props_tSalesforceInput_2.setValue("columnNameDelimiter",
 		                    "_");
 		                    
 		                    props_tSalesforceInput_2.setValue("dataTimeUTC",
 		                    true);
 		                    
 		                    props_tSalesforceInput_2.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_2.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    props_tSalesforceInput_2.module.setValue("moduleName",
 		                    "RL_Service_Detail__c");
 		                    
 		                    props_tSalesforceInput_2.module.connection.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.module.connection.proxy.userPassword.setValue("useAuth",
 		                    false);
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("referenceType",
 		                        org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE);
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("componentInstanceId",
 		                    "tSalesforceConnection_1");
 		                    
 		                    props_tSalesforceInput_2.module.connection.referencedComponent.setValue("referenceDefinitionName",
 		                    "tSalesforceConnection");
 		                    
 		                    class SchemaSettingTool_tSalesforceInput_2_1_fisrt {
 		                    		
 		                    		String getSchemaValue() {
 		                    				
 		                    						StringBuilder s = new StringBuilder();
                    						
     		                    						a("{\"type\":\"record\",",s);
     		                    						
     		                    						a("\"name\":\"RL_Service_Detail__c\",\"fields\":[{",s);
     		                    						
     		                    						a("\"name\":\"Id\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Id\",\"talend.field.dbColumnName\":\"Id\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Id\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"OwnerId\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"OwnerId\",\"talend.field.dbColumnName\":\"OwnerId\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"OwnerId\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"IsDeleted\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"IsDeleted\",\"talend.field.dbColumnName\":\"IsDeleted\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"IsDeleted\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Name\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Name\",\"talend.field.dbColumnName\":\"Name\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"80\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Name\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"CreatedDate\",\"talend.field.dbColumnName\":\"CreatedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"CreatedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"CreatedById\",\"talend.field.dbColumnName\":\"CreatedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"CreatedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedDate\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedDate\",\"talend.field.dbColumnName\":\"LastModifiedDate\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastModifiedById\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"LastModifiedById\",\"talend.field.dbColumnName\":\"LastModifiedById\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastModifiedById\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"SystemModstamp\",\"type\":{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"SystemModstamp\",\"talend.field.dbColumnName\":\"SystemModstamp\",\"di.column.talendType\":\"id_Date\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"SystemModstamp\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastViewedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastViewedDate\",\"talend.field.dbColumnName\":\"LastViewedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastViewedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"LastReferencedDate\",\"type\":[{\"type\":\"long\",\"java-class\":\"java.util.Date\"},\"null\"],\"di.table.comment\":\"\",\"di.prop.di.date.noLogicalType\":\"true\",\"AVRO_TECHNICAL_KEY\":\"LastReferencedDate\",\"talend.field.dbColumnName\":\"LastReferencedDate\",\"di.column.talendType\":\"id_Date\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"yyyy-MM-dd'T'HH:mm:ss'.000Z'\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"LastReferencedDate\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"Is_Modified__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"Is_Modified__c\",\"talend.field.dbColumnName\":\"Is_Modified__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"Is_Modified__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Billing_type__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Billing_type__c\",\"talend.field.dbColumnName\":\"RL_Billing_type__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Billing_type__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Category__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Category__c\",\"talend.field.dbColumnName\":\"RL_Category__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Category__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Client__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Client__c\",\"talend.field.dbColumnName\":\"RL_Client__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"18\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Client__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_External_id__c\",\"type\":[\"double\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_External_id__c\",\"talend.field.dbColumnName\":\"RL_External_id__c\",\"di.column.talendType\":\"id_Double\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"16\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_External_id__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Deleted__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Deleted__c\",\"talend.field.dbColumnName\":\"RL_Is_Deleted__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Deleted__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Service__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Service__c\",\"talend.field.dbColumnName\":\"RL_Service__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Service__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Sub_category__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Sub_category__c\",\"talend.field.dbColumnName\":\"RL_Sub_category__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Sub_category__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Unit__c\",\"type\":\"string\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Unit__c\",\"talend.field.dbColumnName\":\"RL_Unit__c\",\"di.column.talendType\":\"id_String\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Unit__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Is_Active__c\",\"type\":\"boolean\",\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Is_Active__c\",\"talend.field.dbColumnName\":\"RL_Is_Active__c\",\"di.column.talendType\":\"id_Boolean\",\"talend.field.pattern\":\"\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Is_Active__c\",\"di.column.relatedEntity\":\"\"},{",s);
     		                    						
     		                    						a("\"name\":\"RL_Vehicle__c\",\"type\":[\"string\",\"null\"],\"di.table.comment\":\"\",\"AVRO_TECHNICAL_KEY\":\"RL_Vehicle__c\",\"talend.field.dbColumnName\":\"RL_Vehicle__c\",\"di.column.talendType\":\"id_String\",\"di.column.isNullable\":\"true\",\"talend.field.pattern\":\"\",\"talend.field.length\":\"255\",\"di.column.relationshipType\":\"\",\"di.table.label\":\"RL_Vehicle__c\",\"di.column.relatedEntity\":\"\"}],\"di.table.name\":\"MAIN\",\"di.table.label\":\"RL_Service_Detail__c\"}",s);
     		                    						
     		                    				return s.toString();
     		                    		
 		                    		}
 		                    		
 		                    		void a(String part, StringBuilder strB) {
 		                    				strB.append(part);
 		                    		}
 		                    		
 		                    }
 		                    
 		                    SchemaSettingTool_tSalesforceInput_2_1_fisrt sst_tSalesforceInput_2_1_fisrt = new SchemaSettingTool_tSalesforceInput_2_1_fisrt();
 		                    
 		                    props_tSalesforceInput_2.module.main.setValue("schema",
 		                        new org.apache.avro.Schema.Parser().setValidateDefaults(false).parse(sst_tSalesforceInput_2_1_fisrt.getSchemaValue()));
 		                    
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_2.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_2 = props_tSalesforceInput_2.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_2 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_2 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_2 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_2.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_2);
        }
    }
    if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tSalesforceInput_2.module.connection.referencedComponent.referenceType.getValue()) {
        final String referencedComponentInstanceId_tSalesforceInput_2 = props_tSalesforceInput_2.module.connection.referencedComponent.componentInstanceId.getStringValue();
        if (referencedComponentInstanceId_tSalesforceInput_2 != null) {
            org.talend.daikon.properties.Properties referencedComponentProperties_tSalesforceInput_2 = (org.talend.daikon.properties.Properties) globalMap.get(
                referencedComponentInstanceId_tSalesforceInput_2 + "_COMPONENT_RUNTIME_PROPERTIES");
            props_tSalesforceInput_2.module.connection.referencedComponent.setReference(referencedComponentProperties_tSalesforceInput_2);
        }
    }
globalMap.put("tSalesforceInput_2_COMPONENT_RUNTIME_PROPERTIES", props_tSalesforceInput_2);
globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "8.0");
globalMap.put("TALEND_COMPONENTS_VERSION", "0.37.29");
java.net.URL mappings_url_tSalesforceInput_2= this.getClass().getResource("/xmlMappings");
globalMap.put("tSalesforceInput_2_MAPPINGS_URL", mappings_url_tSalesforceInput_2);

org.talend.components.api.container.RuntimeContainer container_tSalesforceInput_2 = new org.talend.components.api.container.RuntimeContainer() {
    public Object getComponentData(String componentId, String key) {
        return globalMap.get(componentId + "_" + key);
    }

    public void setComponentData(String componentId, String key, Object data) {
        globalMap.put(componentId + "_" + key, data);
    }

    public String getCurrentComponentId() {
        return "tSalesforceInput_2";
    }

    public Object getGlobalData(String key) {
    	return globalMap.get(key);
    }
};

int nb_line_tSalesforceInput_2 = 0;

org.talend.components.api.component.ConnectorTopology topology_tSalesforceInput_2 = null;
topology_tSalesforceInput_2 = org.talend.components.api.component.ConnectorTopology.OUTGOING;

org.talend.daikon.runtime.RuntimeInfo runtime_info_tSalesforceInput_2 = def_tSalesforceInput_2.getRuntimeInfo(
    org.talend.components.api.component.runtime.ExecutionEngine.DI, props_tSalesforceInput_2, topology_tSalesforceInput_2);
java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tSalesforceInput_2 = def_tSalesforceInput_2.getSupportedConnectorTopologies();

org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tSalesforceInput_2 = (org.talend.components.api.component.runtime.RuntimableRuntime)(Class.forName(runtime_info_tSalesforceInput_2.getRuntimeClassName()).newInstance());
org.talend.daikon.properties.ValidationResult initVr_tSalesforceInput_2 = componentRuntime_tSalesforceInput_2.initialize(container_tSalesforceInput_2, props_tSalesforceInput_2);

if (initVr_tSalesforceInput_2.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
    throw new RuntimeException(initVr_tSalesforceInput_2.getMessage());
}

if(componentRuntime_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
	org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tSalesforceInput_2 = (org.talend.components.api.component.runtime.ComponentDriverInitialization)componentRuntime_tSalesforceInput_2;
	compDriverInitialization_tSalesforceInput_2.runAtDriver(container_tSalesforceInput_2);
}

org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tSalesforceInput_2 = null;
if(componentRuntime_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
	sourceOrSink_tSalesforceInput_2 = (org.talend.components.api.component.runtime.SourceOrSink)componentRuntime_tSalesforceInput_2;
	if (doesNodeBelongToRequest_tSalesforceInput_2) {
        org.talend.daikon.properties.ValidationResult vr_tSalesforceInput_2 = sourceOrSink_tSalesforceInput_2.validate(container_tSalesforceInput_2);
        if (vr_tSalesforceInput_2.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR ) {
            throw new RuntimeException(vr_tSalesforceInput_2.getMessage());
        }
	}
}

    if (sourceOrSink_tSalesforceInput_2 instanceof org.talend.components.api.component.runtime.Source) {
        org.talend.components.api.component.runtime.Source source_tSalesforceInput_2 =
                (org.talend.components.api.component.runtime.Source)sourceOrSink_tSalesforceInput_2;
        reader_tSalesforceInput_2 = source_tSalesforceInput_2.createReader(container_tSalesforceInput_2);
	    reader_tSalesforceInput_2 = new org.talend.codegen.flowvariables.runtime.FlowVariablesReader(reader_tSalesforceInput_2, container_tSalesforceInput_2);

            boolean multi_output_is_allowed_tSalesforceInput_2 = false;
            org.talend.components.api.component.Connector c_tSalesforceInput_2 = null;
            for (org.talend.components.api.component.Connector currentConnector : props_tSalesforceInput_2.getAvailableConnectors(null, true)) {
                if (currentConnector.getName().equals("MAIN")) {
                    c_tSalesforceInput_2 = currentConnector;
                }

                if (currentConnector.getName().equals("REJECT")) {//it's better to move the code to javajet
                    multi_output_is_allowed_tSalesforceInput_2 = true;
                }
            }
            org.apache.avro.Schema schema_tSalesforceInput_2 = props_tSalesforceInput_2.getSchema(c_tSalesforceInput_2, true);

        org.talend.codegen.enforcer.OutgoingSchemaEnforcer outgoingEnforcer_tSalesforceInput_2 = org.talend.codegen.enforcer.EnforcerCreator.createOutgoingEnforcer(schema_tSalesforceInput_2, false);

        // Create a reusable factory that converts the output of the reader to an IndexedRecord.
        org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord> factory_tSalesforceInput_2 = null;

        // Iterate through the incoming data.
        boolean available_tSalesforceInput_2 = reader_tSalesforceInput_2.start();

        resourceMap.put("reader_tSalesforceInput_2", reader_tSalesforceInput_2);

        for (; available_tSalesforceInput_2; available_tSalesforceInput_2 = reader_tSalesforceInput_2.advance()) {
			nb_line_tSalesforceInput_2++;

			
			if (multi_output_is_allowed_tSalesforceInput_2) {
				
					row2 = null;
				

				
			}
			

			try {
				Object data_tSalesforceInput_2 = reader_tSalesforceInput_2.getCurrent();
				

					if(multi_output_is_allowed_tSalesforceInput_2) {
						row2 = new row2Struct();
					}

					
        // Construct the factory once when the first data arrives.
        if (factory_tSalesforceInput_2 == null) {
            factory_tSalesforceInput_2 = (org.talend.daikon.avro.converter.IndexedRecordConverter<Object, ? extends org.apache.avro.generic.IndexedRecord>)
                    new org.talend.daikon.avro.AvroRegistry()
                            .createIndexedRecordConverter(data_tSalesforceInput_2.getClass());
        }

        // Enforce the outgoing schema on the input.
        outgoingEnforcer_tSalesforceInput_2.setWrapped(factory_tSalesforceInput_2.convertToAvro(data_tSalesforceInput_2));
                Object columnValue_0_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(0);
                        row2.Id = (String) (columnValue_0_tSalesforceInput_2);
                Object columnValue_1_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(1);
                        row2.OwnerId = (String) (columnValue_1_tSalesforceInput_2);
                Object columnValue_2_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(2);
                    if (columnValue_2_tSalesforceInput_2 == null) {
                        row2.IsDeleted = false;
                    } else {
                            row2.IsDeleted = (boolean) (columnValue_2_tSalesforceInput_2);
                    }
                Object columnValue_3_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(3);
                        row2.Name = (String) (columnValue_3_tSalesforceInput_2);
                Object columnValue_4_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(4);
                        row2.CreatedDate = (java.util.Date) (columnValue_4_tSalesforceInput_2);
                Object columnValue_5_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(5);
                        row2.CreatedById = (String) (columnValue_5_tSalesforceInput_2);
                Object columnValue_6_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(6);
                        row2.LastModifiedDate = (java.util.Date) (columnValue_6_tSalesforceInput_2);
                Object columnValue_7_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(7);
                        row2.LastModifiedById = (String) (columnValue_7_tSalesforceInput_2);
                Object columnValue_8_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(8);
                        row2.SystemModstamp = (java.util.Date) (columnValue_8_tSalesforceInput_2);
                Object columnValue_9_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(9);
                        row2.LastViewedDate = (java.util.Date) (columnValue_9_tSalesforceInput_2);
                Object columnValue_10_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(10);
                        row2.LastReferencedDate = (java.util.Date) (columnValue_10_tSalesforceInput_2);
                Object columnValue_11_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(11);
                    if (columnValue_11_tSalesforceInput_2 == null) {
                        row2.Is_Modified__c = false;
                    } else {
                            row2.Is_Modified__c = (boolean) (columnValue_11_tSalesforceInput_2);
                    }
                Object columnValue_12_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(12);
                        row2.RL_Billing_type__c = (String) (columnValue_12_tSalesforceInput_2);
                Object columnValue_13_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(13);
                        row2.RL_Category__c = (String) (columnValue_13_tSalesforceInput_2);
                Object columnValue_14_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(14);
                        row2.RL_Client__c = (String) (columnValue_14_tSalesforceInput_2);
                Object columnValue_15_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(15);
                        row2.RL_External_id__c = (Double) (columnValue_15_tSalesforceInput_2);
                Object columnValue_16_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(16);
                    if (columnValue_16_tSalesforceInput_2 == null) {
                        row2.RL_Is_Deleted__c = false;
                    } else {
                            row2.RL_Is_Deleted__c = (boolean) (columnValue_16_tSalesforceInput_2);
                    }
                Object columnValue_17_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(17);
                        row2.RL_Service__c = (String) (columnValue_17_tSalesforceInput_2);
                Object columnValue_18_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(18);
                        row2.RL_Sub_category__c = (String) (columnValue_18_tSalesforceInput_2);
                Object columnValue_19_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(19);
                        row2.RL_Unit__c = (String) (columnValue_19_tSalesforceInput_2);
                Object columnValue_20_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(20);
                    if (columnValue_20_tSalesforceInput_2 == null) {
                        row2.RL_Is_Active__c = false;
                    } else {
                            row2.RL_Is_Active__c = (boolean) (columnValue_20_tSalesforceInput_2);
                    }
                Object columnValue_21_tSalesforceInput_2 = outgoingEnforcer_tSalesforceInput_2.get(21);
                        row2.RL_Vehicle__c = (String) (columnValue_21_tSalesforceInput_2);
			} catch (org.talend.components.api.exception.DataRejectException e_tSalesforceInput_2) {
				java.util.Map<String,Object> info_tSalesforceInput_2 = e_tSalesforceInput_2.getRejectInfo();
				
					//TODO use a method instead of getting method by the special key "error/errorMessage"
					Object errorMessage_tSalesforceInput_2 = null;
					if(info_tSalesforceInput_2.containsKey("error")){
						errorMessage_tSalesforceInput_2 = info_tSalesforceInput_2.get("error");
					}else if(info_tSalesforceInput_2.containsKey("errorMessage")){
						errorMessage_tSalesforceInput_2 = info_tSalesforceInput_2.get("errorMessage");
					}else{
						errorMessage_tSalesforceInput_2 = "Rejected but error message missing";
					}
					errorMessage_tSalesforceInput_2 = "Row "+ nb_line_tSalesforceInput_2 + ": "+errorMessage_tSalesforceInput_2;
					System.err.println(errorMessage_tSalesforceInput_2);
				
					// If the record is reject, the main line record should put NULL
					row2 = null;
				
			} // end of catch

                java.lang.Iterable<?> outgoingMainRecordsList_tSalesforceInput_2 = new java.util.ArrayList<Object>();
                java.util.Iterator outgoingMainRecordsIt_tSalesforceInput_2 = null;


 



/**
 * [tSalesforceInput_2 begin ] stop
 */
	
	/**
	 * [tSalesforceInput_2 main ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		


 


	tos_count_tSalesforceInput_2++;

/**
 * [tSalesforceInput_2 main ] stop
 */
	
	/**
	 * [tSalesforceInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		


 



/**
 * [tSalesforceInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tConvertType_2 main ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tSalesforceInput_2","RL_Service_Detail__c","tSalesforceInput","tConvertType_2","tConvertType_2","tConvertType"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		


  row5 = new row5Struct();
  boolean bHasError_tConvertType_2 = false;             
          try {
              if ("".equals(row2.Id)){  
                row2.Id = null;
              }
              row5.Id=TypeConvert.String2String(row2.Id);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.OwnerId)){  
                row2.OwnerId = null;
              }
              row5.OwnerId=TypeConvert.String2String(row2.OwnerId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.IsDeleted=TypeConvert.boolean2boolean(row2.IsDeleted);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.Name)){  
                row2.Name = null;
              }
              row5.Name=TypeConvert.String2String(row2.Name);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.CreatedDate=TypeConvert.Date2Date(row2.CreatedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.CreatedById)){  
                row2.CreatedById = null;
              }
              row5.CreatedById=TypeConvert.String2String(row2.CreatedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastModifiedDate=TypeConvert.Date2Date(row2.LastModifiedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.LastModifiedById)){  
                row2.LastModifiedById = null;
              }
              row5.LastModifiedById=TypeConvert.String2String(row2.LastModifiedById);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.SystemModstamp=TypeConvert.Date2Date(row2.SystemModstamp);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastViewedDate=TypeConvert.Date2Date(row2.LastViewedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.LastReferencedDate=TypeConvert.Date2Date(row2.LastReferencedDate);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.Is_Modified__c=TypeConvert.boolean2boolean(row2.Is_Modified__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Billing_type__c)){  
                row2.RL_Billing_type__c = null;
              }
              row5.RL_Billing_type__c=TypeConvert.String2String(row2.RL_Billing_type__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Category__c)){  
                row2.RL_Category__c = null;
              }
              row5.RL_Category__c=TypeConvert.String2String(row2.RL_Category__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Client__c)){  
                row2.RL_Client__c = null;
              }
              row5.RL_Client__c=TypeConvert.String2String(row2.RL_Client__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_External_id__c=TypeConvert.Double2Integer(row2.RL_External_id__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_Is_Deleted__c=TypeConvert.boolean2boolean(row2.RL_Is_Deleted__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Service__c)){  
                row2.RL_Service__c = null;
              }
              row5.RL_Service__c=TypeConvert.String2String(row2.RL_Service__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Sub_category__c)){  
                row2.RL_Sub_category__c = null;
              }
              row5.RL_Sub_category__c=TypeConvert.String2String(row2.RL_Sub_category__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Unit__c)){  
                row2.RL_Unit__c = null;
              }
              row5.RL_Unit__c=TypeConvert.String2String(row2.RL_Unit__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row5.RL_Is_Active__c=TypeConvert.boolean2boolean(row2.RL_Is_Active__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row2.RL_Vehicle__c)){  
                row2.RL_Vehicle__c = null;
              }
              row5.RL_Vehicle__c=TypeConvert.String2String(row2.RL_Vehicle__c);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_2_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_2 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_2) {row5 = null;}

  nb_line_tConvertType_2 ++ ;

 


	tos_count_tConvertType_2++;

/**
 * [tConvertType_2 main ] stop
 */
	
	/**
	 * [tConvertType_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tFilterRow_12 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tConvertType_2","tConvertType_2","tConvertType","tFilterRow_12","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

          row6 = null;
    Operator_tFilterRow_12 ope_tFilterRow_12 = new Operator_tFilterRow_12("&&");
    
    if (ope_tFilterRow_12.getMatchFlag()) {
              if(row6 == null){ 
                row6 = new row6Struct();
              }
               row6.Id = row5.Id;
               row6.OwnerId = row5.OwnerId;
               row6.IsDeleted = row5.IsDeleted;
               row6.Name = row5.Name;
               row6.CreatedDate = row5.CreatedDate;
               row6.CreatedById = row5.CreatedById;
               row6.LastModifiedDate = row5.LastModifiedDate;
               row6.LastModifiedById = row5.LastModifiedById;
               row6.SystemModstamp = row5.SystemModstamp;
               row6.LastViewedDate = row5.LastViewedDate;
               row6.LastReferencedDate = row5.LastReferencedDate;
               row6.Is_Modified__c = row5.Is_Modified__c;
               row6.RL_Billing_type__c = row5.RL_Billing_type__c;
               row6.RL_Category__c = row5.RL_Category__c;
               row6.RL_Client__c = row5.RL_Client__c;
               row6.RL_External_id__c = row5.RL_External_id__c;
               row6.RL_Is_Deleted__c = row5.RL_Is_Deleted__c;
               row6.RL_Service__c = row5.RL_Service__c;
               row6.RL_Sub_category__c = row5.RL_Sub_category__c;
               row6.RL_Unit__c = row5.RL_Unit__c;
               row6.RL_Is_Active__c = row5.RL_Is_Active__c;
               row6.RL_Vehicle__c = row5.RL_Vehicle__c;
					log.debug("tFilterRow_12 - Process the record " + (nb_line_tFilterRow_12+1) + ".");
					    
      nb_line_ok_tFilterRow_12++;
    } else {
      nb_line_reject_tFilterRow_12++;
    }

nb_line_tFilterRow_12++;

 


	tos_count_tFilterRow_12++;

/**
 * [tFilterRow_12 main ] stop
 */
	
	/**
	 * [tFilterRow_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tUniqRow_2 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tFilterRow_12","tFilterRow_1","tFilterRow","tUniqRow_2","tUniqRow_2","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		
row8.Id = row6.Id;			row8.OwnerId = row6.OwnerId;			row8.IsDeleted = row6.IsDeleted;			row8.Name = row6.Name;			row8.CreatedDate = row6.CreatedDate;			row8.CreatedById = row6.CreatedById;			row8.LastModifiedDate = row6.LastModifiedDate;			row8.LastModifiedById = row6.LastModifiedById;			row8.SystemModstamp = row6.SystemModstamp;			row8.LastViewedDate = row6.LastViewedDate;			row8.LastReferencedDate = row6.LastReferencedDate;			row8.Is_Modified__c = row6.Is_Modified__c;			row8.RL_Billing_type__c = row6.RL_Billing_type__c;			row8.RL_Category__c = row6.RL_Category__c;			row8.RL_Client__c = row6.RL_Client__c;			row8.RL_External_id__c = row6.RL_External_id__c;			row8.RL_Is_Deleted__c = row6.RL_Is_Deleted__c;			row8.RL_Service__c = row6.RL_Service__c;			row8.RL_Sub_category__c = row6.RL_Sub_category__c;			row8.RL_Unit__c = row6.RL_Unit__c;			row8.RL_Is_Active__c = row6.RL_Is_Active__c;			row8.RL_Vehicle__c = row6.RL_Vehicle__c;			row8.Id = row6.Id;			row8.OwnerId = row6.OwnerId;			row8.IsDeleted = row6.IsDeleted;			row8.Name = row6.Name;			row8.CreatedDate = row6.CreatedDate;			row8.CreatedById = row6.CreatedById;			row8.LastModifiedDate = row6.LastModifiedDate;			row8.LastModifiedById = row6.LastModifiedById;			row8.SystemModstamp = row6.SystemModstamp;			row8.LastViewedDate = row6.LastViewedDate;			row8.LastReferencedDate = row6.LastReferencedDate;			row8.Is_Modified__c = row6.Is_Modified__c;			row8.RL_Billing_type__c = row6.RL_Billing_type__c;			row8.RL_Category__c = row6.RL_Category__c;			row8.RL_Client__c = row6.RL_Client__c;			row8.RL_External_id__c = row6.RL_External_id__c;			row8.RL_Is_Deleted__c = row6.RL_Is_Deleted__c;			row8.RL_Service__c = row6.RL_Service__c;			row8.RL_Sub_category__c = row6.RL_Sub_category__c;			row8.RL_Unit__c = row6.RL_Unit__c;			row8.RL_Is_Active__c = row6.RL_Is_Active__c;			row8.RL_Vehicle__c = row6.RL_Vehicle__c;			

 


	tos_count_tUniqRow_2++;

/**
 * [tUniqRow_2 main ] stop
 */
	
	/**
	 * [tUniqRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tAdvancedHash_row8 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tUniqRow_2","tUniqRow_2","tUniqRow","tAdvancedHash_row8","tAdvancedHash_row8","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		


			   
			   

					row8Struct row8_HashRow = new row8Struct();
		   	   	   
				
				row8_HashRow.Id = row8.Id;
				
				row8_HashRow.OwnerId = row8.OwnerId;
				
				row8_HashRow.IsDeleted = row8.IsDeleted;
				
				row8_HashRow.Name = row8.Name;
				
				row8_HashRow.CreatedDate = row8.CreatedDate;
				
				row8_HashRow.CreatedById = row8.CreatedById;
				
				row8_HashRow.LastModifiedDate = row8.LastModifiedDate;
				
				row8_HashRow.LastModifiedById = row8.LastModifiedById;
				
				row8_HashRow.SystemModstamp = row8.SystemModstamp;
				
				row8_HashRow.LastViewedDate = row8.LastViewedDate;
				
				row8_HashRow.LastReferencedDate = row8.LastReferencedDate;
				
				row8_HashRow.Is_Modified__c = row8.Is_Modified__c;
				
				row8_HashRow.RL_Billing_type__c = row8.RL_Billing_type__c;
				
				row8_HashRow.RL_Category__c = row8.RL_Category__c;
				
				row8_HashRow.RL_Client__c = row8.RL_Client__c;
				
				row8_HashRow.RL_External_id__c = row8.RL_External_id__c;
				
				row8_HashRow.RL_Is_Deleted__c = row8.RL_Is_Deleted__c;
				
				row8_HashRow.RL_Service__c = row8.RL_Service__c;
				
				row8_HashRow.RL_Sub_category__c = row8.RL_Sub_category__c;
				
				row8_HashRow.RL_Unit__c = row8.RL_Unit__c;
				
				row8_HashRow.RL_Is_Active__c = row8.RL_Is_Active__c;
				
				row8_HashRow.RL_Vehicle__c = row8.RL_Vehicle__c;
				
			tHash_Lookup_row8.put(row8_HashRow);
			
            




 


	tos_count_tAdvancedHash_row8++;

/**
 * [tAdvancedHash_row8 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tUniqRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tFilterRow_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tConvertType_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 process_data_end ] stop
 */



	
	/**
	 * [tSalesforceInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		


 



/**
 * [tSalesforceInput_2 process_data_end ] stop
 */
	
	/**
	 * [tSalesforceInput_2 end ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		
// end of generic


resourceMap.put("finish_tSalesforceInput_2", Boolean.TRUE);

    } // while  
    } // end of "if (sourceOrSink_tSalesforceInput_2 instanceof ...Source)"
    java.util.Map<String, Object> resultMap_tSalesforceInput_2 = null;
    if (reader_tSalesforceInput_2 != null) {
        reader_tSalesforceInput_2.close();
        resultMap_tSalesforceInput_2 = reader_tSalesforceInput_2.getReturnValues();
    }
if(resultMap_tSalesforceInput_2!=null) {
	for(java.util.Map.Entry<String,Object> entry_tSalesforceInput_2 : resultMap_tSalesforceInput_2.entrySet()) {
		switch(entry_tSalesforceInput_2.getKey()) {
		case org.talend.components.api.component.ComponentDefinition.RETURN_ERROR_MESSAGE :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "ERROR_MESSAGE", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_TOTAL_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_LINE", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_SUCCESS_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_SUCCESS", entry_tSalesforceInput_2.getValue());
			break;
		case org.talend.components.api.component.ComponentDefinition.RETURN_REJECT_RECORD_COUNT :
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", "NB_REJECT", entry_tSalesforceInput_2.getValue());
			break;
		default :
            StringBuilder studio_key_tSalesforceInput_2 = new StringBuilder();
            for (int i_tSalesforceInput_2 = 0; i_tSalesforceInput_2 < entry_tSalesforceInput_2.getKey().length(); i_tSalesforceInput_2++) {
                char ch_tSalesforceInput_2 = entry_tSalesforceInput_2.getKey().charAt(i_tSalesforceInput_2);
                if(Character.isUpperCase(ch_tSalesforceInput_2) && i_tSalesforceInput_2> 0) {
                	studio_key_tSalesforceInput_2.append('_');
                }
                studio_key_tSalesforceInput_2.append(ch_tSalesforceInput_2);
            }
			container_tSalesforceInput_2.setComponentData("tSalesforceInput_2", studio_key_tSalesforceInput_2.toString().toUpperCase(java.util.Locale.ENGLISH), entry_tSalesforceInput_2.getValue());
			break;
		}
	}
}

 

ok_Hash.put("tSalesforceInput_2", true);
end_Hash.put("tSalesforceInput_2", System.currentTimeMillis());




/**
 * [tSalesforceInput_2 end ] stop
 */

	
	/**
	 * [tConvertType_2 end ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	
      globalMap.put("tConvertType_2_NB_LINE", nb_line_tConvertType_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tSalesforceInput_2","RL_Service_Detail__c","tSalesforceInput","tConvertType_2","tConvertType_2","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_2", true);
end_Hash.put("tConvertType_2", System.currentTimeMillis());




/**
 * [tConvertType_2 end ] stop
 */

	
	/**
	 * [tFilterRow_12 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	
    globalMap.put("tFilterRow_12_NB_LINE", nb_line_tFilterRow_12);
    globalMap.put("tFilterRow_12_NB_LINE_OK", nb_line_ok_tFilterRow_12);
    globalMap.put("tFilterRow_12_NB_LINE_REJECT", nb_line_reject_tFilterRow_12);
    
    	log.info("tFilterRow_12 - Processed records count:" + nb_line_tFilterRow_12 + ". Matched records count:" + nb_line_ok_tFilterRow_12 + ". Rejected records count:" + nb_line_reject_tFilterRow_12 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tConvertType_2","tConvertType_2","tConvertType","tFilterRow_12","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_12 - "  + ("Done.") );

ok_Hash.put("tFilterRow_12", true);
end_Hash.put("tFilterRow_12", System.currentTimeMillis());




/**
 * [tFilterRow_12 end ] stop
 */

	
	/**
	 * [tUniqRow_2 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

globalMap.put("tUniqRow_2_NB_UNIQUES",nb_uniques_tUniqRow_2);
globalMap.put("tUniqRow_2_NB_DUPLICATES",nb_duplicates_tUniqRow_2);
	log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2)+" .");
	log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tFilterRow_12","tFilterRow_1","tFilterRow","tUniqRow_2","tUniqRow_2","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Done.") );

ok_Hash.put("tUniqRow_2", true);
end_Hash.put("tUniqRow_2", System.currentTimeMillis());




/**
 * [tUniqRow_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

tHash_Lookup_row8.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tUniqRow_2","tUniqRow_2","tUniqRow","tAdvancedHash_row8","tAdvancedHash_row8","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row8", true);
end_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());




/**
 * [tAdvancedHash_row8 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSalesforceInput_2 finally ] start
	 */

	

	
	
	currentComponent="tSalesforceInput_2";
	
	
			cLabel="RL_Service_Detail__c";
		
// finally of generic


if(resourceMap.get("finish_tSalesforceInput_2")==null){
    if(resourceMap.get("reader_tSalesforceInput_2")!=null){
		try {
			((org.talend.components.api.component.runtime.Reader)resourceMap.get("reader_tSalesforceInput_2")).close();
		} catch (java.io.IOException e_tSalesforceInput_2) {
			String errorMessage_tSalesforceInput_2 = "failed to release the resource in tSalesforceInput_2 :" + e_tSalesforceInput_2.getMessage();
			System.err.println(errorMessage_tSalesforceInput_2);
		}
	}
}
 



/**
 * [tSalesforceInput_2 finally ] stop
 */

	
	/**
	 * [tConvertType_2 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_2";
	
	

 



/**
 * [tConvertType_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_12 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_12";
	
	

 



/**
 * [tFilterRow_12 finally ] stop
 */

	
	/**
	 * [tUniqRow_2 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";
	
	

 



/**
 * [tAdvancedHash_row8 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSalesforceInput_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "6G0QMb_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tWarn_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_2");
		org.slf4j.MDC.put("_subJobPid", "31Nwmu_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";
	
	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
                    log4jParamters_tWarn_2.append("Parameters:");
                            log4jParamters_tWarn_2.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
                    } 
                } 
            new BytesLimit65535_tWarn_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_2", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_2 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_2_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_2_WARN_PRIORITY", 4);
	globalMap.put("tWarn_2_WARN_CODE", 42);
	
} catch (Exception e_tWarn_2) {
globalMap.put("tWarn_2_ERROR_MESSAGE",e_tWarn_2.getMessage());
	logIgnoredError(String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2), e_tWarn_2);
}


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_end ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "CDmedK_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    private final org.talend.components.common.runtime.SharedConnectionsPool connectionPool = new org.talend.components.common.runtime.SharedConnectionsPool() {
    	public java.sql.Connection getDBConnection(String dbDriver, String url, String userName, String password, String dbConnectionName)
            throws ClassNotFoundException, java.sql.SQLException {
            return SharedDBConnection.getDBConnection(dbDriver, url, userName, password, dbConnectionName);
        }

    	public java.sql.Connection getDBConnection(String dbDriver, String url, String dbConnectionName)
            throws ClassNotFoundException, java.sql.SQLException {
            return SharedDBConnection.getDBConnection(dbDriver, url, dbConnectionName);
        }
    };
    
    private static final String GLOBAL_CONNECTION_POOL_KEY = "GLOBAL_CONNECTION_POOL";
    
    {
    	globalMap.put(GLOBAL_CONNECTION_POOL_KEY, connectionPool);
    }
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ECOLOTRANS_SALESFORCE_PRICING_IMPORT ECOLOTRANS_SALESFORCE_PRICING_IMPORTClass = new ECOLOTRANS_SALESFORCE_PRICING_IMPORT();

        int exitCode = ECOLOTRANS_SALESFORCE_PRICING_IMPORTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_PRICING_IMPORT' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_PRICING_IMPORT' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_IMXkgNewEe6aSY3JqFxI6w");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-03-05T13:26:47.649266200Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ECOLOTRANS_SALESFORCE_PRICING_IMPORT.class.getClassLoader().getResourceAsStream("atelier_facturation/ecolotrans_salesforce_pricing_import_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ECOLOTRANS_SALESFORCE_PRICING_IMPORT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("ODS_Database", "id_String");
                        if(context.getStringValue("ODS_Database") == null) {
                            context.ODS_Database = null;
                        } else {
                            context.ODS_Database=(String) context.getProperty("ODS_Database");
                        }
                        context.setContextType("PBI_Database", "id_String");
                        if(context.getStringValue("PBI_Database") == null) {
                            context.PBI_Database = null;
                        } else {
                            context.PBI_Database=(String) context.getProperty("PBI_Database");
                        }
                        context.setContextType("PBI_PC_Database", "id_String");
                        if(context.getStringValue("PBI_PC_Database") == null) {
                            context.PBI_PC_Database = null;
                        } else {
                            context.PBI_PC_Database=(String) context.getProperty("PBI_PC_Database");
                        }
                        context.setContextType("PBI_RT_Database", "id_String");
                        if(context.getStringValue("PBI_RT_Database") == null) {
                            context.PBI_RT_Database = null;
                        } else {
                            context.PBI_RT_Database=(String) context.getProperty("PBI_RT_Database");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("Salesforce_Name", "id_String");
                        if(context.getStringValue("Salesforce_Name") == null) {
                            context.Salesforce_Name = null;
                        } else {
                            context.Salesforce_Name=(String) context.getProperty("Salesforce_Name");
                        }
                        context.setContextType("Salesforce_Password", "id_Password");
                        if(context.getStringValue("Salesforce_Password") == null) {
                            context.Salesforce_Password = null;
                        } else {
                            String pwd_Salesforce_Password_value = context.getProperty("Salesforce_Password");
                            context.Salesforce_Password = null;
                            if(pwd_Salesforce_Password_value!=null) {
                                if(context_param.containsKey("Salesforce_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Password = pwd_Salesforce_Password_value;
                                } else if (!pwd_Salesforce_Password_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Password_value);
                                        context.put("Salesforce_Password",context.Salesforce_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_Security_Token", "id_Password");
                        if(context.getStringValue("Salesforce_Security_Token") == null) {
                            context.Salesforce_Security_Token = null;
                        } else {
                            String pwd_Salesforce_Security_Token_value = context.getProperty("Salesforce_Security_Token");
                            context.Salesforce_Security_Token = null;
                            if(pwd_Salesforce_Security_Token_value!=null) {
                                if(context_param.containsKey("Salesforce_Security_Token")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Security_Token = pwd_Salesforce_Security_Token_value;
                                } else if (!pwd_Salesforce_Security_Token_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Security_Token = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Security_Token_value);
                                        context.put("Salesforce_Security_Token",context.Salesforce_Security_Token);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_User_ID", "id_String");
                        if(context.getStringValue("Salesforce_User_ID") == null) {
                            context.Salesforce_User_ID = null;
                        } else {
                            context.Salesforce_User_ID=(String) context.getProperty("Salesforce_User_ID");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("ODS_Database")) {
                context.ODS_Database = (String) parentContextMap.get("ODS_Database");
            }if (parentContextMap.containsKey("PBI_Database")) {
                context.PBI_Database = (String) parentContextMap.get("PBI_Database");
            }if (parentContextMap.containsKey("PBI_PC_Database")) {
                context.PBI_PC_Database = (String) parentContextMap.get("PBI_PC_Database");
            }if (parentContextMap.containsKey("PBI_RT_Database")) {
                context.PBI_RT_Database = (String) parentContextMap.get("PBI_RT_Database");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("Salesforce_Name")) {
                context.Salesforce_Name = (String) parentContextMap.get("Salesforce_Name");
            }if (parentContextMap.containsKey("Salesforce_Password")) {
                context.Salesforce_Password = (java.lang.String) parentContextMap.get("Salesforce_Password");
            }if (parentContextMap.containsKey("Salesforce_Security_Token")) {
                context.Salesforce_Security_Token = (java.lang.String) parentContextMap.get("Salesforce_Security_Token");
            }if (parentContextMap.containsKey("Salesforce_User_ID")) {
                context.Salesforce_User_ID = (String) parentContextMap.get("Salesforce_User_ID");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("Salesforce_Password");
			parametersToEncrypt.add("Salesforce_Security_Token");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_PRICING_IMPORT' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs


this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ECOLOTRANS_SALESFORCE_PRICING_IMPORT");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ECOLOTRANS_SALESFORCE_PRICING_IMPORT' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));




            connections.put("tSalesforceConnection_1_connection", globalMap.get("tSalesforceConnection_1_connection"));
            connections.put("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES", globalMap.get("tSalesforceConnection_1_COMPONENT_RUNTIME_PROPERTIES"));


        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     679150 characters generated by Talend Cloud Data Integration 
 *     on the 5 mars 2024 à 14:26:47 WAT
 ************************************************************************************************/
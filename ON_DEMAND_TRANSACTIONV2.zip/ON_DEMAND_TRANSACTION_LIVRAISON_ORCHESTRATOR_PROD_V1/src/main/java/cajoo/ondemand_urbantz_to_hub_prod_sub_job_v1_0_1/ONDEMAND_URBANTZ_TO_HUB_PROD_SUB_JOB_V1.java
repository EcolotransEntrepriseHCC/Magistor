
package cajoo.ondemand_urbantz_to_hub_prod_sub_job_v1_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_11
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 implements TalendJob {
	static {System.setProperty("TalendJob.log", "ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(transaction_id != null){
				
					this.setProperty("transaction_id", transaction_id.toString());
				
			}
			
			if(jobs_to_start != null){
				
					this.setProperty("jobs_to_start", jobs_to_start.toString());
				
			}
			
			if(file_source != null){
				
					this.setProperty("file_source", file_source.toString());
				
			}
			
			if(ondemand_server_directory != null){
				
					this.setProperty("ondemand_server_directory", ondemand_server_directory.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(Hote_Ondemand != null){
				
					this.setProperty("Hote_Ondemand", Hote_Ondemand.toString());
				
			}
			
			if(Ondemand_Database != null){
				
					this.setProperty("Ondemand_Database", Ondemand_Database.toString());
				
			}
			
			if(OnDemand_DB_Password != null){
				
					this.setProperty("OnDemand_DB_Password", OnDemand_DB_Password.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(Port_Ondemand != null){
				
					this.setProperty("Port_Ondemand", Port_Ondemand.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(User_Ondemand != null){
				
					this.setProperty("User_Ondemand", User_Ondemand.toString());
				
			}
			
			if(FTP_Password != null){
				
					this.setProperty("FTP_Password", FTP_Password.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Ondemand_Server_Address != null){
				
					this.setProperty("Ondemand_Server_Address", Ondemand_Server_Address.toString());
				
			}
			
			if(Ondemand_Server_Password != null){
				
					this.setProperty("Ondemand_Server_Password", Ondemand_Server_Password.toString());
				
			}
			
			if(Ondemand_Server_Port != null){
				
					this.setProperty("Ondemand_Server_Port", Ondemand_Server_Port.toString());
				
			}
			
			if(Ondemand_Server_User != null){
				
					this.setProperty("Ondemand_Server_User", Ondemand_Server_User.toString());
				
			}
			
			if(Csv_File_Masque != null){
				
					this.setProperty("Csv_File_Masque", Csv_File_Masque.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String transaction_id;
public String getTransaction_id(){
	return this.transaction_id;
}
public String jobs_to_start;
public String getJobs_to_start(){
	return this.jobs_to_start;
}
public String file_source;
public String getFile_source(){
	return this.file_source;
}
public String ondemand_server_directory;
public String getOndemand_server_directory(){
	return this.ondemand_server_directory;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String Hote_Ondemand;
public String getHote_Ondemand(){
	return this.Hote_Ondemand;
}
public String Ondemand_Database;
public String getOndemand_Database(){
	return this.Ondemand_Database;
}
public java.lang.String OnDemand_DB_Password;
public java.lang.String getOnDemand_DB_Password(){
	return this.OnDemand_DB_Password;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public Integer Port_Ondemand;
public Integer getPort_Ondemand(){
	return this.Port_Ondemand;
}
public String User;
public String getUser(){
	return this.User;
}
public String User_Ondemand;
public String getUser_Ondemand(){
	return this.User_Ondemand;
}
public java.lang.String FTP_Password;
public java.lang.String getFTP_Password(){
	return this.FTP_Password;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Ondemand_Server_Address;
public String getOndemand_Server_Address(){
	return this.Ondemand_Server_Address;
}
public java.lang.String Ondemand_Server_Password;
public java.lang.String getOndemand_Server_Password(){
	return this.Ondemand_Server_Password;
}
public String Ondemand_Server_Port;
public String getOndemand_Server_Port(){
	return this.Ondemand_Server_Port;
}
public String Ondemand_Server_User;
public String getOndemand_Server_User(){
	return this.Ondemand_Server_User;
}
public String Csv_File_Masque;
public String getCsv_File_Masque(){
	return this.Csv_File_Masque;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1";
	private final String projectName = "CAJOO";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Object>());
		
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final java.util.concurrent.ExecutorService es = java.util.concurrent.Executors.newCachedThreadPool();
private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_KDjEMHLHEeyCn7izvFQjtg", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tREST_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRowGenerator_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRowGenerator_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tREST_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRowGenerator_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRowGenerator_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRowGenerator_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWriteJSONField_2_Out_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tWriteJSONField_2_In_error(exception, errorComponent, globalMap);
						
						}
					
			public void tWriteJSONField_2_In_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWriteJSONField_1_Out_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tWriteJSONField_1_In_error(exception, errorComponent, globalMap);
						
						}
					
			public void tWriteJSONField_1_In_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tREST_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tRowGenerator_5Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRowGenerator_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRowGenerator_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tREST_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError3", 0, "error");
						}
					
					errorCode = null;
					tRowGenerator_3Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRowGenerator_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRowGenerator_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWriteJSONField_2_In_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWriteJSONField_1_In_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_1");
		org.slf4j.MDC.put("_subJobPid", "zhPSU7_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";
	
	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_1.append("Parameters:");
                            log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("context.jobs_to_start")+", KEY="+("\"jobs_to_start\"")+"}, {VALUE="+("context.transaction_id")+", KEY="+("\"transaction_id\"")+"}]");
                        log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_1", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

globalMap.put("jobs_to_start", context.jobs_to_start);
globalMap.put("transaction_id", context.transaction_id);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tDBConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "6hHISm_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote_Ondemand");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port_Ondemand");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Ondemand_Database");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User_Ondemand");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.OnDemand_DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote_Ondemand + ":" + context.Port_Ondemand + "/" + context.Ondemand_Database + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User_Ondemand;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.OnDemand_DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Ondemand_Database);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tFixedFlowInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int transactionId;

				public int getTransactionId () {
					return this.transactionId;
				}

				public Boolean transactionIdIsNullable(){
				    return false;
				}
				public Boolean transactionIdIsKey(){
				    return true;
				}
				public Integer transactionIdLength(){
				    return null;
				}
				public Integer transactionIdPrecision(){
				    return null;
				}
				public String transactionIdDefault(){
				
					return null;
				
				}
				public String transactionIdComment(){
				
				    return "";
				
				}
				public String transactionIdPattern(){
				
					return "";
				
				}
				public String transactionIdOriginalDbColumnName(){
				
					return "transactionId";
				
				}

				
			    public String transactionStatus;

				public String getTransactionStatus () {
					return this.transactionStatus;
				}

				public Boolean transactionStatusIsNullable(){
				    return true;
				}
				public Boolean transactionStatusIsKey(){
				    return false;
				}
				public Integer transactionStatusLength(){
				    return null;
				}
				public Integer transactionStatusPrecision(){
				    return null;
				}
				public String transactionStatusDefault(){
				
					return null;
				
				}
				public String transactionStatusComment(){
				
				    return "";
				
				}
				public String transactionStatusPattern(){
				
					return "";
				
				}
				public String transactionStatusOriginalDbColumnName(){
				
					return "transactionStatus";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.transactionId;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.transactionId != other.transactionId)
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.transactionId = this.transactionId;
	            other.transactionStatus = this.transactionStatus;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.transactionId = this.transactionId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.transactionId = dis.readInt();
					
					this.transactionStatus = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.transactionId = dis.readInt();
					
					this.transactionStatus = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.transactionId);
					
					// String
				
						writeString(this.transactionStatus,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.transactionId);
					
					// String
				
						writeString(this.transactionStatus,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("transactionId="+String.valueOf(transactionId));
		sb.append(",transactionStatus="+transactionStatus);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(transactionId);
        			
        			sb.append("|");
        		
        				if(transactionStatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(transactionStatus);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.transactionId, other.transactionId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFixedFlowInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFixedFlowInput_2");
		org.slf4j.MDC.put("_subJobPid", "Tn7GEp_" + subJobPidCounter.getAndIncrement());
	

		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tWriteJSONField_2_Out begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_2_Out", false);
		start_Hash.put("tWriteJSONField_2_Out", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tWriteJSONField_2_Out = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_Out - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWriteJSONField_2_Out{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWriteJSONField_2_Out = new StringBuilder();
                    log4jParamters_tWriteJSONField_2_Out.append("Parameters:");
                            log4jParamters_tWriteJSONField_2_Out.append("GROUPBYS" + " = " + "[]");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("REMOVE_HEADER" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("CREATE" + " = " + "true");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("CREATE_EMPTY_ELEMENT" + " = " + "true");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("EXPAND_EMPTY_ELM" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("ALLOW_EMPTY_STRINGS" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("OUTPUT_AS_XSD" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("COMPACT_FORMAT" + " = " + "true");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("GENERATION_MODE" + " = " + "Dom4j");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                            log4jParamters_tWriteJSONField_2_Out.append("DESTINATION" + " = " + "tWriteJSONField_2");
                        log4jParamters_tWriteJSONField_2_Out.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_Out - "  + (log4jParamters_tWriteJSONField_2_Out) );
                    } 
                } 
            new BytesLimit65535_tWriteJSONField_2_Out().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWriteJSONField_2_Out", "tWriteJSONField_2_Out", "tWriteXMLFieldOut");
				talendJobLogProcess(globalMap);
			}
			
//tWriteXMLFieldOut_begin
				int nb_line_tWriteJSONField_2_Out = 0;
				boolean needRoot_tWriteJSONField_2_Out  = true;
				
				String  strCompCache_tWriteJSONField_2_Out= null;		
				
						        java.util.Queue<row9Struct> listGroupby_tWriteJSONField_2_Out = new java.util.concurrent.ConcurrentLinkedQueue<row9Struct>();
							
	
					class ThreadXMLField_tWriteJSONField_2_Out implements java.lang.Runnable {
						
									    java.util.Queue<row9Struct> queue;
									
						java.util.List<java.util.Map<String,String>> flows;
						java.lang.Exception lastException;
						java.lang.Error lastError;
						String currentComponent;
						
						ThreadXMLField_tWriteJSONField_2_Out(java.util.Queue q) {
							this.queue = q;
							globalMap.put("queue_tWriteJSONField_2_In", queue);
							lastException = null;
						}
						
						ThreadXMLField_tWriteJSONField_2_Out(java.util.Queue q, java.util.List<java.util.Map<String,String>> l) {
							this.queue = q;
							this.flows = l;
							lastException = null;
							globalMap.put("queue_tWriteJSONField_2_In", queue);
							globalMap.put("flows_tWriteJSONField_2_In", flows);
						}
						
						public java.lang.Exception getLastException() {
							return this.lastException;
						}
						
						public java.lang.Error getLastError() {
							return this.lastError;
						}
						
						public String getCurrentComponent() {
							return this.currentComponent;
						}
	
						@Override
						public void run() {
							try {
								tWriteJSONField_2_InProcess(globalMap);
							} catch (TalendException te) {
globalMap.put("tWriteJSONField_2_Out_ERROR_MESSAGE",te.getMessage());
								this.lastException = te.getException();
								this.currentComponent = te.getCurrentComponent();
							} catch (java.lang.Error error) {
								this.lastError = error;
							}
						}
					}
					
						ThreadXMLField_tWriteJSONField_2_Out txf_tWriteJSONField_2_Out = new ThreadXMLField_tWriteJSONField_2_Out(listGroupby_tWriteJSONField_2_Out);
					
					
					java.util.concurrent.Future<?> future_tWriteJSONField_2_Out = es.submit(txf_tWriteJSONField_2_Out);
					globalMap.put("wrtXMLFieldIn_tWriteJSONField_2_Out", future_tWriteJSONField_2_Out);
				

java.util.List<java.util.List<String>> groupbyList_tWriteJSONField_2_Out = new java.util.ArrayList<java.util.List<String>>();
java.util.Map<String,String> valueMap_tWriteJSONField_2_Out = new java.util.HashMap<String,String>();
java.util.Map<String,String> arraysValueMap_tWriteJSONField_2_Out = new java.util.HashMap<String,String>();

class NestXMLTool_tWriteJSONField_2_Out{
	public void parseAndAdd(org.dom4j.Element nestRoot, String value){
		try {
            org.dom4j.Document doc4Str = org.dom4j.DocumentHelper.parseText("<root>"+ value + "</root>");
    		nestRoot.setContent(doc4Str.getRootElement().content());
    	} catch (java.lang.Exception e) {
globalMap.put("tWriteJSONField_2_Out_ERROR_MESSAGE",e.getMessage());
    		e.printStackTrace();
    		nestRoot.setText(value);
        }
	}
	
	public void setText(org.dom4j.Element element, String value){
		if (value.startsWith("<![CDATA[") && value.endsWith("]]>")) {
			String text = value.substring(9, value.length()-3);
			element.addCDATA(text);
		}else{
			element.setText(value);
		}
	}
	
	public void replaceDefaultNameSpace(org.dom4j.Element nestRoot){
		if (nestRoot!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) nestRoot.elements()) {
        		if (("").equals(tmp.getQName().getNamespace().getURI()) && ("").equals(tmp.getQName().getNamespace().getPrefix())){
        			tmp.setQName(org.dom4j.DocumentHelper.createQName(tmp.getName(), nestRoot.getQName().getNamespace()));
	        	}
    	    	replaceDefaultNameSpace(tmp);
       		}
       	}
	}
	
	public void removeEmptyElement(org.dom4j.Element root){
		if (root!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) root.elements()) {
				removeEmptyElement(tmp);
			}

            boolean noSignificantDataAnnotationsExist = root.attributes().isEmpty() ;
            if (root.content().isEmpty()
                && noSignificantDataAnnotationsExist && root.declaredNamespaces().isEmpty()) {
                if(root.getParent()!=null){
                    root.getParent().remove(root);
                }
            }
        }
    }
	public String objectToString(Object value){
		if(value.getClass().isArray()){
			StringBuilder sb = new StringBuilder();

			int length = java.lang.reflect.Array.getLength(value);
			for (int i = 0; i < length; i++) {
				Object obj = java.lang.reflect.Array.get(value, i);
				sb.append("<element>");
				sb.append(obj);
				sb.append("</element>");
			}
			return sb.toString();
		}else{
			return value.toString();
		}
	}
}
NestXMLTool_tWriteJSONField_2_Out nestXMLTool_tWriteJSONField_2_Out = new NestXMLTool_tWriteJSONField_2_Out();

row8Struct  rowStructOutput_tWriteJSONField_2_Out = new row8Struct();
// sort group root element for judgement of group
java.util.List<org.dom4j.Element> groupElementList_tWriteJSONField_2_Out = new java.util.ArrayList<org.dom4j.Element>();
org.dom4j.Element root4Group_tWriteJSONField_2_Out = null;
org.dom4j.Document doc_tWriteJSONField_2_Out  = org.dom4j.DocumentHelper.createDocument();
org.dom4j.io.OutputFormat format_tWriteJSONField_2_Out = org.dom4j.io.OutputFormat.createCompactFormat();
format_tWriteJSONField_2_Out.setNewLineAfterDeclaration(false);
format_tWriteJSONField_2_Out.setTrimText(false);
format_tWriteJSONField_2_Out.setEncoding("ISO-8859-15");
int[] orders_tWriteJSONField_2_Out = new int[1];

 



/**
 * [tWriteJSONField_2_Out begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_2", false);
		start_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_2";
	
	
		int tos_count_tFixedFlowInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFixedFlowInput_2", "tFixedFlowInput_2", "tFixedFlowInput");
				talendJobLogProcess(globalMap);
			}
			

	    for (int i_tFixedFlowInput_2 = 0 ; i_tFixedFlowInput_2 < 1 ; i_tFixedFlowInput_2++) {
	                	            	
    	            		row8.transactionId = Integer.parseInt(context.transaction_id);
    	            	        	            	
    	            		row8.transactionStatus = "En cours";
    	            	

 



/**
 * [tFixedFlowInput_2 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_2 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";
	
	

 


	tos_count_tFixedFlowInput_2++;

/**
 * [tFixedFlowInput_2 main ] stop
 */
	
	/**
	 * [tFixedFlowInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";
	
	

 



/**
 * [tFixedFlowInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tWriteJSONField_2_Out main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tFixedFlowInput_2","tFixedFlowInput_2","tFixedFlowInput","tWriteJSONField_2_Out","tWriteJSONField_2_Out","tWriteXMLFieldOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

	if(txf_tWriteJSONField_2_Out.getLastException()!=null) {
		currentComponent = txf_tWriteJSONField_2_Out.getCurrentComponent();
		throw txf_tWriteJSONField_2_Out.getLastException();
	}
	
	if(txf_tWriteJSONField_2_Out.getLastError()!=null) {
		throw txf_tWriteJSONField_2_Out.getLastError();
	}
	nb_line_tWriteJSONField_2_Out++;
				log.debug("tWriteJSONField_2_Out - Processing the record " + nb_line_tWriteJSONField_2_Out + ".");
			
	class ToStringHelper_tWriteJSONField_2_Out {
	    public String toString(final Object value) {
	        return value != null ? value.toString() : null;
	    }
	}
	final ToStringHelper_tWriteJSONField_2_Out helper_tWriteJSONField_2_Out = new ToStringHelper_tWriteJSONField_2_Out();

	valueMap_tWriteJSONField_2_Out.clear();
	arraysValueMap_tWriteJSONField_2_Out.clear();
	valueMap_tWriteJSONField_2_Out.put("transactionId", helper_tWriteJSONField_2_Out.toString(
	(
            String.valueOf(row8.transactionId)
		)));
	arraysValueMap_tWriteJSONField_2_Out.put("transactionId", helper_tWriteJSONField_2_Out.toString(
	(
            String.valueOf(row8.transactionId)
		)));
	valueMap_tWriteJSONField_2_Out.put("transactionStatus", helper_tWriteJSONField_2_Out.toString(
	(
		row8.transactionStatus != null?
            row8.transactionStatus.toString():null
		)));
	arraysValueMap_tWriteJSONField_2_Out.put("transactionStatus", helper_tWriteJSONField_2_Out.toString(
	(
		row8.transactionStatus != null?
            row8.transactionStatus.toString():null
		)));
		String strTemp_tWriteJSONField_2_Out = "";
	if(strCompCache_tWriteJSONField_2_Out==null){
		strCompCache_tWriteJSONField_2_Out=strTemp_tWriteJSONField_2_Out;
		
	}else{  
    		nestXMLTool_tWriteJSONField_2_Out.replaceDefaultNameSpace(doc_tWriteJSONField_2_Out.getRootElement());			
			java.io.StringWriter strWriter_tWriteJSONField_2_Out = new java.io.StringWriter();	
			org.dom4j.io.XMLWriter output_tWriteJSONField_2_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_2_Out, format_tWriteJSONField_2_Out);
			output_tWriteJSONField_2_Out.write(doc_tWriteJSONField_2_Out);
		    output_tWriteJSONField_2_Out.close();
			
				  		  row9Struct row_tWriteJSONField_2_Out = new row9Struct();
						  
					     		row_tWriteJSONField_2_Out.body = strWriter_tWriteJSONField_2_Out.toString();
					     		listGroupby_tWriteJSONField_2_Out.add(row_tWriteJSONField_2_Out);
					
		    doc_tWriteJSONField_2_Out.clearContent();
			needRoot_tWriteJSONField_2_Out = true;
			for(int i_tWriteJSONField_2_Out=0;i_tWriteJSONField_2_Out<orders_tWriteJSONField_2_Out.length;i_tWriteJSONField_2_Out++){
				orders_tWriteJSONField_2_Out[i_tWriteJSONField_2_Out] = 0;
			}
			
			if(groupbyList_tWriteJSONField_2_Out != null && groupbyList_tWriteJSONField_2_Out.size() >= 0){
				groupbyList_tWriteJSONField_2_Out.clear();
			}
			strCompCache_tWriteJSONField_2_Out=strTemp_tWriteJSONField_2_Out;
	}

	org.dom4j.Element subTreeRootParent_tWriteJSONField_2_Out = null;
	
	// build root xml tree 
	if (needRoot_tWriteJSONField_2_Out) {
		needRoot_tWriteJSONField_2_Out=false;
		org.dom4j.Element root_tWriteJSONField_2_Out = doc_tWriteJSONField_2_Out.addElement("root");
		subTreeRootParent_tWriteJSONField_2_Out = root_tWriteJSONField_2_Out;
		org.dom4j.Element root_0_tWriteJSONField_2_Out = root_tWriteJSONField_2_Out.addElement("transactionStatus");
		if(
		valueMap_tWriteJSONField_2_Out.get("transactionStatus")!=null){
			nestXMLTool_tWriteJSONField_2_Out .setText(root_0_tWriteJSONField_2_Out,
		valueMap_tWriteJSONField_2_Out.get("transactionStatus"));
		}
		root4Group_tWriteJSONField_2_Out = subTreeRootParent_tWriteJSONField_2_Out;
	}else{
		subTreeRootParent_tWriteJSONField_2_Out=root4Group_tWriteJSONField_2_Out;
	}
	// build group xml tree 
	// build loop xml tree
		org.dom4j.Element loop_tWriteJSONField_2_Out = org.dom4j.DocumentHelper.createElement("transactionId");
        if(orders_tWriteJSONField_2_Out[0]==0){
        	orders_tWriteJSONField_2_Out[0] = 0;
        }
        if(1 < orders_tWriteJSONField_2_Out.length){
        		orders_tWriteJSONField_2_Out[1] = 0;
        }
        subTreeRootParent_tWriteJSONField_2_Out.elements().add(orders_tWriteJSONField_2_Out[0]++,loop_tWriteJSONField_2_Out);
		if(
		valueMap_tWriteJSONField_2_Out.get("transactionId")!=null){
			nestXMLTool_tWriteJSONField_2_Out .setText(loop_tWriteJSONField_2_Out,
		valueMap_tWriteJSONField_2_Out.get("transactionId"));
            loop_tWriteJSONField_2_Out.addAttribute("type", "number");
		}

 


	tos_count_tWriteJSONField_2_Out++;

/**
 * [tWriteJSONField_2_Out main ] stop
 */
	
	/**
	 * [tWriteJSONField_2_Out process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	

 



/**
 * [tWriteJSONField_2_Out process_data_begin ] stop
 */
	
	/**
	 * [tWriteJSONField_2_Out process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	

 



/**
 * [tWriteJSONField_2_Out process_data_end ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";
	
	

 



/**
 * [tFixedFlowInput_2 process_data_end ] stop
 */
	
	/**
	 * [tFixedFlowInput_2 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";
	
	

        }
        globalMap.put("tFixedFlowInput_2_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_2", true);
end_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());




/**
 * [tFixedFlowInput_2 end ] stop
 */

	
	/**
	 * [tWriteJSONField_2_Out end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	

if(nb_line_tWriteJSONField_2_Out > 0){  
    nestXMLTool_tWriteJSONField_2_Out.replaceDefaultNameSpace(doc_tWriteJSONField_2_Out.getRootElement());
	java.io.StringWriter strWriter_tWriteJSONField_2_Out = new java.io.StringWriter();
	org.dom4j.io.XMLWriter output_tWriteJSONField_2_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_2_Out, format_tWriteJSONField_2_Out);
	output_tWriteJSONField_2_Out.write(doc_tWriteJSONField_2_Out);
    output_tWriteJSONField_2_Out.close();
					row9Struct row_tWriteJSONField_2_Out = new row9Struct();
						  
					     		row_tWriteJSONField_2_Out.body = strWriter_tWriteJSONField_2_Out.toString();
					     		listGroupby_tWriteJSONField_2_Out.add(row_tWriteJSONField_2_Out);
		    		

}
globalMap.put("tWriteJSONField_2_Out_NB_LINE",nb_line_tWriteJSONField_2_Out);
globalMap.put("tWriteJSONField_2_In_FINISH" + (listGroupby_tWriteJSONField_2_Out==null?"":listGroupby_tWriteJSONField_2_Out.hashCode()), "true");
	
		future_tWriteJSONField_2_Out.get();
		
		if(txf_tWriteJSONField_2_Out.getLastException()!=null) {
			currentComponent = txf_tWriteJSONField_2_Out.getCurrentComponent();
			throw txf_tWriteJSONField_2_Out.getLastException();
		}
		
		if(txf_tWriteJSONField_2_Out.getLastError()!=null) {
			throw txf_tWriteJSONField_2_Out.getLastError();
		}
	
resourceMap.put("finish_tWriteJSONField_2_Out", true);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tFixedFlowInput_2","tFixedFlowInput_2","tFixedFlowInput","tWriteJSONField_2_Out","tWriteJSONField_2_Out","tWriteXMLFieldOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_Out - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_2_Out", true);
end_Hash.put("tWriteJSONField_2_Out", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk", 0, "ok");
				}



/**
 * [tWriteJSONField_2_Out end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tREST_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_2 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";
	
	

 



/**
 * [tFixedFlowInput_2 finally ] stop
 */

	
	/**
	 * [tWriteJSONField_2_Out finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_Out";
	
	

		java.util.Queue listGroupby_tWriteJSONField_2_Out = (java.util.Queue)globalMap.get("queue_tWriteJSONField_2_In");
		if(resourceMap.get("finish_tWriteJSONField_2_Out") == null){
			globalMap.put("tWriteJSONField_2_In_FINISH_WITH_EXCEPTION" + (listGroupby_tWriteJSONField_2_Out==null?"":listGroupby_tWriteJSONField_2_Out.hashCode()), "true");
		}
	
	if (listGroupby_tWriteJSONField_2_Out != null) {
		globalMap.put("tWriteJSONField_2_In_FINISH" + (listGroupby_tWriteJSONField_2_Out==null?"":listGroupby_tWriteJSONField_2_Out.hashCode()), "true");
	}
	// workaround for 37349 - in case of normal execution it will pass normally
	// in case it fails and handle by catch - it will wait for child thread finish
	java.util.concurrent.Future<?> future_tWriteJSONField_2_Out = (java.util.concurrent.Future) globalMap.get("wrtXMLFieldIn_tWriteJSONField_2_Out");
	if (future_tWriteJSONField_2_Out != null) {
		future_tWriteJSONField_2_Out.get();
	}

 



/**
 * [tWriteJSONField_2_Out finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String ResponseMessage;

				public String getResponseMessage () {
					return this.ResponseMessage;
				}

				public Boolean ResponseMessageIsNullable(){
				    return true;
				}
				public Boolean ResponseMessageIsKey(){
				    return false;
				}
				public Integer ResponseMessageLength(){
				    return null;
				}
				public Integer ResponseMessagePrecision(){
				    return null;
				}
				public String ResponseMessageDefault(){
				
					return null;
				
				}
				public String ResponseMessageComment(){
				
				    return "";
				
				}
				public String ResponseMessagePattern(){
				
					return "";
				
				}
				public String ResponseMessageOriginalDbColumnName(){
				
					return "ResponseMessage";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.ResponseMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.ResponseMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.ResponseMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.ResponseMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ResponseMessage="+ResponseMessage);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(ResponseMessage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ResponseMessage);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}

				public Boolean BodyIsNullable(){
				    return true;
				}
				public Boolean BodyIsKey(){
				    return false;
				}
				public Integer BodyLength(){
				    return 0;
				}
				public Integer BodyPrecision(){
				    return 0;
				}
				public String BodyDefault(){
				
					return "";
				
				}
				public String BodyComment(){
				
				    return null;
				
				}
				public String BodyPattern(){
				
				    return null;
				
				}
				public String BodyOriginalDbColumnName(){
				
					return "Body";
				
				}

				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}

				public Boolean ERROR_CODEIsNullable(){
				    return true;
				}
				public Boolean ERROR_CODEIsKey(){
				    return false;
				}
				public Integer ERROR_CODELength(){
				    return 0;
				}
				public Integer ERROR_CODEPrecision(){
				    return 0;
				}
				public String ERROR_CODEDefault(){
				
					return "";
				
				}
				public String ERROR_CODEComment(){
				
				    return null;
				
				}
				public String ERROR_CODEPattern(){
				
				    return null;
				
				}
				public String ERROR_CODEOriginalDbColumnName(){
				
					return "ERROR_CODE";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tREST_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tREST_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tREST_2");
		org.slf4j.MDC.put("_subJobPid", "m4Dwgu_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();
row11Struct row11 = new row11Struct();





	
	/**
	 * [tJava_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_11", false);
		start_Hash.put("tJava_11", System.currentTimeMillis());
		
	
	currentComponent="tJava_11";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row11");
			
		int tos_count_tJava_11 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_11", "tJava_11", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_11 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_2", false);
		start_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row10");
			
		int tos_count_tExtractJSONFields_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_2 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_2.append("Parameters:");
                            log4jParamters_tExtractJSONFields_2.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("JSONFIELD" + " = " + "Body");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("JSON_LOOP_QUERY" + " = " + "\"$\"");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"$.message\"")+", SCHEMA_COLUMN="+("ResponseMessage")+"}]");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                            log4jParamters_tExtractJSONFields_2.append("USE_LOOP_AS_ROOT" + " = " + "true");
                        log4jParamters_tExtractJSONFields_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_2 - "  + (log4jParamters_tExtractJSONFields_2) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_2", "tExtractJSONFields_2", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_2 = 0;
String jsonStr_tExtractJSONFields_2 = "";

	

class JsonPathCache_tExtractJSONFields_2 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_2 jsonPathCache_tExtractJSONFields_2 = new JsonPathCache_tExtractJSONFields_2();

 



/**
 * [tExtractJSONFields_2 begin ] stop
 */



	
	/**
	 * [tREST_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tREST_2", false);
		start_Hash.put("tREST_2", System.currentTimeMillis());
		
	
	currentComponent="tREST_2";
	
	
		int tos_count_tREST_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tREST_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tREST_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tREST_2 = new StringBuilder();
                    log4jParamters_tREST_2.append("Parameters:");
                            log4jParamters_tREST_2.append("URL" + " = " + "\"http://\" + context.Hote_Ondemand + \":8000/talendEsb/updateMetaDataFileInTableTransactionsLivraison\"");
                        log4jParamters_tREST_2.append(" | ");
                            log4jParamters_tREST_2.append("METHOD" + " = " + "POST");
                        log4jParamters_tREST_2.append(" | ");
                            log4jParamters_tREST_2.append("HEADERS" + " = " + "[{VALUE="+("\"application/json\"")+", NAME="+("\"content-type\"")+"}]");
                        log4jParamters_tREST_2.append(" | ");
                            log4jParamters_tREST_2.append("BODY" + " = " + "(String)globalMap.get(\"rest_api_body\")");
                        log4jParamters_tREST_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tREST_2 - "  + (log4jParamters_tREST_2) );
                    } 
                } 
            new BytesLimit65535_tREST_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tREST_2", "tREST_2", "tREST");
				talendJobLogProcess(globalMap);
			}
			
	

	
	String endpoint_tREST_2 = "http://" + context.Hote_Ondemand + ":8000/talendEsb/updateMetaDataFileInTableTransactionsLivraison";
	
	String trustStoreFile_tREST_2 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_tREST_2 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_tREST_2 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_tREST_2 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_tREST_2 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_tREST_2 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_tREST_2 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	
	// APPINT-33909: add entitiy providers (for OSGi deployment)
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.StringProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.ByteArrayProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.FileProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.InputStreamProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.DataSourceProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.MimeMultipartProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.FormProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.ReaderProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.DocumentProvider.class);
	config_tREST_2.getClasses().add(com.sun.jersey.core.impl.provider.entity.StreamingOutputProvider.class);
	
	javax.net.ssl.SSLContext ctx_tREST_2 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_tREST_2 = null;
	if(trustStoreFile_tREST_2!=null && trustStoreType_tREST_2!=null){
		char[] password_tREST_2 = null;
		if(trustStorePWD_tREST_2!=null)
			password_tREST_2 = trustStorePWD_tREST_2.toCharArray();
		java.security.KeyStore trustStore_tREST_2 = java.security.KeyStore.getInstance(trustStoreType_tREST_2);
		trustStore_tREST_2.load(new java.io.FileInputStream(trustStoreFile_tREST_2), password_tREST_2);
		
		javax.net.ssl.TrustManagerFactory tmf_tREST_2 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_tREST_2.init(trustStore_tREST_2);
        tms_tREST_2 = tmf_tREST_2.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_tREST_2 = null;
	if(keyStoreFile_tREST_2!=null && keyStoreType_tREST_2!=null){
		char[] password_tREST_2 = null;
		if(keyStorePWD_tREST_2!=null)
			password_tREST_2 = keyStorePWD_tREST_2.toCharArray();
		java.security.KeyStore keyStore_tREST_2 = java.security.KeyStore.getInstance(keyStoreType_tREST_2);
		keyStore_tREST_2.load(new java.io.FileInputStream(keyStoreFile_tREST_2), password_tREST_2);
		
		javax.net.ssl.KeyManagerFactory kmf_tREST_2 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_tREST_2.init(keyStore_tREST_2,password_tREST_2);
        kms_tREST_2 = kmf_tREST_2.getKeyManagers();
	}
	
    ctx_tREST_2.init(kms_tREST_2, tms_tREST_2 , null);
    config_tREST_2.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_tREST_2));

	com.sun.jersey.api.client.Client restClient_tREST_2 = com.sun.jersey.api.client.Client.create(config_tREST_2);
	
	java.util.Map<String, Object> headers_tREST_2 = new java.util.HashMap<String, Object>();
	
    	headers_tREST_2.put("content-type","application/json");
	
	
	Object transfer_encoding_tREST_2 = headers_tREST_2.get("Transfer-Encoding");
	if(transfer_encoding_tREST_2!=null && "chunked".equals(transfer_encoding_tREST_2)) {
		restClient_tREST_2.setChunkedEncodingSize(4096);
	}
	
	com.sun.jersey.api.client.WebResource restResource_tREST_2;
	if(endpoint_tREST_2!=null && !("").equals(endpoint_tREST_2)){
		restResource_tREST_2 = restClient_tREST_2.resource(endpoint_tREST_2);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_tREST_2 = null;
	String restResponse_tREST_2 = "";
	try{
		
                if(log.isInfoEnabled())
            log.info("tREST_2 - "  + ("Prepare to send request to rest server.") );
		com.sun.jersey.api.client.WebResource.Builder builder_tREST_2 = null;
		for(java.util.Map.Entry<String, Object> header_tREST_2 : headers_tREST_2.entrySet()) {
			if(builder_tREST_2 == null) {
				builder_tREST_2 = restResource_tREST_2.header(header_tREST_2.getKey(), header_tREST_2.getValue());
			} else {
				builder_tREST_2.header(header_tREST_2.getKey(), header_tREST_2.getValue());
			}
		}
		
		
			if(builder_tREST_2!=null) {
				restResponse_tREST_2 = builder_tREST_2.post(String.class,(String)globalMap.get("rest_api_body"));
			} else {
				restResponse_tREST_2 = restResource_tREST_2.post(String.class,(String)globalMap.get("rest_api_body"));
			}
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
globalMap.put("tREST_2_ERROR_MESSAGE",ue.getMessage());
        errorResponse_tREST_2 = ue.getResponse();
    }
	
                if(log.isInfoEnabled())
            log.info("tREST_2 - "  + ("Has sent request to rest server.") );
	// for output
			
				row10 = new row10Struct();
				if(errorResponse_tREST_2!=null){
					row10.ERROR_CODE = errorResponse_tREST_2.getStatus();
					if(row10.ERROR_CODE!=204){
					    row10.Body = errorResponse_tREST_2.getEntity(String.class);
					}
				}else{
					row10.Body = restResponse_tREST_2;
				}
			

 



/**
 * [tREST_2 begin ] stop
 */
	
	/**
	 * [tREST_2 main ] start
	 */

	

	
	
	currentComponent="tREST_2";
	
	

 


	tos_count_tREST_2++;

/**
 * [tREST_2 main ] stop
 */
	
	/**
	 * [tREST_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tREST_2";
	
	

 



/**
 * [tREST_2 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row10","tREST_2","tREST_2","tREST","tExtractJSONFields_2","tExtractJSONFields_2","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		

            if(row10.Body!=null){// C_01
                jsonStr_tExtractJSONFields_2 = row10.Body.toString();
   
row11 = null;

	

String loopPath_tExtractJSONFields_2 = "$";
java.util.List<Object> resultset_tExtractJSONFields_2 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_2 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_2 = null;
try {
	document_tExtractJSONFields_2 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_2);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(loopPath_tExtractJSONFields_2);
	Object result_tExtractJSONFields_2 = document_tExtractJSONFields_2.read(compiledLoopPath_tExtractJSONFields_2,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_2 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_2 = (net.minidev.json.JSONArray) result_tExtractJSONFields_2;
	} else {
		resultset_tExtractJSONFields_2.add(result_tExtractJSONFields_2);
	}
	
	isStructError_tExtractJSONFields_2 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",ex_tExtractJSONFields_2.getMessage());
		log.error("tExtractJSONFields_2 - " + ex_tExtractJSONFields_2.getMessage());
		System.err.println(ex_tExtractJSONFields_2.getMessage());
}

String jsonPath_tExtractJSONFields_2 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_2 = null;

Object value_tExtractJSONFields_2 = null;

Object root_tExtractJSONFields_2 = null;
for(int i_tExtractJSONFields_2=0; isStructError_tExtractJSONFields_2 || (i_tExtractJSONFields_2 < resultset_tExtractJSONFields_2.size());i_tExtractJSONFields_2++){
	if(!isStructError_tExtractJSONFields_2){
		Object row_tExtractJSONFields_2 = resultset_tExtractJSONFields_2.get(i_tExtractJSONFields_2);
            row11 = null;
	row11 = new row11Struct();
	nb_line_tExtractJSONFields_2++;
	try {
		jsonPath_tExtractJSONFields_2 = "$.message";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row11.ResponseMessage = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row11.ResponseMessage = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",ex_tExtractJSONFields_2.getMessage());
			log.error("tExtractJSONFields_2 - " + ex_tExtractJSONFields_2.getMessage());
		    System.err.println(ex_tExtractJSONFields_2.getMessage());
		    row11 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_2 = false;
	
	log.debug("tExtractJSONFields_2 - Extracting the record " + nb_line_tExtractJSONFields_2 + ".");
//}


 


	tos_count_tExtractJSONFields_2++;

/**
 * [tExtractJSONFields_2 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";
	
	

 



/**
 * [tExtractJSONFields_2 process_data_begin ] stop
 */
// Start of branch "row11"
if(row11 != null) { 



	
	/**
	 * [tJava_11 main ] start
	 */

	

	
	
	currentComponent="tJava_11";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row11","tExtractJSONFields_2","tExtractJSONFields_2","tExtractJSONFields","tJava_11","tJava_11","tJava"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		

 


	tos_count_tJava_11++;

/**
 * [tJava_11 main ] stop
 */
	
	/**
	 * [tJava_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_11";
	
	

 



/**
 * [tJava_11 process_data_begin ] stop
 */
	
	/**
	 * [tJava_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_11";
	
	

 



/**
 * [tJava_11 process_data_end ] stop
 */

} // End of branch "row11"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";
	
	

 



/**
 * [tExtractJSONFields_2 process_data_end ] stop
 */



	
	/**
	 * [tREST_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tREST_2";
	
	

 



/**
 * [tREST_2 process_data_end ] stop
 */
	
	/**
	 * [tREST_2 end ] start
	 */

	

	
	
	currentComponent="tREST_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tREST_2 - "  + ("Done.") );

ok_Hash.put("tREST_2", true);
end_Hash.put("tREST_2", System.currentTimeMillis());




/**
 * [tREST_2 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";
	
	
   globalMap.put("tExtractJSONFields_2_NB_LINE", nb_line_tExtractJSONFields_2);
	log.debug("tExtractJSONFields_2 - Extracted records count: " + nb_line_tExtractJSONFields_2 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row10",2,0,
			 			"tREST_2","tREST_2","tREST","tExtractJSONFields_2","tExtractJSONFields_2","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_2 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_2", true);
end_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());




/**
 * [tExtractJSONFields_2 end ] stop
 */

	
	/**
	 * [tJava_11 end ] start
	 */

	

	
	
	currentComponent="tJava_11";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row11",2,0,
			 			"tExtractJSONFields_2","tExtractJSONFields_2","tExtractJSONFields","tJava_11","tJava_11","tJava","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJava_11", true);
end_Hash.put("tJava_11", System.currentTimeMillis());

   			if (row11.ResponseMessage == null || !row11.ResponseMessage.equals("done")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				tRowGenerator_4Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}



/**
 * [tJava_11 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tREST_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tDBInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tREST_2 finally ] start
	 */

	

	
	
	currentComponent="tREST_2";
	
	

 



/**
 * [tREST_2 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";
	
	

 



/**
 * [tExtractJSONFields_2 finally ] stop
 */

	
	/**
	 * [tJava_11 finally ] start
	 */

	

	
	
	currentComponent="tJava_11";
	
	

 



/**
 * [tJava_11 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tREST_2_SUBPROCESS_STATE", 1);
	}
	


public static class row66Struct implements routines.system.IPersistableRow<row66Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return null;
				}
				public Integer idPrecision(){
				    return null;
				}
				public String idDefault(){
				
					return "";
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String statut;

				public String getStatut () {
					return this.statut;
				}

				public Boolean statutIsNullable(){
				    return true;
				}
				public Boolean statutIsKey(){
				    return false;
				}
				public Integer statutLength(){
				    return null;
				}
				public Integer statutPrecision(){
				    return null;
				}
				public String statutDefault(){
				
					return null;
				
				}
				public String statutComment(){
				
				    return "";
				
				}
				public String statutPattern(){
				
					return "";
				
				}
				public String statutOriginalDbColumnName(){
				
					return "statut";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row66Struct other = (row66Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row66Struct other) {

		other.id = this.id;
	            other.statut = this.statut;
	            
	}

	public void copyKeysDataTo(row66Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",statut="+statut);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(statut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statut);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row66Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String newColumn;

				public String getNewColumn () {
					return this.newColumn;
				}

				public Boolean newColumnIsNullable(){
				    return true;
				}
				public Boolean newColumnIsKey(){
				    return false;
				}
				public Integer newColumnLength(){
				    return null;
				}
				public Integer newColumnPrecision(){
				    return null;
				}
				public String newColumnDefault(){
				
					return null;
				
				}
				public String newColumnComment(){
				
				    return "";
				
				}
				public String newColumnPattern(){
				
					return "";
				
				}
				public String newColumnOriginalDbColumnName(){
				
					return "newColumn";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("newColumn="+newColumn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(newColumn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(newColumn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tRowGenerator_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRowGenerator_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRowGenerator_4");
		org.slf4j.MDC.put("_subJobPid", "0QXghj_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();
row66Struct row66 = new row66Struct();





	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row66");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"transactions_livraison\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "UPDATE");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "\"transactions_livraison\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_5 = 1;
        if(updateKeyCount_tDBOutput_5 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_5 == 2 && true) {        
                throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

String tableName_tDBOutput_5 = "transactions_livraison";
boolean whetherReject_tDBOutput_5 = false;

java.util.Calendar calendar_tDBOutput_5 = java.util.Calendar.getInstance();
calendar_tDBOutput_5.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
calendar_tDBOutput_5.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
long date_tDBOutput_5;

java.sql.Connection conn_tDBOutput_5 = null;
		conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );
		int batchSize_tDBOutput_5 = 10000;
		int batchSizeCounter_tDBOutput_5=0;
	

		int count_tDBOutput_5=0;
		
				
			
				String update_tDBOutput_5 = "UPDATE `" + "transactions_livraison" + "` SET `statut` = ? WHERE `id` = ?";
				
				java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(update_tDBOutput_5);
				resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
				


 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_5", false);
		start_Hash.put("tMap_5", System.currentTimeMillis());
		
	
	currentComponent="tMap_5";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row12");
			
		int tos_count_tMap_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_5 = new StringBuilder();
                    log4jParamters_tMap_5.append("Parameters:");
                            log4jParamters_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + (log4jParamters_tMap_5) );
                    } 
                } 
            new BytesLimit65535_tMap_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_5", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row12_tMap_5 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_5__Struct  {
}
Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row66_tMap_5 = 0;
				
row66Struct row66_tmp = new row66Struct();
// ###############################

        
        



        









 



/**
 * [tMap_5 begin ] stop
 */



	
	/**
	 * [tRowGenerator_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRowGenerator_4", false);
		start_Hash.put("tRowGenerator_4", System.currentTimeMillis());
		
	
	currentComponent="tRowGenerator_4";
	
	
		int tos_count_tRowGenerator_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRowGenerator_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRowGenerator_4 = new StringBuilder();
                    log4jParamters_tRowGenerator_4.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_4 - "  + (log4jParamters_tRowGenerator_4) );
                    } 
                } 
            new BytesLimit65535_tRowGenerator_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRowGenerator_4", "tRowGenerator_2", "tRowGenerator");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tRowGenerator_4 = 0;
int nb_max_row_tRowGenerator_4 = 1;


class tRowGenerator_4Randomizer {
	public String getRandomnewColumn() {
		
		return TalendString.getAsciiRandomString(6);
		
	}
}
	tRowGenerator_4Randomizer randtRowGenerator_4 = new tRowGenerator_4Randomizer();
	
    	log.info("tRowGenerator_4 - Generating records.");
	for (int itRowGenerator_4=0; itRowGenerator_4<nb_max_row_tRowGenerator_4 ;itRowGenerator_4++) {
		row12.newColumn = randtRowGenerator_4.getRandomnewColumn();
		nb_line_tRowGenerator_4++;
		
			log.debug("tRowGenerator_4 - Retrieving the record " + nb_line_tRowGenerator_4 + ".");
		

 



/**
 * [tRowGenerator_4 begin ] stop
 */
	
	/**
	 * [tRowGenerator_4 main ] start
	 */

	

	
	
	currentComponent="tRowGenerator_4";
	
	

 


	tos_count_tRowGenerator_4++;

/**
 * [tRowGenerator_4 main ] stop
 */
	
	/**
	 * [tRowGenerator_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRowGenerator_4";
	
	

 



/**
 * [tRowGenerator_4 process_data_begin ] stop
 */

	
	/**
	 * [tMap_5 main ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row12","tRowGenerator_4","tRowGenerator_2","tRowGenerator","tMap_5","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_5 = false;
		boolean mainRowRejected_tMap_5 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
        // ###############################
        // # Output tables

row66 = null;


// # Output table : 'row66'
count_row66_tMap_5++;

row66_tmp.id = Integer.parseInt(context.transaction_id) ;
row66_tmp.statut = "En cours" ;
row66 = row66_tmp;
log.debug("tMap_5 - Outputting the record " + count_row66_tMap_5 + " of the output table 'row66'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_5 = false;










 


	tos_count_tMap_5++;

/**
 * [tMap_5 main ] stop
 */
	
	/**
	 * [tMap_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 process_data_begin ] stop
 */
// Start of branch "row66"
if(row66 != null) { 



	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row66","tMap_5","tMap_2","tMap","tDBOutput_5","\"transactions_livraison\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row66 - " + (row66==null? "": row66.toLogString()));
    			}
    		



        whetherReject_tDBOutput_5 = false;
                    if(row66.statut == null) {
pstmt_tDBOutput_5.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(1, row66.statut);
}


                    pstmt_tDBOutput_5.setInt(2 + count_tDBOutput_5, row66.id);


            pstmt_tDBOutput_5.addBatch();
            nb_line_tDBOutput_5++;

                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("UPDATE")  + (" batch.") );
                  batchSizeCounter_tDBOutput_5++;
                if ( batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5) {
                        try {
                                int countSum_tDBOutput_5 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
                                for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
                                    countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
                                }
                                rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
                                updatedCount_tDBOutput_5 += countSum_tDBOutput_5;
                                batchSizeCounter_tDBOutput_5 = 0;
                        }catch (java.sql.BatchUpdateException e){
                            globalMap.put("tDBOutput_5_ERROR_MESSAGE",e.getMessage());
                            int countSum_tDBOutput_5 = 0;
                            for(int countEach_tDBOutput_5: e.getUpdateCounts()) {
                                countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
                            }
                            rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
                            updatedCount_tDBOutput_5 += countSum_tDBOutput_5;
                            System.err.println(e.getMessage());
            log.error("tDBOutput_5 - "  + (e.getMessage()) );
                        }
                }

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */

} // End of branch "row66"




	
	/**
	 * [tMap_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 process_data_end ] stop
 */



	
	/**
	 * [tRowGenerator_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_4";
	
	

 



/**
 * [tRowGenerator_4 process_data_end ] stop
 */
	
	/**
	 * [tRowGenerator_4 end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_4";
	
	

}
globalMap.put("tRowGenerator_4_NB_LINE",nb_line_tRowGenerator_4);
	log.info("tRowGenerator_4 - Generated records count:" + nb_line_tRowGenerator_4 + " .");

 
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_4 - "  + ("Done.") );

ok_Hash.put("tRowGenerator_4", true);
end_Hash.put("tRowGenerator_4", System.currentTimeMillis());




/**
 * [tRowGenerator_4 end ] stop
 */

	
	/**
	 * [tMap_5 end ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_5 - Written records count in the table 'row66': " + count_row66_tMap_5 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row12",2,0,
			 			"tRowGenerator_4","tRowGenerator_2","tRowGenerator","tMap_5","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Done.") );

ok_Hash.put("tMap_5", true);
end_Hash.put("tMap_5", System.currentTimeMillis());




/**
 * [tMap_5 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		



		
			try {
				if(pstmt_tDBOutput_5 != null){
					int countSum_tDBOutput_5 = 0;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
					
						updatedCount_tDBOutput_5 += countSum_tDBOutput_5;
					
				}
			}catch (java.sql.BatchUpdateException e){
				globalMap.put("tDBOutput_5_ERROR_MESSAGE",e.getMessage());
				
					int countSum_tDBOutput_5 = 0;
					for(int countEach_tDBOutput_5: e.getUpdateCounts()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
					
						updatedCount_tDBOutput_5 += countSum_tDBOutput_5;
						
            log.error("tDBOutput_5 - "  + (e.getMessage()) );
					System.err.println(e.getMessage());
					
			}
			

		if(pstmt_tDBOutput_5 != null) {
			
				pstmt_tDBOutput_5.close();
				resourceMap.remove("pstmt_tDBOutput_5");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_5", true);
	

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Has ")  + ("updated")  + (" ")  + (nb_line_update_tDBOutput_5)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row66",2,0,
			 			"tMap_5","tMap_2","tMap","tDBOutput_5","\"transactions_livraison\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRowGenerator_4 finally ] start
	 */

	

	
	
	currentComponent="tRowGenerator_4";
	
	

 



/**
 * [tRowGenerator_4 finally ] stop
 */

	
	/**
	 * [tMap_5 finally ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"transactions_livraison\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRowGenerator_4_SUBPROCESS_STATE", 1);
	}
	


public static class row65Struct implements routines.system.IPersistableRow<row65Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return null;
				}
				public Integer idPrecision(){
				    return null;
				}
				public String idDefault(){
				
					return "";
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String statut;

				public String getStatut () {
					return this.statut;
				}

				public Boolean statutIsNullable(){
				    return true;
				}
				public Boolean statutIsKey(){
				    return false;
				}
				public Integer statutLength(){
				    return null;
				}
				public Integer statutPrecision(){
				    return null;
				}
				public String statutDefault(){
				
					return null;
				
				}
				public String statutComment(){
				
				    return "";
				
				}
				public String statutPattern(){
				
					return "";
				
				}
				public String statutOriginalDbColumnName(){
				
					return "statut";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row65Struct other = (row65Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row65Struct other) {

		other.id = this.id;
	            other.statut = this.statut;
	            
	}

	public void copyKeysDataTo(row65Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",statut="+statut);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(statut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statut);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row65Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String newColumn;

				public String getNewColumn () {
					return this.newColumn;
				}

				public Boolean newColumnIsNullable(){
				    return true;
				}
				public Boolean newColumnIsKey(){
				    return false;
				}
				public Integer newColumnLength(){
				    return null;
				}
				public Integer newColumnPrecision(){
				    return null;
				}
				public String newColumnDefault(){
				
					return "";
				
				}
				public String newColumnComment(){
				
				    return "";
				
				}
				public String newColumnPattern(){
				
					return "";
				
				}
				public String newColumnOriginalDbColumnName(){
				
					return "newColumn";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("newColumn="+newColumn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(newColumn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(newColumn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tRowGenerator_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRowGenerator_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRowGenerator_5");
		org.slf4j.MDC.put("_subJobPid", "JSLnzc_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();
row65Struct row65 = new row65Struct();





	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row65");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"transactions_livraison\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "UPDATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "\"transactions_livraison\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_4 = 1;
        if(updateKeyCount_tDBOutput_4 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_4 == 2 && true) {        
                throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

String tableName_tDBOutput_4 = "transactions_livraison";
boolean whetherReject_tDBOutput_4 = false;

java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
calendar_tDBOutput_4.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
calendar_tDBOutput_4.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
long date_tDBOutput_4;

java.sql.Connection conn_tDBOutput_4 = null;
		conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );
		int batchSize_tDBOutput_4 = 10000;
		int batchSizeCounter_tDBOutput_4=0;
	

		int count_tDBOutput_4=0;
		
				
			
				String update_tDBOutput_4 = "UPDATE `" + "transactions_livraison" + "` SET `statut` = ? WHERE `id` = ?";
				
				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(update_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
				


 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tMap_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_6", false);
		start_Hash.put("tMap_6", System.currentTimeMillis());
		
	
	currentComponent="tMap_6";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row13");
			
		int tos_count_tMap_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_6 = new StringBuilder();
                    log4jParamters_tMap_6.append("Parameters:");
                            log4jParamters_tMap_6.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + (log4jParamters_tMap_6) );
                    } 
                } 
            new BytesLimit65535_tMap_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_6", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row13_tMap_6 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_6__Struct  {
}
Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row65_tMap_6 = 0;
				
row65Struct row65_tmp = new row65Struct();
// ###############################

        
        



        









 



/**
 * [tMap_6 begin ] stop
 */



	
	/**
	 * [tRowGenerator_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tRowGenerator_5", false);
		start_Hash.put("tRowGenerator_5", System.currentTimeMillis());
		
	
	currentComponent="tRowGenerator_5";
	
	
		int tos_count_tRowGenerator_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRowGenerator_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRowGenerator_5 = new StringBuilder();
                    log4jParamters_tRowGenerator_5.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_5 - "  + (log4jParamters_tRowGenerator_5) );
                    } 
                } 
            new BytesLimit65535_tRowGenerator_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRowGenerator_5", "tRowGenerator_2", "tRowGenerator");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tRowGenerator_5 = 0;
int nb_max_row_tRowGenerator_5 = 1;


class tRowGenerator_5Randomizer {
	public String getRandomnewColumn() {
		
		return TalendString.getAsciiRandomString(6);
		
	}
}
	tRowGenerator_5Randomizer randtRowGenerator_5 = new tRowGenerator_5Randomizer();
	
    	log.info("tRowGenerator_5 - Generating records.");
	for (int itRowGenerator_5=0; itRowGenerator_5<nb_max_row_tRowGenerator_5 ;itRowGenerator_5++) {
		row13.newColumn = randtRowGenerator_5.getRandomnewColumn();
		nb_line_tRowGenerator_5++;
		
			log.debug("tRowGenerator_5 - Retrieving the record " + nb_line_tRowGenerator_5 + ".");
		

 



/**
 * [tRowGenerator_5 begin ] stop
 */
	
	/**
	 * [tRowGenerator_5 main ] start
	 */

	

	
	
	currentComponent="tRowGenerator_5";
	
	

 


	tos_count_tRowGenerator_5++;

/**
 * [tRowGenerator_5 main ] stop
 */
	
	/**
	 * [tRowGenerator_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRowGenerator_5";
	
	

 



/**
 * [tRowGenerator_5 process_data_begin ] stop
 */

	
	/**
	 * [tMap_6 main ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row13","tRowGenerator_5","tRowGenerator_2","tRowGenerator","tMap_6","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_6 = false;
		boolean mainRowRejected_tMap_6 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
        // ###############################
        // # Output tables

row65 = null;


// # Output table : 'row65'
count_row65_tMap_6++;

row65_tmp.id = Integer.parseInt(context.transaction_id) ;
row65_tmp.statut = "En cours" ;
row65 = row65_tmp;
log.debug("tMap_6 - Outputting the record " + count_row65_tMap_6 + " of the output table 'row65'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_6 = false;










 


	tos_count_tMap_6++;

/**
 * [tMap_6 main ] stop
 */
	
	/**
	 * [tMap_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 process_data_begin ] stop
 */
// Start of branch "row65"
if(row65 != null) { 



	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row65","tMap_6","tMap_2","tMap","tDBOutput_4","\"transactions_livraison\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row65 - " + (row65==null? "": row65.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    if(row65.statut == null) {
pstmt_tDBOutput_4.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(1, row65.statut);
}


                    pstmt_tDBOutput_4.setInt(2 + count_tDBOutput_4, row65.id);


            pstmt_tDBOutput_4.addBatch();
            nb_line_tDBOutput_4++;

                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("UPDATE")  + (" batch.") );
                  batchSizeCounter_tDBOutput_4++;
                if ( batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4) {
                        try {
                                int countSum_tDBOutput_4 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
                                for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
                                    countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
                                }
                                rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
                                updatedCount_tDBOutput_4 += countSum_tDBOutput_4;
                                batchSizeCounter_tDBOutput_4 = 0;
                        }catch (java.sql.BatchUpdateException e){
                            globalMap.put("tDBOutput_4_ERROR_MESSAGE",e.getMessage());
                            int countSum_tDBOutput_4 = 0;
                            for(int countEach_tDBOutput_4: e.getUpdateCounts()) {
                                countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
                            }
                            rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
                            updatedCount_tDBOutput_4 += countSum_tDBOutput_4;
                            System.err.println(e.getMessage());
            log.error("tDBOutput_4 - "  + (e.getMessage()) );
                        }
                }

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */

} // End of branch "row65"




	
	/**
	 * [tMap_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 process_data_end ] stop
 */



	
	/**
	 * [tRowGenerator_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_5";
	
	

 



/**
 * [tRowGenerator_5 process_data_end ] stop
 */
	
	/**
	 * [tRowGenerator_5 end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_5";
	
	

}
globalMap.put("tRowGenerator_5_NB_LINE",nb_line_tRowGenerator_5);
	log.info("tRowGenerator_5 - Generated records count:" + nb_line_tRowGenerator_5 + " .");

 
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_5 - "  + ("Done.") );

ok_Hash.put("tRowGenerator_5", true);
end_Hash.put("tRowGenerator_5", System.currentTimeMillis());




/**
 * [tRowGenerator_5 end ] stop
 */

	
	/**
	 * [tMap_6 end ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_6 - Written records count in the table 'row65': " + count_row65_tMap_6 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row13",2,0,
			 			"tRowGenerator_5","tRowGenerator_2","tRowGenerator","tMap_6","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Done.") );

ok_Hash.put("tMap_6", true);
end_Hash.put("tMap_6", System.currentTimeMillis());




/**
 * [tMap_6 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		



		
			try {
				if(pstmt_tDBOutput_4 != null){
					int countSum_tDBOutput_4 = 0;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
					
						updatedCount_tDBOutput_4 += countSum_tDBOutput_4;
					
				}
			}catch (java.sql.BatchUpdateException e){
				globalMap.put("tDBOutput_4_ERROR_MESSAGE",e.getMessage());
				
					int countSum_tDBOutput_4 = 0;
					for(int countEach_tDBOutput_4: e.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
					
						updatedCount_tDBOutput_4 += countSum_tDBOutput_4;
						
            log.error("tDBOutput_4 - "  + (e.getMessage()) );
					System.err.println(e.getMessage());
					
			}
			

		if(pstmt_tDBOutput_4 != null) {
			
				pstmt_tDBOutput_4.close();
				resourceMap.remove("pstmt_tDBOutput_4");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_4", true);
	

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("updated")  + (" ")  + (nb_line_update_tDBOutput_4)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row65",2,0,
			 			"tMap_6","tMap_2","tMap","tDBOutput_4","\"transactions_livraison\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRowGenerator_5 finally ] start
	 */

	

	
	
	currentComponent="tRowGenerator_5";
	
	

 



/**
 * [tRowGenerator_5 finally ] stop
 */

	
	/**
	 * [tMap_6 finally ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"transactions_livraison\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRowGenerator_5_SUBPROCESS_STATE", 1);
	}
	


public static class out2Struct implements routines.system.IPersistableRow<out2Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String start_date;

				public String getStart_date () {
					return this.start_date;
				}

				public Boolean start_dateIsNullable(){
				    return false;
				}
				public Boolean start_dateIsKey(){
				    return false;
				}
				public Integer start_dateLength(){
				    return 19;
				}
				public Integer start_datePrecision(){
				    return 0;
				}
				public String start_dateDefault(){
				
					return null;
				
				}
				public String start_dateComment(){
				
				    return "";
				
				}
				public String start_datePattern(){
				
					return "yyyy/MM/dd";
				
				}
				public String start_dateOriginalDbColumnName(){
				
					return "start_date";
				
				}

				
			    public String end_date;

				public String getEnd_date () {
					return this.end_date;
				}

				public Boolean end_dateIsNullable(){
				    return false;
				}
				public Boolean end_dateIsKey(){
				    return false;
				}
				public Integer end_dateLength(){
				    return 19;
				}
				public Integer end_datePrecision(){
				    return 0;
				}
				public String end_dateDefault(){
				
					return null;
				
				}
				public String end_dateComment(){
				
				    return "";
				
				}
				public String end_datePattern(){
				
					return "yyyy/MM/dd";
				
				}
				public String end_dateOriginalDbColumnName(){
				
					return "end_date";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out2Struct other = (out2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(out2Struct other) {

		other.id = this.id;
	            other.start_date = this.start_date;
	            other.end_date = this.end_date;
	            
	}

	public void copyKeysDataTo(out2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.start_date = readString(dis);
					
					this.end_date = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.start_date = readString(dis);
					
					this.end_date = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.start_date,dos);
					
					// String
				
						writeString(this.end_date,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.start_date,dos);
					
					// String
				
						writeString(this.end_date,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",start_date="+start_date);
		sb.append(",end_date="+end_date);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(start_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_date);
            			}
            		
        			sb.append("|");
        		
        				if(end_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_date);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public java.util.Date start_date;

				public java.util.Date getStart_date () {
					return this.start_date;
				}

				public Boolean start_dateIsNullable(){
				    return false;
				}
				public Boolean start_dateIsKey(){
				    return false;
				}
				public Integer start_dateLength(){
				    return 19;
				}
				public Integer start_datePrecision(){
				    return 0;
				}
				public String start_dateDefault(){
				
					return null;
				
				}
				public String start_dateComment(){
				
				    return "";
				
				}
				public String start_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String start_dateOriginalDbColumnName(){
				
					return "start_date";
				
				}

				
			    public java.util.Date end_date;

				public java.util.Date getEnd_date () {
					return this.end_date;
				}

				public Boolean end_dateIsNullable(){
				    return false;
				}
				public Boolean end_dateIsKey(){
				    return false;
				}
				public Integer end_dateLength(){
				    return 19;
				}
				public Integer end_datePrecision(){
				    return 0;
				}
				public String end_dateDefault(){
				
					return null;
				
				}
				public String end_dateComment(){
				
				    return "";
				
				}
				public String end_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String end_dateOriginalDbColumnName(){
				
					return "end_date";
				
				}

				
			    public String statut;

				public String getStatut () {
					return this.statut;
				}

				public Boolean statutIsNullable(){
				    return true;
				}
				public Boolean statutIsKey(){
				    return false;
				}
				public Integer statutLength(){
				    return 45;
				}
				public Integer statutPrecision(){
				    return 0;
				}
				public String statutDefault(){
				
					return null;
				
				}
				public String statutComment(){
				
				    return "";
				
				}
				public String statutPattern(){
				
					return "";
				
				}
				public String statutOriginalDbColumnName(){
				
					return "statut";
				
				}

				
			    public String fichier_livraison_sftp;

				public String getFichier_livraison_sftp () {
					return this.fichier_livraison_sftp;
				}

				public Boolean fichier_livraison_sftpIsNullable(){
				    return true;
				}
				public Boolean fichier_livraison_sftpIsKey(){
				    return false;
				}
				public Integer fichier_livraison_sftpLength(){
				    return 100;
				}
				public Integer fichier_livraison_sftpPrecision(){
				    return 0;
				}
				public String fichier_livraison_sftpDefault(){
				
					return null;
				
				}
				public String fichier_livraison_sftpComment(){
				
				    return "";
				
				}
				public String fichier_livraison_sftpPattern(){
				
					return "";
				
				}
				public String fichier_livraison_sftpOriginalDbColumnName(){
				
					return "fichier_livraison_sftp";
				
				}

				
			    public String fichier_exception_sftp;

				public String getFichier_exception_sftp () {
					return this.fichier_exception_sftp;
				}

				public Boolean fichier_exception_sftpIsNullable(){
				    return true;
				}
				public Boolean fichier_exception_sftpIsKey(){
				    return false;
				}
				public Integer fichier_exception_sftpLength(){
				    return 100;
				}
				public Integer fichier_exception_sftpPrecision(){
				    return 0;
				}
				public String fichier_exception_sftpDefault(){
				
					return null;
				
				}
				public String fichier_exception_sftpComment(){
				
				    return "";
				
				}
				public String fichier_exception_sftpPattern(){
				
					return "";
				
				}
				public String fichier_exception_sftpOriginalDbColumnName(){
				
					return "fichier_exception_sftp";
				
				}

				
			    public String fichier_metadata_sftp;

				public String getFichier_metadata_sftp () {
					return this.fichier_metadata_sftp;
				}

				public Boolean fichier_metadata_sftpIsNullable(){
				    return true;
				}
				public Boolean fichier_metadata_sftpIsKey(){
				    return false;
				}
				public Integer fichier_metadata_sftpLength(){
				    return 100;
				}
				public Integer fichier_metadata_sftpPrecision(){
				    return 0;
				}
				public String fichier_metadata_sftpDefault(){
				
					return null;
				
				}
				public String fichier_metadata_sftpComment(){
				
				    return "";
				
				}
				public String fichier_metadata_sftpPattern(){
				
					return "";
				
				}
				public String fichier_metadata_sftpOriginalDbColumnName(){
				
					return "fichier_metadata_sftp";
				
				}

				
			    public String fichier_mad_sftp;

				public String getFichier_mad_sftp () {
					return this.fichier_mad_sftp;
				}

				public Boolean fichier_mad_sftpIsNullable(){
				    return true;
				}
				public Boolean fichier_mad_sftpIsKey(){
				    return false;
				}
				public Integer fichier_mad_sftpLength(){
				    return 100;
				}
				public Integer fichier_mad_sftpPrecision(){
				    return 0;
				}
				public String fichier_mad_sftpDefault(){
				
					return null;
				
				}
				public String fichier_mad_sftpComment(){
				
				    return "";
				
				}
				public String fichier_mad_sftpPattern(){
				
					return "";
				
				}
				public String fichier_mad_sftpOriginalDbColumnName(){
				
					return "fichier_mad_sftp";
				
				}

				
			    public java.util.Date created_at;

				public java.util.Date getCreated_at () {
					return this.created_at;
				}

				public Boolean created_atIsNullable(){
				    return true;
				}
				public Boolean created_atIsKey(){
				    return false;
				}
				public Integer created_atLength(){
				    return 26;
				}
				public Integer created_atPrecision(){
				    return 0;
				}
				public String created_atDefault(){
				
					return null;
				
				}
				public String created_atComment(){
				
				    return "";
				
				}
				public String created_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_atOriginalDbColumnName(){
				
					return "created_at";
				
				}

				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.start_date = readDate(dis);
					
					this.end_date = readDate(dis);
					
					this.statut = readString(dis);
					
					this.fichier_livraison_sftp = readString(dis);
					
					this.fichier_exception_sftp = readString(dis);
					
					this.fichier_metadata_sftp = readString(dis);
					
					this.fichier_mad_sftp = readString(dis);
					
					this.created_at = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.start_date = readDate(dis);
					
					this.end_date = readDate(dis);
					
					this.statut = readString(dis);
					
					this.fichier_livraison_sftp = readString(dis);
					
					this.fichier_exception_sftp = readString(dis);
					
					this.fichier_metadata_sftp = readString(dis);
					
					this.fichier_mad_sftp = readString(dis);
					
					this.created_at = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// java.util.Date
				
						writeDate(this.start_date,dos);
					
					// java.util.Date
				
						writeDate(this.end_date,dos);
					
					// String
				
						writeString(this.statut,dos);
					
					// String
				
						writeString(this.fichier_livraison_sftp,dos);
					
					// String
				
						writeString(this.fichier_exception_sftp,dos);
					
					// String
				
						writeString(this.fichier_metadata_sftp,dos);
					
					// String
				
						writeString(this.fichier_mad_sftp,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// java.util.Date
				
						writeDate(this.start_date,dos);
					
					// java.util.Date
				
						writeDate(this.end_date,dos);
					
					// String
				
						writeString(this.statut,dos);
					
					// String
				
						writeString(this.fichier_livraison_sftp,dos);
					
					// String
				
						writeString(this.fichier_exception_sftp,dos);
					
					// String
				
						writeString(this.fichier_metadata_sftp,dos);
					
					// String
				
						writeString(this.fichier_mad_sftp,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",start_date="+String.valueOf(start_date));
		sb.append(",end_date="+String.valueOf(end_date));
		sb.append(",statut="+statut);
		sb.append(",fichier_livraison_sftp="+fichier_livraison_sftp);
		sb.append(",fichier_exception_sftp="+fichier_exception_sftp);
		sb.append(",fichier_metadata_sftp="+fichier_metadata_sftp);
		sb.append(",fichier_mad_sftp="+fichier_mad_sftp);
		sb.append(",created_at="+String.valueOf(created_at));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(start_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_date);
            			}
            		
        			sb.append("|");
        		
        				if(end_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_date);
            			}
            		
        			sb.append("|");
        		
        				if(statut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statut);
            			}
            		
        			sb.append("|");
        		
        				if(fichier_livraison_sftp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fichier_livraison_sftp);
            			}
            		
        			sb.append("|");
        		
        				if(fichier_exception_sftp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fichier_exception_sftp);
            			}
            		
        			sb.append("|");
        		
        				if(fichier_metadata_sftp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fichier_metadata_sftp);
            			}
            		
        			sb.append("|");
        		
        				if(fichier_mad_sftp == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fichier_mad_sftp);
            			}
            		
        			sb.append("|");
        		
        				if(created_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_at);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "hyhPqH_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
out2Struct out2 = new out2Struct();





	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out2");
			
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_2.append("Parameters:");
                            log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("out2.start_date")+", KEY="+("\"start_date\"")+"}, {VALUE="+("out2.end_date")+", KEY="+("\"end_date\"")+"}]");
                        log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_2", "tSetGlobalVar_2", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row1_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out2_tMap_1 = 0;
				
out2Struct out2_tmp = new out2Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"transactions_livraison\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `transactions_livraison`.`id`,    `transactions_livraison`.`start_date`,    `transactions_livraison`.`end_date`,    `transactions_livraison`.`statut`,    `transactions_livraison`.`fichier_livraison_sftp`,    `transactions_livraison`.`fichier_exception_sftp`,    `transactions_livraison`.`fichier_metadata_sftp`,    `transactions_livraison`.`fichier_mad_sftp`,    `transactions_livraison`.`created_at` FROM `transactions_livraison`  WHERE `transactions_livraison`.`id` = \" + Integer.parseInt((String)globalMap.get(\"transaction_id\"))");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("start_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("end_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("statut")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("fichier_livraison_sftp")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("fichier_exception_sftp")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("fichier_metadata_sftp")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("fichier_mad_sftp")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_at")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"transactions_livraison\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  `transactions_livraison`.`id`, \n  `transactions_livraison`.`start_date`, \n  `transactions_livraison`.`end_dat"
+"e`, \n  `transactions_livraison`.`statut`, \n  `transactions_livraison`.`fichier_livraison_sftp`, \n  `transactions_livrais"
+"on`.`fichier_exception_sftp`, \n  `transactions_livraison`.`fichier_metadata_sftp`, \n  `transactions_livraison`.`fichier_"
+"mad_sftp`, \n  `transactions_livraison`.`created_at`\nFROM `transactions_livraison`\nWHERE `transactions_livraison`.`id` ="
+" " + Integer.parseInt((String)globalMap.get("transaction_id"));
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

		    globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);

		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.id = 0;
							} else {
		                          
            row1.id = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.start_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(2) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(2);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.start_date = rs_tDBInput_1.getTimestamp(2);
					} else {
						row1.start_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.start_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.end_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(3) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(3);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.end_date = rs_tDBInput_1.getTimestamp(3);
					} else {
						row1.end_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.end_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.statut = null;
							} else {
	                         		
        	row1.statut = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.fichier_livraison_sftp = null;
							} else {
	                         		
        	row1.fichier_livraison_sftp = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.fichier_exception_sftp = null;
							} else {
	                         		
        	row1.fichier_exception_sftp = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.fichier_metadata_sftp = null;
							} else {
	                         		
        	row1.fichier_metadata_sftp = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.fichier_mad_sftp = null;
							} else {
	                         		
        	row1.fichier_mad_sftp = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.created_at = null;
							} else {
										
				if(rs_tDBInput_1.getString(9) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(9);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.created_at = rs_tDBInput_1.getTimestamp(9);
					} else {
						row1.created_at = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.created_at =  null;
				}
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"transactions_livraison\"","tMysqlInput","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out2 = null;


// # Output table : 'out2'
count_out2_tMap_1++;

out2_tmp.id = row1.id ;
out2_tmp.start_date = TalendDate.formatDate("yyyy/MM/dd", row1.start_date) ;
out2_tmp.end_date = TalendDate.formatDate("yyyy/MM/dd", row1.end_date) ;
out2 = out2_tmp;
log.debug("tMap_1 - Outputting the record " + count_out2_tMap_1 + " of the output table 'out2'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "out2"
if(out2 != null) { 



	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"out2","tMap_1","tMap_1","tMap","tSetGlobalVar_2","tSetGlobalVar_2","tSetGlobalVar"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("out2 - " + (out2==null? "": out2.toLogString()));
    			}
    		

globalMap.put("start_date", out2.start_date);
globalMap.put("end_date", out2.end_date);

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_end ] stop
 */

} // End of branch "out2"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out2': " + count_out2_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"transactions_livraison\"","tMysqlInput","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out2",2,0,
			 			"tMap_1","tMap_1","tMap","tSetGlobalVar_2","tSetGlobalVar_2","tSetGlobalVar","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk12", 0, "ok");
								} 
							
							tJava_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_1");
		org.slf4j.MDC.put("_subJobPid", "NiIHvT_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";
	
	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_1", "tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_CORRECTION_EXCEPTIONS_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				tRunJob_10Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tJava_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_10");
		org.slf4j.MDC.put("_subJobPid", "oh7t1i_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_10", false);
		start_Hash.put("tRunJob_10", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_10{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_10 = new StringBuilder();
                    log4jParamters_tRunJob_10.append("Parameters:");
                            log4jParamters_tRunJob_10.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PROCESS" + " = " + "URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + (log4jParamters_tRunJob_10) );
                    } 
                } 
            new BytesLimit65535_tRunJob_10().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_10", "URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_10 begin ] stop
 */
	
	/**
	 * [tRunJob_10 main ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_10 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_10.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_10.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_10.add("--father_node=tRunJob_10");
	      			
	        				paraList_tRunJob_10.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_10.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_10.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_10.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_10.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_10 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_10 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_10".equals(tRunJobName_tRunJob_10) && childResumePath_tRunJob_10 != null){
		paraList_tRunJob_10.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_10.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_10");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_10 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_10 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_10.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_10.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_10.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("file_source", context.file_source);
                    paraList_tRunJob_10.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_10.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_10.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_10.put("Hote", context.Hote);
                    paraList_tRunJob_10.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_10.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_10.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_10.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_10.put("Port", context.Port);
                    paraList_tRunJob_10.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_10.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_10.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_10.put("User", context.User);
                    paraList_tRunJob_10.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_10.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_10.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_10.put("Server_In", context.Server_In);
                    paraList_tRunJob_10.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_10.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_10.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_10.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_10.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_10.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_10.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_10.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_10().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_10 = context.propertyNames();
		while (propertyNames_tRunJob_10.hasMoreElements()) {
			String key_tRunJob_10 = (String) propertyNames_tRunJob_10.nextElement();
			Object value_tRunJob_10 = (Object) context.get(key_tRunJob_10);
			if(value_tRunJob_10!=null) {  
				
					paraList_tRunJob_10.add("--context_param " + key_tRunJob_10 + "=" + value_tRunJob_10);
					
			} else {
				paraList_tRunJob_10.add("--context_param " + key_tRunJob_10 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_10 = null;

	
	
		cajoo.urbantz_correction_exceptions_prod_v1_vehicule_0_1.URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE childJob_tRunJob_10 = new cajoo.urbantz_correction_exceptions_prod_v1_vehicule_0_1.URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_10 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_10) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_10 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_10 : talendDataSources_tRunJob_10
			        .entrySet()) {
	            dataSources_tRunJob_10.put(talendDataSourceEntry_tRunJob_10.getKey(),
	                    talendDataSourceEntry_tRunJob_10.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_10.setDataSources(dataSources_tRunJob_10);
	    }
		  
			childJob_tRunJob_10.parentContextMap = parentContextMap_tRunJob_10;
		  
		
			log.info("tRunJob_10 - The child job 'cajoo.urbantz_correction_exceptions_prod_v1_vehicule_0_1.URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_10 = childJob_tRunJob_10.runJob((String[]) paraList_tRunJob_10.toArray(new String[paraList_tRunJob_10.size()]));
		
			log.info("tRunJob_10 - The child job 'cajoo.urbantz_correction_exceptions_prod_v1_vehicule_0_1.URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_10.getErrorCode() == null){
                globalMap.put("tRunJob_10_CHILD_RETURN_CODE", childJob_tRunJob_10.getStatus() != null && ("failure").equals(childJob_tRunJob_10.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_10_CHILD_RETURN_CODE", childJob_tRunJob_10.getErrorCode());
            }
            if (childJob_tRunJob_10.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_10_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_10.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_10.getErrorCode();
                if (childJob_tRunJob_10.getErrorCode() != null || ("failure").equals(childJob_tRunJob_10.getStatus())) {
                    java.lang.Exception ce_tRunJob_10 = childJob_tRunJob_10.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_10!=null) ? (ce_tRunJob_10.getClass().getName() + ": " + ce_tRunJob_10.getMessage()) : ""));
                }

 


	tos_count_tRunJob_10++;

/**
 * [tRunJob_10 main ] stop
 */
	
	/**
	 * [tRunJob_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_10 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_10 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_10 end ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + ("Done.") );

ok_Hash.put("tRunJob_10", true);
end_Hash.put("tRunJob_10", System.currentTimeMillis());




/**
 * [tRunJob_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_10 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_10_SUBPROCESS_STATE", 1);
	}
	


public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_2");
		org.slf4j.MDC.put("_subJobPid", "V6DH8v_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";
	
	
		int tos_count_tJava_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_2", "tJava_2", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_CORRECTION_FACTURATION_VALUES_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				tRunJob_11Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tJava_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_11");
		org.slf4j.MDC.put("_subJobPid", "Lh3IDH_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_11", false);
		start_Hash.put("tRunJob_11", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		
		int tos_count_tRunJob_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_11 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_11{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_11 = new StringBuilder();
                    log4jParamters_tRunJob_11.append("Parameters:");
                            log4jParamters_tRunJob_11.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("PROCESS" + " = " + "URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_11.append(" | ");
                            log4jParamters_tRunJob_11.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_11 - "  + (log4jParamters_tRunJob_11) );
                    } 
                } 
            new BytesLimit65535_tRunJob_11().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_11", "URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_11 begin ] stop
 */
	
	/**
	 * [tRunJob_11 main ] start
	 */

	

	
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		
	java.util.List<String> paraList_tRunJob_11 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_11.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_11.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_11.add("--father_node=tRunJob_11");
	      			
	        				paraList_tRunJob_11.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_11.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_11.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_11.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_11.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_11 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_11 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_11".equals(tRunJobName_tRunJob_11) && childResumePath_tRunJob_11 != null){
		paraList_tRunJob_11.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_11.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_11");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_11 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_11 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_11.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_11.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_11.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("file_source", context.file_source);
                    paraList_tRunJob_11.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_11.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_11.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_11.put("Hote", context.Hote);
                    paraList_tRunJob_11.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_11.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_11.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_11.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_11.put("Port", context.Port);
                    paraList_tRunJob_11.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_11.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_11.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_11.put("User", context.User);
                    paraList_tRunJob_11.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_11.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_11.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_11.put("Server_In", context.Server_In);
                    paraList_tRunJob_11.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_11.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_11.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_11.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_11.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_11.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_11.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_11.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_11().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_11 = context.propertyNames();
		while (propertyNames_tRunJob_11.hasMoreElements()) {
			String key_tRunJob_11 = (String) propertyNames_tRunJob_11.nextElement();
			Object value_tRunJob_11 = (Object) context.get(key_tRunJob_11);
			if(value_tRunJob_11!=null) {  
				
					paraList_tRunJob_11.add("--context_param " + key_tRunJob_11 + "=" + value_tRunJob_11);
					
			} else {
				paraList_tRunJob_11.add("--context_param " + key_tRunJob_11 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_11 = null;

	
	
		cajoo.urbantz_correction_facturation_values_prod_v1_0_1.URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1 childJob_tRunJob_11 = new cajoo.urbantz_correction_facturation_values_prod_v1_0_1.URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_11 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_11) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_11 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_11 : talendDataSources_tRunJob_11
			        .entrySet()) {
	            dataSources_tRunJob_11.put(talendDataSourceEntry_tRunJob_11.getKey(),
	                    talendDataSourceEntry_tRunJob_11.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_11.setDataSources(dataSources_tRunJob_11);
	    }
		  
			childJob_tRunJob_11.parentContextMap = parentContextMap_tRunJob_11;
		  
		
			log.info("tRunJob_11 - The child job 'cajoo.urbantz_correction_facturation_values_prod_v1_0_1.URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_11 = childJob_tRunJob_11.runJob((String[]) paraList_tRunJob_11.toArray(new String[paraList_tRunJob_11.size()]));
		
			log.info("tRunJob_11 - The child job 'cajoo.urbantz_correction_facturation_values_prod_v1_0_1.URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1' is done.");
		
            if(childJob_tRunJob_11.getErrorCode() == null){
                globalMap.put("tRunJob_11_CHILD_RETURN_CODE", childJob_tRunJob_11.getStatus() != null && ("failure").equals(childJob_tRunJob_11.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_11_CHILD_RETURN_CODE", childJob_tRunJob_11.getErrorCode());
            }
            if (childJob_tRunJob_11.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_11_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_11.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_11.getErrorCode();
                if (childJob_tRunJob_11.getErrorCode() != null || ("failure").equals(childJob_tRunJob_11.getStatus())) {
                    java.lang.Exception ce_tRunJob_11 = childJob_tRunJob_11.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_11!=null) ? (ce_tRunJob_11.getClass().getName() + ": " + ce_tRunJob_11.getMessage()) : ""));
                }

 


	tos_count_tRunJob_11++;

/**
 * [tRunJob_11 main ] stop
 */
	
	/**
	 * [tRunJob_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		

 



/**
 * [tRunJob_11 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		

 



/**
 * [tRunJob_11 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_11 end ] start
	 */

	

	
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_11 - "  + ("Done.") );

ok_Hash.put("tRunJob_11", true);
end_Hash.put("tRunJob_11", System.currentTimeMillis());




/**
 * [tRunJob_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_11 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_11";
	
	
			cLabel="URBANTZ_CORRECTION_FACTURATION_VALUES_PROD_V1";
		
	
 



/**
 * [tRunJob_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_11_SUBPROCESS_STATE", 1);
	}
	


public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_3");
		org.slf4j.MDC.put("_subJobPid", "pNDI8w_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";
	
	
		int tos_count_tJava_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_3", "tJava_3", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_begin ] stop
 */
	
	/**
	 * [tJava_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_end ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_LIVRAISON_FILE_CORRECTION")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				tRunJob_12Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}



/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tJava_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_12");
		org.slf4j.MDC.put("_subJobPid", "UqNAK1_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_12", false);
		start_Hash.put("tRunJob_12", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_12 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_12{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_12 = new StringBuilder();
                    log4jParamters_tRunJob_12.append("Parameters:");
                            log4jParamters_tRunJob_12.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("PROCESS" + " = " + "URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_12.append(" | ");
                            log4jParamters_tRunJob_12.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_12 - "  + (log4jParamters_tRunJob_12) );
                    } 
                } 
            new BytesLimit65535_tRunJob_12().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_12", "URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_12 begin ] stop
 */
	
	/**
	 * [tRunJob_12 main ] start
	 */

	

	
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_12 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_12.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_12.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_12.add("--father_node=tRunJob_12");
	      			
	        				paraList_tRunJob_12.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_12.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_12.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_12.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_12.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_12 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_12 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_12".equals(tRunJobName_tRunJob_12) && childResumePath_tRunJob_12 != null){
		paraList_tRunJob_12.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_12.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_12");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_12 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_12 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_12.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_12.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_12.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("file_source", context.file_source);
                    paraList_tRunJob_12.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_12.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_12.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_12.put("Hote", context.Hote);
                    paraList_tRunJob_12.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_12.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_12.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_12.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_12.put("Port", context.Port);
                    paraList_tRunJob_12.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_12.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_12.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_12.put("User", context.User);
                    paraList_tRunJob_12.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_12.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_12.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_12.put("Server_In", context.Server_In);
                    paraList_tRunJob_12.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_12.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_12.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_12.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_12.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_12.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_12.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_12.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_12().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_12 = context.propertyNames();
		while (propertyNames_tRunJob_12.hasMoreElements()) {
			String key_tRunJob_12 = (String) propertyNames_tRunJob_12.nextElement();
			Object value_tRunJob_12 = (Object) context.get(key_tRunJob_12);
			if(value_tRunJob_12!=null) {  
				
					paraList_tRunJob_12.add("--context_param " + key_tRunJob_12 + "=" + value_tRunJob_12);
					
			} else {
				paraList_tRunJob_12.add("--context_param " + key_tRunJob_12 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_12 = null;

	
	
		cajoo.urbantz_livraison_file_correction_prod_v1_vehicule_0_1.URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE childJob_tRunJob_12 = new cajoo.urbantz_livraison_file_correction_prod_v1_vehicule_0_1.URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_12 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_12) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_12 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_12 : talendDataSources_tRunJob_12
			        .entrySet()) {
	            dataSources_tRunJob_12.put(talendDataSourceEntry_tRunJob_12.getKey(),
	                    talendDataSourceEntry_tRunJob_12.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_12.setDataSources(dataSources_tRunJob_12);
	    }
		  
			childJob_tRunJob_12.parentContextMap = parentContextMap_tRunJob_12;
		  
		
			log.info("tRunJob_12 - The child job 'cajoo.urbantz_livraison_file_correction_prod_v1_vehicule_0_1.URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_12 = childJob_tRunJob_12.runJob((String[]) paraList_tRunJob_12.toArray(new String[paraList_tRunJob_12.size()]));
		
			log.info("tRunJob_12 - The child job 'cajoo.urbantz_livraison_file_correction_prod_v1_vehicule_0_1.URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_12.getErrorCode() == null){
                globalMap.put("tRunJob_12_CHILD_RETURN_CODE", childJob_tRunJob_12.getStatus() != null && ("failure").equals(childJob_tRunJob_12.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_12_CHILD_RETURN_CODE", childJob_tRunJob_12.getErrorCode());
            }
            if (childJob_tRunJob_12.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_12_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_12.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_12.getErrorCode();
                if (childJob_tRunJob_12.getErrorCode() != null || ("failure").equals(childJob_tRunJob_12.getStatus())) {
                    java.lang.Exception ce_tRunJob_12 = childJob_tRunJob_12.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_12!=null) ? (ce_tRunJob_12.getClass().getName() + ": " + ce_tRunJob_12.getMessage()) : ""));
                }

 


	tos_count_tRunJob_12++;

/**
 * [tRunJob_12 main ] stop
 */
	
	/**
	 * [tRunJob_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_12 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_12 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_12 end ] start
	 */

	

	
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_12 - "  + ("Done.") );

ok_Hash.put("tRunJob_12", true);
end_Hash.put("tRunJob_12", System.currentTimeMillis());




/**
 * [tRunJob_12 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_12 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_12";
	
	
			cLabel="URBANTZ_LIVRAISON_FILE_CORRECTION_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_12_SUBPROCESS_STATE", 1);
	}
	


public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_4");
		org.slf4j.MDC.put("_subJobPid", "u3T1PO_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";
	
	
		int tos_count_tJava_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_4", "tJava_4", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";
	
	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_4";
	
	

 



/**
 * [tJava_4 process_data_begin ] stop
 */
	
	/**
	 * [tJava_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_4";
	
	

 



/**
 * [tJava_4 process_data_end ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";
	
	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_TO_HUB_MAD_CORRECTION")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				tRunJob_13Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tJava_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";
	
	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_13");
		org.slf4j.MDC.put("_subJobPid", "vum6UT_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_13", false);
		start_Hash.put("tRunJob_13", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		
		int tos_count_tRunJob_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_13 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_13{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_13 = new StringBuilder();
                    log4jParamters_tRunJob_13.append("Parameters:");
                            log4jParamters_tRunJob_13.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("PROCESS" + " = " + "URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_13.append(" | ");
                            log4jParamters_tRunJob_13.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_13 - "  + (log4jParamters_tRunJob_13) );
                    } 
                } 
            new BytesLimit65535_tRunJob_13().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_13", "URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_13 begin ] stop
 */
	
	/**
	 * [tRunJob_13 main ] start
	 */

	

	
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		
	java.util.List<String> paraList_tRunJob_13 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_13.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_13.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_13.add("--father_node=tRunJob_13");
	      			
	        				paraList_tRunJob_13.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_13.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_13.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_13.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_13.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_13 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_13 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_13".equals(tRunJobName_tRunJob_13) && childResumePath_tRunJob_13 != null){
		paraList_tRunJob_13.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_13.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_13");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_13 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_13 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_13.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_13.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_13.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("file_source", context.file_source);
                    paraList_tRunJob_13.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_13.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_13.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_13.put("Hote", context.Hote);
                    paraList_tRunJob_13.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_13.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_13.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_13.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_13.put("Port", context.Port);
                    paraList_tRunJob_13.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_13.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_13.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_13.put("User", context.User);
                    paraList_tRunJob_13.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_13.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_13.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_13.put("Server_In", context.Server_In);
                    paraList_tRunJob_13.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_13.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_13.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_13.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_13.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_13.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_13.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_13.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_13().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_13 = context.propertyNames();
		while (propertyNames_tRunJob_13.hasMoreElements()) {
			String key_tRunJob_13 = (String) propertyNames_tRunJob_13.nextElement();
			Object value_tRunJob_13 = (Object) context.get(key_tRunJob_13);
			if(value_tRunJob_13!=null) {  
				
					paraList_tRunJob_13.add("--context_param " + key_tRunJob_13 + "=" + value_tRunJob_13);
					
			} else {
				paraList_tRunJob_13.add("--context_param " + key_tRunJob_13 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_13 = null;

	
	
		cajoo.urbantz_to_hub_mad_correction_prod_v1_0_1.URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 childJob_tRunJob_13 = new cajoo.urbantz_to_hub_mad_correction_prod_v1_0_1.URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_13 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_13) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_13 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_13 : talendDataSources_tRunJob_13
			        .entrySet()) {
	            dataSources_tRunJob_13.put(talendDataSourceEntry_tRunJob_13.getKey(),
	                    talendDataSourceEntry_tRunJob_13.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_13.setDataSources(dataSources_tRunJob_13);
	    }
		  
			childJob_tRunJob_13.parentContextMap = parentContextMap_tRunJob_13;
		  
		
			log.info("tRunJob_13 - The child job 'cajoo.urbantz_to_hub_mad_correction_prod_v1_0_1.URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_13 = childJob_tRunJob_13.runJob((String[]) paraList_tRunJob_13.toArray(new String[paraList_tRunJob_13.size()]));
		
			log.info("tRunJob_13 - The child job 'cajoo.urbantz_to_hub_mad_correction_prod_v1_0_1.URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' is done.");
		
            if(childJob_tRunJob_13.getErrorCode() == null){
                globalMap.put("tRunJob_13_CHILD_RETURN_CODE", childJob_tRunJob_13.getStatus() != null && ("failure").equals(childJob_tRunJob_13.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_13_CHILD_RETURN_CODE", childJob_tRunJob_13.getErrorCode());
            }
            if (childJob_tRunJob_13.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_13_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_13.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_13.getErrorCode();
                if (childJob_tRunJob_13.getErrorCode() != null || ("failure").equals(childJob_tRunJob_13.getStatus())) {
                    java.lang.Exception ce_tRunJob_13 = childJob_tRunJob_13.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_13!=null) ? (ce_tRunJob_13.getClass().getName() + ": " + ce_tRunJob_13.getMessage()) : ""));
                }

 


	tos_count_tRunJob_13++;

/**
 * [tRunJob_13 main ] stop
 */
	
	/**
	 * [tRunJob_13 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		

 



/**
 * [tRunJob_13 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_13 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		

 



/**
 * [tRunJob_13 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_13 end ] start
	 */

	

	
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_13 - "  + ("Done.") );

ok_Hash.put("tRunJob_13", true);
end_Hash.put("tRunJob_13", System.currentTimeMillis());




/**
 * [tRunJob_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_13 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_13";
	
	
			cLabel="URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
		
	
 



/**
 * [tRunJob_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_13_SUBPROCESS_STATE", 1);
	}
	


public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_5");
		org.slf4j.MDC.put("_subJobPid", "PNxWyx_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";
	
	
		int tos_count_tJava_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_5", "tJava_5", "tJava");
				talendJobLogProcess(globalMap);
			}
			





 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";
	
	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_5";
	
	

 



/**
 * [tJava_5 process_data_begin ] stop
 */
	
	/**
	 * [tJava_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_5";
	
	

 



/**
 * [tJava_5 process_data_end ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";
	
	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_TO_HUB_SANS_MAD_OTHERS_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				tRunJob_3Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}



/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tJava_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";
	
	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_3");
		org.slf4j.MDC.put("_subJobPid", "nW5hXx_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_3", false);
		start_Hash.put("tRunJob_3", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_3 = new StringBuilder();
                    log4jParamters_tRunJob_3.append("Parameters:");
                            log4jParamters_tRunJob_3.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PROCESS" + " = " + "SANS_MAD_OTHERS_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("start_date")+", PARAM_VALUE_COLUMN="+("(String)globalMap.get(\"start_date\")")+"}, {PARAM_NAME_COLUMN="+("end_date")+", PARAM_VALUE_COLUMN="+("(String)globalMap.get(\"end_date\")")+"}]");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + (log4jParamters_tRunJob_3) );
                    } 
                } 
            new BytesLimit65535_tRunJob_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_3", "SANS_MAD_OTHERS_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_3 begin ] stop
 */
	
	/**
	 * [tRunJob_3 main ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_3 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_3.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_3.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_3.add("--father_node=tRunJob_3");
	      			
	        				paraList_tRunJob_3.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_3.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_3.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_3.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_3.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_3 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_3 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_3".equals(tRunJobName_tRunJob_3) && childResumePath_tRunJob_3 != null){
		paraList_tRunJob_3.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_3.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_3");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_3 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_3 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_3.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_3.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_3.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("file_source", context.file_source);
                    paraList_tRunJob_3.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_3.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_3.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_3.put("Hote", context.Hote);
                    paraList_tRunJob_3.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_3.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_3.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_3.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_3.put("Port", context.Port);
                    paraList_tRunJob_3.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_3.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_3.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_3.put("User", context.User);
                    paraList_tRunJob_3.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_3.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_3.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_3.put("Server_In", context.Server_In);
                    paraList_tRunJob_3.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_3.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_3.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_3.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_3.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_3.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_3.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_3.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_3().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_3 = context.propertyNames();
		while (propertyNames_tRunJob_3.hasMoreElements()) {
			String key_tRunJob_3 = (String) propertyNames_tRunJob_3.nextElement();
			Object value_tRunJob_3 = (Object) context.get(key_tRunJob_3);
			if(value_tRunJob_3!=null) {  
				
					paraList_tRunJob_3.add("--context_param " + key_tRunJob_3 + "=" + value_tRunJob_3);
					
			} else {
				paraList_tRunJob_3.add("--context_param " + key_tRunJob_3 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_3 = null;

	
		obj_tRunJob_3 = (String)globalMap.get("start_date");
		if(obj_tRunJob_3!=null) {
			if (obj_tRunJob_3.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_3.add("--context_param start_date=" + ((java.util.Date) obj_tRunJob_3).getTime());
			} else {
				
					paraList_tRunJob_3.add("--context_param start_date=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
					
				
			}
		} else {
			paraList_tRunJob_3.add("--context_param start_date=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("start_date", obj_tRunJob_3);
	
		obj_tRunJob_3 = (String)globalMap.get("end_date");
		if(obj_tRunJob_3!=null) {
			if (obj_tRunJob_3.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_3.add("--context_param end_date=" + ((java.util.Date) obj_tRunJob_3).getTime());
			} else {
				
					paraList_tRunJob_3.add("--context_param end_date=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
					
				
			}
		} else {
			paraList_tRunJob_3.add("--context_param end_date=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("end_date", obj_tRunJob_3);
	
	
		cajoo.sans_mad_others_prod_v1_vehicule_0_1.SANS_MAD_OTHERS_PROD_V1_VEHICULE childJob_tRunJob_3 = new cajoo.sans_mad_others_prod_v1_vehicule_0_1.SANS_MAD_OTHERS_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_3 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_3) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_3 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_3 : talendDataSources_tRunJob_3
			        .entrySet()) {
	            dataSources_tRunJob_3.put(talendDataSourceEntry_tRunJob_3.getKey(),
	                    talendDataSourceEntry_tRunJob_3.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_3.setDataSources(dataSources_tRunJob_3);
	    }
		  
			childJob_tRunJob_3.parentContextMap = parentContextMap_tRunJob_3;
		  
		
			log.info("tRunJob_3 - The child job 'cajoo.sans_mad_others_prod_v1_vehicule_0_1.SANS_MAD_OTHERS_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_3 = childJob_tRunJob_3.runJob((String[]) paraList_tRunJob_3.toArray(new String[paraList_tRunJob_3.size()]));
		
			log.info("tRunJob_3 - The child job 'cajoo.sans_mad_others_prod_v1_vehicule_0_1.SANS_MAD_OTHERS_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_3.getErrorCode() == null){
                globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getStatus() != null && ("failure").equals(childJob_tRunJob_3.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getErrorCode());
            }
            if (childJob_tRunJob_3.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_3_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_3.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_3.getErrorCode();
                if (childJob_tRunJob_3.getErrorCode() != null || ("failure").equals(childJob_tRunJob_3.getStatus())) {
                    java.lang.Exception ce_tRunJob_3 = childJob_tRunJob_3.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_3!=null) ? (ce_tRunJob_3.getClass().getName() + ": " + ce_tRunJob_3.getMessage()) : ""));
                }

 


	tos_count_tRunJob_3++;

/**
 * [tRunJob_3 main ] stop
 */
	
	/**
	 * [tRunJob_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_3 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_3 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_3 end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Done.") );

ok_Hash.put("tRunJob_3", true);
end_Hash.put("tRunJob_3", System.currentTimeMillis());




/**
 * [tRunJob_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_3 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="SANS_MAD_OTHERS_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 1);
	}
	


public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_6");
		org.slf4j.MDC.put("_subJobPid", "zba4yJ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";
	
	
		int tos_count_tJava_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_6", "tJava_6", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";
	
	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_6";
	
	

 



/**
 * [tJava_6 process_data_begin ] stop
 */
	
	/**
	 * [tJava_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_6";
	
	

 



/**
 * [tJava_6 process_data_end ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";
	
	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_TO_HUB_SANS_MAD_RUNGIS_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				tRunJob_9Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tJava_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";
	
	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_9");
		org.slf4j.MDC.put("_subJobPid", "dtrduD_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_9", false);
		start_Hash.put("tRunJob_9", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_9{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_9 = new StringBuilder();
                    log4jParamters_tRunJob_9.append("Parameters:");
                            log4jParamters_tRunJob_9.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PROCESS" + " = " + "SANS_MAD_RUNGIS_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("OnDemand_DB_Password")+", PARAM_VALUE_COLUMN="+("context.OnDemand_DB_Password")+"}]");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + (log4jParamters_tRunJob_9) );
                    } 
                } 
            new BytesLimit65535_tRunJob_9().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_9", "SANS_MAD_RUNGIS_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_9 begin ] stop
 */
	
	/**
	 * [tRunJob_9 main ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_9 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_9.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_9.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_9.add("--father_node=tRunJob_9");
	      			
	        				paraList_tRunJob_9.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_9.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_9.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_9.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_9.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_9 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_9 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_9".equals(tRunJobName_tRunJob_9) && childResumePath_tRunJob_9 != null){
		paraList_tRunJob_9.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_9.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_9");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_9 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_9 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_9.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_9.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_9.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("file_source", context.file_source);
                    paraList_tRunJob_9.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_9.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_9.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_9.put("Hote", context.Hote);
                    paraList_tRunJob_9.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_9.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_9.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_9.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_9.put("Port", context.Port);
                    paraList_tRunJob_9.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_9.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_9.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_9.put("User", context.User);
                    paraList_tRunJob_9.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_9.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_9.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_9.put("Server_In", context.Server_In);
                    paraList_tRunJob_9.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_9.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_9.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_9.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_9.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_9.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_9.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_9.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_9().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_9 = context.propertyNames();
		while (propertyNames_tRunJob_9.hasMoreElements()) {
			String key_tRunJob_9 = (String) propertyNames_tRunJob_9.nextElement();
			Object value_tRunJob_9 = (Object) context.get(key_tRunJob_9);
			if(value_tRunJob_9!=null) {  
				
					paraList_tRunJob_9.add("--context_param " + key_tRunJob_9 + "=" + value_tRunJob_9);
					
			} else {
				paraList_tRunJob_9.add("--context_param " + key_tRunJob_9 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_9 = null;

	
		obj_tRunJob_9 = context.OnDemand_DB_Password;
		if(obj_tRunJob_9!=null) {
			if (obj_tRunJob_9.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_9.add("--context_param OnDemand_DB_Password=" + ((java.util.Date) obj_tRunJob_9).getTime());
			} else {
				
					paraList_tRunJob_9.add("--context_param OnDemand_DB_Password=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_9));
					
				
			}
		} else {
			paraList_tRunJob_9.add("--context_param OnDemand_DB_Password=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_9.put("OnDemand_DB_Password", obj_tRunJob_9);
	
	
		cajoo.sans_mad_rungis_prod_v1_vehicule_0_1.SANS_MAD_RUNGIS_PROD_V1_VEHICULE childJob_tRunJob_9 = new cajoo.sans_mad_rungis_prod_v1_vehicule_0_1.SANS_MAD_RUNGIS_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_9 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_9) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_9 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_9 : talendDataSources_tRunJob_9
			        .entrySet()) {
	            dataSources_tRunJob_9.put(talendDataSourceEntry_tRunJob_9.getKey(),
	                    talendDataSourceEntry_tRunJob_9.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_9.setDataSources(dataSources_tRunJob_9);
	    }
		  
			childJob_tRunJob_9.parentContextMap = parentContextMap_tRunJob_9;
		  
		
			log.info("tRunJob_9 - The child job 'cajoo.sans_mad_rungis_prod_v1_vehicule_0_1.SANS_MAD_RUNGIS_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_9 = childJob_tRunJob_9.runJob((String[]) paraList_tRunJob_9.toArray(new String[paraList_tRunJob_9.size()]));
		
			log.info("tRunJob_9 - The child job 'cajoo.sans_mad_rungis_prod_v1_vehicule_0_1.SANS_MAD_RUNGIS_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_9.getErrorCode() == null){
                globalMap.put("tRunJob_9_CHILD_RETURN_CODE", childJob_tRunJob_9.getStatus() != null && ("failure").equals(childJob_tRunJob_9.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_9_CHILD_RETURN_CODE", childJob_tRunJob_9.getErrorCode());
            }
            if (childJob_tRunJob_9.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_9_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_9.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_9.getErrorCode();
                if (childJob_tRunJob_9.getErrorCode() != null || ("failure").equals(childJob_tRunJob_9.getStatus())) {
                    java.lang.Exception ce_tRunJob_9 = childJob_tRunJob_9.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_9!=null) ? (ce_tRunJob_9.getClass().getName() + ": " + ce_tRunJob_9.getMessage()) : ""));
                }

 


	tos_count_tRunJob_9++;

/**
 * [tRunJob_9 main ] stop
 */
	
	/**
	 * [tRunJob_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_9 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_9 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_9 end ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + ("Done.") );

ok_Hash.put("tRunJob_9", true);
end_Hash.put("tRunJob_9", System.currentTimeMillis());




/**
 * [tRunJob_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_9 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="SANS_MAD_RUNGIS_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_9_SUBPROCESS_STATE", 1);
	}
	


public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_7");
		org.slf4j.MDC.put("_subJobPid", "nTI4G5_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";
	
	
		int tos_count_tJava_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_7", "tJava_7", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";
	
	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_7";
	
	

 



/**
 * [tJava_7 process_data_begin ] stop
 */
	
	/**
	 * [tJava_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_7";
	
	

 



/**
 * [tJava_7 process_data_end ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";
	
	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_URBANTZ_TO_HUB_MAD_DB_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				tRunJob_5Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk9", 0, "ok");
								} 
							
							tJava_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";
	
	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_5");
		org.slf4j.MDC.put("_subJobPid", "5s9rzn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_5", false);
		start_Hash.put("tRunJob_5", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_5 = new StringBuilder();
                    log4jParamters_tRunJob_5.append("Parameters:");
                            log4jParamters_tRunJob_5.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROCESS" + " = " + "MAD_DB_DETAILED_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("OnDemand_DB_Password")+", PARAM_VALUE_COLUMN="+("context.OnDemand_DB_Password")+"}]");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + (log4jParamters_tRunJob_5) );
                    } 
                } 
            new BytesLimit65535_tRunJob_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_5", "MAD_DB_DETAILED_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_5 begin ] stop
 */
	
	/**
	 * [tRunJob_5 main ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_5 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_5.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_5.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_5.add("--father_node=tRunJob_5");
	      			
	        				paraList_tRunJob_5.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_5.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_5.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_5.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_5.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_5 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_5 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_5".equals(tRunJobName_tRunJob_5) && childResumePath_tRunJob_5 != null){
		paraList_tRunJob_5.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_5.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_5");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_5 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_5 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_5.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_5.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_5.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("file_source", context.file_source);
                    paraList_tRunJob_5.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_5.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_5.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_5.put("Hote", context.Hote);
                    paraList_tRunJob_5.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_5.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_5.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_5.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_5.put("Port", context.Port);
                    paraList_tRunJob_5.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_5.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_5.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_5.put("User", context.User);
                    paraList_tRunJob_5.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_5.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_5.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_5.put("Server_In", context.Server_In);
                    paraList_tRunJob_5.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_5.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_5.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_5.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_5.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_5.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_5.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_5.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_5().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_5 = context.propertyNames();
		while (propertyNames_tRunJob_5.hasMoreElements()) {
			String key_tRunJob_5 = (String) propertyNames_tRunJob_5.nextElement();
			Object value_tRunJob_5 = (Object) context.get(key_tRunJob_5);
			if(value_tRunJob_5!=null) {  
				
					paraList_tRunJob_5.add("--context_param " + key_tRunJob_5 + "=" + value_tRunJob_5);
					
			} else {
				paraList_tRunJob_5.add("--context_param " + key_tRunJob_5 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_5 = null;

	
		obj_tRunJob_5 = context.OnDemand_DB_Password;
		if(obj_tRunJob_5!=null) {
			if (obj_tRunJob_5.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_5.add("--context_param OnDemand_DB_Password=" + ((java.util.Date) obj_tRunJob_5).getTime());
			} else {
				
					paraList_tRunJob_5.add("--context_param OnDemand_DB_Password=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
					
				
			}
		} else {
			paraList_tRunJob_5.add("--context_param OnDemand_DB_Password=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("OnDemand_DB_Password", obj_tRunJob_5);
	
	
		cajoo.mad_db_detailed_prod_v1_vehicule_0_1.MAD_DB_DETAILED_PROD_V1_VEHICULE childJob_tRunJob_5 = new cajoo.mad_db_detailed_prod_v1_vehicule_0_1.MAD_DB_DETAILED_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_5 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_5) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_5 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_5 : talendDataSources_tRunJob_5
			        .entrySet()) {
	            dataSources_tRunJob_5.put(talendDataSourceEntry_tRunJob_5.getKey(),
	                    talendDataSourceEntry_tRunJob_5.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_5.setDataSources(dataSources_tRunJob_5);
	    }
		  
			childJob_tRunJob_5.parentContextMap = parentContextMap_tRunJob_5;
		  
		
			log.info("tRunJob_5 - The child job 'cajoo.mad_db_detailed_prod_v1_vehicule_0_1.MAD_DB_DETAILED_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_5 = childJob_tRunJob_5.runJob((String[]) paraList_tRunJob_5.toArray(new String[paraList_tRunJob_5.size()]));
		
			log.info("tRunJob_5 - The child job 'cajoo.mad_db_detailed_prod_v1_vehicule_0_1.MAD_DB_DETAILED_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_5.getErrorCode() == null){
                globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getStatus() != null && ("failure").equals(childJob_tRunJob_5.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getErrorCode());
            }
            if (childJob_tRunJob_5.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_5_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_5.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_5.getErrorCode();
                if (childJob_tRunJob_5.getErrorCode() != null || ("failure").equals(childJob_tRunJob_5.getStatus())) {
                    java.lang.Exception ce_tRunJob_5 = childJob_tRunJob_5.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_5!=null) ? (ce_tRunJob_5.getClass().getName() + ": " + ce_tRunJob_5.getMessage()) : ""));
                }

 


	tos_count_tRunJob_5++;

/**
 * [tRunJob_5 main ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_5 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_5 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_5 end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Done.") );

ok_Hash.put("tRunJob_5", true);
end_Hash.put("tRunJob_5", System.currentTimeMillis());




/**
 * [tRunJob_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_5 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="MAD_DB_DETAILED_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_5_SUBPROCESS_STATE", 1);
	}
	


public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_8");
		org.slf4j.MDC.put("_subJobPid", "p9R4um_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";
	
	
		int tos_count_tJava_8 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_8", "tJava_8", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";
	
	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_8";
	
	

 



/**
 * [tJava_8 process_data_begin ] stop
 */
	
	/**
	 * [tJava_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_8";
	
	

 



/**
 * [tJava_8 process_data_end ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";
	
	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ECOLOTRANS_ROUND_CALCULATE_NEW_RULE_QUANTITY_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				tRunJob_4Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}



/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk10", 0, "ok");
								} 
							
							tJava_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";
	
	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_4");
		org.slf4j.MDC.put("_subJobPid", "h4jHmc_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_4", false);
		start_Hash.put("tRunJob_4", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		
		int tos_count_tRunJob_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_4 = new StringBuilder();
                    log4jParamters_tRunJob_4.append("Parameters:");
                            log4jParamters_tRunJob_4.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROCESS" + " = " + "ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + (log4jParamters_tRunJob_4) );
                    } 
                } 
            new BytesLimit65535_tRunJob_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_4", "ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_4 begin ] stop
 */
	
	/**
	 * [tRunJob_4 main ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		
	java.util.List<String> paraList_tRunJob_4 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_4.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_4.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_4.add("--father_node=tRunJob_4");
	      			
	        				paraList_tRunJob_4.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_4.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_4.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_4.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_4.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_4 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_4 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_4".equals(tRunJobName_tRunJob_4) && childResumePath_tRunJob_4 != null){
		paraList_tRunJob_4.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_4.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_4");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_4 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_4 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_4.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_4.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_4.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("file_source", context.file_source);
                    paraList_tRunJob_4.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_4.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_4.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_4.put("Hote", context.Hote);
                    paraList_tRunJob_4.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_4.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_4.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_4.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_4.put("Port", context.Port);
                    paraList_tRunJob_4.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_4.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_4.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_4.put("User", context.User);
                    paraList_tRunJob_4.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_4.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_4.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_4.put("Server_In", context.Server_In);
                    paraList_tRunJob_4.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_4.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_4.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_4.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_4.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_4.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_4.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_4.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_4().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_4 = context.propertyNames();
		while (propertyNames_tRunJob_4.hasMoreElements()) {
			String key_tRunJob_4 = (String) propertyNames_tRunJob_4.nextElement();
			Object value_tRunJob_4 = (Object) context.get(key_tRunJob_4);
			if(value_tRunJob_4!=null) {  
				
					paraList_tRunJob_4.add("--context_param " + key_tRunJob_4 + "=" + value_tRunJob_4);
					
			} else {
				paraList_tRunJob_4.add("--context_param " + key_tRunJob_4 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_4 = null;

	
	
		cajoo.round_calculate_new_rule_quantity_prod_v4_vehicules_calcul_0_1.ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL childJob_tRunJob_4 = new cajoo.round_calculate_new_rule_quantity_prod_v4_vehicules_calcul_0_1.ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_4 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_4) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_4 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_4 : talendDataSources_tRunJob_4
			        .entrySet()) {
	            dataSources_tRunJob_4.put(talendDataSourceEntry_tRunJob_4.getKey(),
	                    talendDataSourceEntry_tRunJob_4.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_4.setDataSources(dataSources_tRunJob_4);
	    }
		  
			childJob_tRunJob_4.parentContextMap = parentContextMap_tRunJob_4;
		  
		
			log.info("tRunJob_4 - The child job 'cajoo.round_calculate_new_rule_quantity_prod_v4_vehicules_calcul_0_1.ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_4 = childJob_tRunJob_4.runJob((String[]) paraList_tRunJob_4.toArray(new String[paraList_tRunJob_4.size()]));
		
			log.info("tRunJob_4 - The child job 'cajoo.round_calculate_new_rule_quantity_prod_v4_vehicules_calcul_0_1.ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL' is done.");
		
            if(childJob_tRunJob_4.getErrorCode() == null){
                globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getStatus() != null && ("failure").equals(childJob_tRunJob_4.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getErrorCode());
            }
            if (childJob_tRunJob_4.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_4_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_4.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_4.getErrorCode();
                if (childJob_tRunJob_4.getErrorCode() != null || ("failure").equals(childJob_tRunJob_4.getStatus())) {
                    java.lang.Exception ce_tRunJob_4 = childJob_tRunJob_4.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_4!=null) ? (ce_tRunJob_4.getClass().getName() + ": " + ce_tRunJob_4.getMessage()) : ""));
                }

 


	tos_count_tRunJob_4++;

/**
 * [tRunJob_4 main ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		

 



/**
 * [tRunJob_4 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		

 



/**
 * [tRunJob_4 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_4 end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Done.") );

ok_Hash.put("tRunJob_4", true);
end_Hash.put("tRunJob_4", System.currentTimeMillis());




/**
 * [tRunJob_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_4 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="ROUND_CALCULATE_NEW_RULE_QUANTITY_PROD_V4_VEHICULES_CALCUL";
		
	
 



/**
 * [tRunJob_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_4_SUBPROCESS_STATE", 1);
	}
	


public void tJava_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_9");
		org.slf4j.MDC.put("_subJobPid", "jRutNe_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";
	
	
		int tos_count_tJava_9 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_9", "tJava_9", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";
	
	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_9";
	
	

 



/**
 * [tJava_9 process_data_begin ] stop
 */
	
	/**
	 * [tJava_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_9";
	
	

 



/**
 * [tJava_9 process_data_end ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";
	
	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());

   			if (((String)globalMap.get("jobs_to_start")).contains("ROUND_ECOLOTRANS_DIAGNOSTIC_LIVRAISON_QUANTITY_ONDEMAND")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				tRunJob_14Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tJava_9 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tFixedFlowInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";
	
	

 



/**
 * [tJava_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_14");
		org.slf4j.MDC.put("_subJobPid", "i3VxUf_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_14", false);
		start_Hash.put("tRunJob_14", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		
		int tos_count_tRunJob_14 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_14 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_14{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_14 = new StringBuilder();
                    log4jParamters_tRunJob_14.append("Parameters:");
                            log4jParamters_tRunJob_14.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("PROCESS" + " = " + "DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("OnDemand_DB_Password")+", PARAM_VALUE_COLUMN="+("context.OnDemand_DB_Password")+"}]");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_14.append(" | ");
                            log4jParamters_tRunJob_14.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_14.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_14 - "  + (log4jParamters_tRunJob_14) );
                    } 
                } 
            new BytesLimit65535_tRunJob_14().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_14", "DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_14 begin ] stop
 */
	
	/**
	 * [tRunJob_14 main ] start
	 */

	

	
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		
	java.util.List<String> paraList_tRunJob_14 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_14.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_14.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_14.add("--father_node=tRunJob_14");
	      			
	        				paraList_tRunJob_14.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_14.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_14.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_14.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_14.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_14 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_14 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_14".equals(tRunJobName_tRunJob_14) && childResumePath_tRunJob_14 != null){
		paraList_tRunJob_14.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_14.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_14");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_14 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
            class ContextProcessor_tRunJob_14 {
                    private void transmitContext_0() {
                    parentContextMap_tRunJob_14.put("transaction_id", context.transaction_id);
                    paraList_tRunJob_14.add("--context_type " + "transaction_id" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("jobs_to_start", context.jobs_to_start);
                    paraList_tRunJob_14.add("--context_type " + "jobs_to_start" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("file_source", context.file_source);
                    paraList_tRunJob_14.add("--context_type " + "file_source" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("ondemand_server_directory", context.ondemand_server_directory);
                    paraList_tRunJob_14.add("--context_type " + "ondemand_server_directory" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("DB_Password", context.DB_Password);
                    paraList_tRunJob_14.add("--context_type " + "DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_14.put("Hote", context.Hote);
                    paraList_tRunJob_14.add("--context_type " + "Hote" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Hote_Ondemand", context.Hote_Ondemand);
                    paraList_tRunJob_14.add("--context_type " + "Hote_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Ondemand_Database", context.Ondemand_Database);
                    paraList_tRunJob_14.add("--context_type " + "Ondemand_Database" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("OnDemand_DB_Password", context.OnDemand_DB_Password);
                    paraList_tRunJob_14.add("--context_type " + "OnDemand_DB_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_14.put("Port", context.Port);
                    paraList_tRunJob_14.add("--context_type " + "Port" + "=" + "id_Integer");
                    parentContextMap_tRunJob_14.put("Port_Ondemand", context.Port_Ondemand);
                    paraList_tRunJob_14.add("--context_type " + "Port_Ondemand" + "=" + "id_Integer");
                    parentContextMap_tRunJob_14.put("User", context.User);
                    paraList_tRunJob_14.add("--context_type " + "User" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("User_Ondemand", context.User_Ondemand);
                    paraList_tRunJob_14.add("--context_type " + "User_Ondemand" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("FTP_Password", context.FTP_Password);
                    paraList_tRunJob_14.add("--context_type " + "FTP_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_14.put("Server_In", context.Server_In);
                    paraList_tRunJob_14.add("--context_type " + "Server_In" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Ondemand_Server_Address", context.Ondemand_Server_Address);
                    paraList_tRunJob_14.add("--context_type " + "Ondemand_Server_Address" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Ondemand_Server_Password", context.Ondemand_Server_Password);
                    paraList_tRunJob_14.add("--context_type " + "Ondemand_Server_Password" + "=" + "id_Password");
                    parentContextMap_tRunJob_14.put("Ondemand_Server_Port", context.Ondemand_Server_Port);
                    paraList_tRunJob_14.add("--context_type " + "Ondemand_Server_Port" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Ondemand_Server_User", context.Ondemand_Server_User);
                    paraList_tRunJob_14.add("--context_type " + "Ondemand_Server_User" + "=" + "id_String");
                    parentContextMap_tRunJob_14.put("Csv_File_Masque", context.Csv_File_Masque);
                    paraList_tRunJob_14.add("--context_type " + "Csv_File_Masque" + "=" + "id_String");
                        }
                    public void transmitAllContext() {
                        transmitContext_0();
                    }
            }
            new ContextProcessor_tRunJob_14().transmitAllContext();
		java.util.Enumeration<?> propertyNames_tRunJob_14 = context.propertyNames();
		while (propertyNames_tRunJob_14.hasMoreElements()) {
			String key_tRunJob_14 = (String) propertyNames_tRunJob_14.nextElement();
			Object value_tRunJob_14 = (Object) context.get(key_tRunJob_14);
			if(value_tRunJob_14!=null) {  
				
					paraList_tRunJob_14.add("--context_param " + key_tRunJob_14 + "=" + value_tRunJob_14);
					
			} else {
				paraList_tRunJob_14.add("--context_param " + key_tRunJob_14 + "=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
			}
			
		}
		

	Object obj_tRunJob_14 = null;

	
		obj_tRunJob_14 = context.OnDemand_DB_Password;
		if(obj_tRunJob_14!=null) {
			if (obj_tRunJob_14.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_14.add("--context_param OnDemand_DB_Password=" + ((java.util.Date) obj_tRunJob_14).getTime());
			} else {
				
					paraList_tRunJob_14.add("--context_param OnDemand_DB_Password=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_14));
					
				
			}
		} else {
			paraList_tRunJob_14.add("--context_param OnDemand_DB_Password=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_14.put("OnDemand_DB_Password", obj_tRunJob_14);
	
	
		cajoo.diagnostic_livraison_quantity_prod_v1_vehicule_0_1.DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE childJob_tRunJob_14 = new cajoo.diagnostic_livraison_quantity_prod_v1_vehicule_0_1.DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_14 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_14) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_14 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_14 : talendDataSources_tRunJob_14
			        .entrySet()) {
	            dataSources_tRunJob_14.put(talendDataSourceEntry_tRunJob_14.getKey(),
	                    talendDataSourceEntry_tRunJob_14.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_14.setDataSources(dataSources_tRunJob_14);
	    }
		  
			childJob_tRunJob_14.parentContextMap = parentContextMap_tRunJob_14;
		  
		
			log.info("tRunJob_14 - The child job 'cajoo.diagnostic_livraison_quantity_prod_v1_vehicule_0_1.DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_14 = childJob_tRunJob_14.runJob((String[]) paraList_tRunJob_14.toArray(new String[paraList_tRunJob_14.size()]));
		
			log.info("tRunJob_14 - The child job 'cajoo.diagnostic_livraison_quantity_prod_v1_vehicule_0_1.DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE' is done.");
		
            if(childJob_tRunJob_14.getErrorCode() == null){
                globalMap.put("tRunJob_14_CHILD_RETURN_CODE", childJob_tRunJob_14.getStatus() != null && ("failure").equals(childJob_tRunJob_14.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_14_CHILD_RETURN_CODE", childJob_tRunJob_14.getErrorCode());
            }
            if (childJob_tRunJob_14.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_14_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_14.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_14.getErrorCode();
                if (childJob_tRunJob_14.getErrorCode() != null || ("failure").equals(childJob_tRunJob_14.getStatus())) {
                    java.lang.Exception ce_tRunJob_14 = childJob_tRunJob_14.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_14!=null) ? (ce_tRunJob_14.getClass().getName() + ": " + ce_tRunJob_14.getMessage()) : ""));
                }

 


	tos_count_tRunJob_14++;

/**
 * [tRunJob_14 main ] stop
 */
	
	/**
	 * [tRunJob_14 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_14 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_14 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		

 



/**
 * [tRunJob_14 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_14 end ] start
	 */

	

	
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_14 - "  + ("Done.") );

ok_Hash.put("tRunJob_14", true);
end_Hash.put("tRunJob_14", System.currentTimeMillis());




/**
 * [tRunJob_14 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_14 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_14";
	
	
			cLabel="DIAGNOSTIC_LIVRAISON_QUANTITY_PROD_V1_VEHICULE";
		
	
 



/**
 * [tRunJob_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_14_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int transactionId;

				public int getTransactionId () {
					return this.transactionId;
				}

				public Boolean transactionIdIsNullable(){
				    return false;
				}
				public Boolean transactionIdIsKey(){
				    return true;
				}
				public Integer transactionIdLength(){
				    return null;
				}
				public Integer transactionIdPrecision(){
				    return null;
				}
				public String transactionIdDefault(){
				
					return null;
				
				}
				public String transactionIdComment(){
				
				    return "";
				
				}
				public String transactionIdPattern(){
				
					return "";
				
				}
				public String transactionIdOriginalDbColumnName(){
				
					return "transactionId";
				
				}

				
			    public String transactionStatus;

				public String getTransactionStatus () {
					return this.transactionStatus;
				}

				public Boolean transactionStatusIsNullable(){
				    return true;
				}
				public Boolean transactionStatusIsKey(){
				    return false;
				}
				public Integer transactionStatusLength(){
				    return null;
				}
				public Integer transactionStatusPrecision(){
				    return null;
				}
				public String transactionStatusDefault(){
				
					return null;
				
				}
				public String transactionStatusComment(){
				
				    return "";
				
				}
				public String transactionStatusPattern(){
				
					return "";
				
				}
				public String transactionStatusOriginalDbColumnName(){
				
					return "transactionStatus";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.transactionId;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.transactionId != other.transactionId)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.transactionId = this.transactionId;
	            other.transactionStatus = this.transactionStatus;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.transactionId = this.transactionId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.transactionId = dis.readInt();
					
					this.transactionStatus = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.transactionId = dis.readInt();
					
					this.transactionStatus = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.transactionId);
					
					// String
				
						writeString(this.transactionStatus,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.transactionId);
					
					// String
				
						writeString(this.transactionStatus,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("transactionId="+String.valueOf(transactionId));
		sb.append(",transactionStatus="+transactionStatus);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(transactionId);
        			
        			sb.append("|");
        		
        				if(transactionStatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(transactionStatus);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.transactionId, other.transactionId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFixedFlowInput_1");
		org.slf4j.MDC.put("_subJobPid", "EmsReh_" + subJobPidCounter.getAndIncrement());
	

		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tWriteJSONField_1_Out begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_1_Out", false);
		start_Hash.put("tWriteJSONField_1_Out", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tWriteJSONField_1_Out = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWriteJSONField_1_Out{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWriteJSONField_1_Out = new StringBuilder();
                    log4jParamters_tWriteJSONField_1_Out.append("Parameters:");
                            log4jParamters_tWriteJSONField_1_Out.append("GROUPBYS" + " = " + "[]");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("REMOVE_HEADER" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("CREATE" + " = " + "true");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("CREATE_EMPTY_ELEMENT" + " = " + "true");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("EXPAND_EMPTY_ELM" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("ALLOW_EMPTY_STRINGS" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("OUTPUT_AS_XSD" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("COMPACT_FORMAT" + " = " + "true");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("GENERATION_MODE" + " = " + "Dom4j");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                            log4jParamters_tWriteJSONField_1_Out.append("DESTINATION" + " = " + "tWriteJSONField_1");
                        log4jParamters_tWriteJSONField_1_Out.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + (log4jParamters_tWriteJSONField_1_Out) );
                    } 
                } 
            new BytesLimit65535_tWriteJSONField_1_Out().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWriteJSONField_1_Out", "tWriteJSONField_1_Out", "tWriteXMLFieldOut");
				talendJobLogProcess(globalMap);
			}
			
//tWriteXMLFieldOut_begin
				int nb_line_tWriteJSONField_1_Out = 0;
				boolean needRoot_tWriteJSONField_1_Out  = true;
				
				String  strCompCache_tWriteJSONField_1_Out= null;		
				
						        java.util.Queue<row5Struct> listGroupby_tWriteJSONField_1_Out = new java.util.concurrent.ConcurrentLinkedQueue<row5Struct>();
							
	
					class ThreadXMLField_tWriteJSONField_1_Out implements java.lang.Runnable {
						
									    java.util.Queue<row5Struct> queue;
									
						java.util.List<java.util.Map<String,String>> flows;
						java.lang.Exception lastException;
						java.lang.Error lastError;
						String currentComponent;
						
						ThreadXMLField_tWriteJSONField_1_Out(java.util.Queue q) {
							this.queue = q;
							globalMap.put("queue_tWriteJSONField_1_In", queue);
							lastException = null;
						}
						
						ThreadXMLField_tWriteJSONField_1_Out(java.util.Queue q, java.util.List<java.util.Map<String,String>> l) {
							this.queue = q;
							this.flows = l;
							lastException = null;
							globalMap.put("queue_tWriteJSONField_1_In", queue);
							globalMap.put("flows_tWriteJSONField_1_In", flows);
						}
						
						public java.lang.Exception getLastException() {
							return this.lastException;
						}
						
						public java.lang.Error getLastError() {
							return this.lastError;
						}
						
						public String getCurrentComponent() {
							return this.currentComponent;
						}
	
						@Override
						public void run() {
							try {
								tWriteJSONField_1_InProcess(globalMap);
							} catch (TalendException te) {
globalMap.put("tWriteJSONField_1_Out_ERROR_MESSAGE",te.getMessage());
								this.lastException = te.getException();
								this.currentComponent = te.getCurrentComponent();
							} catch (java.lang.Error error) {
								this.lastError = error;
							}
						}
					}
					
						ThreadXMLField_tWriteJSONField_1_Out txf_tWriteJSONField_1_Out = new ThreadXMLField_tWriteJSONField_1_Out(listGroupby_tWriteJSONField_1_Out);
					
					
					java.util.concurrent.Future<?> future_tWriteJSONField_1_Out = es.submit(txf_tWriteJSONField_1_Out);
					globalMap.put("wrtXMLFieldIn_tWriteJSONField_1_Out", future_tWriteJSONField_1_Out);
				

java.util.List<java.util.List<String>> groupbyList_tWriteJSONField_1_Out = new java.util.ArrayList<java.util.List<String>>();
java.util.Map<String,String> valueMap_tWriteJSONField_1_Out = new java.util.HashMap<String,String>();
java.util.Map<String,String> arraysValueMap_tWriteJSONField_1_Out = new java.util.HashMap<String,String>();

class NestXMLTool_tWriteJSONField_1_Out{
	public void parseAndAdd(org.dom4j.Element nestRoot, String value){
		try {
            org.dom4j.Document doc4Str = org.dom4j.DocumentHelper.parseText("<root>"+ value + "</root>");
    		nestRoot.setContent(doc4Str.getRootElement().content());
    	} catch (java.lang.Exception e) {
globalMap.put("tWriteJSONField_1_Out_ERROR_MESSAGE",e.getMessage());
    		e.printStackTrace();
    		nestRoot.setText(value);
        }
	}
	
	public void setText(org.dom4j.Element element, String value){
		if (value.startsWith("<![CDATA[") && value.endsWith("]]>")) {
			String text = value.substring(9, value.length()-3);
			element.addCDATA(text);
		}else{
			element.setText(value);
		}
	}
	
	public void replaceDefaultNameSpace(org.dom4j.Element nestRoot){
		if (nestRoot!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) nestRoot.elements()) {
        		if (("").equals(tmp.getQName().getNamespace().getURI()) && ("").equals(tmp.getQName().getNamespace().getPrefix())){
        			tmp.setQName(org.dom4j.DocumentHelper.createQName(tmp.getName(), nestRoot.getQName().getNamespace()));
	        	}
    	    	replaceDefaultNameSpace(tmp);
       		}
       	}
	}
	
	public void removeEmptyElement(org.dom4j.Element root){
		if (root!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) root.elements()) {
				removeEmptyElement(tmp);
			}

            boolean noSignificantDataAnnotationsExist = root.attributes().isEmpty() ;
            if (root.content().isEmpty()
                && noSignificantDataAnnotationsExist && root.declaredNamespaces().isEmpty()) {
                if(root.getParent()!=null){
                    root.getParent().remove(root);
                }
            }
        }
    }
	public String objectToString(Object value){
		if(value.getClass().isArray()){
			StringBuilder sb = new StringBuilder();

			int length = java.lang.reflect.Array.getLength(value);
			for (int i = 0; i < length; i++) {
				Object obj = java.lang.reflect.Array.get(value, i);
				sb.append("<element>");
				sb.append(obj);
				sb.append("</element>");
			}
			return sb.toString();
		}else{
			return value.toString();
		}
	}
}
NestXMLTool_tWriteJSONField_1_Out nestXMLTool_tWriteJSONField_1_Out = new NestXMLTool_tWriteJSONField_1_Out();

row3Struct  rowStructOutput_tWriteJSONField_1_Out = new row3Struct();
// sort group root element for judgement of group
java.util.List<org.dom4j.Element> groupElementList_tWriteJSONField_1_Out = new java.util.ArrayList<org.dom4j.Element>();
org.dom4j.Element root4Group_tWriteJSONField_1_Out = null;
org.dom4j.Document doc_tWriteJSONField_1_Out  = org.dom4j.DocumentHelper.createDocument();
org.dom4j.io.OutputFormat format_tWriteJSONField_1_Out = org.dom4j.io.OutputFormat.createCompactFormat();
format_tWriteJSONField_1_Out.setNewLineAfterDeclaration(false);
format_tWriteJSONField_1_Out.setTrimText(false);
format_tWriteJSONField_1_Out.setEncoding("ISO-8859-15");
int[] orders_tWriteJSONField_1_Out = new int[1];

 



/**
 * [tWriteJSONField_1_Out begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";
	
	
		int tos_count_tFixedFlowInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFixedFlowInput_1", "tFixedFlowInput_1", "tFixedFlowInput");
				talendJobLogProcess(globalMap);
			}
			

	    for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < 1 ; i_tFixedFlowInput_1++) {
	                	            	
    	            		row3.transactionId = Integer.parseInt(context.transaction_id);
    	            	        	            	
    	            		row3.transactionStatus = "Terminé";
    	            	

 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tWriteJSONField_1_Out main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tFixedFlowInput_1","tFixedFlowInput_1","tFixedFlowInput","tWriteJSONField_1_Out","tWriteJSONField_1_Out","tWriteXMLFieldOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

	if(txf_tWriteJSONField_1_Out.getLastException()!=null) {
		currentComponent = txf_tWriteJSONField_1_Out.getCurrentComponent();
		throw txf_tWriteJSONField_1_Out.getLastException();
	}
	
	if(txf_tWriteJSONField_1_Out.getLastError()!=null) {
		throw txf_tWriteJSONField_1_Out.getLastError();
	}
	nb_line_tWriteJSONField_1_Out++;
				log.debug("tWriteJSONField_1_Out - Processing the record " + nb_line_tWriteJSONField_1_Out + ".");
			
	class ToStringHelper_tWriteJSONField_1_Out {
	    public String toString(final Object value) {
	        return value != null ? value.toString() : null;
	    }
	}
	final ToStringHelper_tWriteJSONField_1_Out helper_tWriteJSONField_1_Out = new ToStringHelper_tWriteJSONField_1_Out();

	valueMap_tWriteJSONField_1_Out.clear();
	arraysValueMap_tWriteJSONField_1_Out.clear();
	valueMap_tWriteJSONField_1_Out.put("transactionId", helper_tWriteJSONField_1_Out.toString(
	(
            String.valueOf(row3.transactionId)
		)));
	arraysValueMap_tWriteJSONField_1_Out.put("transactionId", helper_tWriteJSONField_1_Out.toString(
	(
            String.valueOf(row3.transactionId)
		)));
	valueMap_tWriteJSONField_1_Out.put("transactionStatus", helper_tWriteJSONField_1_Out.toString(
	(
		row3.transactionStatus != null?
            row3.transactionStatus.toString():null
		)));
	arraysValueMap_tWriteJSONField_1_Out.put("transactionStatus", helper_tWriteJSONField_1_Out.toString(
	(
		row3.transactionStatus != null?
            row3.transactionStatus.toString():null
		)));
		String strTemp_tWriteJSONField_1_Out = "";
	if(strCompCache_tWriteJSONField_1_Out==null){
		strCompCache_tWriteJSONField_1_Out=strTemp_tWriteJSONField_1_Out;
		
	}else{  
    		nestXMLTool_tWriteJSONField_1_Out.replaceDefaultNameSpace(doc_tWriteJSONField_1_Out.getRootElement());			
			java.io.StringWriter strWriter_tWriteJSONField_1_Out = new java.io.StringWriter();	
			org.dom4j.io.XMLWriter output_tWriteJSONField_1_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_1_Out, format_tWriteJSONField_1_Out);
			output_tWriteJSONField_1_Out.write(doc_tWriteJSONField_1_Out);
		    output_tWriteJSONField_1_Out.close();
			
				  		  row5Struct row_tWriteJSONField_1_Out = new row5Struct();
						  
					     		row_tWriteJSONField_1_Out.body = strWriter_tWriteJSONField_1_Out.toString();
					     		listGroupby_tWriteJSONField_1_Out.add(row_tWriteJSONField_1_Out);
					
		    doc_tWriteJSONField_1_Out.clearContent();
			needRoot_tWriteJSONField_1_Out = true;
			for(int i_tWriteJSONField_1_Out=0;i_tWriteJSONField_1_Out<orders_tWriteJSONField_1_Out.length;i_tWriteJSONField_1_Out++){
				orders_tWriteJSONField_1_Out[i_tWriteJSONField_1_Out] = 0;
			}
			
			if(groupbyList_tWriteJSONField_1_Out != null && groupbyList_tWriteJSONField_1_Out.size() >= 0){
				groupbyList_tWriteJSONField_1_Out.clear();
			}
			strCompCache_tWriteJSONField_1_Out=strTemp_tWriteJSONField_1_Out;
	}

	org.dom4j.Element subTreeRootParent_tWriteJSONField_1_Out = null;
	
	// build root xml tree 
	if (needRoot_tWriteJSONField_1_Out) {
		needRoot_tWriteJSONField_1_Out=false;
		org.dom4j.Element root_tWriteJSONField_1_Out = doc_tWriteJSONField_1_Out.addElement("root");
		subTreeRootParent_tWriteJSONField_1_Out = root_tWriteJSONField_1_Out;
		org.dom4j.Element root_0_tWriteJSONField_1_Out = root_tWriteJSONField_1_Out.addElement("transactionStatus");
		if(
		valueMap_tWriteJSONField_1_Out.get("transactionStatus")!=null){
			nestXMLTool_tWriteJSONField_1_Out .setText(root_0_tWriteJSONField_1_Out,
		valueMap_tWriteJSONField_1_Out.get("transactionStatus"));
		}
		root4Group_tWriteJSONField_1_Out = subTreeRootParent_tWriteJSONField_1_Out;
	}else{
		subTreeRootParent_tWriteJSONField_1_Out=root4Group_tWriteJSONField_1_Out;
	}
	// build group xml tree 
	// build loop xml tree
		org.dom4j.Element loop_tWriteJSONField_1_Out = org.dom4j.DocumentHelper.createElement("transactionId");
        if(orders_tWriteJSONField_1_Out[0]==0){
        	orders_tWriteJSONField_1_Out[0] = 0;
        }
        if(1 < orders_tWriteJSONField_1_Out.length){
        		orders_tWriteJSONField_1_Out[1] = 0;
        }
        subTreeRootParent_tWriteJSONField_1_Out.elements().add(orders_tWriteJSONField_1_Out[0]++,loop_tWriteJSONField_1_Out);
		if(
		valueMap_tWriteJSONField_1_Out.get("transactionId")!=null){
			nestXMLTool_tWriteJSONField_1_Out .setText(loop_tWriteJSONField_1_Out,
		valueMap_tWriteJSONField_1_Out.get("transactionId"));
            loop_tWriteJSONField_1_Out.addAttribute("type", "number");
		}

 


	tos_count_tWriteJSONField_1_Out++;

/**
 * [tWriteJSONField_1_Out main ] stop
 */
	
	/**
	 * [tWriteJSONField_1_Out process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	

 



/**
 * [tWriteJSONField_1_Out process_data_begin ] stop
 */
	
	/**
	 * [tWriteJSONField_1_Out process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	

 



/**
 * [tWriteJSONField_1_Out process_data_end ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 process_data_end ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

        }
        globalMap.put("tFixedFlowInput_1_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [tWriteJSONField_1_Out end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	

if(nb_line_tWriteJSONField_1_Out > 0){  
    nestXMLTool_tWriteJSONField_1_Out.replaceDefaultNameSpace(doc_tWriteJSONField_1_Out.getRootElement());
	java.io.StringWriter strWriter_tWriteJSONField_1_Out = new java.io.StringWriter();
	org.dom4j.io.XMLWriter output_tWriteJSONField_1_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_1_Out, format_tWriteJSONField_1_Out);
	output_tWriteJSONField_1_Out.write(doc_tWriteJSONField_1_Out);
    output_tWriteJSONField_1_Out.close();
					row5Struct row_tWriteJSONField_1_Out = new row5Struct();
						  
					     		row_tWriteJSONField_1_Out.body = strWriter_tWriteJSONField_1_Out.toString();
					     		listGroupby_tWriteJSONField_1_Out.add(row_tWriteJSONField_1_Out);
		    		

}
globalMap.put("tWriteJSONField_1_Out_NB_LINE",nb_line_tWriteJSONField_1_Out);
globalMap.put("tWriteJSONField_1_In_FINISH" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
	
		future_tWriteJSONField_1_Out.get();
		
		if(txf_tWriteJSONField_1_Out.getLastException()!=null) {
			currentComponent = txf_tWriteJSONField_1_Out.getCurrentComponent();
			throw txf_tWriteJSONField_1_Out.getLastException();
		}
		
		if(txf_tWriteJSONField_1_Out.getLastError()!=null) {
			throw txf_tWriteJSONField_1_Out.getLastError();
		}
	
resourceMap.put("finish_tWriteJSONField_1_Out", true);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tFixedFlowInput_1","tFixedFlowInput_1","tFixedFlowInput","tWriteJSONField_1_Out","tWriteJSONField_1_Out","tWriteXMLFieldOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_1_Out", true);
end_Hash.put("tWriteJSONField_1_Out", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk", 0, "ok");
				}



/**
 * [tWriteJSONField_1_Out end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tREST_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [tWriteJSONField_1_Out finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";
	
	

		java.util.Queue listGroupby_tWriteJSONField_1_Out = (java.util.Queue)globalMap.get("queue_tWriteJSONField_1_In");
		if(resourceMap.get("finish_tWriteJSONField_1_Out") == null){
			globalMap.put("tWriteJSONField_1_In_FINISH_WITH_EXCEPTION" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
		}
	
	if (listGroupby_tWriteJSONField_1_Out != null) {
		globalMap.put("tWriteJSONField_1_In_FINISH" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
	}
	// workaround for 37349 - in case of normal execution it will pass normally
	// in case it fails and handle by catch - it will wait for child thread finish
	java.util.concurrent.Future<?> future_tWriteJSONField_1_Out = (java.util.concurrent.Future) globalMap.get("wrtXMLFieldIn_tWriteJSONField_1_Out");
	if (future_tWriteJSONField_1_Out != null) {
		future_tWriteJSONField_1_Out.get();
	}

 



/**
 * [tWriteJSONField_1_Out finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String ResponseMessage;

				public String getResponseMessage () {
					return this.ResponseMessage;
				}

				public Boolean ResponseMessageIsNullable(){
				    return true;
				}
				public Boolean ResponseMessageIsKey(){
				    return false;
				}
				public Integer ResponseMessageLength(){
				    return null;
				}
				public Integer ResponseMessagePrecision(){
				    return null;
				}
				public String ResponseMessageDefault(){
				
					return null;
				
				}
				public String ResponseMessageComment(){
				
				    return "";
				
				}
				public String ResponseMessagePattern(){
				
					return "";
				
				}
				public String ResponseMessageOriginalDbColumnName(){
				
					return "ResponseMessage";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.ResponseMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.ResponseMessage = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.ResponseMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.ResponseMessage,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ResponseMessage="+ResponseMessage);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(ResponseMessage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ResponseMessage);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}

				public Boolean BodyIsNullable(){
				    return true;
				}
				public Boolean BodyIsKey(){
				    return false;
				}
				public Integer BodyLength(){
				    return 0;
				}
				public Integer BodyPrecision(){
				    return 0;
				}
				public String BodyDefault(){
				
					return "";
				
				}
				public String BodyComment(){
				
				    return null;
				
				}
				public String BodyPattern(){
				
				    return null;
				
				}
				public String BodyOriginalDbColumnName(){
				
					return "Body";
				
				}

				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}

				public Boolean ERROR_CODEIsNullable(){
				    return true;
				}
				public Boolean ERROR_CODEIsKey(){
				    return false;
				}
				public Integer ERROR_CODELength(){
				    return 0;
				}
				public Integer ERROR_CODEPrecision(){
				    return 0;
				}
				public String ERROR_CODEDefault(){
				
					return "";
				
				}
				public String ERROR_CODEComment(){
				
				    return null;
				
				}
				public String ERROR_CODEPattern(){
				
				    return null;
				
				}
				public String ERROR_CODEOriginalDbColumnName(){
				
					return "ERROR_CODE";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tREST_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tREST_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tREST_1");
		org.slf4j.MDC.put("_subJobPid", "0p81ay_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
row7Struct row7 = new row7Struct();





	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tJava_10 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_10", "tJava_10", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_10 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tExtractJSONFields_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_1 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_1.append("Parameters:");
                            log4jParamters_tExtractJSONFields_1.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSONFIELD" + " = " + "Body");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_LOOP_QUERY" + " = " + "\"$\"");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"$.message\"")+", SCHEMA_COLUMN="+("ResponseMessage")+"}]");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("USE_LOOP_AS_ROOT" + " = " + "true");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + (log4jParamters_tExtractJSONFields_1) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_1", "tExtractJSONFields_1", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tREST_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tREST_1", false);
		start_Hash.put("tREST_1", System.currentTimeMillis());
		
	
	currentComponent="tREST_1";
	
	
		int tos_count_tREST_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tREST_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tREST_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tREST_1 = new StringBuilder();
                    log4jParamters_tREST_1.append("Parameters:");
                            log4jParamters_tREST_1.append("URL" + " = " + "\"http://\" + context.Hote_Ondemand + \":8000/talendEsb/updateMetaDataFileInTableTransactionsLivraison\"");
                        log4jParamters_tREST_1.append(" | ");
                            log4jParamters_tREST_1.append("METHOD" + " = " + "POST");
                        log4jParamters_tREST_1.append(" | ");
                            log4jParamters_tREST_1.append("HEADERS" + " = " + "[{VALUE="+("\"application/json\"")+", NAME="+("\"content-type\"")+"}]");
                        log4jParamters_tREST_1.append(" | ");
                            log4jParamters_tREST_1.append("BODY" + " = " + "(String)globalMap.get(\"rest_api_body\")");
                        log4jParamters_tREST_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tREST_1 - "  + (log4jParamters_tREST_1) );
                    } 
                } 
            new BytesLimit65535_tREST_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tREST_1", "tREST_1", "tREST");
				talendJobLogProcess(globalMap);
			}
			
	

	
	String endpoint_tREST_1 = "http://" + context.Hote_Ondemand + ":8000/talendEsb/updateMetaDataFileInTableTransactionsLivraison";
	
	String trustStoreFile_tREST_1 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_tREST_1 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_tREST_1 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_tREST_1 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_tREST_1 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_tREST_1 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_tREST_1 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	
	// APPINT-33909: add entitiy providers (for OSGi deployment)
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.StringProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.ByteArrayProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.FileProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.InputStreamProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.DataSourceProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.MimeMultipartProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.FormProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.ReaderProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.DocumentProvider.class);
	config_tREST_1.getClasses().add(com.sun.jersey.core.impl.provider.entity.StreamingOutputProvider.class);
	
	javax.net.ssl.SSLContext ctx_tREST_1 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_tREST_1 = null;
	if(trustStoreFile_tREST_1!=null && trustStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(trustStorePWD_tREST_1!=null)
			password_tREST_1 = trustStorePWD_tREST_1.toCharArray();
		java.security.KeyStore trustStore_tREST_1 = java.security.KeyStore.getInstance(trustStoreType_tREST_1);
		trustStore_tREST_1.load(new java.io.FileInputStream(trustStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.TrustManagerFactory tmf_tREST_1 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_tREST_1.init(trustStore_tREST_1);
        tms_tREST_1 = tmf_tREST_1.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_tREST_1 = null;
	if(keyStoreFile_tREST_1!=null && keyStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(keyStorePWD_tREST_1!=null)
			password_tREST_1 = keyStorePWD_tREST_1.toCharArray();
		java.security.KeyStore keyStore_tREST_1 = java.security.KeyStore.getInstance(keyStoreType_tREST_1);
		keyStore_tREST_1.load(new java.io.FileInputStream(keyStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.KeyManagerFactory kmf_tREST_1 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_tREST_1.init(keyStore_tREST_1,password_tREST_1);
        kms_tREST_1 = kmf_tREST_1.getKeyManagers();
	}
	
    ctx_tREST_1.init(kms_tREST_1, tms_tREST_1 , null);
    config_tREST_1.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_tREST_1));

	com.sun.jersey.api.client.Client restClient_tREST_1 = com.sun.jersey.api.client.Client.create(config_tREST_1);
	
	java.util.Map<String, Object> headers_tREST_1 = new java.util.HashMap<String, Object>();
	
    	headers_tREST_1.put("content-type","application/json");
	
	
	Object transfer_encoding_tREST_1 = headers_tREST_1.get("Transfer-Encoding");
	if(transfer_encoding_tREST_1!=null && "chunked".equals(transfer_encoding_tREST_1)) {
		restClient_tREST_1.setChunkedEncodingSize(4096);
	}
	
	com.sun.jersey.api.client.WebResource restResource_tREST_1;
	if(endpoint_tREST_1!=null && !("").equals(endpoint_tREST_1)){
		restResource_tREST_1 = restClient_tREST_1.resource(endpoint_tREST_1);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_tREST_1 = null;
	String restResponse_tREST_1 = "";
	try{
		
                if(log.isInfoEnabled())
            log.info("tREST_1 - "  + ("Prepare to send request to rest server.") );
		com.sun.jersey.api.client.WebResource.Builder builder_tREST_1 = null;
		for(java.util.Map.Entry<String, Object> header_tREST_1 : headers_tREST_1.entrySet()) {
			if(builder_tREST_1 == null) {
				builder_tREST_1 = restResource_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			} else {
				builder_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			}
		}
		
		
			if(builder_tREST_1!=null) {
				restResponse_tREST_1 = builder_tREST_1.post(String.class,(String)globalMap.get("rest_api_body"));
			} else {
				restResponse_tREST_1 = restResource_tREST_1.post(String.class,(String)globalMap.get("rest_api_body"));
			}
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
globalMap.put("tREST_1_ERROR_MESSAGE",ue.getMessage());
        errorResponse_tREST_1 = ue.getResponse();
    }
	
                if(log.isInfoEnabled())
            log.info("tREST_1 - "  + ("Has sent request to rest server.") );
	// for output
			
				row4 = new row4Struct();
				if(errorResponse_tREST_1!=null){
					row4.ERROR_CODE = errorResponse_tREST_1.getStatus();
					if(row4.ERROR_CODE!=204){
					    row4.Body = errorResponse_tREST_1.getEntity(String.class);
					}
				}else{
					row4.Body = restResponse_tREST_1;
				}
			

 



/**
 * [tREST_1 begin ] stop
 */
	
	/**
	 * [tREST_1 main ] start
	 */

	

	
	
	currentComponent="tREST_1";
	
	

 


	tos_count_tREST_1++;

/**
 * [tREST_1 main ] stop
 */
	
	/**
	 * [tREST_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tREST_1";
	
	

 



/**
 * [tREST_1 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tREST_1","tREST_1","tREST","tExtractJSONFields_1","tExtractJSONFields_1","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

            if(row4.Body!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row4.Body.toString();
   
row7 = null;

	

String loopPath_tExtractJSONFields_1 = "$";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
		log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row7 = null;
	row7 = new row7Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "$.message";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row7.ResponseMessage = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row7.ResponseMessage = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
			log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row7 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
	log.debug("tExtractJSONFields_1 - Extracting the record " + nb_line_tExtractJSONFields_1 + ".");
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tExtractJSONFields_1","tExtractJSONFields_1","tExtractJSONFields","tJava_10","tJava_10","tJava"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_10";
	
	

 



/**
 * [tJava_10 process_data_begin ] stop
 */
	
	/**
	 * [tJava_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_10";
	
	

 



/**
 * [tJava_10 process_data_end ] stop
 */

} // End of branch "row7"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */



	
	/**
	 * [tREST_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tREST_1";
	
	

 



/**
 * [tREST_1 process_data_end ] stop
 */
	
	/**
	 * [tREST_1 end ] start
	 */

	

	
	
	currentComponent="tREST_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tREST_1 - "  + ("Done.") );

ok_Hash.put("tREST_1", true);
end_Hash.put("tREST_1", System.currentTimeMillis());




/**
 * [tREST_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);
	log.debug("tExtractJSONFields_1 - Extracted records count: " + nb_line_tExtractJSONFields_1 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tREST_1","tREST_1","tREST","tExtractJSONFields_1","tExtractJSONFields_1","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());




/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tExtractJSONFields_1","tExtractJSONFields_1","tExtractJSONFields","tJava_10","tJava_10","tJava","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());

   			if (row7.ResponseMessage == null || !row7.ResponseMessage.equals("done")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If10", 0, "true");
					}
				tRowGenerator_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If10", 0, "false");
					}   	 
   				}



/**
 * [tJava_10 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tREST_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk20", 0, "ok");
								} 
							
							tFileDelete_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tREST_1 finally ] start
	 */

	

	
	
	currentComponent="tREST_1";
	
	

 



/**
 * [tREST_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";
	
	

 



/**
 * [tJava_10 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tREST_1_SUBPROCESS_STATE", 1);
	}
	


public static class row36Struct implements routines.system.IPersistableRow<row36Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return null;
				}
				public Integer idPrecision(){
				    return null;
				}
				public String idDefault(){
				
					return "";
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String statut;

				public String getStatut () {
					return this.statut;
				}

				public Boolean statutIsNullable(){
				    return true;
				}
				public Boolean statutIsKey(){
				    return false;
				}
				public Integer statutLength(){
				    return null;
				}
				public Integer statutPrecision(){
				    return null;
				}
				public String statutDefault(){
				
					return null;
				
				}
				public String statutComment(){
				
				    return "";
				
				}
				public String statutPattern(){
				
					return "";
				
				}
				public String statutOriginalDbColumnName(){
				
					return "statut";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row36Struct other = (row36Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row36Struct other) {

		other.id = this.id;
	            other.statut = this.statut;
	            
	}

	public void copyKeysDataTo(row36Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",statut="+statut);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(statut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statut);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row36Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row37Struct implements routines.system.IPersistableRow<row37Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String newColumn;

				public String getNewColumn () {
					return this.newColumn;
				}

				public Boolean newColumnIsNullable(){
				    return true;
				}
				public Boolean newColumnIsKey(){
				    return false;
				}
				public Integer newColumnLength(){
				    return null;
				}
				public Integer newColumnPrecision(){
				    return null;
				}
				public String newColumnDefault(){
				
					return null;
				
				}
				public String newColumnComment(){
				
				    return "";
				
				}
				public String newColumnPattern(){
				
					return "";
				
				}
				public String newColumnOriginalDbColumnName(){
				
					return "newColumn";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("newColumn="+newColumn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(newColumn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(newColumn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row37Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tRowGenerator_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRowGenerator_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRowGenerator_1");
		org.slf4j.MDC.put("_subJobPid", "E1V1UM_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row37Struct row37 = new row37Struct();
row36Struct row36 = new row36Struct();





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row36");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"transactions_livraison\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "UPDATE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"transactions_livraison\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_2 = 1;
        if(updateKeyCount_tDBOutput_2 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_2 == 2 && true) {        
                throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

String tableName_tDBOutput_2 = "transactions_livraison";
boolean whetherReject_tDBOutput_2 = false;

java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
long date_tDBOutput_2;

java.sql.Connection conn_tDBOutput_2 = null;
		conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );
		int batchSize_tDBOutput_2 = 10000;
		int batchSizeCounter_tDBOutput_2=0;
	

		int count_tDBOutput_2=0;
		
				
			
				String update_tDBOutput_2 = "UPDATE `" + "transactions_livraison" + "` SET `statut` = ? WHERE `id` = ?";
				
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(update_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
				


 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row37");
			
		int tos_count_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_3 = new StringBuilder();
                    log4jParamters_tMap_3.append("Parameters:");
                            log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + (log4jParamters_tMap_3) );
                    } 
                } 
            new BytesLimit65535_tMap_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row37_tMap_3 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row36_tMap_3 = 0;
				
row36Struct row36_tmp = new row36Struct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tRowGenerator_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tRowGenerator_1", false);
		start_Hash.put("tRowGenerator_1", System.currentTimeMillis());
		
	
	currentComponent="tRowGenerator_1";
	
	
		int tos_count_tRowGenerator_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRowGenerator_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRowGenerator_1 = new StringBuilder();
                    log4jParamters_tRowGenerator_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_1 - "  + (log4jParamters_tRowGenerator_1) );
                    } 
                } 
            new BytesLimit65535_tRowGenerator_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRowGenerator_1", "tRowGenerator_1", "tRowGenerator");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tRowGenerator_1 = 0;
int nb_max_row_tRowGenerator_1 = 1;


class tRowGenerator_1Randomizer {
	public String getRandomnewColumn() {
		
		return TalendString.getAsciiRandomString(6);
		
	}
}
	tRowGenerator_1Randomizer randtRowGenerator_1 = new tRowGenerator_1Randomizer();
	
    	log.info("tRowGenerator_1 - Generating records.");
	for (int itRowGenerator_1=0; itRowGenerator_1<nb_max_row_tRowGenerator_1 ;itRowGenerator_1++) {
		row37.newColumn = randtRowGenerator_1.getRandomnewColumn();
		nb_line_tRowGenerator_1++;
		
			log.debug("tRowGenerator_1 - Retrieving the record " + nb_line_tRowGenerator_1 + ".");
		

 



/**
 * [tRowGenerator_1 begin ] stop
 */
	
	/**
	 * [tRowGenerator_1 main ] start
	 */

	

	
	
	currentComponent="tRowGenerator_1";
	
	

 


	tos_count_tRowGenerator_1++;

/**
 * [tRowGenerator_1 main ] stop
 */
	
	/**
	 * [tRowGenerator_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRowGenerator_1";
	
	

 



/**
 * [tRowGenerator_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row37","tRowGenerator_1","tRowGenerator_1","tRowGenerator","tMap_3","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row37 - " + (row37==null? "": row37.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_3 = false;
		boolean mainRowRejected_tMap_3 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

row36 = null;


// # Output table : 'row36'
count_row36_tMap_3++;

row36_tmp.id = Integer.parseInt(context.transaction_id) ;
row36_tmp.statut = "Terminé" ;
row36 = row36_tmp;
log.debug("tMap_3 - Outputting the record " + count_row36_tMap_3 + " of the output table 'row36'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "row36"
if(row36 != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row36","tMap_3","tMap_2","tMap","tDBOutput_2","\"transactions_livraison\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row36 - " + (row36==null? "": row36.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    if(row36.statut == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, row36.statut);
}


                    pstmt_tDBOutput_2.setInt(2 + count_tDBOutput_2, row36.id);


            pstmt_tDBOutput_2.addBatch();
            nb_line_tDBOutput_2++;

                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("UPDATE")  + (" batch.") );
                  batchSizeCounter_tDBOutput_2++;
                if ( batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
                        try {
                                int countSum_tDBOutput_2 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
                                for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
                                    countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                                }
                                rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
                                updatedCount_tDBOutput_2 += countSum_tDBOutput_2;
                                batchSizeCounter_tDBOutput_2 = 0;
                        }catch (java.sql.BatchUpdateException e){
                            globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                            int countSum_tDBOutput_2 = 0;
                            for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
                                countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                            }
                            rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
                            updatedCount_tDBOutput_2 += countSum_tDBOutput_2;
                            System.err.println(e.getMessage());
            log.error("tDBOutput_2 - "  + (e.getMessage()) );
                        }
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "row36"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_end ] stop
 */



	
	/**
	 * [tRowGenerator_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_1";
	
	

 



/**
 * [tRowGenerator_1 process_data_end ] stop
 */
	
	/**
	 * [tRowGenerator_1 end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_1";
	
	

}
globalMap.put("tRowGenerator_1_NB_LINE",nb_line_tRowGenerator_1);
	log.info("tRowGenerator_1 - Generated records count:" + nb_line_tRowGenerator_1 + " .");

 
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_1 - "  + ("Done.") );

ok_Hash.put("tRowGenerator_1", true);
end_Hash.put("tRowGenerator_1", System.currentTimeMillis());




/**
 * [tRowGenerator_1 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'row36': " + count_row36_tMap_3 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row37",2,0,
			 			"tRowGenerator_1","tRowGenerator_1","tRowGenerator","tMap_3","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Done.") );

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		



		
			try {
				if(pstmt_tDBOutput_2 != null){
					int countSum_tDBOutput_2 = 0;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
					
						updatedCount_tDBOutput_2 += countSum_tDBOutput_2;
					
				}
			}catch (java.sql.BatchUpdateException e){
				globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
				
					int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
						updatedCount_tDBOutput_2 += countSum_tDBOutput_2;
						
            log.error("tDBOutput_2 - "  + (e.getMessage()) );
					System.err.println(e.getMessage());
					
			}
			

		if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_2", true);
	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("updated")  + (" ")  + (nb_line_update_tDBOutput_2)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row36",2,0,
			 			"tMap_3","tMap_2","tMap","tDBOutput_2","\"transactions_livraison\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRowGenerator_1 finally ] start
	 */

	

	
	
	currentComponent="tRowGenerator_1";
	
	

 



/**
 * [tRowGenerator_1 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"transactions_livraison\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRowGenerator_1_SUBPROCESS_STATE", 1);
	}
	


public void tFileDelete_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileDelete_1");
		org.slf4j.MDC.put("_subJobPid", "3OvSPF_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_1", false);
		start_Hash.put("tFileDelete_1", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_1";
	
	
		int tos_count_tFileDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileDelete_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
                    log4jParamters_tFileDelete_1.append("Parameters:");
                            log4jParamters_tFileDelete_1.append("FILENAME" + " = " + "context.file_source + context.transaction_id + context.Csv_File_Masque");
                        log4jParamters_tFileDelete_1.append(" | ");
                            log4jParamters_tFileDelete_1.append("FAILON" + " = " + "true");
                        log4jParamters_tFileDelete_1.append(" | ");
                            log4jParamters_tFileDelete_1.append("FOLDER" + " = " + "false");
                        log4jParamters_tFileDelete_1.append(" | ");
                            log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = " + "false");
                        log4jParamters_tFileDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + (log4jParamters_tFileDelete_1) );
                    } 
                } 
            new BytesLimit65535_tFileDelete_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileDelete_1", "tFileDelete_1", "tFileDelete");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tFileDelete_1 begin ] stop
 */
	
	/**
	 * [tFileDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";
	
	

 

				final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();
			
class DeleteFoldertFileDelete_1{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_1=new java.io.File(context.file_source + context.transaction_id + context.Csv_File_Masque);
    if(file_tFileDelete_1.exists()&& file_tFileDelete_1.isFile()){
    	if(file_tFileDelete_1.delete()){
    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_1 - File : "+ file_tFileDelete_1.getAbsolutePath() + " is deleted.");
		}else{
			globalMap.put("tFileDelete_1_CURRENT_STATUS", "No file deleted.");
				throw new RuntimeException("File " + file_tFileDelete_1.getAbsolutePath() + " can not be deleted.");
		}
	}else{
		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File does not exist or is invalid.");
			throw new RuntimeException("File " + file_tFileDelete_1.getAbsolutePath() + " does not exist or is invalid or is not a file.");
	}
	globalMap.put("tFileDelete_1_DELETE_PATH",context.file_source + context.transaction_id + context.Csv_File_Masque);
 


	tos_count_tFileDelete_1++;

/**
 * [tFileDelete_1 main ] stop
 */
	
	/**
	 * [tFileDelete_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";
	
	

 



/**
 * [tFileDelete_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileDelete_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";
	
	

 



/**
 * [tFileDelete_1 process_data_end ] stop
 */
	
	/**
	 * [tFileDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Done.") );

ok_Hash.put("tFileDelete_1", true);
end_Hash.put("tFileDelete_1", System.currentTimeMillis());




/**
 * [tFileDelete_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileDelete_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk17", 0, "ok");
								} 
							
							tDBClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";
	
	

 



/**
 * [tFileDelete_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "fUHc4X_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public static class row64Struct implements routines.system.IPersistableRow<row64Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return null;
				}
				public Integer idPrecision(){
				    return null;
				}
				public String idDefault(){
				
					return "";
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String statut;

				public String getStatut () {
					return this.statut;
				}

				public Boolean statutIsNullable(){
				    return true;
				}
				public Boolean statutIsKey(){
				    return false;
				}
				public Integer statutLength(){
				    return null;
				}
				public Integer statutPrecision(){
				    return null;
				}
				public String statutDefault(){
				
					return null;
				
				}
				public String statutComment(){
				
				    return "";
				
				}
				public String statutPattern(){
				
					return "";
				
				}
				public String statutOriginalDbColumnName(){
				
					return "statut";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row64Struct other = (row64Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row64Struct other) {

		other.id = this.id;
	            other.statut = this.statut;
	            
	}

	public void copyKeysDataTo(row64Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",statut="+statut);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(statut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statut);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row64Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String newColumn;

				public String getNewColumn () {
					return this.newColumn;
				}

				public Boolean newColumnIsNullable(){
				    return true;
				}
				public Boolean newColumnIsKey(){
				    return false;
				}
				public Integer newColumnLength(){
				    return null;
				}
				public Integer newColumnPrecision(){
				    return null;
				}
				public String newColumnDefault(){
				
					return "";
				
				}
				public String newColumnComment(){
				
				    return "";
				
				}
				public String newColumnPattern(){
				
					return "";
				
				}
				public String newColumnOriginalDbColumnName(){
				
					return "newColumn";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.newColumn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.newColumn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("newColumn="+newColumn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(newColumn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(newColumn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tRowGenerator_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRowGenerator_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRowGenerator_3");
		org.slf4j.MDC.put("_subJobPid", "PwazSW_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();
row64Struct row64 = new row64Struct();





	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row64");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"transactions_livraison\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "UPDATE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "\"transactions_livraison\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_3 = 1;
        if(updateKeyCount_tDBOutput_3 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_3 == 2 && true) {        
                throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

String tableName_tDBOutput_3 = "transactions_livraison";
boolean whetherReject_tDBOutput_3 = false;

java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
calendar_tDBOutput_3.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
calendar_tDBOutput_3.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
long date_tDBOutput_3;

java.sql.Connection conn_tDBOutput_3 = null;
		conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );
		int batchSize_tDBOutput_3 = 10000;
		int batchSizeCounter_tDBOutput_3=0;
	

		int count_tDBOutput_3=0;
		
				
			
				String update_tDBOutput_3 = "UPDATE `" + "transactions_livraison" + "` SET `statut` = ? WHERE `id` = ?";
				
				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(update_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
				


 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tMap_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_4 = new StringBuilder();
                    log4jParamters_tMap_4.append("Parameters:");
                            log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + (log4jParamters_tMap_4) );
                    } 
                } 
            new BytesLimit65535_tMap_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_4", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row6_tMap_4 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row64_tMap_4 = 0;
				
row64Struct row64_tmp = new row64Struct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tRowGenerator_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRowGenerator_3", false);
		start_Hash.put("tRowGenerator_3", System.currentTimeMillis());
		
	
	currentComponent="tRowGenerator_3";
	
	
		int tos_count_tRowGenerator_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRowGenerator_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRowGenerator_3 = new StringBuilder();
                    log4jParamters_tRowGenerator_3.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_3 - "  + (log4jParamters_tRowGenerator_3) );
                    } 
                } 
            new BytesLimit65535_tRowGenerator_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRowGenerator_3", "tRowGenerator_2", "tRowGenerator");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tRowGenerator_3 = 0;
int nb_max_row_tRowGenerator_3 = 1;


class tRowGenerator_3Randomizer {
	public String getRandomnewColumn() {
		
		return TalendString.getAsciiRandomString(6);
		
	}
}
	tRowGenerator_3Randomizer randtRowGenerator_3 = new tRowGenerator_3Randomizer();
	
    	log.info("tRowGenerator_3 - Generating records.");
	for (int itRowGenerator_3=0; itRowGenerator_3<nb_max_row_tRowGenerator_3 ;itRowGenerator_3++) {
		row6.newColumn = randtRowGenerator_3.getRandomnewColumn();
		nb_line_tRowGenerator_3++;
		
			log.debug("tRowGenerator_3 - Retrieving the record " + nb_line_tRowGenerator_3 + ".");
		

 



/**
 * [tRowGenerator_3 begin ] stop
 */
	
	/**
	 * [tRowGenerator_3 main ] start
	 */

	

	
	
	currentComponent="tRowGenerator_3";
	
	

 


	tos_count_tRowGenerator_3++;

/**
 * [tRowGenerator_3 main ] stop
 */
	
	/**
	 * [tRowGenerator_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRowGenerator_3";
	
	

 



/**
 * [tRowGenerator_3 process_data_begin ] stop
 */

	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tRowGenerator_3","tRowGenerator_2","tRowGenerator","tMap_4","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_4 = false;
		boolean mainRowRejected_tMap_4 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
        // ###############################
        // # Output tables

row64 = null;


// # Output table : 'row64'
count_row64_tMap_4++;

row64_tmp.id = Integer.parseInt(context.transaction_id) ;
row64_tmp.statut = "Terminé" ;
row64 = row64_tmp;
log.debug("tMap_4 - Outputting the record " + count_row64_tMap_4 + " of the output table 'row64'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
	
	/**
	 * [tMap_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 process_data_begin ] stop
 */
// Start of branch "row64"
if(row64 != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row64","tMap_4","tMap_2","tMap","tDBOutput_3","\"transactions_livraison\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row64 - " + (row64==null? "": row64.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    if(row64.statut == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, row64.statut);
}


                    pstmt_tDBOutput_3.setInt(2 + count_tDBOutput_3, row64.id);


            pstmt_tDBOutput_3.addBatch();
            nb_line_tDBOutput_3++;

                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("UPDATE")  + (" batch.") );
                  batchSizeCounter_tDBOutput_3++;
                if ( batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
                        try {
                                int countSum_tDBOutput_3 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
                                for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
                                    countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                                }
                                rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
                                updatedCount_tDBOutput_3 += countSum_tDBOutput_3;
                                batchSizeCounter_tDBOutput_3 = 0;
                        }catch (java.sql.BatchUpdateException e){
                            globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                            int countSum_tDBOutput_3 = 0;
                            for(int countEach_tDBOutput_3: e.getUpdateCounts()) {
                                countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
                            }
                            rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
                            updatedCount_tDBOutput_3 += countSum_tDBOutput_3;
                            System.err.println(e.getMessage());
            log.error("tDBOutput_3 - "  + (e.getMessage()) );
                        }
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "row64"




	
	/**
	 * [tMap_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 process_data_end ] stop
 */



	
	/**
	 * [tRowGenerator_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_3";
	
	

 



/**
 * [tRowGenerator_3 process_data_end ] stop
 */
	
	/**
	 * [tRowGenerator_3 end ] start
	 */

	

	
	
	currentComponent="tRowGenerator_3";
	
	

}
globalMap.put("tRowGenerator_3_NB_LINE",nb_line_tRowGenerator_3);
	log.info("tRowGenerator_3 - Generated records count:" + nb_line_tRowGenerator_3 + " .");

 
                if(log.isDebugEnabled())
            log.debug("tRowGenerator_3 - "  + ("Done.") );

ok_Hash.put("tRowGenerator_3", true);
end_Hash.put("tRowGenerator_3", System.currentTimeMillis());




/**
 * [tRowGenerator_3 end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'row64': " + count_row64_tMap_4 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tRowGenerator_3","tRowGenerator_2","tRowGenerator","tMap_4","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Done.") );

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		



		
			try {
				if(pstmt_tDBOutput_3 != null){
					int countSum_tDBOutput_3 = 0;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPDATE")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPDATE")  + (" batch execution has succeeded.") );
					
						updatedCount_tDBOutput_3 += countSum_tDBOutput_3;
					
				}
			}catch (java.sql.BatchUpdateException e){
				globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
				
					int countSum_tDBOutput_3 = 0;
					for(int countEach_tDBOutput_3: e.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
					
						updatedCount_tDBOutput_3 += countSum_tDBOutput_3;
						
            log.error("tDBOutput_3 - "  + (e.getMessage()) );
					System.err.println(e.getMessage());
					
			}
			

		if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_3", true);
	

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("updated")  + (" ")  + (nb_line_update_tDBOutput_3)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row64",2,0,
			 			"tMap_4","tMap_2","tMap","tDBOutput_3","\"transactions_livraison\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRowGenerator_3 finally ] start
	 */

	

	
	
	currentComponent="tRowGenerator_3";
	
	

 



/**
 * [tRowGenerator_3 finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"transactions_livraison\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRowGenerator_3_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String body;

				public String getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return null;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.body = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.body = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.body,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.body,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("body="+body);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tWriteJSONField_2_InProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWriteJSONField_2_In_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWriteJSONField_2_In");
		org.slf4j.MDC.put("_subJobPid", "HIp657_" + subJobPidCounter.getAndIncrement());
	

		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_4.append("Parameters:");
                            log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("row9.body")+", KEY="+("\"rest_api_body\"")+"}]");
                        log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_4", "tSetGlobalVar_4", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */



	
	/**
	 * [tWriteJSONField_2_In begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_2_In", false);
		start_Hash.put("tWriteJSONField_2_In", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	
		int tos_count_tWriteJSONField_2_In = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_In - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWriteJSONField_2_In{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWriteJSONField_2_In = new StringBuilder();
                    log4jParamters_tWriteJSONField_2_In.append("Parameters:");
                            log4jParamters_tWriteJSONField_2_In.append("JSONFIELD" + " = " + "body");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("DESTINATION" + " = " + "tWriteJSONField_2");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("REMOVE_ROOT" + " = " + "true");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("GROUPBYS" + " = " + "[]");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("QUOTE_ALL_VALUES" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("ALLOW_EMPTY_STRINGS" + " = " + "false");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                            log4jParamters_tWriteJSONField_2_In.append("USE_SCIENTIFIC_NOTATION" + " = " + "true");
                        log4jParamters_tWriteJSONField_2_In.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_In - "  + (log4jParamters_tWriteJSONField_2_In) );
                    } 
                } 
            new BytesLimit65535_tWriteJSONField_2_In().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWriteJSONField_2_In", "tWriteJSONField_2_In", "tWriteJSONFieldIn");
				talendJobLogProcess(globalMap);
			}
			

				int nb_line_tWriteJSONField_2_In = 0;
				net.sf.json.xml.XMLSerializer xmlSerializer_tWriteJSONField_2_In = new net.sf.json.xml.XMLSerializer(); 
			    xmlSerializer_tWriteJSONField_2_In.clearNamespaces();
			    xmlSerializer_tWriteJSONField_2_In.setSkipNamespaces(true);
			    xmlSerializer_tWriteJSONField_2_In.setForceTopLevelObject(false);
			    xmlSerializer_tWriteJSONField_2_In.setUseEmptyStrings(false);
			    xmlSerializer_tWriteJSONField_2_In.setUseScientificNotation(true);
				
					   java.util.Queue<row9Struct> queue_tWriteJSONField_2_In = (java.util.Queue<row9Struct>) globalMap.get("queue_tWriteJSONField_2_In");
					
				String readFinishMarkWithPipeId_tWriteJSONField_2_In = "tWriteJSONField_2_In_FINISH"+(queue_tWriteJSONField_2_In==null?"":queue_tWriteJSONField_2_In.hashCode());
				String str_tWriteJSONField_2_In = null;
				
				while(!globalMap.containsKey(readFinishMarkWithPipeId_tWriteJSONField_2_In) || !queue_tWriteJSONField_2_In.isEmpty()) {
					if (!queue_tWriteJSONField_2_In.isEmpty()) {
			

 



/**
 * [tWriteJSONField_2_In begin ] stop
 */
	
	/**
	 * [tWriteJSONField_2_In main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	

                    row9Struct result_tWriteJSONField_2_In = queue_tWriteJSONField_2_In.poll();
                    str_tWriteJSONField_2_In = result_tWriteJSONField_2_In.body;
        //Convert XML to JSON
        net.sf.json.JsonStandard jsonStandard_tWriteJSONField_2_In =  net.sf.json.JsonStandard.LEGACY  ;
        xmlSerializer_tWriteJSONField_2_In.setJsonStandard(jsonStandard_tWriteJSONField_2_In);
        net.sf.json.JSON json_tWriteJSONField_2_In = xmlSerializer_tWriteJSONField_2_In.read(str_tWriteJSONField_2_In);
        row9.body = net.sf.json.util.JSONUtils.jsonToStandardizedString(json_tWriteJSONField_2_In, jsonStandard_tWriteJSONField_2_In);
    
        nb_line_tWriteJSONField_2_In++;

 


	tos_count_tWriteJSONField_2_In++;

/**
 * [tWriteJSONField_2_In main ] stop
 */
	
	/**
	 * [tWriteJSONField_2_In process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	

 



/**
 * [tWriteJSONField_2_In process_data_begin ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tWriteJSONField_2_In","tWriteJSONField_2_In","tWriteJSONFieldIn","tSetGlobalVar_4","tSetGlobalVar_4","tSetGlobalVar"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

globalMap.put("rest_api_body", row9.body);

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";
	
	

 



/**
 * [tSetGlobalVar_4 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";
	
	

 



/**
 * [tSetGlobalVar_4 process_data_end ] stop
 */



	
	/**
	 * [tWriteJSONField_2_In process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	

 



/**
 * [tWriteJSONField_2_In process_data_end ] stop
 */
	
	/**
	 * [tWriteJSONField_2_In end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	

					}
				}
				
					String readFinishWithExceptionMarkWithPipeId_tWriteJSONField_2_In = "tWriteJSONField_2_In_FINISH_WITH_EXCEPTION"+(queue_tWriteJSONField_2_In==null?"":queue_tWriteJSONField_2_In.hashCode());
					if(globalMap.containsKey(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_2_In)){
						if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
							globalMap.put(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_2_In, null);// syn
						}
						globalMap.remove(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_2_In);
						return;
					}
					globalMap.remove("queue_tWriteJSONField_2_In");
    			
				if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
					globalMap.put(readFinishMarkWithPipeId_tWriteJSONField_2_In,null);//syn
				}
				globalMap.remove(readFinishMarkWithPipeId_tWriteJSONField_2_In);
			
globalMap.put("tWriteJSONField_2_NB_LINE",nb_line_tWriteJSONField_2_In);
				log.debug("tWriteJSONField_2_In - Processed records count: " + nb_line_tWriteJSONField_2_In + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_2_In - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_2_In", true);
end_Hash.put("tWriteJSONField_2_In", System.currentTimeMillis());




/**
 * [tWriteJSONField_2_In end ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tWriteJSONField_2_In","tWriteJSONField_2_In","tWriteJSONFieldIn","tSetGlobalVar_4","tSetGlobalVar_4","tSetGlobalVar","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());




/**
 * [tSetGlobalVar_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWriteJSONField_2_In finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_2";
	
	currentComponent="tWriteJSONField_2_In";
	
	

 



/**
 * [tWriteJSONField_2_In finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";
	
	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWriteJSONField_2_In_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[0];

	
			    public String body;

				public String getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return null;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.length == 0) {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.body = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1) {

        	try {

        		int length = 0;
		
					this.body = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.body,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.body,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("body="+body);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tWriteJSONField_1_InProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWriteJSONField_1_In_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWriteJSONField_1_In");
		org.slf4j.MDC.put("_subJobPid", "hrhCnW_" + subJobPidCounter.getAndIncrement());
	

		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_3.append("Parameters:");
                            log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("row5.body")+", KEY="+("\"rest_api_body\"")+"}]");
                        log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_3", "tSetGlobalVar_3", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [tWriteJSONField_1_In begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_1_In", false);
		start_Hash.put("tWriteJSONField_1_In", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	
		int tos_count_tWriteJSONField_1_In = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWriteJSONField_1_In{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWriteJSONField_1_In = new StringBuilder();
                    log4jParamters_tWriteJSONField_1_In.append("Parameters:");
                            log4jParamters_tWriteJSONField_1_In.append("JSONFIELD" + " = " + "body");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("DESTINATION" + " = " + "tWriteJSONField_1");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("REMOVE_ROOT" + " = " + "true");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("GROUPBYS" + " = " + "[]");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("QUOTE_ALL_VALUES" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("ALLOW_EMPTY_STRINGS" + " = " + "false");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                            log4jParamters_tWriteJSONField_1_In.append("USE_SCIENTIFIC_NOTATION" + " = " + "true");
                        log4jParamters_tWriteJSONField_1_In.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + (log4jParamters_tWriteJSONField_1_In) );
                    } 
                } 
            new BytesLimit65535_tWriteJSONField_1_In().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWriteJSONField_1_In", "tWriteJSONField_1_In", "tWriteJSONFieldIn");
				talendJobLogProcess(globalMap);
			}
			

				int nb_line_tWriteJSONField_1_In = 0;
				net.sf.json.xml.XMLSerializer xmlSerializer_tWriteJSONField_1_In = new net.sf.json.xml.XMLSerializer(); 
			    xmlSerializer_tWriteJSONField_1_In.clearNamespaces();
			    xmlSerializer_tWriteJSONField_1_In.setSkipNamespaces(true);
			    xmlSerializer_tWriteJSONField_1_In.setForceTopLevelObject(false);
			    xmlSerializer_tWriteJSONField_1_In.setUseEmptyStrings(false);
			    xmlSerializer_tWriteJSONField_1_In.setUseScientificNotation(true);
				
					   java.util.Queue<row5Struct> queue_tWriteJSONField_1_In = (java.util.Queue<row5Struct>) globalMap.get("queue_tWriteJSONField_1_In");
					
				String readFinishMarkWithPipeId_tWriteJSONField_1_In = "tWriteJSONField_1_In_FINISH"+(queue_tWriteJSONField_1_In==null?"":queue_tWriteJSONField_1_In.hashCode());
				String str_tWriteJSONField_1_In = null;
				
				while(!globalMap.containsKey(readFinishMarkWithPipeId_tWriteJSONField_1_In) || !queue_tWriteJSONField_1_In.isEmpty()) {
					if (!queue_tWriteJSONField_1_In.isEmpty()) {
			

 



/**
 * [tWriteJSONField_1_In begin ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	

                    row5Struct result_tWriteJSONField_1_In = queue_tWriteJSONField_1_In.poll();
                    str_tWriteJSONField_1_In = result_tWriteJSONField_1_In.body;
        //Convert XML to JSON
        net.sf.json.JsonStandard jsonStandard_tWriteJSONField_1_In =  net.sf.json.JsonStandard.LEGACY  ;
        xmlSerializer_tWriteJSONField_1_In.setJsonStandard(jsonStandard_tWriteJSONField_1_In);
        net.sf.json.JSON json_tWriteJSONField_1_In = xmlSerializer_tWriteJSONField_1_In.read(str_tWriteJSONField_1_In);
        row5.body = net.sf.json.util.JSONUtils.jsonToStandardizedString(json_tWriteJSONField_1_In, jsonStandard_tWriteJSONField_1_In);
    
        nb_line_tWriteJSONField_1_In++;

 


	tos_count_tWriteJSONField_1_In++;

/**
 * [tWriteJSONField_1_In main ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	

 



/**
 * [tWriteJSONField_1_In process_data_begin ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tWriteJSONField_1_In","tWriteJSONField_1_In","tWriteJSONFieldIn","tSetGlobalVar_3","tSetGlobalVar_3","tSetGlobalVar"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

globalMap.put("rest_api_body", row5.body);

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 process_data_end ] stop
 */



	
	/**
	 * [tWriteJSONField_1_In process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	

 



/**
 * [tWriteJSONField_1_In process_data_end ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	

					}
				}
				
					String readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In = "tWriteJSONField_1_In_FINISH_WITH_EXCEPTION"+(queue_tWriteJSONField_1_In==null?"":queue_tWriteJSONField_1_In.hashCode());
					if(globalMap.containsKey(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In)){
						if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
							globalMap.put(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In, null);// syn
						}
						globalMap.remove(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In);
						return;
					}
					globalMap.remove("queue_tWriteJSONField_1_In");
    			
				if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
					globalMap.put(readFinishMarkWithPipeId_tWriteJSONField_1_In,null);//syn
				}
				globalMap.remove(readFinishMarkWithPipeId_tWriteJSONField_1_In);
			
globalMap.put("tWriteJSONField_1_NB_LINE",nb_line_tWriteJSONField_1_In);
				log.debug("tWriteJSONField_1_In - Processed records count: " + nb_line_tWriteJSONField_1_In + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_1_In", true);
end_Hash.put("tWriteJSONField_1_In", System.currentTimeMillis());




/**
 * [tWriteJSONField_1_In end ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tWriteJSONField_1_In","tWriteJSONField_1_In","tWriteJSONFieldIn","tSetGlobalVar_3","tSetGlobalVar_3","tSetGlobalVar","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWriteJSONField_1_In finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";
	
	

 



/**
 * [tWriteJSONField_1_In finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWriteJSONField_1_In_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "k5snm1_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1 ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1Class = new ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1();

        int exitCode = ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_KDjEMHLHEeyCn7izvFQjtg");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-04-17T09:00:21.272044800Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.class.getClassLoader().getResourceAsStream("cajoo/ondemand_urbantz_to_hub_prod_sub_job_v1_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("transaction_id", "id_String");
                        if(context.getStringValue("transaction_id") == null) {
                            context.transaction_id = null;
                        } else {
                            context.transaction_id=(String) context.getProperty("transaction_id");
                        }
                        context.setContextType("jobs_to_start", "id_String");
                        if(context.getStringValue("jobs_to_start") == null) {
                            context.jobs_to_start = null;
                        } else {
                            context.jobs_to_start=(String) context.getProperty("jobs_to_start");
                        }
                        context.setContextType("file_source", "id_String");
                        if(context.getStringValue("file_source") == null) {
                            context.file_source = null;
                        } else {
                            context.file_source=(String) context.getProperty("file_source");
                        }
                        context.setContextType("ondemand_server_directory", "id_String");
                        if(context.getStringValue("ondemand_server_directory") == null) {
                            context.ondemand_server_directory = null;
                        } else {
                            context.ondemand_server_directory=(String) context.getProperty("ondemand_server_directory");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("Hote_Ondemand", "id_String");
                        if(context.getStringValue("Hote_Ondemand") == null) {
                            context.Hote_Ondemand = null;
                        } else {
                            context.Hote_Ondemand=(String) context.getProperty("Hote_Ondemand");
                        }
                        context.setContextType("Ondemand_Database", "id_String");
                        if(context.getStringValue("Ondemand_Database") == null) {
                            context.Ondemand_Database = null;
                        } else {
                            context.Ondemand_Database=(String) context.getProperty("Ondemand_Database");
                        }
                        context.setContextType("OnDemand_DB_Password", "id_Password");
                        if(context.getStringValue("OnDemand_DB_Password") == null) {
                            context.OnDemand_DB_Password = null;
                        } else {
                            String pwd_OnDemand_DB_Password_value = context.getProperty("OnDemand_DB_Password");
                            context.OnDemand_DB_Password = null;
                            if(pwd_OnDemand_DB_Password_value!=null) {
                                if(context_param.containsKey("OnDemand_DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.OnDemand_DB_Password = pwd_OnDemand_DB_Password_value;
                                } else if (!pwd_OnDemand_DB_Password_value.isEmpty()) {
                                    try {
                                        context.OnDemand_DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_OnDemand_DB_Password_value);
                                        context.put("OnDemand_DB_Password",context.OnDemand_DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("Port_Ondemand", "id_Integer");
                        if(context.getStringValue("Port_Ondemand") == null) {
                            context.Port_Ondemand = null;
                        } else {
                            try{
                                context.Port_Ondemand=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port_Ondemand"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port_Ondemand", e.getMessage()));
                                context.Port_Ondemand=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("User_Ondemand", "id_String");
                        if(context.getStringValue("User_Ondemand") == null) {
                            context.User_Ondemand = null;
                        } else {
                            context.User_Ondemand=(String) context.getProperty("User_Ondemand");
                        }
                        context.setContextType("FTP_Password", "id_Password");
                        if(context.getStringValue("FTP_Password") == null) {
                            context.FTP_Password = null;
                        } else {
                            String pwd_FTP_Password_value = context.getProperty("FTP_Password");
                            context.FTP_Password = null;
                            if(pwd_FTP_Password_value!=null) {
                                if(context_param.containsKey("FTP_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.FTP_Password = pwd_FTP_Password_value;
                                } else if (!pwd_FTP_Password_value.isEmpty()) {
                                    try {
                                        context.FTP_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_FTP_Password_value);
                                        context.put("FTP_Password",context.FTP_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Ondemand_Server_Address", "id_String");
                        if(context.getStringValue("Ondemand_Server_Address") == null) {
                            context.Ondemand_Server_Address = null;
                        } else {
                            context.Ondemand_Server_Address=(String) context.getProperty("Ondemand_Server_Address");
                        }
                        context.setContextType("Ondemand_Server_Password", "id_Password");
                        if(context.getStringValue("Ondemand_Server_Password") == null) {
                            context.Ondemand_Server_Password = null;
                        } else {
                            String pwd_Ondemand_Server_Password_value = context.getProperty("Ondemand_Server_Password");
                            context.Ondemand_Server_Password = null;
                            if(pwd_Ondemand_Server_Password_value!=null) {
                                if(context_param.containsKey("Ondemand_Server_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Ondemand_Server_Password = pwd_Ondemand_Server_Password_value;
                                } else if (!pwd_Ondemand_Server_Password_value.isEmpty()) {
                                    try {
                                        context.Ondemand_Server_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Ondemand_Server_Password_value);
                                        context.put("Ondemand_Server_Password",context.Ondemand_Server_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Ondemand_Server_Port", "id_String");
                        if(context.getStringValue("Ondemand_Server_Port") == null) {
                            context.Ondemand_Server_Port = null;
                        } else {
                            context.Ondemand_Server_Port=(String) context.getProperty("Ondemand_Server_Port");
                        }
                        context.setContextType("Ondemand_Server_User", "id_String");
                        if(context.getStringValue("Ondemand_Server_User") == null) {
                            context.Ondemand_Server_User = null;
                        } else {
                            context.Ondemand_Server_User=(String) context.getProperty("Ondemand_Server_User");
                        }
                        context.setContextType("Csv_File_Masque", "id_String");
                        if(context.getStringValue("Csv_File_Masque") == null) {
                            context.Csv_File_Masque = null;
                        } else {
                            context.Csv_File_Masque=(String) context.getProperty("Csv_File_Masque");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("transaction_id")) {
                context.transaction_id = (String) parentContextMap.get("transaction_id");
            }if (parentContextMap.containsKey("jobs_to_start")) {
                context.jobs_to_start = (String) parentContextMap.get("jobs_to_start");
            }if (parentContextMap.containsKey("file_source")) {
                context.file_source = (String) parentContextMap.get("file_source");
            }if (parentContextMap.containsKey("ondemand_server_directory")) {
                context.ondemand_server_directory = (String) parentContextMap.get("ondemand_server_directory");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("Hote_Ondemand")) {
                context.Hote_Ondemand = (String) parentContextMap.get("Hote_Ondemand");
            }if (parentContextMap.containsKey("Ondemand_Database")) {
                context.Ondemand_Database = (String) parentContextMap.get("Ondemand_Database");
            }if (parentContextMap.containsKey("OnDemand_DB_Password")) {
                context.OnDemand_DB_Password = (java.lang.String) parentContextMap.get("OnDemand_DB_Password");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("Port_Ondemand")) {
                context.Port_Ondemand = (Integer) parentContextMap.get("Port_Ondemand");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("User_Ondemand")) {
                context.User_Ondemand = (String) parentContextMap.get("User_Ondemand");
            }if (parentContextMap.containsKey("FTP_Password")) {
                context.FTP_Password = (java.lang.String) parentContextMap.get("FTP_Password");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Ondemand_Server_Address")) {
                context.Ondemand_Server_Address = (String) parentContextMap.get("Ondemand_Server_Address");
            }if (parentContextMap.containsKey("Ondemand_Server_Password")) {
                context.Ondemand_Server_Password = (java.lang.String) parentContextMap.get("Ondemand_Server_Password");
            }if (parentContextMap.containsKey("Ondemand_Server_Port")) {
                context.Ondemand_Server_Port = (String) parentContextMap.get("Ondemand_Server_Port");
            }if (parentContextMap.containsKey("Ondemand_Server_User")) {
                context.Ondemand_Server_User = (String) parentContextMap.get("Ondemand_Server_User");
            }if (parentContextMap.containsKey("Csv_File_Masque")) {
                context.Csv_File_Masque = (String) parentContextMap.get("Csv_File_Masque");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("OnDemand_DB_Password");
			parametersToEncrypt.add("FTP_Password");
			parametersToEncrypt.add("Ondemand_Server_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob




		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSetGlobalVar_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSetGlobalVar_1) {
globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }
        es.shutdown();
        try {
            if(!es.awaitTermination(60, java.util.concurrent.TimeUnit.SECONDS)) {
                es.shutdownNow();
                if(!es.awaitTermination(60, java.util.concurrent.TimeUnit.SECONDS)) {

                }
            }
        } catch (java.lang.InterruptedException ie) {
            es.shutdownNow();
        } catch (java.lang.Exception e) {

        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ONDEMAND_URBANTZ_TO_HUB_PROD_SUB_JOB_V1' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     657758 characters generated by Talend Cloud Data Integration 
 *     on the 17 avril 2024 à 10:00:21 CET
 ************************************************************************************************/

package cajoo.urbantz_correction_exceptions_prod_v1_vehicule_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE implements TalendJob {
	static {System.setProperty("TalendJob.log", "URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(Livraisons_Exception != null){
				
					this.setProperty("Livraisons_Exception", Livraisons_Exception.toString());
				
			}
			
			if(Server_Clean != null){
				
					this.setProperty("Server_Clean", Server_Clean.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Server_Out != null){
				
					this.setProperty("Server_Out", Server_Out.toString());
				
			}
			
			if(Livraison_directory != null){
				
					this.setProperty("Livraison_directory", Livraison_directory.toString());
				
			}
			
			if(Round_Minus_Days != null){
				
					this.setProperty("Round_Minus_Days", Round_Minus_Days.toString());
				
			}
			
			if(transaction_id != null){
				
					this.setProperty("transaction_id", transaction_id.toString());
				
			}
			
			if(ondemand_server_directory != null){
				
					this.setProperty("ondemand_server_directory", ondemand_server_directory.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String Livraisons_Exception;
public String getLivraisons_Exception(){
	return this.Livraisons_Exception;
}
public String Server_Clean;
public String getServer_Clean(){
	return this.Server_Clean;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Server_Out;
public String getServer_Out(){
	return this.Server_Out;
}
public String Livraison_directory;
public String getLivraison_directory(){
	return this.Livraison_directory;
}
public Integer Round_Minus_Days;
public Integer getRound_Minus_Days(){
	return this.Round_Minus_Days;
}
public String transaction_id;
public String getTransaction_id(){
	return this.transaction_id;
}
public String ondemand_server_directory;
public String getOndemand_server_directory(){
	return this.ondemand_server_directory;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE";
	private final String projectName = "CAJOO";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_6532UPFtEeyp790etNOyuA", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tReplace_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tReplicate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBCommit_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBCommit_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_copyOfanciens_valeurs_uniques_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row23_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBCommit_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tSetGlobalVar_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_2");
		org.slf4j.MDC.put("_subJobPid", "HCL04Y_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";
	
	
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_2.append("Parameters:");
                            log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("context.transaction_id")+", KEY="+("\"transaction_id\"")+"}]");
                        log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_2", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

globalMap.put("transaction_id", context.transaction_id);

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());

   			if (((String)globalMap.get("transaction_id")) != null
) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				tFileExist_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 1);
	}
	


public void tFileExist_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileExist_2");
		org.slf4j.MDC.put("_subJobPid", "VEPUpq_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_2", false);
		start_Hash.put("tFileExist_2", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_2";
	
	
		int tos_count_tFileExist_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileExist_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileExist_2 = new StringBuilder();
                    log4jParamters_tFileExist_2.append("Parameters:");
                            log4jParamters_tFileExist_2.append("FILE_NAME" + " = " + "context.Server_Out+ context.Livraison_directory + context.ondemand_server_directory + ((String)globalMap.get(\"transaction_id\")) + \"/\"+ context.Livraisons_Exception");
                        log4jParamters_tFileExist_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + (log4jParamters_tFileExist_2) );
                    } 
                } 
            new BytesLimit65535_tFileExist_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileExist_2", "tFileExist_1", "tFileExist");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tFileExist_2 begin ] stop
 */
	
	/**
	 * [tFileExist_2 main ] start
	 */

	

	
	
	currentComponent="tFileExist_2";
	
	


				final StringBuffer log4jSb_tFileExist_2 = new StringBuffer();
			

java.io.File file_tFileExist_2 = new java.io.File(context.Server_Out+ context.Livraison_directory + context.ondemand_server_directory + ((String)globalMap.get("transaction_id")) + "/"+ context.Livraisons_Exception);
if (!file_tFileExist_2.exists()) {
    globalMap.put("tFileExist_2_EXISTS",false);
    log.info("tFileExist_2 - Directory or file : " + file_tFileExist_2.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_2_EXISTS",true);
    log.info("tFileExist_2 - Directory or file : " + file_tFileExist_2.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_2_FILENAME",context.Server_Out+ context.Livraison_directory + context.ondemand_server_directory + ((String)globalMap.get("transaction_id")) + "/"+ context.Livraisons_Exception);


 


	tos_count_tFileExist_2++;

/**
 * [tFileExist_2 main ] stop
 */
	
	/**
	 * [tFileExist_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileExist_2";
	
	

 



/**
 * [tFileExist_2 process_data_begin ] stop
 */
	
	/**
	 * [tFileExist_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileExist_2";
	
	

 



/**
 * [tFileExist_2 process_data_end ] stop
 */
	
	/**
	 * [tFileExist_2 end ] start
	 */

	

	
	
	currentComponent="tFileExist_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + ("Done.") );

ok_Hash.put("tFileExist_2", true);
end_Hash.put("tFileExist_2", System.currentTimeMillis());

   			if (((Boolean)globalMap.get("tFileExist_2_EXISTS"))) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				tDBConnection_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_2 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_2";
	
	

 



/**
 * [tFileExist_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_2_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "FiEHFX_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'false'.");
			conn_tDBConnection_1.setAutoCommit(false);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tFileInputExcel_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class update_taskStruct implements routines.system.IPersistableRow<update_taskStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return true;
				}
				public Integer sourceIdLength(){
				    return 150;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public Integer locationZip;

				public Integer getLocationZip () {
					return this.locationZip;
				}

				public Boolean locationZipIsNullable(){
				    return true;
				}
				public Boolean locationZipIsKey(){
				    return false;
				}
				public Integer locationZipLength(){
				    return 10;
				}
				public Integer locationZipPrecision(){
				    return 0;
				}
				public String locationZipDefault(){
				
					return null;
				
				}
				public String locationZipComment(){
				
				    return "";
				
				}
				public String locationZipPattern(){
				
					return "";
				
				}
				public String locationZipOriginalDbColumnName(){
				
					return "locationZip";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 150;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 150;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 150;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				
			    public String isExpress;

				public String getIsExpress () {
					return this.isExpress;
				}

				public Boolean isExpressIsNullable(){
				    return true;
				}
				public Boolean isExpressIsKey(){
				    return false;
				}
				public Integer isExpressLength(){
				    return 4;
				}
				public Integer isExpressPrecision(){
				    return null;
				}
				public String isExpressDefault(){
				
					return null;
				
				}
				public String isExpressComment(){
				
				    return "";
				
				}
				public String isExpressPattern(){
				
					return "";
				
				}
				public String isExpressOriginalDbColumnName(){
				
					return "isExpress";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return null;
				}
				public Integer is_deletedPrecision(){
				    return null;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.sourceId == null) ? 0 : this.sourceId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final update_taskStruct other = (update_taskStruct) obj;
		
						if (this.sourceId == null) {
							if (other.sourceId != null)
								return false;
						
						} else if (!this.sourceId.equals(other.sourceId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(update_taskStruct other) {

		other.sourceId = this.sourceId;
	            other.locationZip = this.locationZip;
	            other.taskId = this.taskId;
	            other.sourceType = this.sourceType;
	            other.sourceClient = this.sourceClient;
	            other.sourceRound = this.sourceRound;
	            other.isExpress = this.isExpress;
	            other.is_deleted = this.is_deleted;
	            
	}

	public void copyKeysDataTo(update_taskStruct other) {

		other.sourceId = this.sourceId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.isExpress = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.isExpress = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",locationZip="+String.valueOf(locationZip));
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",sourceRound="+sourceRound);
		sb.append(",isExpress="+isExpress);
		sb.append(",is_deleted="+String.valueOf(is_deleted));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(locationZip == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationZip);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        				if(isExpress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isExpress);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(update_taskStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.sourceId, other.sourceId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class update_itemStruct implements routines.system.IPersistableRow<update_itemStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return true;
				}
				public Integer itemIdLength(){
				    return 150;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return 22;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 150;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 150;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.itemId == null) ? 0 : this.itemId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final update_itemStruct other = (update_itemStruct) obj;
		
						if (this.itemId == null) {
							if (other.itemId != null)
								return false;
						
						} else if (!this.itemId.equals(other.itemId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(update_itemStruct other) {

		other.itemId = this.itemId;
	            other.quantity = this.quantity;
	            other.name = this.name;
	            other.type = this.type;
	            other.taskId = this.taskId;
	            
	}

	public void copyKeysDataTo(update_itemStruct other) {

		other.itemId = this.itemId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",name="+name);
		sb.append(",type="+type);
		sb.append(",taskId="+taskId);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(update_itemStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.itemId, other.itemId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return null;
				}
				public Integer Code_postalPrecision(){
				    return null;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return null;
				}
				public Integer Code_postalPrecision(){
				    return null;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class filterStruct implements routines.system.IPersistableRow<filterStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return null;
				}
				public Integer Code_postalPrecision(){
				    return null;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(filterStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return null;
				}
				public Integer Code_postalPrecision(){
				    return null;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public String Item___Quantite;

				public String getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+Item___Quantite);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public String Item___Quantite;

				public String getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+Item___Quantite);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public String Item___Quantite;

				public String getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+Item___Quantite);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tFileInputExcel_1Struct implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public String Item___Quantite;

				public String getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public String Code_postal;

				public String getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
					this.Item___Quantite = readString(dis);
					
					this.Code_postal = readString(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// String
				
						writeString(this.Item___Quantite,dos);
					
					// String
				
						writeString(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+Item___Quantite);
		sb.append(",Code_postal="+Code_postal);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tFileInputExcel_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_1");
		org.slf4j.MDC.put("_subJobPid", "56lG2f_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_1Process(globalMap);

		row2Struct row2 = new row2Struct();
row2Struct row9 = row2;
row5Struct row5 = new row5Struct();
row8Struct row8 = new row8Struct();
filterStruct filter = new filterStruct();
row1Struct row1 = new row1Struct();
update_taskStruct update_task = new update_taskStruct();
update_itemStruct update_item = new update_itemStruct();
row10Struct row10 = new row10Struct();










	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"update_task");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"urbantz_task\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"urbantz_task\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_2 = 1;
         if (updateKeyCount_tDBOutput_2 == 8 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

String tableName_tDBOutput_2 = "urbantz_task";
boolean whetherReject_tDBOutput_2 = false;

java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
long date_tDBOutput_2;

java.sql.Connection conn_tDBOutput_2 = null;
		conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );

		int count_tDBOutput_2=0;
		
				
			
				String insertIgnore_tDBOutput_2 = "INSERT IGNORE INTO `" + "urbantz_task" + "` (`sourceId`,`locationZip`,`taskId`,`sourceType`,`sourceClient`,`sourceRound`,`isExpress`,`is_deleted`) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `locationZip` = ?,`taskId` = ?,`sourceType` = ?,`sourceClient` = ?,`sourceRound` = ?,`isExpress` = ?,`is_deleted` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insertIgnore_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
				


 



/**
 * [tDBOutput_2 begin ] stop
 */




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"update_item");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"urbantz_item\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"urbantz_item\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
         if (updateKeyCount_tDBOutput_1 == 5 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "urbantz_item";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "urbantz_item" + "` (`itemId`,`quantity`,`name`,`type`,`taskId`) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE `quantity` = ?,`name` = ?,`type` = ?,`taskId` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row1_tMap_1 = 0;
		
		int count_row7_tMap_1 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
					globalMap.get( "tHash_Lookup_row7" ))
					;					
					
	

row7Struct row7HashKey = new row7Struct();
row7Struct row7Default = new row7Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_update_task_tMap_1 = 0;
				
update_taskStruct update_task_tmp = new update_taskStruct();
				int count_update_item_tMap_1 = 0;
				
update_itemStruct update_item_tmp = new update_itemStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */




	
	/**
	 * [tHashOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_1", false);
		start_Hash.put("tHashOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row10");
			
		int tos_count_tHashOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashOutput_1", "tHashOutput_1", "tHashOutput");
				talendJobLogProcess(globalMap);
			}
			



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashOutput_1 = null;
		String hashKey_tHashOutput_1 = "tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid + "_tHashOutput_1";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_1)){
			    if(mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1) == null){
	      		    mf_tHashOutput_1.getResourceMap().put(hashKey_tHashOutput_1, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
			    }else{
			    	tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
			    }
			}
        int nb_line_tHashOutput_1 = 0;

 



/**
 * [tHashOutput_1 begin ] stop
 */



	
	/**
	 * [tReplicate_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tReplicate_1", false);
		start_Hash.put("tReplicate_1", System.currentTimeMillis());
		
	
	currentComponent="tReplicate_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"filter");
			
		int tos_count_tReplicate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tReplicate_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tReplicate_1 = new StringBuilder();
                    log4jParamters_tReplicate_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + (log4jParamters_tReplicate_1) );
                    } 
                } 
            new BytesLimit65535_tReplicate_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tReplicate_1", "tReplicate_1", "tReplicate");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tReplicate_1 begin ] stop
 */



	
	/**
	 * [tFilterRow_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_13", false);
		start_Hash.put("tFilterRow_13", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_13";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tFilterRow_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_13 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_13{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_13 = new StringBuilder();
                    log4jParamters_tFilterRow_13.append("Parameters:");
                            log4jParamters_tFilterRow_13.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_13.append(" | ");
                            log4jParamters_tFilterRow_13.append("CONDITIONS" + " = " + "[{OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("itemId")+", FUNCTION="+("")+"}, {OPERATOR="+("!=")+", RVALUE="+("null")+", INPUT_COLUMN="+("taskId")+", FUNCTION="+("")+"}]");
                        log4jParamters_tFilterRow_13.append(" | ");
                            log4jParamters_tFilterRow_13.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_13 - "  + (log4jParamters_tFilterRow_13) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_13().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_13", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_13 = 0;
    int nb_line_ok_tFilterRow_13 = 0;
    int nb_line_reject_tFilterRow_13 = 0;

    class Operator_tFilterRow_13 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_13(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_13 begin ] stop
 */



	
	/**
	 * [tConvertType_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_1", false);
		start_Hash.put("tConvertType_1", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tConvertType_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_1", "tConvertType_1", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_1 = 0;  
 



/**
 * [tConvertType_1 begin ] stop
 */



	
	/**
	 * [tReplace_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tReplace_1", false);
		start_Hash.put("tReplace_1", System.currentTimeMillis());
		
	
	currentComponent="tReplace_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tReplace_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tReplace_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tReplace_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tReplace_1 = new StringBuilder();
                    log4jParamters_tReplace_1.append("Parameters:");
                            log4jParamters_tReplace_1.append("SIMPLE_MODE" + " = " + "true");
                        log4jParamters_tReplace_1.append(" | ");
                            log4jParamters_tReplace_1.append("SUBSTITUTIONS" + " = " + "[{REPLACE_STRING="+("\"PICKUP\"")+", USE_GLOB="+("false")+", CASE_SENSITIVE="+("true")+", SEARCH_PATTERN="+("\"ENLEVEMENT\"")+", INPUT_COLUMN="+("Type_de_Service")+", WHOLE_WORD="+("true")+", COMMENT="+("")+"}, {REPLACE_STRING="+("\"DELIVERY\"")+", USE_GLOB="+("false")+", CASE_SENSITIVE="+("true")+", SEARCH_PATTERN="+("\"LIVRAISON\"")+", INPUT_COLUMN="+("Type_de_Service")+", WHOLE_WORD="+("true")+", COMMENT="+("")+"}, {REPLACE_STRING="+("\".\"")+", USE_GLOB="+("false")+", CASE_SENSITIVE="+("true")+", SEARCH_PATTERN="+("\",\"")+", INPUT_COLUMN="+("Item___Quantite")+", WHOLE_WORD="+("false")+", COMMENT="+("")+"}]");
                        log4jParamters_tReplace_1.append(" | ");
                            log4jParamters_tReplace_1.append("ADVANCED_MODE" + " = " + "false");
                        log4jParamters_tReplace_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tReplace_1 - "  + (log4jParamters_tReplace_1) );
                    } 
                } 
            new BytesLimit65535_tReplace_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tReplace_1", "tReplace_1", "tReplace");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tReplace_1 = 0;
 



/**
 * [tReplace_1 begin ] stop
 */



	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tLogRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogRow_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
                    log4jParamters_tLogRow_2.append("Parameters:");
                            log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "false");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "true");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                        log4jParamters_tLogRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + (log4jParamters_tLogRow_2) );
                    } 
                } 
            new BytesLimit65535_tLogRow_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_2", "tLogRow_1", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[19];

        public void addRow(String[] row) {

            for (int i = 0; i < 19; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 18 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 18 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%15$-");
        			        sbformat.append(colLengths[14]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%16$-");
        			        sbformat.append(colLengths[15]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%17$-");
        			        sbformat.append(colLengths[16]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%18$-");
        			        sbformat.append(colLengths[17]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%19$-");
        			        sbformat.append(colLengths[18]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[18] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{"Tournee","taskId","itemId","Date","Expediteur","Activite","Categorie","Type_de_Service","ID_de_la_tache","Item___Nom","Item___Type","Item___Quantite","Code_postal","Round_Name","Express","Remarque","Is_deleted","Contact","ref3",});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		
		int tos_count_tFileInputExcel_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
                    log4jParamters_tFileInputExcel_1.append("Parameters:");
                            log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FILENAME" + " = " + "context.Server_Out+ context.Livraison_directory + context.ondemand_server_directory + ((String)globalMap.get(\"transaction_id\")) + \"/\"+ context.Livraisons_Exception");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:kowXjet3i97Z125S+DIWiP20KMn4YG1+9rNmLA==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + (log4jParamters_tFileInputExcel_1) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_1", "exceptions", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:6t1MMs1dgQAB4woCTlNlLtZf+M06jjWmyUBHeg==");
        String password_tFileInputExcel_1 = decryptedPassword_tFileInputExcel_1;
        if (password_tFileInputExcel_1.isEmpty()){
            password_tFileInputExcel_1 = null;
        }
			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();

		Object source_tFileInputExcel_1 = context.Server_Out+ context.Livraison_directory + context.ondemand_server_directory + ((String)globalMap.get("transaction_id")) + "/"+ context.Livraisons_Exception;
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_1 = null;
		
		if(source_tFileInputExcel_1 instanceof String){
			workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_1), password_tFileInputExcel_1, true);
		} else if(source_tFileInputExcel_1 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_1, password_tFileInputExcel_1);
		} else{
			workbook_tFileInputExcel_1 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
    	for(org.apache.poi.ss.usermodel.Sheet sheet_tFileInputExcel_1 : workbook_tFileInputExcel_1){
   			sheetList_tFileInputExcel_1.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet_tFileInputExcel_1);
    	}
    	if(sheetList_tFileInputExcel_1.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
			if(sheet_FilterNull_tFileInputExcel_1!=null && sheetList_FilterNull_tFileInputExcel_1.iterator()!=null && sheet_FilterNull_tFileInputExcel_1.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
			}
		}
		sheetList_tFileInputExcel_1 = sheetList_FilterNull_tFileInputExcel_1;
		int nb_line_tFileInputExcel_1 = 0;
	if(sheetList_tFileInputExcel_1.size()>0){

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
			end_line_tFileInputExcel_1+=(sheet_tFileInputExcel_1.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_1 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = (sheetList_tFileInputExcel_1.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = (sheet_tFileInputExcel_1.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getSheetName());
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
		    row2 = null;
					int tempRowLength_tFileInputExcel_1 = 19;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int excel_end_column_tFileInputExcel_1;
			if(row_tFileInputExcel_1==null){
				excel_end_column_tFileInputExcel_1=0;
			}else{
				excel_end_column_tFileInputExcel_1=row_tFileInputExcel_1.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_1;
			if(end_column_tFileInputExcel_1 == -1){
				actual_end_column_tFileInputExcel_1 = excel_end_column_tFileInputExcel_1;
			}
			else{
				actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	excel_end_column_tFileInputExcel_1 ? excel_end_column_tFileInputExcel_1 : end_column_tFileInputExcel_1;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_1 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){
				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1.getCell(i + start_column_tFileInputExcel_1);
					if(cell_tFileInputExcel_1!=null){
					switch (cell_tFileInputExcel_1.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
									temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_1[i] = df_tFileInputExcel_1.format(cell_tFileInputExcel_1.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_1.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
											temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_1 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_1.getNumericCellValue());
										temp_row_tFileInputExcel_1[i] = ne_tFileInputExcel_1.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_1[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_1[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_1[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_1 = false;
			row2 = new row2Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try{
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Tournee";

				row2.Tournee = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Tournee = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "taskId";

				row2.taskId = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.taskId = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 2;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "itemId";

				row2.itemId = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.itemId = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 3;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Date";

				row2.Date = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Date = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 4;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Expediteur";

				row2.Expediteur = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Expediteur = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 5;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Activite";

				row2.Activite = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Activite = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 6;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Categorie";

				row2.Categorie = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Categorie = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 7;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Type_de_Service";

				row2.Type_de_Service = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Type_de_Service = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 8;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_de_la_tache";

				row2.ID_de_la_tache = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.ID_de_la_tache = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 9;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Nom";

				row2.Item___Nom = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Item___Nom = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 10;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Type";

				row2.Item___Type = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Item___Type = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 11;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Quantite";

				row2.Item___Quantite = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Item___Quantite = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 12;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Code_postal";

				row2.Code_postal = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Code_postal = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 13;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Round_Name";

				row2.Round_Name = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Round_Name = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 14;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Express";

				row2.Express = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Express = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 15;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Remarque";

				row2.Remarque = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Remarque = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 16;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Is_deleted";

				row2.Is_deleted = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim(), null, '.'==decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
			}else{
				row2.Is_deleted = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 17;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Contact";

				row2.Contact = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.Contact = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 18;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ref3";

				row2.ref3 = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row2.ref3 = null;
				emptyColumnCount_tFileInputExcel_1++;
			}

				nb_line_tFileInputExcel_1++;
				
				log.debug("tFileInputExcel_1 - Retrieving the record " + (nb_line_tFileInputExcel_1) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_1 = true;
						log.error("tFileInputExcel_1 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row2 = null;
			}


		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tFileInputExcel_1","exceptions","tFileInputExcel","tLogRow_2","tLogRow_1","tLogRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[19];
   				
	    		if(row2.Tournee != null) { //              
                 row_tLogRow_2[0]=    						    
				                String.valueOf(row2.Tournee)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.taskId != null) { //              
                 row_tLogRow_2[1]=    						    
				                String.valueOf(row2.taskId)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.itemId != null) { //              
                 row_tLogRow_2[2]=    						    
				                String.valueOf(row2.itemId)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Date != null) { //              
                 row_tLogRow_2[3]=    						    
				                String.valueOf(row2.Date)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Expediteur != null) { //              
                 row_tLogRow_2[4]=    						    
				                String.valueOf(row2.Expediteur)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Activite != null) { //              
                 row_tLogRow_2[5]=    						    
				                String.valueOf(row2.Activite)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Categorie != null) { //              
                 row_tLogRow_2[6]=    						    
				                String.valueOf(row2.Categorie)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Type_de_Service != null) { //              
                 row_tLogRow_2[7]=    						    
				                String.valueOf(row2.Type_de_Service)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.ID_de_la_tache != null) { //              
                 row_tLogRow_2[8]=    						    
				                String.valueOf(row2.ID_de_la_tache)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Item___Nom != null) { //              
                 row_tLogRow_2[9]=    						    
				                String.valueOf(row2.Item___Nom)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Item___Type != null) { //              
                 row_tLogRow_2[10]=    						    
				                String.valueOf(row2.Item___Type)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Item___Quantite != null) { //              
                 row_tLogRow_2[11]=    						    
				                String.valueOf(row2.Item___Quantite)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Code_postal != null) { //              
                 row_tLogRow_2[12]=    						    
				                String.valueOf(row2.Code_postal)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Round_Name != null) { //              
                 row_tLogRow_2[13]=    						    
				                String.valueOf(row2.Round_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Express != null) { //              
                 row_tLogRow_2[14]=    						    
				                String.valueOf(row2.Express)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Remarque != null) { //              
                 row_tLogRow_2[15]=    						    
				                String.valueOf(row2.Remarque)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Is_deleted != null) { //              
                 row_tLogRow_2[16]=    						    
				                String.valueOf(row2.Is_deleted)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.Contact != null) { //              
                 row_tLogRow_2[17]=    						    
				                String.valueOf(row2.Contact)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.ref3 != null) { //              
                 row_tLogRow_2[18]=    						    
				                String.valueOf(row2.ref3)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
                	log.info("tLogRow_2 - Content of row "+nb_line_tLogRow_2+": " + TalendString.unionString("|",row_tLogRow_2));
//////

//////                    
                    
///////////////////////    			

 
     row9 = row2;


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */

	
	/**
	 * [tReplace_1 main ] start
	 */

	

	
	
	currentComponent="tReplace_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tLogRow_2","tLogRow_1","tLogRow","tReplace_1","tReplace_1","tReplace"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

						String searchStr_tReplace_1_1 = "ENLEVEMENT" + "";
							row9.Type_de_Service = StringUtils.replaceAllStrictly(row9.Type_de_Service, searchStr_tReplace_1_1, "PICKUP" + "", true, true);
						String searchStr_tReplace_1_2 = "LIVRAISON" + "";
							row9.Type_de_Service = StringUtils.replaceAllStrictly(row9.Type_de_Service, searchStr_tReplace_1_2, "DELIVERY" + "", true, true);
						String searchStr_tReplace_1_3 = "," + "";
							row9.Item___Quantite = StringUtils.replaceAllStrictly(row9.Item___Quantite, searchStr_tReplace_1_3, "." + "", false, true);
	        row5.Tournee = row9.Tournee;
	        
	        row5.taskId = row9.taskId;
	        
	        row5.itemId = row9.itemId;
	        
	        row5.Date = row9.Date;
	        
	        row5.Expediteur = row9.Expediteur;
	        
	        row5.Activite = row9.Activite;
	        
	        row5.Categorie = row9.Categorie;
	        
	        row5.Type_de_Service = row9.Type_de_Service;
	        
	        row5.ID_de_la_tache = row9.ID_de_la_tache;
	        
	        row5.Item___Nom = row9.Item___Nom;
	        
	        row5.Item___Type = row9.Item___Type;
	        
	        row5.Item___Quantite = row9.Item___Quantite;
	        
	        row5.Code_postal = row9.Code_postal;
	        
	        row5.Round_Name = row9.Round_Name;
	        
	        row5.Express = row9.Express;
	        
	        row5.Remarque = row9.Remarque;
	        
	        row5.Is_deleted = row9.Is_deleted;
	        
	        row5.Contact = row9.Contact;
	        
	        row5.ref3 = row9.ref3;
	        
    nb_line_tReplace_1++;

 


	tos_count_tReplace_1++;

/**
 * [tReplace_1 main ] stop
 */
	
	/**
	 * [tReplace_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tReplace_1";
	
	

 



/**
 * [tReplace_1 process_data_begin ] stop
 */

	
	/**
	 * [tConvertType_1 main ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tReplace_1","tReplace_1","tReplace","tConvertType_1","tConvertType_1","tConvertType"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		


  row8 = new row8Struct();
  boolean bHasError_tConvertType_1 = false;             
          try {
              if ("".equals(row5.Tournee)){  
                row5.Tournee = null;
              }
              row8.Tournee=TypeConvert.String2String(row5.Tournee);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.taskId)){  
                row5.taskId = null;
              }
              row8.taskId=TypeConvert.String2String(row5.taskId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.itemId)){  
                row5.itemId = null;
              }
              row8.itemId=TypeConvert.String2String(row5.itemId);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Date)){  
                row5.Date = null;
              }
              row8.Date=TypeConvert.String2String(row5.Date);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Expediteur)){  
                row5.Expediteur = null;
              }
              row8.Expediteur=TypeConvert.String2String(row5.Expediteur);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Activite)){  
                row5.Activite = null;
              }
              row8.Activite=TypeConvert.String2String(row5.Activite);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Categorie)){  
                row5.Categorie = null;
              }
              row8.Categorie=TypeConvert.String2String(row5.Categorie);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Type_de_Service)){  
                row5.Type_de_Service = null;
              }
              row8.Type_de_Service=TypeConvert.String2String(row5.Type_de_Service);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.ID_de_la_tache)){  
                row5.ID_de_la_tache = null;
              }
              row8.ID_de_la_tache=TypeConvert.String2String(row5.ID_de_la_tache);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Item___Nom)){  
                row5.Item___Nom = null;
              }
              row8.Item___Nom=TypeConvert.String2String(row5.Item___Nom);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Item___Type)){  
                row5.Item___Type = null;
              }
              row8.Item___Type=TypeConvert.String2String(row5.Item___Type);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Item___Quantite)){  
                row5.Item___Quantite = null;
              }
              row8.Item___Quantite=TypeConvert.String2Double(row5.Item___Quantite);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Code_postal)){  
                row5.Code_postal = null;
              }
              row8.Code_postal=TypeConvert.String2Integer(row5.Code_postal);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Round_Name)){  
                row5.Round_Name = null;
              }
              row8.Round_Name=TypeConvert.String2String(row5.Round_Name);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Express)){  
                row5.Express = null;
              }
              row8.Express=TypeConvert.String2String(row5.Express);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Remarque)){  
                row5.Remarque = null;
              }
              row8.Remarque=TypeConvert.String2String(row5.Remarque);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Is_deleted=TypeConvert.Integer2Integer(row5.Is_deleted);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.Contact)){  
                row5.Contact = null;
              }
              row8.Contact=TypeConvert.String2String(row5.Contact);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              if ("".equals(row5.ref3)){  
                row5.ref3 = null;
              }
              row8.ref3=TypeConvert.String2String(row5.ref3);            
          } catch(java.lang.Exception e){
globalMap.put("tConvertType_1_ERROR_MESSAGE",e.getMessage());
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_1) {row8 = null;}

  nb_line_tConvertType_1 ++ ;

 


	tos_count_tConvertType_1++;

/**
 * [tConvertType_1 main ] stop
 */
	
	/**
	 * [tConvertType_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tFilterRow_13 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_13";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tConvertType_1","tConvertType_1","tConvertType","tFilterRow_13","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

          filter = null;
    Operator_tFilterRow_13 ope_tFilterRow_13 = new Operator_tFilterRow_13("&&");
	        ope_tFilterRow_13.matches((row8.itemId != null)
	                       , "itemId!=null failed");
	        ope_tFilterRow_13.matches((row8.taskId != null)
	                       , "taskId!=null failed");
    
    if (ope_tFilterRow_13.getMatchFlag()) {
              if(filter == null){ 
                filter = new filterStruct();
              }
               filter.Tournee = row8.Tournee;
               filter.taskId = row8.taskId;
               filter.itemId = row8.itemId;
               filter.Date = row8.Date;
               filter.Expediteur = row8.Expediteur;
               filter.Activite = row8.Activite;
               filter.Categorie = row8.Categorie;
               filter.Type_de_Service = row8.Type_de_Service;
               filter.ID_de_la_tache = row8.ID_de_la_tache;
               filter.Item___Nom = row8.Item___Nom;
               filter.Item___Type = row8.Item___Type;
               filter.Item___Quantite = row8.Item___Quantite;
               filter.Code_postal = row8.Code_postal;
               filter.Round_Name = row8.Round_Name;
               filter.Express = row8.Express;
               filter.Remarque = row8.Remarque;
               filter.Is_deleted = row8.Is_deleted;
               filter.Contact = row8.Contact;
               filter.ref3 = row8.ref3;
					log.debug("tFilterRow_13 - Process the record " + (nb_line_tFilterRow_13+1) + ".");
					    
      nb_line_ok_tFilterRow_13++;
    } else {
      nb_line_reject_tFilterRow_13++;
    }

nb_line_tFilterRow_13++;

 


	tos_count_tFilterRow_13++;

/**
 * [tFilterRow_13 main ] stop
 */
	
	/**
	 * [tFilterRow_13 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_13";
	
	

 



/**
 * [tFilterRow_13 process_data_begin ] stop
 */
// Start of branch "filter"
if(filter != null) { 



	
	/**
	 * [tReplicate_1 main ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"filter","tFilterRow_13","tFilterRow_1","tFilterRow","tReplicate_1","tReplicate_1","tReplicate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("filter - " + (filter==null? "": filter.toLogString()));
    			}
    		


	row1 = new row1Struct();
						
	row1.Tournee = filter.Tournee;								
	row1.taskId = filter.taskId;								
	row1.itemId = filter.itemId;								
	row1.Date = filter.Date;								
	row1.Expediteur = filter.Expediteur;								
	row1.Activite = filter.Activite;								
	row1.Categorie = filter.Categorie;								
	row1.Type_de_Service = filter.Type_de_Service;								
	row1.ID_de_la_tache = filter.ID_de_la_tache;								
	row1.Item___Nom = filter.Item___Nom;								
	row1.Item___Type = filter.Item___Type;								
	row1.Item___Quantite = filter.Item___Quantite;								
	row1.Code_postal = filter.Code_postal;								
	row1.Round_Name = filter.Round_Name;								
	row1.Express = filter.Express;								
	row1.Remarque = filter.Remarque;								
	row1.Is_deleted = filter.Is_deleted;								
	row1.Contact = filter.Contact;								
	row1.ref3 = filter.ref3;			
	row10 = new row10Struct();
						
	row10.Tournee = filter.Tournee;								
	row10.taskId = filter.taskId;								
	row10.itemId = filter.itemId;								
	row10.Date = filter.Date;								
	row10.Expediteur = filter.Expediteur;								
	row10.Activite = filter.Activite;								
	row10.Categorie = filter.Categorie;								
	row10.Type_de_Service = filter.Type_de_Service;								
	row10.ID_de_la_tache = filter.ID_de_la_tache;								
	row10.Item___Nom = filter.Item___Nom;								
	row10.Item___Type = filter.Item___Type;								
	row10.Item___Quantite = filter.Item___Quantite;								
	row10.Code_postal = filter.Code_postal;								
	row10.Round_Name = filter.Round_Name;								
	row10.Express = filter.Express;								
	row10.Remarque = filter.Remarque;								
	row10.Is_deleted = filter.Is_deleted;								
	row10.Contact = filter.Contact;								
	row10.ref3 = filter.ref3;			


 


	tos_count_tReplicate_1++;

/**
 * [tReplicate_1 main ] stop
 */
	
	/**
	 * [tReplicate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tReplicate_1","tReplicate_1","tReplicate","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
						row7Struct row7 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row7" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow7 = false;
       		  	    	
       		  	    	
 							row7Struct row7ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row7HashKey.sourceId = row1.taskId ;
                        		    		

								
		                        	row7HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row7.lookup( row7HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row7.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row7 != null && tHash_Lookup_row7.getCount(row7HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row7' and it contains more one result from keys :  row7.sourceId = '" + row7HashKey.sourceId + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row7Struct fromLookup_row7 = null;
							row7 = row7Default;
										 
							
								 
							
							
								if (tHash_Lookup_row7 !=null && tHash_Lookup_row7.hasNext()) { // G 099
								
							
								
								fromLookup_row7 = tHash_Lookup_row7.next();

							
							
								} // G 099
							
							

							if(fromLookup_row7 != null) {
								row7 = fromLookup_row7;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

update_task = null;
update_item = null;

if(!rejectedInnerJoin_tMap_1 ) {

// # Output table : 'update_task'
count_update_task_tMap_1++;

update_task_tmp.sourceId = row7.sourceId ;
update_task_tmp.locationZip = row1.Code_postal ;
update_task_tmp.taskId = row1.ID_de_la_tache ;
update_task_tmp.sourceType = row1.Type_de_Service ;
update_task_tmp.sourceClient = row1.Expediteur ;
update_task_tmp.sourceRound = row1.Tournee ;
update_task_tmp.isExpress = "OUI".equals(row1.Express) ? "true" : null;
update_task_tmp.is_deleted = row1.Is_deleted != null ? row1.Is_deleted : 0 ;
update_task = update_task_tmp;
log.debug("tMap_1 - Outputting the record " + count_update_task_tMap_1 + " of the output table 'update_task'.");


// # Output table : 'update_item'
count_update_item_tMap_1++;

update_item_tmp.itemId = row1.itemId ;
update_item_tmp.quantity = row1.Item___Quantite ;
update_item_tmp.name = row1.Item___Nom ;
update_item_tmp.type = row1.Item___Type ;
update_item_tmp.taskId = row7.sourceId ;
update_item = update_item_tmp;
log.debug("tMap_1 - Outputting the record " + count_update_item_tMap_1 + " of the output table 'update_item'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "update_task"
if(update_task != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"update_task","tMap_1","tMap_1","tMap","tDBOutput_2","\"urbantz_task\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("update_task - " + (update_task==null? "": update_task.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    if(update_task.sourceId == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, update_task.sourceId);
}

                    if(update_task.locationZip == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(2, update_task.locationZip);
}

                    if(update_task.taskId == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, update_task.taskId);
}

                    if(update_task.sourceType == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, update_task.sourceType);
}

                    if(update_task.sourceClient == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, update_task.sourceClient);
}

                    if(update_task.sourceRound == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, update_task.sourceRound);
}

                    if(update_task.isExpress == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, update_task.isExpress);
}

                    if(update_task.is_deleted == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, update_task.is_deleted);
}

                    if(update_task.locationZip == null) {
pstmt_tDBOutput_2.setNull(9 + count_tDBOutput_2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(9 + count_tDBOutput_2, update_task.locationZip);
}

                    if(update_task.taskId == null) {
pstmt_tDBOutput_2.setNull(10 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10 + count_tDBOutput_2, update_task.taskId);
}

                    if(update_task.sourceType == null) {
pstmt_tDBOutput_2.setNull(11 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11 + count_tDBOutput_2, update_task.sourceType);
}

                    if(update_task.sourceClient == null) {
pstmt_tDBOutput_2.setNull(12 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12 + count_tDBOutput_2, update_task.sourceClient);
}

                    if(update_task.sourceRound == null) {
pstmt_tDBOutput_2.setNull(13 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(13 + count_tDBOutput_2, update_task.sourceRound);
}

                    if(update_task.isExpress == null) {
pstmt_tDBOutput_2.setNull(14 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(14 + count_tDBOutput_2, update_task.isExpress);
}

                    if(update_task.is_deleted == null) {
pstmt_tDBOutput_2.setNull(15 + count_tDBOutput_2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(15 + count_tDBOutput_2, update_task.is_deleted);
}

            int count_on_duplicate_key_tDBOutput_2 = 0;
            try {
                int processedCount_tDBOutput_2 = pstmt_tDBOutput_2.executeUpdate();
                count_on_duplicate_key_tDBOutput_2 += processedCount_tDBOutput_2;
                rowsToCommitCount_tDBOutput_2 += processedCount_tDBOutput_2;
                nb_line_tDBOutput_2++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_2 = true;
            log.error("tDBOutput_2 - "  + (e.getMessage()) );
                        System.err.print(e.getMessage());
            }
            if(count_on_duplicate_key_tDBOutput_2 == 1) {
                insertedCount_tDBOutput_2 += count_on_duplicate_key_tDBOutput_2;
            } else {
                insertedCount_tDBOutput_2 += 1;
                updatedCount_tDBOutput_2 += count_on_duplicate_key_tDBOutput_2 - 1;
            }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "update_task"




// Start of branch "update_item"
if(update_item != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"update_item","tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_item\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("update_item - " + (update_item==null? "": update_item.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    if(update_item.itemId == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, update_item.itemId);
}

                    if(update_item.quantity == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(2, update_item.quantity);
}

                    if(update_item.name == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, update_item.name);
}

                    if(update_item.type == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, update_item.type);
}

                    if(update_item.taskId == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, update_item.taskId);
}

                    if(update_item.quantity == null) {
pstmt_tDBOutput_1.setNull(6 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(6 + count_tDBOutput_1, update_item.quantity);
}

                    if(update_item.name == null) {
pstmt_tDBOutput_1.setNull(7 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7 + count_tDBOutput_1, update_item.name);
}

                    if(update_item.type == null) {
pstmt_tDBOutput_1.setNull(8 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8 + count_tDBOutput_1, update_item.type);
}

                    if(update_item.taskId == null) {
pstmt_tDBOutput_1.setNull(9 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9 + count_tDBOutput_1, update_item.taskId);
}

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
            log.error("tDBOutput_1 - "  + (e.getMessage()) );
                        System.err.print(e.getMessage());
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "update_item"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */




	
	/**
	 * [tHashOutput_1 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row10","tReplicate_1","tReplicate_1","tReplicate","tHashOutput_1","tHashOutput_1","tHashOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		



    
		row10Struct oneRow_tHashOutput_1 = new row10Struct();
				
					oneRow_tHashOutput_1.Tournee = row10.Tournee;
					oneRow_tHashOutput_1.taskId = row10.taskId;
					oneRow_tHashOutput_1.itemId = row10.itemId;
					oneRow_tHashOutput_1.Date = row10.Date;
					oneRow_tHashOutput_1.Expediteur = row10.Expediteur;
					oneRow_tHashOutput_1.Activite = row10.Activite;
					oneRow_tHashOutput_1.Categorie = row10.Categorie;
					oneRow_tHashOutput_1.Type_de_Service = row10.Type_de_Service;
					oneRow_tHashOutput_1.ID_de_la_tache = row10.ID_de_la_tache;
					oneRow_tHashOutput_1.Item___Nom = row10.Item___Nom;
					oneRow_tHashOutput_1.Item___Type = row10.Item___Type;
					oneRow_tHashOutput_1.Item___Quantite = row10.Item___Quantite;
					oneRow_tHashOutput_1.Code_postal = row10.Code_postal;
					oneRow_tHashOutput_1.Round_Name = row10.Round_Name;
					oneRow_tHashOutput_1.Express = row10.Express;
					oneRow_tHashOutput_1.Remarque = row10.Remarque;
					oneRow_tHashOutput_1.Is_deleted = row10.Is_deleted;
					oneRow_tHashOutput_1.Contact = row10.Contact;
					oneRow_tHashOutput_1.ref3 = row10.ref3;
		
        tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
        nb_line_tHashOutput_1 ++;

 


	tos_count_tHashOutput_1++;

/**
 * [tHashOutput_1 main ] stop
 */
	
	/**
	 * [tHashOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tHashOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tReplicate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_end ] stop
 */

} // End of branch "filter"




	
	/**
	 * [tFilterRow_13 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_13";
	
	

 



/**
 * [tFilterRow_13 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tConvertType_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 process_data_end ] stop
 */



	
	/**
	 * [tReplace_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tReplace_1";
	
	

 



/**
 * [tReplace_1 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		

			}
			
			
				log.debug("tFileInputExcel_1 - Retrieved records count: "+ nb_line_tFileInputExcel_1 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
		} finally {
				
  				if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_1.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);
                if(log.isInfoEnabled())
            log.info("tLogRow_2 - "  + ("Printed row count: ")  + (nb_line_tLogRow_2)  + (".") );

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tFileInputExcel_1","exceptions","tFileInputExcel","tLogRow_2","tLogRow_1","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Done.") );

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */

	
	/**
	 * [tReplace_1 end ] start
	 */

	

	
	
	currentComponent="tReplace_1";
	
	


globalMap.put("tReplace_1_NB_LINE",nb_line_tReplace_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tLogRow_2","tLogRow_1","tLogRow","tReplace_1","tReplace_1","tReplace","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tReplace_1 - "  + ("Done.") );

ok_Hash.put("tReplace_1", true);
end_Hash.put("tReplace_1", System.currentTimeMillis());




/**
 * [tReplace_1 end ] stop
 */

	
	/**
	 * [tConvertType_1 end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	
      globalMap.put("tConvertType_1_NB_LINE", nb_line_tConvertType_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tReplace_1","tReplace_1","tReplace","tConvertType_1","tConvertType_1","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_1", true);
end_Hash.put("tConvertType_1", System.currentTimeMillis());




/**
 * [tConvertType_1 end ] stop
 */

	
	/**
	 * [tFilterRow_13 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_13";
	
	
    globalMap.put("tFilterRow_13_NB_LINE", nb_line_tFilterRow_13);
    globalMap.put("tFilterRow_13_NB_LINE_OK", nb_line_ok_tFilterRow_13);
    globalMap.put("tFilterRow_13_NB_LINE_REJECT", nb_line_reject_tFilterRow_13);
    
    	log.info("tFilterRow_13 - Processed records count:" + nb_line_tFilterRow_13 + ". Matched records count:" + nb_line_ok_tFilterRow_13 + ". Rejected records count:" + nb_line_reject_tFilterRow_13 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tConvertType_1","tConvertType_1","tConvertType","tFilterRow_13","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_13 - "  + ("Done.") );

ok_Hash.put("tFilterRow_13", true);
end_Hash.put("tFilterRow_13", System.currentTimeMillis());




/**
 * [tFilterRow_13 end ] stop
 */

	
	/**
	 * [tReplicate_1 end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"filter",2,0,
			 			"tFilterRow_13","tFilterRow_1","tFilterRow","tReplicate_1","tReplicate_1","tReplicate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Done.") );

ok_Hash.put("tReplicate_1", true);
end_Hash.put("tReplicate_1", System.currentTimeMillis());




/**
 * [tReplicate_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row7 != null) {
						tHash_Lookup_row7.endGet();
					}
					globalMap.remove( "tHash_Lookup_row7" );

					
					
				
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'update_task': " + count_update_task_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'update_item': " + count_update_item_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		



		

		if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_2", true);
	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"update_task",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_2","\"urbantz_task\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */




	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"update_item",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_item\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */







	
	/**
	 * [tHashOutput_1 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	
globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row10",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tHashOutput_1","tHashOutput_1","tHashOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tHashOutput_1", true);
end_Hash.put("tHashOutput_1", System.currentTimeMillis());




/**
 * [tHashOutput_1 end ] stop
 */


















				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tHashInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row7"); 
				     			
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="exceptions";
		

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 finally ] stop
 */

	
	/**
	 * [tReplace_1 finally ] start
	 */

	

	
	
	currentComponent="tReplace_1";
	
	

 



/**
 * [tReplace_1 finally ] stop
 */

	
	/**
	 * [tConvertType_1 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_1";
	
	

 



/**
 * [tConvertType_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_13 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_13";
	
	

 



/**
 * [tFilterRow_13 finally ] stop
 */

	
	/**
	 * [tReplicate_1 finally ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_task\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */




	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_item\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */







	
	/**
	 * [tHashOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 finally ] stop
 */


















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	


public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 150;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return 150;
				}
				public Integer billingRoundNamePrecision(){
				    return 0;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row21Struct other = (row21Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row21Struct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(row21Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class round_updatedStruct implements routines.system.IPersistableRow<round_updatedStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 150;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return 150;
				}
				public Integer billingRoundNamePrecision(){
				    return 0;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final round_updatedStruct other = (round_updatedStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(round_updatedStruct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(round_updatedStruct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(round_updatedStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tHashInput_1Struct implements routines.system.IPersistableRow<after_tHashInput_1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return null;
				}
				public Integer itemIdPrecision(){
				    return null;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd/MM/yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom;

				public String getItem___Nom () {
					return this.Item___Nom;
				}

				public Boolean Item___NomIsNullable(){
				    return true;
				}
				public Boolean Item___NomIsKey(){
				    return false;
				}
				public Integer Item___NomLength(){
				    return 5;
				}
				public Integer Item___NomPrecision(){
				    return 0;
				}
				public String Item___NomDefault(){
				
					return null;
				
				}
				public String Item___NomComment(){
				
				    return "";
				
				}
				public String Item___NomPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___NomOriginalDbColumnName(){
				
					return "Item___Nom";
				
				}

				
			    public String Item___Type;

				public String getItem___Type () {
					return this.Item___Type;
				}

				public Boolean Item___TypeIsNullable(){
				    return true;
				}
				public Boolean Item___TypeIsKey(){
				    return false;
				}
				public Integer Item___TypeLength(){
				    return 0;
				}
				public Integer Item___TypePrecision(){
				    return 0;
				}
				public String Item___TypeDefault(){
				
					return null;
				
				}
				public String Item___TypeComment(){
				
				    return "";
				
				}
				public String Item___TypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___TypeOriginalDbColumnName(){
				
					return "Item___Type";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return 2;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return null;
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return null;
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public String Express;

				public String getExpress () {
					return this.Express;
				}

				public Boolean ExpressIsNullable(){
				    return true;
				}
				public Boolean ExpressIsKey(){
				    return false;
				}
				public Integer ExpressLength(){
				    return null;
				}
				public Integer ExpressPrecision(){
				    return null;
				}
				public String ExpressDefault(){
				
					return null;
				
				}
				public String ExpressComment(){
				
				    return "";
				
				}
				public String ExpressPattern(){
				
					return "";
				
				}
				public String ExpressOriginalDbColumnName(){
				
					return "Express";
				
				}

				
			    public String Remarque;

				public String getRemarque () {
					return this.Remarque;
				}

				public Boolean RemarqueIsNullable(){
				    return true;
				}
				public Boolean RemarqueIsKey(){
				    return false;
				}
				public Integer RemarqueLength(){
				    return null;
				}
				public Integer RemarquePrecision(){
				    return null;
				}
				public String RemarqueDefault(){
				
					return null;
				
				}
				public String RemarqueComment(){
				
				    return "";
				
				}
				public String RemarquePattern(){
				
					return "";
				
				}
				public String RemarqueOriginalDbColumnName(){
				
					return "Remarque";
				
				}

				
			    public Integer Is_deleted;

				public Integer getIs_deleted () {
					return this.Is_deleted;
				}

				public Boolean Is_deletedIsNullable(){
				    return true;
				}
				public Boolean Is_deletedIsKey(){
				    return false;
				}
				public Integer Is_deletedLength(){
				    return null;
				}
				public Integer Is_deletedPrecision(){
				    return null;
				}
				public String Is_deletedDefault(){
				
					return null;
				
				}
				public String Is_deletedComment(){
				
				    return "";
				
				}
				public String Is_deletedPattern(){
				
					return "";
				
				}
				public String Is_deletedOriginalDbColumnName(){
				
					return "Is_deleted";
				
				}

				
			    public String Contact;

				public String getContact () {
					return this.Contact;
				}

				public Boolean ContactIsNullable(){
				    return true;
				}
				public Boolean ContactIsKey(){
				    return false;
				}
				public Integer ContactLength(){
				    return null;
				}
				public Integer ContactPrecision(){
				    return null;
				}
				public String ContactDefault(){
				
					return null;
				
				}
				public String ContactComment(){
				
				    return "";
				
				}
				public String ContactPattern(){
				
					return "";
				
				}
				public String ContactOriginalDbColumnName(){
				
					return "Contact";
				
				}

				
			    public String ref3;

				public String getRef3 () {
					return this.ref3;
				}

				public Boolean ref3IsNullable(){
				    return true;
				}
				public Boolean ref3IsKey(){
				    return false;
				}
				public Integer ref3Length(){
				    return null;
				}
				public Integer ref3Precision(){
				    return null;
				}
				public String ref3Default(){
				
					return null;
				
				}
				public String ref3Comment(){
				
				    return "";
				
				}
				public String ref3Pattern(){
				
					return "";
				
				}
				public String ref3OriginalDbColumnName(){
				
					return "ref3";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom = readString(dis);
					
					this.Item___Type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.Round_Name = readString(dis);
					
					this.Express = readString(dis);
					
					this.Remarque = readString(dis);
					
						this.Is_deleted = readInteger(dis);
					
					this.Contact = readString(dis);
					
					this.ref3 = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom,dos);
					
					// String
				
						writeString(this.Item___Type,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// String
				
						writeString(this.Express,dos);
					
					// String
				
						writeString(this.Remarque,dos);
					
					// Integer
				
						writeInteger(this.Is_deleted,dos);
					
					// String
				
						writeString(this.Contact,dos);
					
					// String
				
						writeString(this.ref3,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom="+Item___Nom);
		sb.append(",Item___Type="+Item___Type);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",Round_Name="+Round_Name);
		sb.append(",Express="+Express);
		sb.append(",Remarque="+Remarque);
		sb.append(",Is_deleted="+String.valueOf(Is_deleted));
		sb.append(",Contact="+Contact);
		sb.append(",ref3="+ref3);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Express == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Express);
            			}
            		
        			sb.append("|");
        		
        				if(Remarque == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarque);
            			}
            		
        			sb.append("|");
        		
        				if(Is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(Contact == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Contact);
            			}
            		
        			sb.append("|");
        		
        				if(ref3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref3);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tHashInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_1");
		org.slf4j.MDC.put("_subJobPid", "stLWfH_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_2Process(globalMap);

		row4Struct row4 = new row4Struct();
round_updatedStruct round_updated = new round_updatedStruct();
row21Struct row21 = new row21Struct();






	
	/**
	 * [tHashOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_2", false);
		start_Hash.put("tHashOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row21");
			
		int tos_count_tHashOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashOutput_2", "tHashOutput_2", "tHashOutput");
				talendJobLogProcess(globalMap);
			}
			



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row21Struct> tHashFile_tHashOutput_2 = null;
		String hashKey_tHashOutput_2 = "tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid + "_tHashOutput_2";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_2)){
			    if(mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2) == null){
	      		    mf_tHashOutput_2.getResourceMap().put(hashKey_tHashOutput_2, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row21Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }else{
			    	tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }
			}
        int nb_line_tHashOutput_2 = 0;

 



/**
 * [tHashOutput_2 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"round_updated");
			
		int tos_count_tUniqRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
                    log4jParamters_tUniqRow_1.append("Parameters:");
                            log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("true")+", SCHEMA_COLUMN="+("roundId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("true")+", SCHEMA_COLUMN="+("billingRoundName")+"}]");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                            log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + (log4jParamters_tUniqRow_1) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

	
		class KeyStruct_tUniqRow_1 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String roundId;
					String billingRoundName;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
								
								result = prime * result + ((this.billingRoundName == null) ? 0 : this.billingRoundName.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;
				
									if (this.roundId == null) {
										if (other.roundId != null) 
											return false;
								
									} else if (!this.roundId.equals(other.roundId))
								 
										return false;
								
									if (this.billingRoundName == null) {
										if (other.billingRoundName != null) 
											return false;
								
									} else if (!this.billingRoundName.equals(other.billingRoundName))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
	log.debug("tUniqRow_1 - Start to process the data from datasource.");
KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>(); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_3 = new StringBuilder();
                    log4jParamters_tMap_3.append("Parameters:");
                            log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + (log4jParamters_tMap_3) );
                    } 
                } 
            new BytesLimit65535_tMap_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap_3", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row4_tMap_3 = 0;
		
		int count_row11_tMap_3 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
					globalMap.get( "tHash_Lookup_row11" ))
					;					
					
	

row11Struct row11HashKey = new row11Struct();
row11Struct row11Default = new row11Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_round_updated_tMap_3 = 0;
				
round_updatedStruct round_updated_tmp = new round_updatedStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tHashInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_1", false);
		start_Hash.put("tHashInput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_1";
	
	
		int tos_count_tHashInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_1", "tHashInput_1", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_1 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashInput_1 = mf_tHashInput_1.getAdvancedMemoryHashFile("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_1");
if(tHashFile_tHashInput_1==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row10Struct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
while (iterator_tHashInput_1.hasNext()) {
    row10Struct next_tHashInput_1 = iterator_tHashInput_1.next();

	row4.Tournee = next_tHashInput_1.Tournee;
	row4.taskId = next_tHashInput_1.taskId;
	row4.itemId = next_tHashInput_1.itemId;
	row4.Date = next_tHashInput_1.Date;
	row4.Expediteur = next_tHashInput_1.Expediteur;
	row4.Activite = next_tHashInput_1.Activite;
	row4.Categorie = next_tHashInput_1.Categorie;
	row4.Type_de_Service = next_tHashInput_1.Type_de_Service;
	row4.ID_de_la_tache = next_tHashInput_1.ID_de_la_tache;
	row4.Item___Nom = next_tHashInput_1.Item___Nom;
	row4.Item___Type = next_tHashInput_1.Item___Type;
	row4.Item___Quantite = next_tHashInput_1.Item___Quantite;
	row4.Code_postal = next_tHashInput_1.Code_postal;
	row4.Round_Name = next_tHashInput_1.Round_Name;
	row4.Express = next_tHashInput_1.Express;
	row4.Remarque = next_tHashInput_1.Remarque;
	row4.Is_deleted = next_tHashInput_1.Is_deleted;
	row4.Contact = next_tHashInput_1.Contact;
	row4.ref3 = next_tHashInput_1.ref3;

 



/**
 * [tHashInput_1 begin ] stop
 */
	
	/**
	 * [tHashInput_1 main ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 


	tos_count_tHashInput_1++;

/**
 * [tHashInput_1 main ] stop
 */
	
	/**
	 * [tHashInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tHashInput_1","tHashInput_1","tHashInput","tMap_3","tMap_3","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
						row11Struct row11 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_3 = false;
		boolean mainRowRejected_tMap_3 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row11" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow11 = false;
       		  	    	
       		  	    	
 							row11Struct row11ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_3) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_3 = false;
								
                        		    		    row11HashKey.roundId = row4.Tournee ;
                        		    		

								
		                        	row11HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row11.lookup( row11HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row11.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_3 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row11 != null && tHash_Lookup_row11.getCount(row11HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row11' and it contains more one result from keys :  row11.roundId = '" + row11HashKey.roundId + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row11Struct fromLookup_row11 = null;
							row11 = row11Default;
										 
							
								 
							
							
								if (tHash_Lookup_row11 !=null && tHash_Lookup_row11.hasNext()) { // G 099
								
							
								
								fromLookup_row11 = tHash_Lookup_row11.next();

							
							
								} // G 099
							
							

							if(fromLookup_row11 != null) {
								row11 = fromLookup_row11;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

round_updated = null;

if(!rejectedInnerJoin_tMap_3 ) {

// # Output table : 'round_updated'
count_round_updated_tMap_3++;

round_updated_tmp.roundId = row11.roundId ;
round_updated_tmp.billingRoundName = row4.ref3 ;
round_updated = round_updated_tmp;
log.debug("tMap_3 - Outputting the record " + count_round_updated_tMap_3 + " of the output table 'round_updated'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "round_updated"
if(round_updated != null) { 



	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"round_updated","tMap_3","tMap_3","tMap","tUniqRow_1","tUniqRow_1","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("round_updated - " + (round_updated==null? "": round_updated.toLogString()));
    			}
    		
row21 = null;			
if(round_updated.roundId == null){
	finder_tUniqRow_1.roundId = null;
}else{
	finder_tUniqRow_1.roundId = round_updated.roundId.toLowerCase();
}
if(round_updated.billingRoundName == null){
	finder_tUniqRow_1.billingRoundName = null;
}else{
	finder_tUniqRow_1.billingRoundName = round_updated.billingRoundName.toLowerCase();
}	
finder_tUniqRow_1.hashCodeDirty = true;
if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
		KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

		
if(round_updated.roundId == null){
	new_tUniqRow_1.roundId = null;
}else{
	new_tUniqRow_1.roundId = round_updated.roundId.toLowerCase();
}
if(round_updated.billingRoundName == null){
	new_tUniqRow_1.billingRoundName = null;
}else{
	new_tUniqRow_1.billingRoundName = round_updated.billingRoundName.toLowerCase();
}
		
		keystUniqRow_1.add(new_tUniqRow_1);if(row21 == null){ 
	
		log.trace("tUniqRow_1 - Writing the unique record " + (nb_uniques_tUniqRow_1+1) + " into row21.");
	
	row21 = new row21Struct();
}row21.roundId = round_updated.roundId;			row21.billingRoundName = round_updated.billingRoundName;					
		nb_uniques_tUniqRow_1++;
	} else {
	  nb_duplicates_tUniqRow_1++;
	}

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "row21"
if(row21 != null) { 



	
	/**
	 * [tHashOutput_2 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row21","tUniqRow_1","tUniqRow_1","tUniqRow","tHashOutput_2","tHashOutput_2","tHashOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row21 - " + (row21==null? "": row21.toLogString()));
    			}
    		



    
		row21Struct oneRow_tHashOutput_2 = new row21Struct();
				
					oneRow_tHashOutput_2.roundId = row21.roundId;
					oneRow_tHashOutput_2.billingRoundName = row21.billingRoundName;
		
        tHashFile_tHashOutput_2.put(oneRow_tHashOutput_2);
        nb_line_tHashOutput_2 ++;

 


	tos_count_tHashOutput_2++;

/**
 * [tHashOutput_2 main ] stop
 */
	
	/**
	 * [tHashOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";
	
	

 



/**
 * [tHashOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tHashOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";
	
	

 



/**
 * [tHashOutput_2 process_data_end ] stop
 */

} // End of branch "row21"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */

} // End of branch "round_updated"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_1 end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	
    

		
			nb_line_tHashInput_1++;
		}	
    		
    		mf_tHashInput_1.clearCache("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_1");
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_1");
	


	globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);       

 

ok_Hash.put("tHashInput_1", true);
end_Hash.put("tHashInput_1", System.currentTimeMillis());




/**
 * [tHashInput_1 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row11 != null) {
						tHash_Lookup_row11.endGet();
					}
					globalMap.remove( "tHash_Lookup_row11" );

					
					
				
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'round_updated': " + count_round_updated_tMap_3 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tHashInput_1","tHashInput_1","tHashInput","tMap_3","tMap_3","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Done.") );

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);
	log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1)+" .");
	log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"round_updated",2,0,
			 			"tMap_3","tMap_3","tMap","tUniqRow_1","tUniqRow_1","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_1 - "  + ("Done.") );

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());




/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tHashOutput_2 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";
	
	
globalMap.put("tHashOutput_2_NB_LINE", nb_line_tHashOutput_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row21",2,0,
			 			"tUniqRow_1","tUniqRow_1","tUniqRow","tHashOutput_2","tHashOutput_2","tHashOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tHashOutput_2", true);
end_Hash.put("tHashOutput_2", System.currentTimeMillis());




/**
 * [tHashOutput_2 end ] stop
 */









				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tHashInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_3"
					     			globalMap.remove("tHash_Lookup_row11"); 
				     			
				try{
					
	
	/**
	 * [tHashInput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";
	
	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tHashOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";
	
	

 



/**
 * [tHashOutput_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfrejectStruct implements routines.system.IPersistableRow<copyOfrejectStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingnouveau;

				public String getBillingnouveau () {
					return this.billingnouveau;
				}

				public Boolean billingnouveauIsNullable(){
				    return true;
				}
				public Boolean billingnouveauIsKey(){
				    return false;
				}
				public Integer billingnouveauLength(){
				    return null;
				}
				public Integer billingnouveauPrecision(){
				    return null;
				}
				public String billingnouveauDefault(){
				
					return null;
				
				}
				public String billingnouveauComment(){
				
				    return "";
				
				}
				public String billingnouveauPattern(){
				
					return "";
				
				}
				public String billingnouveauOriginalDbColumnName(){
				
					return "billingnouveau";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final copyOfrejectStruct other = (copyOfrejectStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(copyOfrejectStruct other) {

		other.roundId = this.roundId;
	            other.billingnouveau = this.billingnouveau;
	            
	}

	public void copyKeysDataTo(copyOfrejectStruct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingnouveau="+billingnouveau);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingnouveau == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingnouveau);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfrejectStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfout1Struct implements routines.system.IPersistableRow<copyOfout1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingnouveau;

				public String getBillingnouveau () {
					return this.billingnouveau;
				}

				public Boolean billingnouveauIsNullable(){
				    return true;
				}
				public Boolean billingnouveauIsKey(){
				    return false;
				}
				public Integer billingnouveauLength(){
				    return null;
				}
				public Integer billingnouveauPrecision(){
				    return null;
				}
				public String billingnouveauDefault(){
				
					return null;
				
				}
				public String billingnouveauComment(){
				
				    return "";
				
				}
				public String billingnouveauPattern(){
				
					return "";
				
				}
				public String billingnouveauOriginalDbColumnName(){
				
					return "billingnouveau";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingnouveau="+billingnouveau);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingnouveau == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingnouveau);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfout1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row22Struct implements routines.system.IPersistableRow<row22Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row22Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tHashInput_2Struct implements routines.system.IPersistableRow<after_tHashInput_2Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final after_tHashInput_2Struct other = (after_tHashInput_2Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(after_tHashInput_2Struct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(after_tHashInput_2Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tHashInput_2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_2");
		org.slf4j.MDC.put("_subJobPid", "49qUBm_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tHashInput_3Process(globalMap);

		row22Struct row22 = new row22Struct();
copyOfout1Struct copyOfout1 = new copyOfout1Struct();
copyOfrejectStruct copyOfreject = new copyOfrejectStruct();






	
	/**
	 * [tHashOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_3", false);
		start_Hash.put("tHashOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfreject");
			
		int tos_count_tHashOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashOutput_3", "tHashOutput_3", "tHashOutput");
				talendJobLogProcess(globalMap);
			}
			



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_3=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<copyOfrejectStruct> tHashFile_tHashOutput_3 = null;
		String hashKey_tHashOutput_3 = "tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid + "_tHashOutput_3";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_3)){
			    if(mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3) == null){
	      		    mf_tHashOutput_3.getResourceMap().put(hashKey_tHashOutput_3, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<copyOfrejectStruct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_3 = mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3);
			    }else{
			    	tHashFile_tHashOutput_3 = mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3);
			    }
			}
        int nb_line_tHashOutput_3 = 0;

 



/**
 * [tHashOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_5", false);
		start_Hash.put("tMap_5", System.currentTimeMillis());
		
	
	currentComponent="tMap_5";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfout1");
			
		int tos_count_tMap_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_5 = new StringBuilder();
                    log4jParamters_tMap_5.append("Parameters:");
                            log4jParamters_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_5.append(" | ");
                            log4jParamters_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + (log4jParamters_tMap_5) );
                    } 
                } 
            new BytesLimit65535_tMap_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_5", "tMap_5", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_copyOfout1_tMap_5 = 0;
		
		int count_copyOfanciens_valeurs_uniques_tMap_5 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<copyOfanciens_valeurs_uniquesStruct> tHash_Lookup_copyOfanciens_valeurs_uniques = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<copyOfanciens_valeurs_uniquesStruct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<copyOfanciens_valeurs_uniquesStruct>) 
					globalMap.get( "tHash_Lookup_copyOfanciens_valeurs_uniques" ))
					;					
					
	

copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniquesHashKey = new copyOfanciens_valeurs_uniquesStruct();
copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniquesDefault = new copyOfanciens_valeurs_uniquesStruct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_5__Struct  {
}
Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfreject_tMap_5 = 0;
				
copyOfrejectStruct copyOfreject_tmp = new copyOfrejectStruct();
// ###############################

        
        



        









 



/**
 * [tMap_5 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row22");
			
		int tos_count_tMap_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_4 = new StringBuilder();
                    log4jParamters_tMap_4.append("Parameters:");
                            log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_4.append(" | ");
                            log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + (log4jParamters_tMap_4) );
                    } 
                } 
            new BytesLimit65535_tMap_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_4", "tMap_4", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row22_tMap_4 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfout1_tMap_4 = 0;
				
copyOfout1Struct copyOfout1_tmp = new copyOfout1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tHashInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_2", false);
		start_Hash.put("tHashInput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_2";
	
	
		int tos_count_tHashInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_2", "tHashInput_2", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_2 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row21Struct> tHashFile_tHashInput_2 = mf_tHashInput_2.getAdvancedMemoryHashFile("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_2");
if(tHashFile_tHashInput_2==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row21Struct> iterator_tHashInput_2 = tHashFile_tHashInput_2.iterator();
while (iterator_tHashInput_2.hasNext()) {
    row21Struct next_tHashInput_2 = iterator_tHashInput_2.next();

	row22.roundId = next_tHashInput_2.roundId;
	row22.billingRoundName = next_tHashInput_2.billingRoundName;

 



/**
 * [tHashInput_2 begin ] stop
 */
	
	/**
	 * [tHashInput_2 main ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 


	tos_count_tHashInput_2++;

/**
 * [tHashInput_2 main ] stop
 */
	
	/**
	 * [tHashInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row22","tHashInput_2","tHashInput_2","tHashInput","tMap_4","tMap_4","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row22 - " + (row22==null? "": row22.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_4 = false;
		boolean mainRowRejected_tMap_4 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
        // ###############################
        // # Output tables

copyOfout1 = null;


// # Output table : 'copyOfout1'
count_copyOfout1_tMap_4++;

copyOfout1_tmp.roundId = row22.roundId ;
copyOfout1_tmp.billingnouveau = row22.billingRoundName ;
copyOfout1 = copyOfout1_tmp;
log.debug("tMap_4 - Outputting the record " + count_copyOfout1_tMap_4 + " of the output table 'copyOfout1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
	
	/**
	 * [tMap_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 process_data_begin ] stop
 */
// Start of branch "copyOfout1"
if(copyOfout1 != null) { 



	
	/**
	 * [tMap_5 main ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"copyOfout1","tMap_4","tMap_4","tMap","tMap_5","tMap_5","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("copyOfout1 - " + (copyOfout1==null? "": copyOfout1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;
		
						copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniques = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_5 = false;
		boolean mainRowRejected_tMap_5 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "copyOfanciens_valeurs_uniques" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLoopcopyOfanciens_valeurs_uniques = false;
       		  	    	
       		  	    	
 							copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniquesObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_5) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_5 = false;
								
                        		    		    copyOfanciens_valeurs_uniquesHashKey.roundId = copyOfout1.roundId ;
                        		    		
                        		    		    copyOfanciens_valeurs_uniquesHashKey.billingRoundName = copyOfout1.billingnouveau ;
                        		    		

								
		                        	copyOfanciens_valeurs_uniquesHashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_copyOfanciens_valeurs_uniques.lookup( copyOfanciens_valeurs_uniquesHashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_copyOfanciens_valeurs_uniques.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_5 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_copyOfanciens_valeurs_uniques != null && tHash_Lookup_copyOfanciens_valeurs_uniques.getCount(copyOfanciens_valeurs_uniquesHashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'copyOfanciens_valeurs_uniques' and it contains more one result from keys :  copyOfanciens_valeurs_uniques.roundId = '" + copyOfanciens_valeurs_uniquesHashKey.roundId + "', copyOfanciens_valeurs_uniques.billingRoundName = '" + copyOfanciens_valeurs_uniquesHashKey.billingRoundName + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	copyOfanciens_valeurs_uniquesStruct fromLookup_copyOfanciens_valeurs_uniques = null;
							copyOfanciens_valeurs_uniques = copyOfanciens_valeurs_uniquesDefault;
										 
							
								 
							
							
								if (tHash_Lookup_copyOfanciens_valeurs_uniques !=null && tHash_Lookup_copyOfanciens_valeurs_uniques.hasNext()) { // G 099
								
							
								
								fromLookup_copyOfanciens_valeurs_uniques = tHash_Lookup_copyOfanciens_valeurs_uniques.next();

							
							
								} // G 099
							
							

							if(fromLookup_copyOfanciens_valeurs_uniques != null) {
								copyOfanciens_valeurs_uniques = fromLookup_copyOfanciens_valeurs_uniques;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
        // ###############################
        // # Output tables

copyOfreject = null;

if(!rejectedInnerJoin_tMap_5 ) {
} // closing inner join bracket (1)
// ###### START REJECTS ##### 

// # Output reject table : 'copyOfreject'
// # Filter conditions 
if( rejectedInnerJoin_tMap_5 ) {
count_copyOfreject_tMap_5++;

copyOfreject_tmp.roundId = copyOfout1.roundId ;
copyOfreject_tmp.billingnouveau = copyOfout1.billingnouveau ;
copyOfreject = copyOfreject_tmp;
log.debug("tMap_5 - Outputting the record " + count_copyOfreject_tMap_5 + " of the output table 'copyOfreject'.");

} // closing filter/reject
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_5 = false;










 


	tos_count_tMap_5++;

/**
 * [tMap_5 main ] stop
 */
	
	/**
	 * [tMap_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 process_data_begin ] stop
 */
// Start of branch "copyOfreject"
if(copyOfreject != null) { 



	
	/**
	 * [tHashOutput_3 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"copyOfreject","tMap_5","tMap_5","tMap","tHashOutput_3","tHashOutput_3","tHashOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("copyOfreject - " + (copyOfreject==null? "": copyOfreject.toLogString()));
    			}
    		



    
		copyOfrejectStruct oneRow_tHashOutput_3 = new copyOfrejectStruct();
				
					oneRow_tHashOutput_3.roundId = copyOfreject.roundId;
					oneRow_tHashOutput_3.billingnouveau = copyOfreject.billingnouveau;
		
        tHashFile_tHashOutput_3.put(oneRow_tHashOutput_3);
        nb_line_tHashOutput_3 ++;

 


	tos_count_tHashOutput_3++;

/**
 * [tHashOutput_3 main ] stop
 */
	
	/**
	 * [tHashOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";
	
	

 



/**
 * [tHashOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tHashOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";
	
	

 



/**
 * [tHashOutput_3 process_data_end ] stop
 */

} // End of branch "copyOfreject"




	
	/**
	 * [tMap_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 process_data_end ] stop
 */

} // End of branch "copyOfout1"




	
	/**
	 * [tMap_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_2 end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	
    

		
			nb_line_tHashInput_2++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_2");
	


	globalMap.put("tHashInput_2_NB_LINE", nb_line_tHashInput_2);       

 

ok_Hash.put("tHashInput_2", true);
end_Hash.put("tHashInput_2", System.currentTimeMillis());




/**
 * [tHashInput_2 end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'copyOfout1': " + count_copyOfout1_tMap_4 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row22",2,0,
			 			"tHashInput_2","tHashInput_2","tHashInput","tMap_4","tMap_4","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Done.") );

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tMap_5 end ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_copyOfanciens_valeurs_uniques != null) {
						tHash_Lookup_copyOfanciens_valeurs_uniques.endGet();
					}
					globalMap.remove( "tHash_Lookup_copyOfanciens_valeurs_uniques" );

					
					
				
// ###############################      
				log.debug("tMap_5 - Written records count in the table 'copyOfreject': " + count_copyOfreject_tMap_5 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfout1",2,0,
			 			"tMap_4","tMap_4","tMap","tMap_5","tMap_5","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Done.") );

ok_Hash.put("tMap_5", true);
end_Hash.put("tMap_5", System.currentTimeMillis());




/**
 * [tMap_5 end ] stop
 */

	
	/**
	 * [tHashOutput_3 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";
	
	
globalMap.put("tHashOutput_3_NB_LINE", nb_line_tHashOutput_3);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfreject",2,0,
			 			"tMap_5","tMap_5","tMap","tHashOutput_3","tHashOutput_3","tHashOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tHashOutput_3", true);
end_Hash.put("tHashOutput_3", System.currentTimeMillis());




/**
 * [tHashOutput_3 end ] stop
 */









				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tHashInput_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_5"
					     			globalMap.remove("tHash_Lookup_copyOfanciens_valeurs_uniques"); 
				     			
				try{
					
	
	/**
	 * [tHashInput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";
	
	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tMap_5 finally ] start
	 */

	

	
	
	currentComponent="tMap_5";
	
	

 



/**
 * [tMap_5 finally ] stop
 */

	
	/**
	 * [tHashOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";
	
	

 



/**
 * [tHashOutput_3 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class round_billing_name_updatedStruct implements routines.system.IPersistableRow<round_billing_name_updatedStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final round_billing_name_updatedStruct other = (round_billing_name_updatedStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(round_billing_name_updatedStruct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(round_billing_name_updatedStruct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(round_billing_name_updatedStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingnouveau;

				public String getBillingnouveau () {
					return this.billingnouveau;
				}

				public Boolean billingnouveauIsNullable(){
				    return true;
				}
				public Boolean billingnouveauIsKey(){
				    return false;
				}
				public Integer billingnouveauLength(){
				    return null;
				}
				public Integer billingnouveauPrecision(){
				    return null;
				}
				public String billingnouveauDefault(){
				
					return null;
				
				}
				public String billingnouveauComment(){
				
				    return "";
				
				}
				public String billingnouveauPattern(){
				
					return "";
				
				}
				public String billingnouveauOriginalDbColumnName(){
				
					return "billingnouveau";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingnouveau = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingnouveau,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingnouveau="+billingnouveau);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingnouveau == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingnouveau);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_4");
		org.slf4j.MDC.put("_subJobPid", "9g2HJf_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();
round_billing_name_updatedStruct round_billing_name_updated = new round_billing_name_updatedStruct();





	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"round_billing_name_updated");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"urbantz_round\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "\"urbantz_round\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_3 = 1;
         if (updateKeyCount_tDBOutput_3 == 2 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

String tableName_tDBOutput_3 = "urbantz_round";
boolean whetherReject_tDBOutput_3 = false;

java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
calendar_tDBOutput_3.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
calendar_tDBOutput_3.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
long date_tDBOutput_3;

java.sql.Connection conn_tDBOutput_3 = null;
		conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );

		int count_tDBOutput_3=0;
		
				
			
				String insertIgnore_tDBOutput_3 = "INSERT IGNORE INTO `" + "urbantz_round" + "` (`roundId`,`billingRoundName`) VALUES (?,?) ON DUPLICATE KEY UPDATE `billingRoundName` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insertIgnore_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
				


 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_8", false);
		start_Hash.put("tMap_8", System.currentTimeMillis());
		
	
	currentComponent="tMap_8";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row14");
			
		int tos_count_tMap_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_8 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_8{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_8 = new StringBuilder();
                    log4jParamters_tMap_8.append("Parameters:");
                            log4jParamters_tMap_8.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_8.append(" | ");
                            log4jParamters_tMap_8.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_8.append(" | ");
                            log4jParamters_tMap_8.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_8.append(" | ");
                            log4jParamters_tMap_8.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_8 - "  + (log4jParamters_tMap_8) );
                    } 
                } 
            new BytesLimit65535_tMap_8().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_8", "tMap_8", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row14_tMap_8 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_8__Struct  {
}
Var__tMap_8__Struct Var__tMap_8 = new Var__tMap_8__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_round_billing_name_updated_tMap_8 = 0;
				
round_billing_name_updatedStruct round_billing_name_updated_tmp = new round_billing_name_updatedStruct();
// ###############################

        
        



        









 



/**
 * [tMap_8 begin ] stop
 */



	
	/**
	 * [tHashInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_4", false);
		start_Hash.put("tHashInput_4", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_4";
	
	
		int tos_count_tHashInput_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_4", "tHashInput_4", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_4 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_4=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<copyOfrejectStruct> tHashFile_tHashInput_4 = mf_tHashInput_4.getAdvancedMemoryHashFile("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_3");
if(tHashFile_tHashInput_4==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<copyOfrejectStruct> iterator_tHashInput_4 = tHashFile_tHashInput_4.iterator();
while (iterator_tHashInput_4.hasNext()) {
    copyOfrejectStruct next_tHashInput_4 = iterator_tHashInput_4.next();

	row14.roundId = next_tHashInput_4.roundId;
	row14.billingnouveau = next_tHashInput_4.billingnouveau;

 



/**
 * [tHashInput_4 begin ] stop
 */
	
	/**
	 * [tHashInput_4 main ] start
	 */

	

	
	
	currentComponent="tHashInput_4";
	
	

 


	tos_count_tHashInput_4++;

/**
 * [tHashInput_4 main ] stop
 */
	
	/**
	 * [tHashInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_4";
	
	

 



/**
 * [tHashInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tMap_8 main ] start
	 */

	

	
	
	currentComponent="tMap_8";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row14","tHashInput_4","tHashInput_4","tHashInput","tMap_8","tMap_8","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_8 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_8 = false;
		boolean mainRowRejected_tMap_8 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_8__Struct Var = Var__tMap_8;// ###############################
        // ###############################
        // # Output tables

round_billing_name_updated = null;


// # Output table : 'round_billing_name_updated'
count_round_billing_name_updated_tMap_8++;

round_billing_name_updated_tmp.roundId = row14.roundId ;
round_billing_name_updated_tmp.billingRoundName = row14.billingnouveau ;
round_billing_name_updated = round_billing_name_updated_tmp;
log.debug("tMap_8 - Outputting the record " + count_round_billing_name_updated_tMap_8 + " of the output table 'round_billing_name_updated'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_8 = false;










 


	tos_count_tMap_8++;

/**
 * [tMap_8 main ] stop
 */
	
	/**
	 * [tMap_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_8";
	
	

 



/**
 * [tMap_8 process_data_begin ] stop
 */
// Start of branch "round_billing_name_updated"
if(round_billing_name_updated != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"round_billing_name_updated","tMap_8","tMap_8","tMap","tDBOutput_3","\"urbantz_round\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("round_billing_name_updated - " + (round_billing_name_updated==null? "": round_billing_name_updated.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    if(round_billing_name_updated.roundId == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, round_billing_name_updated.roundId);
}

                    if(round_billing_name_updated.billingRoundName == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, round_billing_name_updated.billingRoundName);
}

                    if(round_billing_name_updated.billingRoundName == null) {
pstmt_tDBOutput_3.setNull(3 + count_tDBOutput_3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3 + count_tDBOutput_3, round_billing_name_updated.billingRoundName);
}

            int count_on_duplicate_key_tDBOutput_3 = 0;
            try {
                int processedCount_tDBOutput_3 = pstmt_tDBOutput_3.executeUpdate();
                count_on_duplicate_key_tDBOutput_3 += processedCount_tDBOutput_3;
                rowsToCommitCount_tDBOutput_3 += processedCount_tDBOutput_3;
                nb_line_tDBOutput_3++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_3 = true;
            log.error("tDBOutput_3 - "  + (e.getMessage()) );
                        System.err.print(e.getMessage());
            }
            if(count_on_duplicate_key_tDBOutput_3 == 1) {
                insertedCount_tDBOutput_3 += count_on_duplicate_key_tDBOutput_3;
            } else {
                insertedCount_tDBOutput_3 += 1;
                updatedCount_tDBOutput_3 += count_on_duplicate_key_tDBOutput_3 - 1;
            }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "round_billing_name_updated"




	
	/**
	 * [tMap_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_8";
	
	

 



/**
 * [tMap_8 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_4";
	
	

 



/**
 * [tHashInput_4 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_4 end ] start
	 */

	

	
	
	currentComponent="tHashInput_4";
	
	
    

		
			nb_line_tHashInput_4++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_3");
	


	globalMap.put("tHashInput_4_NB_LINE", nb_line_tHashInput_4);       

 

ok_Hash.put("tHashInput_4", true);
end_Hash.put("tHashInput_4", System.currentTimeMillis());




/**
 * [tHashInput_4 end ] stop
 */

	
	/**
	 * [tMap_8 end ] start
	 */

	

	
	
	currentComponent="tMap_8";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_8 - Written records count in the table 'round_billing_name_updated': " + count_round_billing_name_updated_tMap_8 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row14",2,0,
			 			"tHashInput_4","tHashInput_4","tHashInput","tMap_8","tMap_8","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_8 - "  + ("Done.") );

ok_Hash.put("tMap_8", true);
end_Hash.put("tMap_8", System.currentTimeMillis());




/**
 * [tMap_8 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		



		

		if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_3", true);
	

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"round_billing_name_updated",2,0,
			 			"tMap_8","tMap_8","tMap","tDBOutput_3","\"urbantz_round\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tDBCommit_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_4 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_4";
	
	

 



/**
 * [tHashInput_4 finally ] stop
 */

	
	/**
	 * [tMap_8 finally ] start
	 */

	

	
	
	currentComponent="tMap_8";
	
	

 



/**
 * [tMap_8 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_4_SUBPROCESS_STATE", 1);
	}
	


public void tDBCommit_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBCommit_1");
		org.slf4j.MDC.put("_subJobPid", "OsdGIh_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBCommit_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBCommit_1", false);
		start_Hash.put("tDBCommit_1", System.currentTimeMillis());
		
	
	currentComponent="tDBCommit_1";
	
	
		int tos_count_tDBCommit_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBCommit_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBCommit_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBCommit_1 = new StringBuilder();
                    log4jParamters_tDBCommit_1.append("Parameters:");
                            log4jParamters_tDBCommit_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBCommit_1.append(" | ");
                            log4jParamters_tDBCommit_1.append("CLOSE" + " = " + "true");
                        log4jParamters_tDBCommit_1.append(" | ");
                            log4jParamters_tDBCommit_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlCommit");
                        log4jParamters_tDBCommit_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBCommit_1 - "  + (log4jParamters_tDBCommit_1) );
                    } 
                } 
            new BytesLimit65535_tDBCommit_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBCommit_1", "tDBCommit_1", "tMysqlCommit");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBCommit_1 begin ] stop
 */
	
	/**
	 * [tDBCommit_1 main ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";
	
	

	java.sql.Connection conn_tDBCommit_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

if(conn_tDBCommit_1 != null && !conn_tDBCommit_1.isClosed()) {
	
		try{
	
			
	    		log.debug("tDBCommit_1 - Connection 'tDBConnection_1' starting to commit.");
			
			conn_tDBCommit_1.commit();
			
	    		log.debug("tDBCommit_1 - Connection 'tDBConnection_1' commit has succeeded.");
			
	
		}finally{
			
	    		log.debug("tDBCommit_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBCommit_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBCommit_1 - Connection 'tDBConnection_1' to the database closed.");
			
	    }
	
}

 


	tos_count_tDBCommit_1++;

/**
 * [tDBCommit_1 main ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";
	
	

 



/**
 * [tDBCommit_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";
	
	

 



/**
 * [tDBCommit_1 process_data_end ] stop
 */
	
	/**
	 * [tDBCommit_1 end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBCommit_1 - "  + ("Done.") );

ok_Hash.put("tDBCommit_1", true);
end_Hash.put("tDBCommit_1", System.currentTimeMillis());




/**
 * [tDBCommit_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBCommit_1 finally ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";
	
	

 



/**
 * [tDBCommit_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableComparableLookupRow<row7Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return true;
				}
				public Integer sourceIdLength(){
				    return 150;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public String sourceDate;

				public String getSourceDate () {
					return this.sourceDate;
				}

				public Boolean sourceDateIsNullable(){
				    return true;
				}
				public Boolean sourceDateIsKey(){
				    return false;
				}
				public Integer sourceDateLength(){
				    return 150;
				}
				public Integer sourceDatePrecision(){
				    return 0;
				}
				public String sourceDateDefault(){
				
					return null;
				
				}
				public String sourceDateComment(){
				
				    return "";
				
				}
				public String sourceDatePattern(){
				
					return "";
				
				}
				public String sourceDateOriginalDbColumnName(){
				
					return "sourceDate";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 150;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 150;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 150;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.sourceId == null) ? 0 : this.sourceId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.sourceId == null) {
							if (other.sourceId != null)
								return false;
						
						} else if (!this.sourceId.equals(other.sourceId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.sourceId = this.sourceId;
	            other.sourceDate = this.sourceDate;
	            other.taskId = this.taskId;
	            other.sourceType = this.sourceType;
	            other.sourceClient = this.sourceClient;
	            other.sourceRound = this.sourceRound;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.sourceId = this.sourceId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.sourceDate = readString(dis,ois);
					
						this.taskId = readString(dis,ois);
					
						this.sourceType = readString(dis,ois);
					
						this.sourceClient = readString(dis,ois);
					
						this.sourceRound = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.sourceDate = readString(dis,objectIn);
					
						this.taskId = readString(dis,objectIn);
					
						this.sourceType = readString(dis,objectIn);
					
						this.sourceClient = readString(dis,objectIn);
					
						this.sourceRound = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.sourceDate, dos, oos);
					
						writeString(this.taskId, dos, oos);
					
						writeString(this.sourceType, dos, oos);
					
						writeString(this.sourceClient, dos, oos);
					
						writeString(this.sourceRound, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.sourceDate, dos, objectOut);
					
						writeString(this.taskId, dos, objectOut);
					
						writeString(this.sourceType, dos, objectOut);
					
						writeString(this.sourceClient, dos, objectOut);
					
						writeString(this.sourceRound, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",sourceDate="+sourceDate);
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",sourceRound="+sourceRound);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceDate);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.sourceId, other.sourceId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return false;
				}
				public Integer sourceIdLength(){
				    return 150;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public String sourceDate;

				public String getSourceDate () {
					return this.sourceDate;
				}

				public Boolean sourceDateIsNullable(){
				    return true;
				}
				public Boolean sourceDateIsKey(){
				    return false;
				}
				public Integer sourceDateLength(){
				    return 150;
				}
				public Integer sourceDatePrecision(){
				    return 0;
				}
				public String sourceDateDefault(){
				
					return null;
				
				}
				public String sourceDateComment(){
				
				    return "";
				
				}
				public String sourceDatePattern(){
				
					return "";
				
				}
				public String sourceDateOriginalDbColumnName(){
				
					return "sourceDate";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 150;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 150;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 150;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",sourceDate="+sourceDate);
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",sourceRound="+sourceRound);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceDate);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return false;
				}
				public Integer sourceIdLength(){
				    return 150;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public String sourceDate;

				public String getSourceDate () {
					return this.sourceDate;
				}

				public Boolean sourceDateIsNullable(){
				    return true;
				}
				public Boolean sourceDateIsKey(){
				    return false;
				}
				public Integer sourceDateLength(){
				    return 150;
				}
				public Integer sourceDatePrecision(){
				    return 0;
				}
				public String sourceDateDefault(){
				
					return null;
				
				}
				public String sourceDateComment(){
				
				    return "";
				
				}
				public String sourceDatePattern(){
				
					return "";
				
				}
				public String sourceDateOriginalDbColumnName(){
				
					return "sourceDate";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 150;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 150;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 150;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.sourceRound = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",sourceDate="+sourceDate);
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",sourceRound="+sourceRound);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceDate);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "5lCCVR_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();
row3Struct row3 = new row3Struct();
row3Struct row7 = row3;






	
	/**
	 * [tAdvancedHash_row7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row7", false);
		start_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row7";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tAdvancedHash_row7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row7", "tAdvancedHash_row7", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row7
			   		// source node:tLogRow_1 - inputs:(row3) outputs:(row7,row7) | target node:tAdvancedHash_row7 - inputs:(row7) outputs:()
			   		// linked node: tMap_1 - inputs:(row1,row7) outputs:(update_task,update_item)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row7 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row7Struct>getLookup(matchingModeEnum_row7);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row7", tHash_Lookup_row7);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row7 begin ] stop
 */



	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tLogRow_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_1", "tLogRow_1", "tDummyRow");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_2 = new StringBuilder();
                    log4jParamters_tMap_2.append("Parameters:");
                            log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
                    } 
                } 
            new BytesLimit65535_tMap_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row6_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
	String var1;
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row3_tMap_2 = 0;
				
row3Struct row3_tmp = new row3Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"urbantz_task\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `urbantz_task`.`sourceId`,    `urbantz_task`.`sourceDate`,    `urbantz_task`.`taskId`,    `urbantz_task`.`sourceType`,    `urbantz_task`.`sourceClient`,    `urbantz_task`.`sourceRound` FROM `urbantz_task`\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"urbantz_task\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  `urbantz_task`.`sourceId`, \n  `urbantz_task`.`sourceDate`, \n  `urbantz_task`.`taskId`, \n  `urbantz_task`.`sou"
+"rceType`, \n  `urbantz_task`.`sourceClient`, \n  `urbantz_task`.`sourceRound`\nFROM `urbantz_task`";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

		    globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);

		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row6.sourceId = null;
							} else {
	                         		
        	row6.sourceId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, true);
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row6.sourceDate = null;
							} else {
	                         		
        	row6.sourceDate = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, true);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row6.taskId = null;
							} else {
	                         		
        	row6.taskId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, true);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row6.sourceType = null;
							} else {
	                         		
        	row6.sourceType = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, true);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row6.sourceClient = null;
							} else {
	                         		
        	row6.sourceClient = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, true);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row6.sourceRound = null;
							} else {
	                         		
        	row6.sourceRound = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, true);
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_1","\"urbantz_task\"","tMysqlInput","tMap_2","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_2 = false;
		boolean mainRowRejected_tMap_2 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.var1 = row6.sourceDate != null ? 
 ( row6.sourceDate.contains("-") ? 
TalendDate.formatDate("dd/MM/yyyy",TalendDate.parseDate("yyyy-MM-dd",row6.sourceDate))  :
 TalendDate.formatDate("dd/MM/yyyy",TalendDate.parseDate("dd/MM/yyyy",row6.sourceDate)) ) : null ;// ###############################
        // ###############################
        // # Output tables

row3 = null;


// # Output table : 'row3'
count_row3_tMap_2++;

row3_tmp.sourceId = row6.sourceId;
row3_tmp.sourceDate = Var.var1 ;
row3_tmp.taskId = row6.taskId != null ? row6.taskId.toUpperCase() : null ;
row3_tmp.sourceType = row6.sourceType != null ? row6.sourceType.toUpperCase() : null ;
row3_tmp.sourceClient = row6.sourceClient != null ? row6.sourceClient.toUpperCase() : null ;
row3_tmp.sourceRound = row6.sourceRound;
row3 = row3_tmp;
log.debug("tMap_2 - Outputting the record " + count_row3_tMap_2 + " of the output table 'row3'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tMap_2","tMap_2","tMap","tLogRow_1","tLogRow_1","tDummyRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

 
     row7 = row3;


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tLogRow_1","tLogRow_1","tDummyRow","tAdvancedHash_row7","tAdvancedHash_row7","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		


			   
			   

					row7Struct row7_HashRow = new row7Struct();
		   	   	   
				
				row7_HashRow.sourceId = row7.sourceId;
				
				row7_HashRow.sourceDate = row7.sourceDate;
				
				row7_HashRow.taskId = row7.taskId;
				
				row7_HashRow.sourceType = row7.sourceType;
				
				row7_HashRow.sourceClient = row7.sourceClient;
				
				row7_HashRow.sourceRound = row7.sourceRound;
				
			tHash_Lookup_row7.put(row7_HashRow);
			
            




 


	tos_count_tAdvancedHash_row7++;

/**
 * [tAdvancedHash_row7 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";
	
	

 



/**
 * [tAdvancedHash_row7 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";
	
	

 



/**
 * [tAdvancedHash_row7 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'row3': " + count_row3_tMap_2 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_1","\"urbantz_task\"","tMysqlInput","tMap_2","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tMap_2","tMap_2","tMap","tLogRow_1","tLogRow_1","tDummyRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";
	
	

tHash_Lookup_row7.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tLogRow_1","tLogRow_1","tDummyRow","tAdvancedHash_row7","tAdvancedHash_row7","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row7", true);
end_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());




/**
 * [tAdvancedHash_row7 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";
	
	

 



/**
 * [tAdvancedHash_row7 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableComparableLookupRow<row11Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return false;
				}
				public Boolean roundIdIsKey(){
				    return false;
				}
				public Integer roundIdLength(){
				    return 150;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String roundName;

				public String getRoundName () {
					return this.roundName;
				}

				public Boolean roundNameIsNullable(){
				    return true;
				}
				public Boolean roundNameIsKey(){
				    return false;
				}
				public Integer roundNameLength(){
				    return 150;
				}
				public Integer roundNamePrecision(){
				    return 0;
				}
				public String roundNameDefault(){
				
					return null;
				
				}
				public String roundNameComment(){
				
				    return "";
				
				}
				public String roundNamePattern(){
				
					return "";
				
				}
				public String roundNameOriginalDbColumnName(){
				
					return "roundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row11Struct other = (row11Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row11Struct other) {

		other.roundId = this.roundId;
	            other.roundName = this.roundName;
	            
	}

	public void copyKeysDataTo(row11Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.roundName = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.roundName = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.roundName, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.roundName, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",roundName="+roundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(roundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", "xGHZND_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tAdvancedHash_row11 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row11", false);
		start_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row11";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row11");
			
		int tos_count_tAdvancedHash_row11 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row11", "tAdvancedHash_row11", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row11
			   		// source node:tDBInput_2 - inputs:(after_tHashInput_1) outputs:(row11,row11) | target node:tAdvancedHash_row11 - inputs:(row11) outputs:()
			   		// linked node: tMap_3 - inputs:(row4,row11) outputs:(round_updated)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row11 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row11Struct>getLookup(matchingModeEnum_row11);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row11", tHash_Lookup_row11);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row11 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"urbantz_round\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT    `urbantz_round`.`roundId`,    `urbantz_round`.`roundName` FROM `urbantz_round`\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("ENABLE_STREAM" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("roundId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("roundName")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"urbantz_round\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
		    calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT \n  `urbantz_round`.`roundId`, \n  `urbantz_round`.`roundName`\nFROM `urbantz_round`";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

		    globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);

		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row11.roundId = null;
							} else {
	                         		
        	row11.roundId = routines.system.JDBCUtil.getString(rs_tDBInput_2, 1, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row11.roundName = null;
							} else {
	                         		
        	row11.roundName = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					

 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row11","tDBInput_2","\"urbantz_round\"","tMysqlInput","tAdvancedHash_row11","tAdvancedHash_row11","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		


			   
			   

					row11Struct row11_HashRow = new row11Struct();
		   	   	   
				
				row11_HashRow.roundId = row11.roundId;
				
				row11_HashRow.roundName = row11.roundName;
				
			tHash_Lookup_row11.put(row11_HashRow);
			
            




 


	tos_count_tAdvancedHash_row11++;

/**
 * [tAdvancedHash_row11 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";
	
	

 



/**
 * [tAdvancedHash_row11 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";
	
	

 



/**
 * [tAdvancedHash_row11 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";
	
	

tHash_Lookup_row11.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row11",2,0,
			 			"tDBInput_2","\"urbantz_round\"","tMysqlInput","tAdvancedHash_row11","tAdvancedHash_row11","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row11", true);
end_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());




/**
 * [tAdvancedHash_row11 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";
	
	

 



/**
 * [tAdvancedHash_row11 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfanciens_valeurs_uniquesStruct implements routines.system.IPersistableComparableLookupRow<copyOfanciens_valeurs_uniquesStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
						result = prime * result + ((this.billingRoundName == null) ? 0 : this.billingRoundName.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final copyOfanciens_valeurs_uniquesStruct other = (copyOfanciens_valeurs_uniquesStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					
						if (this.billingRoundName == null) {
							if (other.billingRoundName != null)
								return false;
						
						} else if (!this.billingRoundName.equals(other.billingRoundName))
						
							return false;
					

		return true;
    }

	public void copyDataTo(copyOfanciens_valeurs_uniquesStruct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(copyOfanciens_valeurs_uniquesStruct other) {

		other.roundId = this.roundId;
	            	other.billingRoundName = this.billingRoundName;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		

		

        }

		
        	finally {}

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		

		

        }

		
        	finally {}

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
        	}
        	finally {}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
        	}
        	finally {}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfanciens_valeurs_uniquesStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.billingRoundName, other.billingRoundName);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row26Struct implements routines.system.IPersistableRow<row26Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row26Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row25Struct implements routines.system.IPersistableRow<row25Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row25Struct other = (row25Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row25Struct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(row25Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row25Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfancien_billingStruct implements routines.system.IPersistableRow<copyOfancien_billingStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final copyOfancien_billingStruct other = (copyOfancien_billingStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(copyOfancien_billingStruct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(copyOfancien_billingStruct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfancien_billingStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tHashInput_3Struct implements routines.system.IPersistableRow<after_tHashInput_3Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return null;
				}
				public Integer roundIdPrecision(){
				    return null;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final after_tHashInput_3Struct other = (after_tHashInput_3Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(after_tHashInput_3Struct other) {

		other.roundId = this.roundId;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(after_tHashInput_3Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tHashInput_3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_3");
		org.slf4j.MDC.put("_subJobPid", "il81LA_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_3Process(globalMap);

		row13Struct row13 = new row13Struct();
copyOfancien_billingStruct copyOfancien_billing = new copyOfancien_billingStruct();
copyOfancien_billingStruct row25 = copyOfancien_billing;
row26Struct row26 = new row26Struct();
copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniques = new copyOfanciens_valeurs_uniquesStruct();








	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_copyOfanciens_valeurs_uniques", false);
		start_Hash.put("tAdvancedHash_copyOfanciens_valeurs_uniques", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfanciens_valeurs_uniques");
			
		int tos_count_tAdvancedHash_copyOfanciens_valeurs_uniques = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_copyOfanciens_valeurs_uniques", "tAdvancedHash_copyOfanciens_valeurs_uniques", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:copyOfanciens_valeurs_uniques
			   		// source node:tMap_7 - inputs:(row26) outputs:(copyOfanciens_valeurs_uniques,copyOfanciens_valeurs_uniques) | target node:tAdvancedHash_copyOfanciens_valeurs_uniques - inputs:(copyOfanciens_valeurs_uniques) outputs:()
			   		// linked node: tMap_5 - inputs:(copyOfout1,copyOfanciens_valeurs_uniques) outputs:(copyOfreject)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_copyOfanciens_valeurs_uniques = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<copyOfanciens_valeurs_uniquesStruct> tHash_Lookup_copyOfanciens_valeurs_uniques =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<copyOfanciens_valeurs_uniquesStruct>getLookup(matchingModeEnum_copyOfanciens_valeurs_uniques);
	   						   
		   	   	   globalMap.put("tHash_Lookup_copyOfanciens_valeurs_uniques", tHash_Lookup_copyOfanciens_valeurs_uniques);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques begin ] stop
 */



	
	/**
	 * [tMap_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_7", false);
		start_Hash.put("tMap_7", System.currentTimeMillis());
		
	
	currentComponent="tMap_7";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row26");
			
		int tos_count_tMap_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_7 = new StringBuilder();
                    log4jParamters_tMap_7.append("Parameters:");
                            log4jParamters_tMap_7.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_7.append(" | ");
                            log4jParamters_tMap_7.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_7.append(" | ");
                            log4jParamters_tMap_7.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_7.append(" | ");
                            log4jParamters_tMap_7.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_7 - "  + (log4jParamters_tMap_7) );
                    } 
                } 
            new BytesLimit65535_tMap_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_7", "tMap_7", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row26_tMap_7 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_7__Struct  {
}
Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfanciens_valeurs_uniques_tMap_7 = 0;
				
copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniques_tmp = new copyOfanciens_valeurs_uniquesStruct();
// ###############################

        
        



        









 



/**
 * [tMap_7 begin ] stop
 */



	
	/**
	 * [tUniqRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_2", false);
		start_Hash.put("tUniqRow_2", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row25");
			
		int tos_count_tUniqRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tUniqRow_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
                    log4jParamters_tUniqRow_2.append("Parameters:");
                            log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("true")+", SCHEMA_COLUMN="+("roundId")+"}, {CASE_SENSITIVE="+("false")+", KEY_ATTRIBUTE="+("true")+", SCHEMA_COLUMN="+("billingRoundName")+"}]");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                            log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tUniqRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + (log4jParamters_tUniqRow_2) );
                    } 
                } 
            new BytesLimit65535_tUniqRow_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
				talendJobLogProcess(globalMap);
			}
			

	
		class KeyStruct_tUniqRow_2 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String roundId;
					String billingRoundName;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
								
								result = prime * result + ((this.billingRoundName == null) ? 0 : this.billingRoundName.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;
				
									if (this.roundId == null) {
										if (other.roundId != null) 
											return false;
								
									} else if (!this.roundId.equals(other.roundId))
								 
										return false;
								
									if (this.billingRoundName == null) {
										if (other.billingRoundName != null) 
											return false;
								
									} else if (!this.billingRoundName.equals(other.billingRoundName))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_2 = 0;
int nb_duplicates_tUniqRow_2 = 0;
	log.debug("tUniqRow_2 - Start to process the data from datasource.");
KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>(); 

 



/**
 * [tUniqRow_2 begin ] stop
 */



	
	/**
	 * [tLogRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_3", false);
		start_Hash.put("tLogRow_3", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfancien_billing");
			
		int tos_count_tLogRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogRow_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogRow_3 = new StringBuilder();
                    log4jParamters_tLogRow_3.append("Parameters:");
                            log4jParamters_tLogRow_3.append("BASIC_MODE" + " = " + "true");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("TABLE_PRINT" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("VERTICAL" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("FIELDSEPARATOR" + " = " + "\"|\"");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("PRINT_HEADER" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("PRINT_UNIQUE_NAME" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("PRINT_COLNAMES" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("USE_FIXED_LENGTH" + " = " + "false");
                        log4jParamters_tLogRow_3.append(" | ");
                            log4jParamters_tLogRow_3.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                        log4jParamters_tLogRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + (log4jParamters_tLogRow_3) );
                    } 
                } 
            new BytesLimit65535_tLogRow_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_3", "tLogRow_3", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_tLogRow_3 = "|";
		java.io.PrintStream consoleOut_tLogRow_3 = null;	

 		StringBuilder strBuffer_tLogRow_3 = null;
		int nb_line_tLogRow_3 = 0;
///////////////////////    			



 



/**
 * [tLogRow_3 begin ] stop
 */



	
	/**
	 * [tMap_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_6", false);
		start_Hash.put("tMap_6", System.currentTimeMillis());
		
	
	currentComponent="tMap_6";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row13");
			
		int tos_count_tMap_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_6 = new StringBuilder();
                    log4jParamters_tMap_6.append("Parameters:");
                            log4jParamters_tMap_6.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_6.append(" | ");
                            log4jParamters_tMap_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + (log4jParamters_tMap_6) );
                    } 
                } 
            new BytesLimit65535_tMap_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_6", "tMap_6", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row13_tMap_6 = 0;
		
		int count_row23_tMap_6 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row23Struct> tHash_Lookup_row23 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row23Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row23Struct>) 
					globalMap.get( "tHash_Lookup_row23" ))
					;					
					
	

row23Struct row23HashKey = new row23Struct();
row23Struct row23Default = new row23Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_6__Struct  {
}
Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfancien_billing_tMap_6 = 0;
				
copyOfancien_billingStruct copyOfancien_billing_tmp = new copyOfancien_billingStruct();
// ###############################

        
        



        









 



/**
 * [tMap_6 begin ] stop
 */



	
	/**
	 * [tHashInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_3", false);
		start_Hash.put("tHashInput_3", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_3";
	
	
		int tos_count_tHashInput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_3", "tHashInput_3", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_3 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_3=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row21Struct> tHashFile_tHashInput_3 = mf_tHashInput_3.getAdvancedMemoryHashFile("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_2");
if(tHashFile_tHashInput_3==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row21Struct> iterator_tHashInput_3 = tHashFile_tHashInput_3.iterator();
while (iterator_tHashInput_3.hasNext()) {
    row21Struct next_tHashInput_3 = iterator_tHashInput_3.next();

	row13.roundId = next_tHashInput_3.roundId;
	row13.billingRoundName = next_tHashInput_3.billingRoundName;

 



/**
 * [tHashInput_3 begin ] stop
 */
	
	/**
	 * [tHashInput_3 main ] start
	 */

	

	
	
	currentComponent="tHashInput_3";
	
	

 


	tos_count_tHashInput_3++;

/**
 * [tHashInput_3 main ] stop
 */
	
	/**
	 * [tHashInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_3";
	
	

 



/**
 * [tHashInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tMap_6 main ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row13","tHashInput_3","tHashInput_3","tHashInput","tMap_6","tMap_6","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;
		
						row23Struct row23 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_6 = false;
		boolean mainRowRejected_tMap_6 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row23" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow23 = false;
       		  	    	
       		  	    	
 							row23Struct row23ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_6) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_6 = false;
								
                        		    		    row23HashKey.roundId = row13.roundId ;
                        		    		

								
		                        	row23HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row23.lookup( row23HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row23.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_6 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row23 != null && tHash_Lookup_row23.getCount(row23HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row23' and it contains more one result from keys :  row23.roundId = '" + row23HashKey.roundId + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row23Struct fromLookup_row23 = null;
							row23 = row23Default;
										 
							
								 
							
							
								if (tHash_Lookup_row23 !=null && tHash_Lookup_row23.hasNext()) { // G 099
								
							
								
								fromLookup_row23 = tHash_Lookup_row23.next();

							
							
								} // G 099
							
							

							if(fromLookup_row23 != null) {
								row23 = fromLookup_row23;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
        // ###############################
        // # Output tables

copyOfancien_billing = null;

if(!rejectedInnerJoin_tMap_6 ) {

// # Output table : 'copyOfancien_billing'
count_copyOfancien_billing_tMap_6++;

copyOfancien_billing_tmp.roundId = row13.roundId ;
copyOfancien_billing_tmp.billingRoundName = row23.billingRoundName ;
copyOfancien_billing = copyOfancien_billing_tmp;
log.debug("tMap_6 - Outputting the record " + count_copyOfancien_billing_tMap_6 + " of the output table 'copyOfancien_billing'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_6 = false;










 


	tos_count_tMap_6++;

/**
 * [tMap_6 main ] stop
 */
	
	/**
	 * [tMap_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 process_data_begin ] stop
 */
// Start of branch "copyOfancien_billing"
if(copyOfancien_billing != null) { 



	
	/**
	 * [tLogRow_3 main ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"copyOfancien_billing","tMap_6","tMap_6","tMap","tLogRow_3","tLogRow_3","tLogRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("copyOfancien_billing - " + (copyOfancien_billing==null? "": copyOfancien_billing.toLogString()));
    			}
    		
///////////////////////		
						



				strBuffer_tLogRow_3 = new StringBuilder();




   				
	    		if(copyOfancien_billing.roundId != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(copyOfancien_billing.roundId)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(copyOfancien_billing.billingRoundName != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(copyOfancien_billing.billingRoundName)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_3);
                    }
                    	log.info("tLogRow_3 - Content of row "+(nb_line_tLogRow_3+1)+": " + strBuffer_tLogRow_3.toString());
                    consoleOut_tLogRow_3.println(strBuffer_tLogRow_3.toString());
                    consoleOut_tLogRow_3.flush();
                    nb_line_tLogRow_3++;
//////

//////                    
                    
///////////////////////    			

 
     row25 = copyOfancien_billing;


	tos_count_tLogRow_3++;

/**
 * [tLogRow_3 main ] stop
 */
	
	/**
	 * [tLogRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 process_data_begin ] stop
 */

	
	/**
	 * [tUniqRow_2 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row25","tLogRow_3","tLogRow_3","tLogRow","tUniqRow_2","tUniqRow_2","tUniqRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row25 - " + (row25==null? "": row25.toLogString()));
    			}
    		
row26 = null;			
if(row25.roundId == null){
	finder_tUniqRow_2.roundId = null;
}else{
	finder_tUniqRow_2.roundId = row25.roundId.toLowerCase();
}
if(row25.billingRoundName == null){
	finder_tUniqRow_2.billingRoundName = null;
}else{
	finder_tUniqRow_2.billingRoundName = row25.billingRoundName.toLowerCase();
}	
finder_tUniqRow_2.hashCodeDirty = true;
if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
		KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

		
if(row25.roundId == null){
	new_tUniqRow_2.roundId = null;
}else{
	new_tUniqRow_2.roundId = row25.roundId.toLowerCase();
}
if(row25.billingRoundName == null){
	new_tUniqRow_2.billingRoundName = null;
}else{
	new_tUniqRow_2.billingRoundName = row25.billingRoundName.toLowerCase();
}
		
		keystUniqRow_2.add(new_tUniqRow_2);if(row26 == null){ 
	
		log.trace("tUniqRow_2 - Writing the unique record " + (nb_uniques_tUniqRow_2+1) + " into row26.");
	
	row26 = new row26Struct();
}row26.roundId = row25.roundId;			row26.billingRoundName = row25.billingRoundName;					
		nb_uniques_tUniqRow_2++;
	} else {
	  nb_duplicates_tUniqRow_2++;
	}

 


	tos_count_tUniqRow_2++;

/**
 * [tUniqRow_2 main ] stop
 */
	
	/**
	 * [tUniqRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_begin ] stop
 */
// Start of branch "row26"
if(row26 != null) { 



	
	/**
	 * [tMap_7 main ] start
	 */

	

	
	
	currentComponent="tMap_7";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row26","tUniqRow_2","tUniqRow_2","tUniqRow","tMap_7","tMap_7","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row26 - " + (row26==null? "": row26.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_7 = false;
		boolean mainRowRejected_tMap_7 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
        // ###############################
        // # Output tables

copyOfanciens_valeurs_uniques = null;


// # Output table : 'copyOfanciens_valeurs_uniques'
count_copyOfanciens_valeurs_uniques_tMap_7++;

copyOfanciens_valeurs_uniques_tmp.roundId = row26.roundId ;
copyOfanciens_valeurs_uniques_tmp.billingRoundName = row26.billingRoundName ;
copyOfanciens_valeurs_uniques = copyOfanciens_valeurs_uniques_tmp;
log.debug("tMap_7 - Outputting the record " + count_copyOfanciens_valeurs_uniques_tMap_7 + " of the output table 'copyOfanciens_valeurs_uniques'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_7 = false;










 


	tos_count_tMap_7++;

/**
 * [tMap_7 main ] stop
 */
	
	/**
	 * [tMap_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_7";
	
	

 



/**
 * [tMap_7 process_data_begin ] stop
 */
// Start of branch "copyOfanciens_valeurs_uniques"
if(copyOfanciens_valeurs_uniques != null) { 



	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"copyOfanciens_valeurs_uniques","tMap_7","tMap_7","tMap","tAdvancedHash_copyOfanciens_valeurs_uniques","tAdvancedHash_copyOfanciens_valeurs_uniques","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("copyOfanciens_valeurs_uniques - " + (copyOfanciens_valeurs_uniques==null? "": copyOfanciens_valeurs_uniques.toLogString()));
    			}
    		


			   
			   

					copyOfanciens_valeurs_uniquesStruct copyOfanciens_valeurs_uniques_HashRow = new copyOfanciens_valeurs_uniquesStruct();
		   	   	   
				
				copyOfanciens_valeurs_uniques_HashRow.roundId = copyOfanciens_valeurs_uniques.roundId;
				
				copyOfanciens_valeurs_uniques_HashRow.billingRoundName = copyOfanciens_valeurs_uniques.billingRoundName;
				
			tHash_Lookup_copyOfanciens_valeurs_uniques.put(copyOfanciens_valeurs_uniques_HashRow);
			
            




 


	tos_count_tAdvancedHash_copyOfanciens_valeurs_uniques++;

/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques main ] stop
 */
	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	

 



/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	

 



/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques process_data_end ] stop
 */

} // End of branch "copyOfanciens_valeurs_uniques"




	
	/**
	 * [tMap_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_7";
	
	

 



/**
 * [tMap_7 process_data_end ] stop
 */

} // End of branch "row26"




	
	/**
	 * [tUniqRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 process_data_end ] stop
 */

} // End of branch "copyOfancien_billing"




	
	/**
	 * [tMap_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_3";
	
	

 



/**
 * [tHashInput_3 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_3 end ] start
	 */

	

	
	
	currentComponent="tHashInput_3";
	
	
    

		
			nb_line_tHashInput_3++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE_" + pid +"_tHashOutput_2");
	


	globalMap.put("tHashInput_3_NB_LINE", nb_line_tHashInput_3);       

 

ok_Hash.put("tHashInput_3", true);
end_Hash.put("tHashInput_3", System.currentTimeMillis());




/**
 * [tHashInput_3 end ] stop
 */

	
	/**
	 * [tMap_6 end ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row23 != null) {
						tHash_Lookup_row23.endGet();
					}
					globalMap.remove( "tHash_Lookup_row23" );

					
					
				
// ###############################      
				log.debug("tMap_6 - Written records count in the table 'copyOfancien_billing': " + count_copyOfancien_billing_tMap_6 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row13",2,0,
			 			"tHashInput_3","tHashInput_3","tHashInput","tMap_6","tMap_6","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Done.") );

ok_Hash.put("tMap_6", true);
end_Hash.put("tMap_6", System.currentTimeMillis());




/**
 * [tMap_6 end ] stop
 */

	
	/**
	 * [tLogRow_3 end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	


//////
//////
globalMap.put("tLogRow_3_NB_LINE",nb_line_tLogRow_3);
                if(log.isInfoEnabled())
            log.info("tLogRow_3 - "  + ("Printed row count: ")  + (nb_line_tLogRow_3)  + (".") );

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfancien_billing",2,0,
			 			"tMap_6","tMap_6","tMap","tLogRow_3","tLogRow_3","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + ("Done.") );

ok_Hash.put("tLogRow_3", true);
end_Hash.put("tLogRow_3", System.currentTimeMillis());




/**
 * [tLogRow_3 end ] stop
 */

	
	/**
	 * [tUniqRow_2 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

globalMap.put("tUniqRow_2_NB_UNIQUES",nb_uniques_tUniqRow_2);
globalMap.put("tUniqRow_2_NB_DUPLICATES",nb_duplicates_tUniqRow_2);
	log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2)+" .");
	log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2)+" .");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row25",2,0,
			 			"tLogRow_3","tLogRow_3","tLogRow","tUniqRow_2","tUniqRow_2","tUniqRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tUniqRow_2 - "  + ("Done.") );

ok_Hash.put("tUniqRow_2", true);
end_Hash.put("tUniqRow_2", System.currentTimeMillis());




/**
 * [tUniqRow_2 end ] stop
 */

	
	/**
	 * [tMap_7 end ] start
	 */

	

	
	
	currentComponent="tMap_7";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_7 - Written records count in the table 'copyOfanciens_valeurs_uniques': " + count_copyOfanciens_valeurs_uniques_tMap_7 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row26",2,0,
			 			"tUniqRow_2","tUniqRow_2","tUniqRow","tMap_7","tMap_7","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_7 - "  + ("Done.") );

ok_Hash.put("tMap_7", true);
end_Hash.put("tMap_7", System.currentTimeMillis());




/**
 * [tMap_7 end ] stop
 */

	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	

tHash_Lookup_copyOfanciens_valeurs_uniques.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfanciens_valeurs_uniques",2,0,
			 			"tMap_7","tMap_7","tMap","tAdvancedHash_copyOfanciens_valeurs_uniques","tAdvancedHash_copyOfanciens_valeurs_uniques","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_copyOfanciens_valeurs_uniques", true);
end_Hash.put("tAdvancedHash_copyOfanciens_valeurs_uniques", System.currentTimeMillis());




/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques end ] stop
 */















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_6"
					     			globalMap.remove("tHash_Lookup_row23"); 
				     			
				try{
					
	
	/**
	 * [tHashInput_3 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_3";
	
	

 



/**
 * [tHashInput_3 finally ] stop
 */

	
	/**
	 * [tMap_6 finally ] start
	 */

	

	
	
	currentComponent="tMap_6";
	
	

 



/**
 * [tMap_6 finally ] stop
 */

	
	/**
	 * [tLogRow_3 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 finally ] stop
 */

	
	/**
	 * [tUniqRow_2 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";
	
	

 



/**
 * [tUniqRow_2 finally ] stop
 */

	
	/**
	 * [tMap_7 finally ] start
	 */

	

	
	
	currentComponent="tMap_7";
	
	

 



/**
 * [tMap_7 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_copyOfanciens_valeurs_uniques finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_copyOfanciens_valeurs_uniques";
	
	

 



/**
 * [tAdvancedHash_copyOfanciens_valeurs_uniques finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row23Struct implements routines.system.IPersistableComparableLookupRow<row23Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return false;
				}
				public Boolean roundIdIsKey(){
				    return false;
				}
				public Integer roundIdLength(){
				    return 150;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String roundName;

				public String getRoundName () {
					return this.roundName;
				}

				public Boolean roundNameIsNullable(){
				    return true;
				}
				public Boolean roundNameIsKey(){
				    return false;
				}
				public Integer roundNameLength(){
				    return 150;
				}
				public Integer roundNamePrecision(){
				    return 0;
				}
				public String roundNameDefault(){
				
					return null;
				
				}
				public String roundNameComment(){
				
				    return "";
				
				}
				public String roundNamePattern(){
				
					return "";
				
				}
				public String roundNameOriginalDbColumnName(){
				
					return "roundName";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return null;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row23Struct other = (row23Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row23Struct other) {

		other.roundId = this.roundId;
	            other.roundName = this.roundName;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(row23Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.roundName = readString(dis,ois);
					
						this.billingRoundName = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.roundName = readString(dis,objectIn);
					
						this.billingRoundName = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.roundName, dos, oos);
					
						writeString(this.billingRoundName, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.roundName, dos, objectOut);
					
						writeString(this.billingRoundName, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",roundName="+roundName);
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(roundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundName);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row23Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", "PclHxa_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row23Struct row23 = new row23Struct();




	
	/**
	 * [tAdvancedHash_row23 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row23", false);
		start_Hash.put("tAdvancedHash_row23", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row23";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row23");
			
		int tos_count_tAdvancedHash_row23 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row23", "tAdvancedHash_row23", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row23
			   		// source node:tDBInput_3 - inputs:(after_tHashInput_3) outputs:(row23,row23) | target node:tAdvancedHash_row23 - inputs:(row23) outputs:()
			   		// linked node: tMap_6 - inputs:(row13,row23) outputs:(copyOfancien_billing)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row23 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row23Struct> tHash_Lookup_row23 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row23Struct>getLookup(matchingModeEnum_row23);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row23", tHash_Lookup_row23);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row23 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"urbantz_round\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT    `urbantz_round`.`roundId`,    `urbantz_round`.`roundName`,   `urbantz_round`.`billingRoundName` FROM `urbantz_round`\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("ENABLE_STREAM" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("roundId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("roundName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("billingRoundName")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"urbantz_round\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_3 = java.util.Calendar.getInstance();
		    calendar_tDBInput_3.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_3 = calendar_tDBInput_3.getTime();
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT \n  `urbantz_round`.`roundId`, \n  `urbantz_round`.`roundName`,\n  `urbantz_round`.`billingRoundName`\nFROM `urbantz"
+"_round`";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

		    globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);

		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row23.roundId = null;
							} else {
	                         		
        	row23.roundId = routines.system.JDBCUtil.getString(rs_tDBInput_3, 1, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row23.roundName = null;
							} else {
	                         		
        	row23.roundName = routines.system.JDBCUtil.getString(rs_tDBInput_3, 2, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row23.billingRoundName = null;
							} else {
	                         		
        	row23.billingRoundName = routines.system.JDBCUtil.getString(rs_tDBInput_3, 3, false);
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					

 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row23 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row23";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row23","tDBInput_3","\"urbantz_round\"","tMysqlInput","tAdvancedHash_row23","tAdvancedHash_row23","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row23 - " + (row23==null? "": row23.toLogString()));
    			}
    		


			   
			   

					row23Struct row23_HashRow = new row23Struct();
		   	   	   
				
				row23_HashRow.roundId = row23.roundId;
				
				row23_HashRow.roundName = row23.roundName;
				
				row23_HashRow.billingRoundName = row23.billingRoundName;
				
			tHash_Lookup_row23.put(row23_HashRow);
			
            




 


	tos_count_tAdvancedHash_row23++;

/**
 * [tAdvancedHash_row23 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row23 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row23";
	
	

 



/**
 * [tAdvancedHash_row23 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row23 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row23";
	
	

 



/**
 * [tAdvancedHash_row23 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row23 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row23";
	
	

tHash_Lookup_row23.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row23",2,0,
			 			"tDBInput_3","\"urbantz_round\"","tMysqlInput","tAdvancedHash_row23","tAdvancedHash_row23","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row23", true);
end_Hash.put("tAdvancedHash_row23", System.currentTimeMillis());




/**
 * [tAdvancedHash_row23 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row23 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row23";
	
	

 



/**
 * [tAdvancedHash_row23 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "v2LNnG_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULEClass = new URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE();

        int exitCode = URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULEClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_6532UPFtEeyp790etNOyuA");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-04-17T08:59:31.910135500Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.class.getClassLoader().getResourceAsStream("cajoo/urbantz_correction_exceptions_prod_v1_vehicule_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("Livraisons_Exception", "id_String");
                        if(context.getStringValue("Livraisons_Exception") == null) {
                            context.Livraisons_Exception = null;
                        } else {
                            context.Livraisons_Exception=(String) context.getProperty("Livraisons_Exception");
                        }
                        context.setContextType("Server_Clean", "id_String");
                        if(context.getStringValue("Server_Clean") == null) {
                            context.Server_Clean = null;
                        } else {
                            context.Server_Clean=(String) context.getProperty("Server_Clean");
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Server_Out", "id_String");
                        if(context.getStringValue("Server_Out") == null) {
                            context.Server_Out = null;
                        } else {
                            context.Server_Out=(String) context.getProperty("Server_Out");
                        }
                        context.setContextType("Livraison_directory", "id_String");
                        if(context.getStringValue("Livraison_directory") == null) {
                            context.Livraison_directory = null;
                        } else {
                            context.Livraison_directory=(String) context.getProperty("Livraison_directory");
                        }
                        context.setContextType("Round_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Minus_Days") == null) {
                            context.Round_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Minus_Days", e.getMessage()));
                                context.Round_Minus_Days=null;
                            }
                        }
                        context.setContextType("transaction_id", "id_String");
                        if(context.getStringValue("transaction_id") == null) {
                            context.transaction_id = null;
                        } else {
                            context.transaction_id=(String) context.getProperty("transaction_id");
                        }
                        context.setContextType("ondemand_server_directory", "id_String");
                        if(context.getStringValue("ondemand_server_directory") == null) {
                            context.ondemand_server_directory = null;
                        } else {
                            context.ondemand_server_directory=(String) context.getProperty("ondemand_server_directory");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("Livraisons_Exception")) {
                context.Livraisons_Exception = (String) parentContextMap.get("Livraisons_Exception");
            }if (parentContextMap.containsKey("Server_Clean")) {
                context.Server_Clean = (String) parentContextMap.get("Server_Clean");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Server_Out")) {
                context.Server_Out = (String) parentContextMap.get("Server_Out");
            }if (parentContextMap.containsKey("Livraison_directory")) {
                context.Livraison_directory = (String) parentContextMap.get("Livraison_directory");
            }if (parentContextMap.containsKey("Round_Minus_Days")) {
                context.Round_Minus_Days = (Integer) parentContextMap.get("Round_Minus_Days");
            }if (parentContextMap.containsKey("transaction_id")) {
                context.transaction_id = (String) parentContextMap.get("transaction_id");
            }if (parentContextMap.containsKey("ondemand_server_directory")) {
                context.ondemand_server_directory = (String) parentContextMap.get("ondemand_server_directory");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob




		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSetGlobalVar_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSetGlobalVar_2) {
globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'URBANTZ_CORRECTION_EXCEPTIONS_PROD_V1_VEHICULE' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     871208 characters generated by Talend Cloud Data Integration 
 *     on the 17 avril 2024 à 09:59:32 CET
 ************************************************************************************************/
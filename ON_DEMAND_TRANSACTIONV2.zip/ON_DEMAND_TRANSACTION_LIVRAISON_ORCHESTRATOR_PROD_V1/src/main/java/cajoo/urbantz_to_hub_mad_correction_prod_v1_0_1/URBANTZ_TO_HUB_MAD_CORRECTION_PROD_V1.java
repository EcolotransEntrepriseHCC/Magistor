
package cajoo.urbantz_to_hub_mad_correction_prod_v1_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 implements TalendJob {
	static {System.setProperty("TalendJob.log", "URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(ODS_Database != null){
				
					this.setProperty("ODS_Database", ODS_Database.toString());
				
			}
			
			if(PBI_Database != null){
				
					this.setProperty("PBI_Database", PBI_Database.toString());
				
			}
			
			if(PBI_RT_Database != null){
				
					this.setProperty("PBI_RT_Database", PBI_RT_Database.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(Clients_Masque != null){
				
					this.setProperty("Clients_Masque", Clients_Masque.toString());
				
			}
			
			if(Code_client_masque != null){
				
					this.setProperty("Code_client_masque", Code_client_masque.toString());
				
			}
			
			if(Command_Logistic_Invalid_Date != null){
				
					this.setProperty("Command_Logistic_Invalid_Date", Command_Logistic_Invalid_Date.toString());
				
			}
			
			if(Command_Logistic_Masque != null){
				
					this.setProperty("Command_Logistic_Masque", Command_Logistic_Masque.toString());
				
			}
			
			if(Command_Transport_Masque != null){
				
					this.setProperty("Command_Transport_Masque", Command_Transport_Masque.toString());
				
			}
			
			if(Command_Transport_Masque_Express != null){
				
					this.setProperty("Command_Transport_Masque_Express", Command_Transport_Masque_Express.toString());
				
			}
			
			if(Ecolotrans_JP != null){
				
					this.setProperty("Ecolotrans_JP", Ecolotrans_JP.toString());
				
			}
			
			if(Holiday_Days_Masque != null){
				
					this.setProperty("Holiday_Days_Masque", Holiday_Days_Masque.toString());
				
			}
			
			if(Livraisons_Exception != null){
				
					this.setProperty("Livraisons_Exception", Livraisons_Exception.toString());
				
			}
			
			if(Livraisons_Masque != null){
				
					this.setProperty("Livraisons_Masque", Livraisons_Masque.toString());
				
			}
			
			if(Livraisons_Ok != null){
				
					this.setProperty("Livraisons_Ok", Livraisons_Ok.toString());
				
			}
			
			if(ST_Drivers != null){
				
					this.setProperty("ST_Drivers", ST_Drivers.toString());
				
			}
			
			if(Tarification_Logistic_Masque != null){
				
					this.setProperty("Tarification_Logistic_Masque", Tarification_Logistic_Masque.toString());
				
			}
			
			if(Tarification_Transport_Masque != null){
				
					this.setProperty("Tarification_Transport_Masque", Tarification_Transport_Masque.toString());
				
			}
			
			if(Tournee_Masque != null){
				
					this.setProperty("Tournee_Masque", Tournee_Masque.toString());
				
			}
			
			if(TVA_Exceptions != null){
				
					this.setProperty("TVA_Exceptions", TVA_Exceptions.toString());
				
			}
			
			if(Backup != null){
				
					this.setProperty("Backup", Backup.toString());
				
			}
			
			if(Server_Clean != null){
				
					this.setProperty("Server_Clean", Server_Clean.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Server_Out != null){
				
					this.setProperty("Server_Out", Server_Out.toString());
				
			}
			
			if(Server_Out_DataMart != null){
				
					this.setProperty("Server_Out_DataMart", Server_Out_DataMart.toString());
				
			}
			
			if(transaction_id != null){
				
					this.setProperty("transaction_id", transaction_id.toString());
				
			}
			
			if(ondemand_server_directory != null){
				
					this.setProperty("ondemand_server_directory", ondemand_server_directory.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String ODS_Database;
public String getODS_Database(){
	return this.ODS_Database;
}
public String PBI_Database;
public String getPBI_Database(){
	return this.PBI_Database;
}
public String PBI_RT_Database;
public String getPBI_RT_Database(){
	return this.PBI_RT_Database;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String Clients_Masque;
public String getClients_Masque(){
	return this.Clients_Masque;
}
public String Code_client_masque;
public String getCode_client_masque(){
	return this.Code_client_masque;
}
public String Command_Logistic_Invalid_Date;
public String getCommand_Logistic_Invalid_Date(){
	return this.Command_Logistic_Invalid_Date;
}
public String Command_Logistic_Masque;
public String getCommand_Logistic_Masque(){
	return this.Command_Logistic_Masque;
}
public String Command_Transport_Masque;
public String getCommand_Transport_Masque(){
	return this.Command_Transport_Masque;
}
public String Command_Transport_Masque_Express;
public String getCommand_Transport_Masque_Express(){
	return this.Command_Transport_Masque_Express;
}
public String Ecolotrans_JP;
public String getEcolotrans_JP(){
	return this.Ecolotrans_JP;
}
public String Holiday_Days_Masque;
public String getHoliday_Days_Masque(){
	return this.Holiday_Days_Masque;
}
public String Livraisons_Exception;
public String getLivraisons_Exception(){
	return this.Livraisons_Exception;
}
public String Livraisons_Masque;
public String getLivraisons_Masque(){
	return this.Livraisons_Masque;
}
public String Livraisons_Ok;
public String getLivraisons_Ok(){
	return this.Livraisons_Ok;
}
public String ST_Drivers;
public String getST_Drivers(){
	return this.ST_Drivers;
}
public String Tarification_Logistic_Masque;
public String getTarification_Logistic_Masque(){
	return this.Tarification_Logistic_Masque;
}
public String Tarification_Transport_Masque;
public String getTarification_Transport_Masque(){
	return this.Tarification_Transport_Masque;
}
public String Tournee_Masque;
public String getTournee_Masque(){
	return this.Tournee_Masque;
}
public String TVA_Exceptions;
public String getTVA_Exceptions(){
	return this.TVA_Exceptions;
}
public String Backup;
public String getBackup(){
	return this.Backup;
}
public String Server_Clean;
public String getServer_Clean(){
	return this.Server_Clean;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Server_Out;
public String getServer_Out(){
	return this.Server_Out;
}
public String Server_Out_DataMart;
public String getServer_Out_DataMart(){
	return this.Server_Out_DataMart;
}
public String transaction_id;
public String getTransaction_id(){
	return this.transaction_id;
}
public String ondemand_server_directory;
public String getOndemand_server_directory(){
	return this.ondemand_server_directory;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1";
	private final String projectName = "CAJOO";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_XrfksHOEEeyMP6NhmRAVjA", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_1");
		org.slf4j.MDC.put("_subJobPid", "zaB4vZ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";
	
	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_1.append("Parameters:");
                            log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("TalendDate.getDate(\"dd_MM_yyyy_\")")+", KEY="+("\"today_date\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyyMMdd\",TalendDate.addDate(new Date(),-1,\"dd\"))")+", KEY="+("\"start_date\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyyMMdd\",TalendDate.addDate(new Date(),+2,\"dd\"))")+", KEY="+("\"end_date\"")+"}, {VALUE="+("context.transaction_id")+", KEY="+("\"transaction_id\"")+"}]");
                        log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_1", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

globalMap.put("today_date", TalendDate.getDate("dd_MM_yyyy_"));
globalMap.put("start_date", TalendDate.formatDate("yyyyMMdd",TalendDate.addDate(new Date(),-1,"dd")));
globalMap.put("end_date", TalendDate.formatDate("yyyyMMdd",TalendDate.addDate(new Date(),+2,"dd")));
globalMap.put("transaction_id", context.transaction_id);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());

   			if (((String)globalMap.get("transaction_id")) != null) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				tDBConnection_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "mfp7Jq_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tFileExist_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tFileExist_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileExist_1");
		org.slf4j.MDC.put("_subJobPid", "WzPVu0_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_1", false);
		start_Hash.put("tFileExist_1", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_1";
	
	
		int tos_count_tFileExist_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileExist_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileExist_1 = new StringBuilder();
                    log4jParamters_tFileExist_1.append("Parameters:");
                            log4jParamters_tFileExist_1.append("FILE_NAME" + " = " + "context.Server_In + context.ondemand_server_directory +  ((String)globalMap.get(\"transaction_id\")) + \"/\" +\"ToVerifyQTE_MAD_\"+context.Livraisons_Masque");
                        log4jParamters_tFileExist_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + (log4jParamters_tFileExist_1) );
                    } 
                } 
            new BytesLimit65535_tFileExist_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileExist_1", "tFileExist_1", "tFileExist");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tFileExist_1 begin ] stop
 */
	
	/**
	 * [tFileExist_1 main ] start
	 */

	

	
	
	currentComponent="tFileExist_1";
	
	


				final StringBuffer log4jSb_tFileExist_1 = new StringBuffer();
			

java.io.File file_tFileExist_1 = new java.io.File(context.Server_In + context.ondemand_server_directory +  ((String)globalMap.get("transaction_id")) + "/" +"ToVerifyQTE_MAD_"+context.Livraisons_Masque);
if (!file_tFileExist_1.exists()) {
    globalMap.put("tFileExist_1_EXISTS",false);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_1_EXISTS",true);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_1_FILENAME",context.Server_In + context.ondemand_server_directory +  ((String)globalMap.get("transaction_id")) + "/" +"ToVerifyQTE_MAD_"+context.Livraisons_Masque);


 


	tos_count_tFileExist_1++;

/**
 * [tFileExist_1 main ] stop
 */
	
	/**
	 * [tFileExist_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileExist_1";
	
	

 



/**
 * [tFileExist_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileExist_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileExist_1";
	
	

 



/**
 * [tFileExist_1 process_data_end ] stop
 */
	
	/**
	 * [tFileExist_1 end ] start
	 */

	

	
	
	currentComponent="tFileExist_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Done.") );

ok_Hash.put("tFileExist_1", true);
end_Hash.put("tFileExist_1", System.currentTimeMillis());

   			if (((Boolean)globalMap.get("tFileExist_1_EXISTS"))	== true ) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				tFileInputExcel_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_1 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_1";
	
	

 



/**
 * [tFileExist_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_1_SUBPROCESS_STATE", 1);
	}
	


public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return false;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 50;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return true;
				}
				public Integer taskIdLength(){
				    return 50;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return 12;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public String date;

				public String getDate () {
					return this.date;
				}

				public Boolean dateIsNullable(){
				    return true;
				}
				public Boolean dateIsKey(){
				    return false;
				}
				public Integer dateLength(){
				    return 10;
				}
				public Integer datePrecision(){
				    return 0;
				}
				public String dateDefault(){
				
					return null;
				
				}
				public String dateComment(){
				
				    return "";
				
				}
				public String datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String dateOriginalDbColumnName(){
				
					return "date";
				
				}

				
			    public String expediteur;

				public String getExpediteur () {
					return this.expediteur;
				}

				public Boolean expediteurIsNullable(){
				    return true;
				}
				public Boolean expediteurIsKey(){
				    return false;
				}
				public Integer expediteurLength(){
				    return 28;
				}
				public Integer expediteurPrecision(){
				    return 0;
				}
				public String expediteurDefault(){
				
					return null;
				
				}
				public String expediteurComment(){
				
				    return "";
				
				}
				public String expediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String expediteurOriginalDbColumnName(){
				
					return "expediteur";
				
				}

				
			    public String roundName;

				public String getRoundName () {
					return this.roundName;
				}

				public Boolean roundNameIsNullable(){
				    return true;
				}
				public Boolean roundNameIsKey(){
				    return false;
				}
				public Integer roundNameLength(){
				    return null;
				}
				public Integer roundNamePrecision(){
				    return null;
				}
				public String roundNameDefault(){
				
					return null;
				
				}
				public String roundNameComment(){
				
				    return "";
				
				}
				public String roundNamePattern(){
				
					return "";
				
				}
				public String roundNameOriginalDbColumnName(){
				
					return "roundName";
				
				}

				
			    public java.util.Date created_at;

				public java.util.Date getCreated_at () {
					return this.created_at;
				}

				public Boolean created_atIsNullable(){
				    return true;
				}
				public Boolean created_atIsKey(){
				    return false;
				}
				public Integer created_atLength(){
				    return null;
				}
				public Integer created_atPrecision(){
				    return null;
				}
				public String created_atDefault(){
				
					return null;
				
				}
				public String created_atComment(){
				
				    return "";
				
				}
				public String created_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_atOriginalDbColumnName(){
				
					return "created_at";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
						result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out1Struct other = (out1Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					
						if (this.taskId == null) {
							if (other.taskId != null)
								return false;
						
						} else if (!this.taskId.equals(other.taskId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(out1Struct other) {

		other.roundId = this.roundId;
	            other.taskId = this.taskId;
	            other.quantity = this.quantity;
	            other.date = this.date;
	            other.expediteur = this.expediteur;
	            other.roundName = this.roundName;
	            other.created_at = this.created_at;
	            
	}

	public void copyKeysDataTo(out1Struct other) {

		other.roundId = this.roundId;
	            	other.taskId = this.taskId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.expediteur = readString(dis);
					
					this.roundName = readString(dis);
					
					this.created_at = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.expediteur = readString(dis);
					
					this.roundName = readString(dis);
					
					this.created_at = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.expediteur,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.expediteur,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// java.util.Date
				
						writeDate(this.created_at,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",taskId="+taskId);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",date="+date);
		sb.append(",expediteur="+expediteur);
		sb.append(",roundName="+roundName);
		sb.append(",created_at="+String.valueOf(created_at));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(roundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundName);
            			}
            		
        			sb.append("|");
        		
        				if(created_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_at);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.taskId, other.taskId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class ALL_TASKSStruct implements routines.system.IPersistableRow<ALL_TASKSStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(ALL_TASKSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return 150;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom_sous_categorie;

				public String getItem___Nom_sous_categorie () {
					return this.Item___Nom_sous_categorie;
				}

				public Boolean Item___Nom_sous_categorieIsNullable(){
				    return true;
				}
				public Boolean Item___Nom_sous_categorieIsKey(){
				    return false;
				}
				public Integer Item___Nom_sous_categorieLength(){
				    return 5;
				}
				public Integer Item___Nom_sous_categoriePrecision(){
				    return 0;
				}
				public String Item___Nom_sous_categorieDefault(){
				
					return null;
				
				}
				public String Item___Nom_sous_categorieComment(){
				
				    return "";
				
				}
				public String Item___Nom_sous_categoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___Nom_sous_categorieOriginalDbColumnName(){
				
					return "Item___Nom_sous_categorie";
				
				}

				
			    public String Item___Type_unite_manutention;

				public String getItem___Type_unite_manutention () {
					return this.Item___Type_unite_manutention;
				}

				public Boolean Item___Type_unite_manutentionIsNullable(){
				    return true;
				}
				public Boolean Item___Type_unite_manutentionIsKey(){
				    return false;
				}
				public Integer Item___Type_unite_manutentionLength(){
				    return 0;
				}
				public Integer Item___Type_unite_manutentionPrecision(){
				    return 0;
				}
				public String Item___Type_unite_manutentionDefault(){
				
					return null;
				
				}
				public String Item___Type_unite_manutentionComment(){
				
				    return "";
				
				}
				public String Item___Type_unite_manutentionPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___Type_unite_manutentionOriginalDbColumnName(){
				
					return "Item___Type_unite_manutention";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return null;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return "";
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return "";
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String sourceHubName;

				public String getSourceHubName () {
					return this.sourceHubName;
				}

				public Boolean sourceHubNameIsNullable(){
				    return true;
				}
				public Boolean sourceHubNameIsKey(){
				    return false;
				}
				public Integer sourceHubNameLength(){
				    return 150;
				}
				public Integer sourceHubNamePrecision(){
				    return 0;
				}
				public String sourceHubNameDefault(){
				
					return null;
				
				}
				public String sourceHubNameComment(){
				
				    return "";
				
				}
				public String sourceHubNamePattern(){
				
					return "";
				
				}
				public String sourceHubNameOriginalDbColumnName(){
				
					return "sourceHubName";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom_sous_categorie = readString(dis);
					
					this.Item___Type_unite_manutention = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.sourceHubName = readString(dis);
					
					this.Round_Name = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom_sous_categorie = readString(dis);
					
					this.Item___Type_unite_manutention = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.sourceHubName = readString(dis);
					
					this.Round_Name = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom_sous_categorie,dos);
					
					// String
				
						writeString(this.Item___Type_unite_manutention,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom_sous_categorie,dos);
					
					// String
				
						writeString(this.Item___Type_unite_manutention,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom_sous_categorie="+Item___Nom_sous_categorie);
		sb.append(",Item___Type_unite_manutention="+Item___Type_unite_manutention);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",sourceHubName="+sourceHubName);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom_sous_categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom_sous_categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type_unite_manutention == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type_unite_manutention);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHubName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHubName);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tFileInputExcel_1Struct implements routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return 150;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public String Activite;

				public String getActivite () {
					return this.Activite;
				}

				public Boolean ActiviteIsNullable(){
				    return true;
				}
				public Boolean ActiviteIsKey(){
				    return false;
				}
				public Integer ActiviteLength(){
				    return 7;
				}
				public Integer ActivitePrecision(){
				    return 0;
				}
				public String ActiviteDefault(){
				
					return null;
				
				}
				public String ActiviteComment(){
				
				    return "";
				
				}
				public String ActivitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ActiviteOriginalDbColumnName(){
				
					return "Activite";
				
				}

				
			    public String Categorie;

				public String getCategorie () {
					return this.Categorie;
				}

				public Boolean CategorieIsNullable(){
				    return true;
				}
				public Boolean CategorieIsKey(){
				    return false;
				}
				public Integer CategorieLength(){
				    return 7;
				}
				public Integer CategoriePrecision(){
				    return 0;
				}
				public String CategorieDefault(){
				
					return null;
				
				}
				public String CategorieComment(){
				
				    return "";
				
				}
				public String CategoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CategorieOriginalDbColumnName(){
				
					return "Categorie";
				
				}

				
			    public String Type_de_Service;

				public String getType_de_Service () {
					return this.Type_de_Service;
				}

				public Boolean Type_de_ServiceIsNullable(){
				    return true;
				}
				public Boolean Type_de_ServiceIsKey(){
				    return false;
				}
				public Integer Type_de_ServiceLength(){
				    return 8;
				}
				public Integer Type_de_ServicePrecision(){
				    return 0;
				}
				public String Type_de_ServiceDefault(){
				
					return null;
				
				}
				public String Type_de_ServiceComment(){
				
				    return "";
				
				}
				public String Type_de_ServicePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Type_de_ServiceOriginalDbColumnName(){
				
					return "Type_de_Service";
				
				}

				
			    public String ID_de_la_tache;

				public String getID_de_la_tache () {
					return this.ID_de_la_tache;
				}

				public Boolean ID_de_la_tacheIsNullable(){
				    return true;
				}
				public Boolean ID_de_la_tacheIsKey(){
				    return false;
				}
				public Integer ID_de_la_tacheLength(){
				    return 13;
				}
				public Integer ID_de_la_tachePrecision(){
				    return 0;
				}
				public String ID_de_la_tacheDefault(){
				
					return null;
				
				}
				public String ID_de_la_tacheComment(){
				
				    return "";
				
				}
				public String ID_de_la_tachePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ID_de_la_tacheOriginalDbColumnName(){
				
					return "ID_de_la_tache";
				
				}

				
			    public String Item___Nom_sous_categorie;

				public String getItem___Nom_sous_categorie () {
					return this.Item___Nom_sous_categorie;
				}

				public Boolean Item___Nom_sous_categorieIsNullable(){
				    return true;
				}
				public Boolean Item___Nom_sous_categorieIsKey(){
				    return false;
				}
				public Integer Item___Nom_sous_categorieLength(){
				    return 5;
				}
				public Integer Item___Nom_sous_categoriePrecision(){
				    return 0;
				}
				public String Item___Nom_sous_categorieDefault(){
				
					return null;
				
				}
				public String Item___Nom_sous_categorieComment(){
				
				    return "";
				
				}
				public String Item___Nom_sous_categoriePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___Nom_sous_categorieOriginalDbColumnName(){
				
					return "Item___Nom_sous_categorie";
				
				}

				
			    public String Item___Type_unite_manutention;

				public String getItem___Type_unite_manutention () {
					return this.Item___Type_unite_manutention;
				}

				public Boolean Item___Type_unite_manutentionIsNullable(){
				    return true;
				}
				public Boolean Item___Type_unite_manutentionIsKey(){
				    return false;
				}
				public Integer Item___Type_unite_manutentionLength(){
				    return 0;
				}
				public Integer Item___Type_unite_manutentionPrecision(){
				    return 0;
				}
				public String Item___Type_unite_manutentionDefault(){
				
					return null;
				
				}
				public String Item___Type_unite_manutentionComment(){
				
				    return "";
				
				}
				public String Item___Type_unite_manutentionPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___Type_unite_manutentionOriginalDbColumnName(){
				
					return "Item___Type_unite_manutention";
				
				}

				
			    public Double Item___Quantite;

				public Double getItem___Quantite () {
					return this.Item___Quantite;
				}

				public Boolean Item___QuantiteIsNullable(){
				    return true;
				}
				public Boolean Item___QuantiteIsKey(){
				    return false;
				}
				public Integer Item___QuantiteLength(){
				    return null;
				}
				public Integer Item___QuantitePrecision(){
				    return 0;
				}
				public String Item___QuantiteDefault(){
				
					return "";
				
				}
				public String Item___QuantiteComment(){
				
				    return "";
				
				}
				public String Item___QuantitePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Item___QuantiteOriginalDbColumnName(){
				
					return "Item___Quantite";
				
				}

				
			    public Integer Code_postal;

				public Integer getCode_postal () {
					return this.Code_postal;
				}

				public Boolean Code_postalIsNullable(){
				    return true;
				}
				public Boolean Code_postalIsKey(){
				    return false;
				}
				public Integer Code_postalLength(){
				    return 5;
				}
				public Integer Code_postalPrecision(){
				    return 0;
				}
				public String Code_postalDefault(){
				
					return "";
				
				}
				public String Code_postalComment(){
				
				    return "";
				
				}
				public String Code_postalPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String Code_postalOriginalDbColumnName(){
				
					return "Code_postal";
				
				}

				
			    public String sourceHubName;

				public String getSourceHubName () {
					return this.sourceHubName;
				}

				public Boolean sourceHubNameIsNullable(){
				    return true;
				}
				public Boolean sourceHubNameIsKey(){
				    return false;
				}
				public Integer sourceHubNameLength(){
				    return 150;
				}
				public Integer sourceHubNamePrecision(){
				    return 0;
				}
				public String sourceHubNameDefault(){
				
					return null;
				
				}
				public String sourceHubNameComment(){
				
				    return "";
				
				}
				public String sourceHubNamePattern(){
				
					return "";
				
				}
				public String sourceHubNameOriginalDbColumnName(){
				
					return "sourceHubName";
				
				}

				
			    public String Round_Name;

				public String getRound_Name () {
					return this.Round_Name;
				}

				public Boolean Round_NameIsNullable(){
				    return true;
				}
				public Boolean Round_NameIsKey(){
				    return false;
				}
				public Integer Round_NameLength(){
				    return null;
				}
				public Integer Round_NamePrecision(){
				    return null;
				}
				public String Round_NameDefault(){
				
					return null;
				
				}
				public String Round_NameComment(){
				
				    return "";
				
				}
				public String Round_NamePattern(){
				
					return "";
				
				}
				public String Round_NameOriginalDbColumnName(){
				
					return "Round_Name";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom_sous_categorie = readString(dis);
					
					this.Item___Type_unite_manutention = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.sourceHubName = readString(dis);
					
					this.Round_Name = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
					this.Activite = readString(dis);
					
					this.Categorie = readString(dis);
					
					this.Type_de_Service = readString(dis);
					
					this.ID_de_la_tache = readString(dis);
					
					this.Item___Nom_sous_categorie = readString(dis);
					
					this.Item___Type_unite_manutention = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Item___Quantite = null;
           				} else {
           			    	this.Item___Quantite = dis.readDouble();
           				}
					
						this.Code_postal = readInteger(dis);
					
					this.sourceHubName = readString(dis);
					
					this.Round_Name = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom_sous_categorie,dos);
					
					// String
				
						writeString(this.Item___Type_unite_manutention,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// String
				
						writeString(this.Activite,dos);
					
					// String
				
						writeString(this.Categorie,dos);
					
					// String
				
						writeString(this.Type_de_Service,dos);
					
					// String
				
						writeString(this.ID_de_la_tache,dos);
					
					// String
				
						writeString(this.Item___Nom_sous_categorie,dos);
					
					// String
				
						writeString(this.Item___Type_unite_manutention,dos);
					
					// Double
				
						if(this.Item___Quantite == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.Item___Quantite);
		            	}
					
					// Integer
				
						writeInteger(this.Code_postal,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.Round_Name,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",itemId="+itemId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",Activite="+Activite);
		sb.append(",Categorie="+Categorie);
		sb.append(",Type_de_Service="+Type_de_Service);
		sb.append(",ID_de_la_tache="+ID_de_la_tache);
		sb.append(",Item___Nom_sous_categorie="+Item___Nom_sous_categorie);
		sb.append(",Item___Type_unite_manutention="+Item___Type_unite_manutention);
		sb.append(",Item___Quantite="+String.valueOf(Item___Quantite));
		sb.append(",Code_postal="+String.valueOf(Code_postal));
		sb.append(",sourceHubName="+sourceHubName);
		sb.append(",Round_Name="+Round_Name);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(Activite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Activite);
            			}
            		
        			sb.append("|");
        		
        				if(Categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Type_de_Service == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Type_de_Service);
            			}
            		
        			sb.append("|");
        		
        				if(ID_de_la_tache == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ID_de_la_tache);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Nom_sous_categorie == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Nom_sous_categorie);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Type_unite_manutention == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Type_unite_manutention);
            			}
            		
        			sb.append("|");
        		
        				if(Item___Quantite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Item___Quantite);
            			}
            		
        			sb.append("|");
        		
        				if(Code_postal == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Code_postal);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHubName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHubName);
            			}
            		
        			sb.append("|");
        		
        				if(Round_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round_Name);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tFileInputExcel_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_1");
		org.slf4j.MDC.put("_subJobPid", "CBNTYq_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_1Process(globalMap);

		row7Struct row7 = new row7Struct();
out1Struct out1 = new out1Struct();
ALL_TASKSStruct ALL_TASKS = new ALL_TASKSStruct();





	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"mad_correction\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"mad_correction\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 2;
         if (updateKeyCount_tDBOutput_1 == 7 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "mad_correction";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "mad_correction" + "` (`roundId`,`taskId`,`quantity`,`date`,`expediteur`,`roundName`,`created_at`) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `quantity` = ?,`date` = ?,`expediteur` = ?,`roundName` = ?,`created_at` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */




	
	/**
	 * [tHashOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_1", false);
		start_Hash.put("tHashOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"ALL_TASKS");
			
		int tos_count_tHashOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashOutput_1", "tHashOutput_1", "tHashOutput");
				talendJobLogProcess(globalMap);
			}
			



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ALL_TASKSStruct> tHashFile_tHashOutput_1 = null;
		String hashKey_tHashOutput_1 = "tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid + "_tHashOutput_1";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_1)){
			    if(mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1) == null){
	      		    mf_tHashOutput_1.getResourceMap().put(hashKey_tHashOutput_1, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ALL_TASKSStruct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
			    }else{
			    	tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
			    }
			}
        int nb_line_tHashOutput_1 = 0;

 



/**
 * [tHashOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row7_tMap_1 = 0;
		
		int count_row4_tMap_1 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
					globalMap.get( "tHash_Lookup_row4" ))
					;					
					
	

row4Struct row4HashKey = new row4Struct();
row4Struct row4Default = new row4Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out1_tMap_1 = 0;
				
out1Struct out1_tmp = new out1Struct();
				int count_ALL_TASKS_tMap_1 = 0;
				
ALL_TASKSStruct ALL_TASKS_tmp = new ALL_TASKSStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";
	
	
		int tos_count_tFileInputExcel_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
                    log4jParamters_tFileInputExcel_1.append("Parameters:");
                            log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FILENAME" + " = " + "context.Server_In + context.ondemand_server_directory +  ((String)globalMap.get(\"transaction_id\")) + \"/\" +\"ToVerifyQTE_MAD_\"+context.Livraisons_Masque");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:4gEiqabBI1TLkuXzh1d/iK5J5DbXof0oHt/OpA==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMSELECT" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("Tournee")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("taskId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("itemId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Expediteur")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Activite")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Categorie")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Type_de_Service")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ID_de_la_tache")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Item___Nom_sous_categorie")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Item___Type_unite_manutention")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Item___Quantite")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Code_postal")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sourceHubName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Round_Name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("toDelete")+"}]");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + (log4jParamters_tFileInputExcel_1) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_1", "tFileInputExcel_1", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:MGY6M4nWn0rCKS6c81S0EkV/zgpJFI/SoeG9rg==");
        String password_tFileInputExcel_1 = decryptedPassword_tFileInputExcel_1;
        if (password_tFileInputExcel_1.isEmpty()){
            password_tFileInputExcel_1 = null;
        }
			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();

		Object source_tFileInputExcel_1 = context.Server_In + context.ondemand_server_directory +  ((String)globalMap.get("transaction_id")) + "/" +"ToVerifyQTE_MAD_"+context.Livraisons_Masque;
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_1 = null;
		
		if(source_tFileInputExcel_1 instanceof String){
			workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_1), password_tFileInputExcel_1, true);
		} else if(source_tFileInputExcel_1 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_1, password_tFileInputExcel_1);
		} else{
			workbook_tFileInputExcel_1 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
    	for(org.apache.poi.ss.usermodel.Sheet sheet_tFileInputExcel_1 : workbook_tFileInputExcel_1){
   			sheetList_tFileInputExcel_1.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet_tFileInputExcel_1);
    	}
    	if(sheetList_tFileInputExcel_1.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
			if(sheet_FilterNull_tFileInputExcel_1!=null && sheetList_FilterNull_tFileInputExcel_1.iterator()!=null && sheet_FilterNull_tFileInputExcel_1.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
			}
		}
		sheetList_tFileInputExcel_1 = sheetList_FilterNull_tFileInputExcel_1;
		int nb_line_tFileInputExcel_1 = 0;
	if(sheetList_tFileInputExcel_1.size()>0){

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
			end_line_tFileInputExcel_1+=(sheet_tFileInputExcel_1.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_1 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = (sheetList_tFileInputExcel_1.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = (sheet_tFileInputExcel_1.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getSheetName());
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
		    row7 = null;
					int tempRowLength_tFileInputExcel_1 = 16;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int excel_end_column_tFileInputExcel_1;
			if(row_tFileInputExcel_1==null){
				excel_end_column_tFileInputExcel_1=0;
			}else{
				excel_end_column_tFileInputExcel_1=row_tFileInputExcel_1.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_1;
			if(end_column_tFileInputExcel_1 == -1){
				actual_end_column_tFileInputExcel_1 = excel_end_column_tFileInputExcel_1;
			}
			else{
				actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	excel_end_column_tFileInputExcel_1 ? excel_end_column_tFileInputExcel_1 : end_column_tFileInputExcel_1;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_1 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){
				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1.getCell(i + start_column_tFileInputExcel_1);
					if(cell_tFileInputExcel_1!=null){
					switch (cell_tFileInputExcel_1.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
									temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_1[i] = df_tFileInputExcel_1.format(cell_tFileInputExcel_1.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_1.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
											temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_1 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_1.getNumericCellValue());
										temp_row_tFileInputExcel_1[i] = ne_tFileInputExcel_1.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_1[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_1[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_1[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_1 = false;
			row7 = new row7Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try{
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Tournee";

				row7.Tournee = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Tournee = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "taskId";

				row7.taskId = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.taskId = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 2;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "itemId";

				row7.itemId = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.itemId = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 3;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Date";

				row7.Date = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Date = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 4;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Expediteur";

				row7.Expediteur = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Expediteur = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 5;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Activite";

				row7.Activite = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Activite = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 6;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Categorie";

				row7.Categorie = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Categorie = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 7;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Type_de_Service";

				row7.Type_de_Service = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Type_de_Service = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 8;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_de_la_tache";

				row7.ID_de_la_tache = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.ID_de_la_tache = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 9;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Nom_sous_categorie";

				row7.Item___Nom_sous_categorie = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Item___Nom_sous_categorie = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 10;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Type_unite_manutention";

				row7.Item___Type_unite_manutention = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Item___Type_unite_manutention = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 11;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Item___Quantite";

				row7.Item___Quantite = ParserUtils.parseTo_Double(ParserUtils.parseTo_Number(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null, '.'==decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
			}else{
				row7.Item___Quantite = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 12;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Code_postal";

				row7.Code_postal = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null, '.'==decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
			}else{
				row7.Code_postal = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 13;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "sourceHubName";

				row7.sourceHubName = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.sourceHubName = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 14;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Round_Name";

				row7.Round_Name = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else{
				row7.Round_Name = null;
				emptyColumnCount_tFileInputExcel_1++;
			}
							columnIndex_tFileInputExcel_1 = 15;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "toDelete";

				row7.toDelete = ParserUtils.parseTo_Integer(ParserUtils.parseTo_Number(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1], null, '.'==decimalChar_tFileInputExcel_1 ? null : decimalChar_tFileInputExcel_1));
			}else{
				row7.toDelete = null;
				emptyColumnCount_tFileInputExcel_1++;
			}

				nb_line_tFileInputExcel_1++;
				
				log.debug("tFileInputExcel_1 - Retrieving the record " + (nb_line_tFileInputExcel_1) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_1 = true;
						log.error("tFileInputExcel_1 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row7 = null;
			}


		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tFileInputExcel_1","tFileInputExcel_1","tFileInputExcel","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
						row4Struct row4 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row4" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow4 = false;
       		  	    	
       		  	    	
 							row4Struct row4ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row4HashKey.roundId = row7.Tournee ;
                        		    		
                        		    		    row4HashKey.taskId = row7.taskId ;
                        		    		

								
		                        	row4HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row4.lookup( row4HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row4 != null && tHash_Lookup_row4.getCount(row4HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row4' and it contains more one result from keys :  row4.roundId = '" + row4HashKey.roundId + "', row4.taskId = '" + row4HashKey.taskId + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row4Struct fromLookup_row4 = null;
							row4 = row4Default;
										 
							
								 
							
							
								if (tHash_Lookup_row4 !=null && tHash_Lookup_row4.hasNext()) { // G 099
								
							
								
								fromLookup_row4 = tHash_Lookup_row4.next();

							
							
								} // G 099
							
							

							if(fromLookup_row4 != null) {
								row4 = fromLookup_row4;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out1 = null;
ALL_TASKS = null;


// # Output table : 'out1'
// # Filter conditions 
if( 

row7.Tournee != null

 ) {
count_out1_tMap_1++;

out1_tmp.roundId = row7.Tournee ;
out1_tmp.taskId = row7.taskId ;
out1_tmp.quantity = row7.Item___Quantite ;
out1_tmp.date = row7.Date ;
out1_tmp.expediteur = row7.Expediteur ;
out1_tmp.roundName = row7.Round_Name ;
out1_tmp.created_at = row4.taskId != null ? row4.created_at  : TalendDate.getCurrentDate() ;
out1 = out1_tmp;
log.debug("tMap_1 - Outputting the record " + count_out1_tMap_1 + " of the output table 'out1'.");

} // closing filter/reject

// # Output table : 'ALL_TASKS'
count_ALL_TASKS_tMap_1++;

ALL_TASKS_tmp.Tournee = row7.Tournee ;
ALL_TASKS_tmp.taskId = row7.taskId ;
ALL_TASKS_tmp.Date = row7.Date ;
ALL_TASKS_tmp.Expediteur = row7.Expediteur ;
ALL_TASKS_tmp.toDelete = row7.toDelete ;
ALL_TASKS = ALL_TASKS_tmp;
log.debug("tMap_1 - Outputting the record " + count_ALL_TASKS_tMap_1 + " of the output table 'ALL_TASKS'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"out1","tMap_1","tMap_1","tMap","tDBOutput_1","\"mad_correction\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    if(out1.roundId == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, out1.roundId);
}

                    if(out1.taskId == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, out1.taskId);
}

                    if(out1.quantity == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(3, out1.quantity);
}

                    if(out1.date == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, out1.date);
}

                    if(out1.expediteur == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, out1.expediteur);
}

                    if(out1.roundName == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, out1.roundName);
}

                    if(out1.created_at != null) {
date_tDBOutput_1 = out1.created_at.getTime();
if(date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
pstmt_tDBOutput_1.setString(7, "0000-00-00 00:00:00");
} else {pstmt_tDBOutput_1.setTimestamp(7, new java.sql.Timestamp(date_tDBOutput_1));
}
} else {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.DATE);
}

                    if(out1.quantity == null) {
pstmt_tDBOutput_1.setNull(8 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(8 + count_tDBOutput_1, out1.quantity);
}

                    if(out1.date == null) {
pstmt_tDBOutput_1.setNull(9 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9 + count_tDBOutput_1, out1.date);
}

                    if(out1.expediteur == null) {
pstmt_tDBOutput_1.setNull(10 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10 + count_tDBOutput_1, out1.expediteur);
}

                    if(out1.roundName == null) {
pstmt_tDBOutput_1.setNull(11 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11 + count_tDBOutput_1, out1.roundName);
}

                    if(out1.created_at != null) {
pstmt_tDBOutput_1.setTimestamp(12 + count_tDBOutput_1, new java.sql.Timestamp(out1.created_at.getTime()));
} else {
pstmt_tDBOutput_1.setNull(12 + count_tDBOutput_1, java.sql.Types.TIMESTAMP);
}

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
            log.error("tDBOutput_1 - "  + (e.getMessage()) );
                        System.err.print(e.getMessage());
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "out1"




// Start of branch "ALL_TASKS"
if(ALL_TASKS != null) { 



	
	/**
	 * [tHashOutput_1 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"ALL_TASKS","tMap_1","tMap_1","tMap","tHashOutput_1","tHashOutput_1","tHashOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("ALL_TASKS - " + (ALL_TASKS==null? "": ALL_TASKS.toLogString()));
    			}
    		



    
		ALL_TASKSStruct oneRow_tHashOutput_1 = new ALL_TASKSStruct();
				
					oneRow_tHashOutput_1.Tournee = ALL_TASKS.Tournee;
					oneRow_tHashOutput_1.taskId = ALL_TASKS.taskId;
					oneRow_tHashOutput_1.Date = ALL_TASKS.Date;
					oneRow_tHashOutput_1.Expediteur = ALL_TASKS.Expediteur;
					oneRow_tHashOutput_1.toDelete = ALL_TASKS.toDelete;
		
        tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
        nb_line_tHashOutput_1 ++;

 


	tos_count_tHashOutput_1++;

/**
 * [tHashOutput_1 main ] stop
 */
	
	/**
	 * [tHashOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tHashOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 process_data_end ] stop
 */

} // End of branch "ALL_TASKS"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	

			}
			
			
				log.debug("tFileInputExcel_1 - Retrieved records count: "+ nb_line_tFileInputExcel_1 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
		} finally {
				
  				if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_1.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row4 != null) {
						tHash_Lookup_row4.endGet();
					}
					globalMap.remove( "tHash_Lookup_row4" );

					
					
				
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out1': " + count_out1_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'ALL_TASKS': " + count_ALL_TASKS_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tFileInputExcel_1","tFileInputExcel_1","tFileInputExcel","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out1",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","\"mad_correction\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */




	
	/**
	 * [tHashOutput_1 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	
globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"ALL_TASKS",2,0,
			 			"tMap_1","tMap_1","tMap","tHashOutput_1","tHashOutput_1","tHashOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tHashOutput_1", true);
end_Hash.put("tHashOutput_1", System.currentTimeMillis());




/**
 * [tHashOutput_1 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tHashInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row4"); 
				     			
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"mad_correction\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */




	
	/**
	 * [tHashOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";
	
	

 



/**
 * [tHashOutput_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	


public static class TO_DELETEStruct implements routines.system.IPersistableRow<TO_DELETEStruct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return false;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 50;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return true;
				}
				public Integer taskIdLength(){
				    return 50;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
						result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final TO_DELETEStruct other = (TO_DELETEStruct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					
						if (this.taskId == null) {
							if (other.taskId != null)
								return false;
						
						} else if (!this.taskId.equals(other.taskId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(TO_DELETEStruct other) {

		other.roundId = this.roundId;
	            other.taskId = this.taskId;
	            
	}

	public void copyKeysDataTo(TO_DELETEStruct other) {

		other.roundId = this.roundId;
	            	other.taskId = this.taskId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",taskId="+taskId);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(TO_DELETEStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.taskId, other.taskId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tHashInput_1Struct implements routines.system.IPersistableRow<after_tHashInput_1Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];

	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				
			    public Integer toDelete;

				public Integer getToDelete () {
					return this.toDelete;
				}

				public Boolean toDeleteIsNullable(){
				    return true;
				}
				public Boolean toDeleteIsKey(){
				    return false;
				}
				public Integer toDeleteLength(){
				    return null;
				}
				public Integer toDeletePrecision(){
				    return null;
				}
				public String toDeleteDefault(){
				
					return null;
				
				}
				public String toDeleteComment(){
				
				    return "";
				
				}
				public String toDeletePattern(){
				
					return "";
				
				}
				public String toDeleteOriginalDbColumnName(){
				
					return "toDelete";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.taskId = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
						this.toDelete = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
					// Integer
				
						writeInteger(this.toDelete,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
		sb.append(",toDelete="+String.valueOf(toDelete));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        				if(toDelete == null){
        					sb.append("<null>");
        				}else{
            				sb.append(toDelete);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_tHashInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_1");
		org.slf4j.MDC.put("_subJobPid", "WfYi6a_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tHashInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
row2Struct row2 = new row2Struct();
TO_DELETEStruct TO_DELETE = new TO_DELETEStruct();






	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"TO_DELETE");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"mad_correction\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "DELETE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"mad_correction\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int deleteKeyCount_tDBOutput_2 = 2;
        if(deleteKeyCount_tDBOutput_2 < 1) {
            throw new RuntimeException("For delete, Schema must have a key");
        }

int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

String tableName_tDBOutput_2 = "mad_correction";
boolean whetherReject_tDBOutput_2 = false;

java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
long date_tDBOutput_2;

java.sql.Connection conn_tDBOutput_2 = null;
		conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );
		int batchSize_tDBOutput_2 = 10000;
		int batchSizeCounter_tDBOutput_2=0;
	

		int count_tDBOutput_2=0;
		
				
			
				String delete_tDBOutput_2 = "DELETE FROM `" + "mad_correction" + "` WHERE `roundId` = ? AND `taskId` = ?";
				
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(delete_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
				


 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_2 = new StringBuilder();
                    log4jParamters_tMap_2.append("Parameters:");
                            log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
                    } 
                } 
            new BytesLimit65535_tMap_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row2_tMap_2 = 0;
		
		int count_row3_tMap_2 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
					globalMap.get( "tHash_Lookup_row3" ))
					;					
					
	

row3Struct row3HashKey = new row3Struct();
row3Struct row3Default = new row3Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_TO_DELETE_tMap_2 = 0;
				
TO_DELETEStruct TO_DELETE_tmp = new TO_DELETEStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tFilterRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_3", false);
		start_Hash.put("tFilterRow_3", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tFilterRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFilterRow_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFilterRow_3 = new StringBuilder();
                    log4jParamters_tFilterRow_3.append("Parameters:");
                            log4jParamters_tFilterRow_3.append("LOGICAL_OP" + " = " + "&&");
                        log4jParamters_tFilterRow_3.append(" | ");
                            log4jParamters_tFilterRow_3.append("CONDITIONS" + " = " + "[{OPERATOR="+("==")+", RVALUE="+("1")+", INPUT_COLUMN="+("toDelete")+", FUNCTION="+("")+"}]");
                        log4jParamters_tFilterRow_3.append(" | ");
                            log4jParamters_tFilterRow_3.append("USE_ADVANCED" + " = " + "false");
                        log4jParamters_tFilterRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_3 - "  + (log4jParamters_tFilterRow_3) );
                    } 
                } 
            new BytesLimit65535_tFilterRow_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_3", "tFilterRow_1", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_3 = 0;
    int nb_line_ok_tFilterRow_3 = 0;
    int nb_line_reject_tFilterRow_3 = 0;

    class Operator_tFilterRow_3 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_3(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_3 begin ] stop
 */



	
	/**
	 * [tHashInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_1", false);
		start_Hash.put("tHashInput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_1";
	
	
		int tos_count_tHashInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_1", "tHashInput_1", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_1 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ALL_TASKSStruct> tHashFile_tHashInput_1 = mf_tHashInput_1.getAdvancedMemoryHashFile("tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid +"_tHashOutput_1");
if(tHashFile_tHashInput_1==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<ALL_TASKSStruct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
while (iterator_tHashInput_1.hasNext()) {
    ALL_TASKSStruct next_tHashInput_1 = iterator_tHashInput_1.next();

	row1.Tournee = next_tHashInput_1.Tournee;
	row1.taskId = next_tHashInput_1.taskId;
	row1.Date = next_tHashInput_1.Date;
	row1.Expediteur = next_tHashInput_1.Expediteur;
	row1.toDelete = next_tHashInput_1.toDelete;

 



/**
 * [tHashInput_1 begin ] stop
 */
	
	/**
	 * [tHashInput_1 main ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 


	tos_count_tHashInput_1++;

/**
 * [tHashInput_1 main ] stop
 */
	
	/**
	 * [tHashInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tFilterRow_3 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tHashInput_1","tHashInput_1","tHashInput","tFilterRow_3","tFilterRow_1","tFilterRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

          row2 = null;
    Operator_tFilterRow_3 ope_tFilterRow_3 = new Operator_tFilterRow_3("&&");
            ope_tFilterRow_3.matches((row1.toDelete == null? false : row1.toDelete.compareTo(ParserUtils.parseTo_Integer(String.valueOf(1))) == 0)
                           , "toDelete.compareTo(1) == 0 failed");
		 	
    
    if (ope_tFilterRow_3.getMatchFlag()) {
              if(row2 == null){ 
                row2 = new row2Struct();
              }
               row2.Tournee = row1.Tournee;
               row2.taskId = row1.taskId;
               row2.Date = row1.Date;
               row2.Expediteur = row1.Expediteur;
               row2.toDelete = row1.toDelete;
					log.debug("tFilterRow_3 - Process the record " + (nb_line_tFilterRow_3+1) + ".");
					    
      nb_line_ok_tFilterRow_3++;
    } else {
      nb_line_reject_tFilterRow_3++;
    }

nb_line_tFilterRow_3++;

 


	tos_count_tFilterRow_3++;

/**
 * [tFilterRow_3 main ] stop
 */
	
	/**
	 * [tFilterRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";
	
	

 



/**
 * [tFilterRow_3 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tFilterRow_3","tFilterRow_1","tFilterRow","tMap_2","tMap_2","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
						row3Struct row3 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_2 = false;
		boolean mainRowRejected_tMap_2 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row3" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow3 = false;
       		  	    	
       		  	    	
 							row3Struct row3ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_2) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_2 = false;
								
                        		    		    row3HashKey.Tournee = row2.Tournee ;
                        		    		
                        		    		    row3HashKey.Date = row2.Date ;
                        		    		
                        		    		    row3HashKey.Expediteur = row2.Expediteur ;
                        		    		

								
		                        	row3HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row3.lookup( row3HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row3.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_2 = true;
	  								
						
									
	
		  								forceLooprow3 = true;
	  					
  									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
								
								else { // G 20 - G 21
   									forceLooprow3 = true;
			           		  	} // G 21
                    		  	
                    		

							
                    		  	 
							

								while ((tHash_Lookup_row3 != null && tHash_Lookup_row3.hasNext()) || forceLooprow3) { // G_TM_M_043

								
									 // CALL close loop of lookup 'row3'
									
                    		  	 
							   
                    		  	 
	       		  	    	row3Struct fromLookup_row3 = null;
							row3 = row3Default;
										 
							
								
								if(!forceLooprow3) { // G 46
								
							
								 
							
								
								fromLookup_row3 = tHash_Lookup_row3.next();

							

							if(fromLookup_row3 != null) {
								row3 = fromLookup_row3;
							}
							
							
							
			  							
								
	                    		  	
		                    
	                    	
	                    		} // G 46
	                    		  	
								forceLooprow3 = false;
									 	
							
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

TO_DELETE = null;

if(!rejectedInnerJoin_tMap_2 ) {

// # Output table : 'TO_DELETE'
count_TO_DELETE_tMap_2++;

TO_DELETE_tmp.roundId = row3.Tournee ;
TO_DELETE_tmp.taskId = row3.taskId ;
TO_DELETE = TO_DELETE_tmp;
log.debug("tMap_2 - Outputting the record " + count_TO_DELETE_tMap_2 + " of the output table 'TO_DELETE'.");

}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "TO_DELETE"
if(TO_DELETE != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"TO_DELETE","tMap_2","tMap_2","tMap","tDBOutput_2","\"mad_correction\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("TO_DELETE - " + (TO_DELETE==null? "": TO_DELETE.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    if(TO_DELETE.roundId == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, TO_DELETE.roundId);
}

                    if(TO_DELETE.taskId == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, TO_DELETE.taskId);
}

            pstmt_tDBOutput_2.addBatch();
            nb_line_tDBOutput_2++;
            	
            	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("DELETE")  + (" batch.") );
              batchSizeCounter_tDBOutput_2++;
                if ( batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
                        try {
                                int countSum_tDBOutput_2 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("DELETE")  + (" batch.") );
                                for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
                                    countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                                }
                                rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("DELETE")  + (" batch execution has succeeded.") );
                                deletedCount_tDBOutput_2 += countSum_tDBOutput_2;
                                batchSizeCounter_tDBOutput_2 = 0;
                        }catch (java.sql.BatchUpdateException e){
                            globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                            int countSum_tDBOutput_2 = 0;
                            for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
                                countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
                            }
                            rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
                            deletedCount_tDBOutput_2 += countSum_tDBOutput_2;
                            System.err.println(e.getMessage());
            log.error("tDBOutput_2 - "  + (e.getMessage()) );
                        }
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "TO_DELETE"



	
		} // close loop of lookup 'row3' // G_TM_M_043
	
	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFilterRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";
	
	

 



/**
 * [tFilterRow_3 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_1 end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	
    

		
			nb_line_tHashInput_1++;
		}	
    		
    		mf_tHashInput_1.clearCache("tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid +"_tHashOutput_1");
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid +"_tHashOutput_1");
	


	globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);       

 

ok_Hash.put("tHashInput_1", true);
end_Hash.put("tHashInput_1", System.currentTimeMillis());




/**
 * [tHashInput_1 end ] stop
 */

	
	/**
	 * [tFilterRow_3 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";
	
	
    globalMap.put("tFilterRow_3_NB_LINE", nb_line_tFilterRow_3);
    globalMap.put("tFilterRow_3_NB_LINE_OK", nb_line_ok_tFilterRow_3);
    globalMap.put("tFilterRow_3_NB_LINE_REJECT", nb_line_reject_tFilterRow_3);
    
    	log.info("tFilterRow_3 - Processed records count:" + nb_line_tFilterRow_3 + ". Matched records count:" + nb_line_ok_tFilterRow_3 + ". Rejected records count:" + nb_line_reject_tFilterRow_3 + ".");

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tHashInput_1","tHashInput_1","tHashInput","tFilterRow_3","tFilterRow_1","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_3 - "  + ("Done.") );

ok_Hash.put("tFilterRow_3", true);
end_Hash.put("tFilterRow_3", System.currentTimeMillis());




/**
 * [tFilterRow_3 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row3 != null) {
						tHash_Lookup_row3.endGet();
					}
					globalMap.remove( "tHash_Lookup_row3" );

					
					
				
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'TO_DELETE': " + count_TO_DELETE_tMap_2 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tFilterRow_3","tFilterRow_1","tFilterRow","tMap_2","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		



		
			try {
				if(pstmt_tDBOutput_2 != null){
					int countSum_tDBOutput_2 = 0;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("DELETE")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("DELETE")  + (" batch execution has succeeded.") );
					
						deletedCount_tDBOutput_2 += countSum_tDBOutput_2;
					
				}
			}catch (java.sql.BatchUpdateException e){
				globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
				
					int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
						deletedCount_tDBOutput_2 += countSum_tDBOutput_2;
						
            log.error("tDBOutput_2 - "  + (e.getMessage()) );
					System.err.println(e.getMessage());
					
			}
			

		if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_2", true);
	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("deleted")  + (" ")  + (nb_line_deleted_tDBOutput_2)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"TO_DELETE",2,0,
			 			"tMap_2","tMap_2","tMap","tDBOutput_2","\"mad_correction\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_2"
					     			globalMap.remove("tHash_Lookup_row3"); 
				     			
				try{
					
	
	/**
	 * [tHashInput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_1";
	
	

 



/**
 * [tHashInput_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_3 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_3";
	
	

 



/**
 * [tFilterRow_3 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mad_correction\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return false;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 50;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return true;
				}
				public Integer taskIdLength(){
				    return 50;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return 22;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public java.util.Date created_at;

				public java.util.Date getCreated_at () {
					return this.created_at;
				}

				public Boolean created_atIsNullable(){
				    return true;
				}
				public Boolean created_atIsKey(){
				    return false;
				}
				public Integer created_atLength(){
				    return null;
				}
				public Integer created_atPrecision(){
				    return null;
				}
				public String created_atDefault(){
				
					return null;
				
				}
				public String created_atComment(){
				
				    return "";
				
				}
				public String created_atPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_atOriginalDbColumnName(){
				
					return "created_at";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
						result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					
						if (this.taskId == null) {
							if (other.taskId != null)
								return false;
						
						} else if (!this.taskId.equals(other.taskId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.roundId = this.roundId;
	            other.taskId = this.taskId;
	            other.quantity = this.quantity;
	            other.created_at = this.created_at;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.roundId = this.roundId;
	            	other.taskId = this.taskId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller ) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

	private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
	}
	
	private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.taskId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
						this.created_at = readDate(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = objectIn.readDouble();
           				}
					
						this.created_at = readDate(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
						writeDate(this.created_at, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						if(this.quantity == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeDouble(this.quantity);
		            	}
					
						writeDate(this.created_at, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",taskId="+taskId);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",created_at="+String.valueOf(created_at));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(created_at == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_at);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.taskId, other.taskId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "MwJjgy_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tAdvancedHash_row4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row4", false);
		start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tAdvancedHash_row4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row4", "tAdvancedHash_row4", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row4
			   		// source node:tDBInput_1 - inputs:(after_tFileInputExcel_1) outputs:(row4,row4) | target node:tAdvancedHash_row4 - inputs:(row4) outputs:()
			   		// linked node: tMap_1 - inputs:(row7,row4) outputs:(out1,ALL_TASKS)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row4Struct>getLookup(matchingModeEnum_row4);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row4 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"mad_correction\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `mad_correction`.`roundId`,    `mad_correction`.`taskId`,    `mad_correction`.`quantity`,    `mad_correction`.`created_at` FROM `mad_correction`\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("roundId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("taskId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("quantity")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_at")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"mad_correction\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  `mad_correction`.`roundId`, \n  `mad_correction`.`taskId`, \n  `mad_correction`.`quantity`, \n  `mad_correction`"
+".`created_at`\nFROM `mad_correction`";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

		    globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);

		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row4.roundId = null;
							} else {
	                         		
        	row4.roundId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row4.taskId = null;
							} else {
	                         		
        	row4.taskId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row4.quantity = null;
							} else {
	                         		
            row4.quantity = rs_tDBInput_1.getDouble(3);
            if(rs_tDBInput_1.wasNull()){
                    row4.quantity = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row4.created_at = null;
							} else {
										
				if(rs_tDBInput_1.getString(4) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(4);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row4.created_at = rs_tDBInput_1.getTimestamp(4);
					} else {
						row4.created_at = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row4.created_at =  null;
				}
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_1","\"mad_correction\"","tMysqlInput","tAdvancedHash_row4","tAdvancedHash_row4","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		


			   
			   

					row4Struct row4_HashRow = new row4Struct();
		   	   	   
				
				row4_HashRow.roundId = row4.roundId;
				
				row4_HashRow.taskId = row4.taskId;
				
				row4_HashRow.quantity = row4.quantity;
				
				row4_HashRow.created_at = row4.created_at;
				
			tHash_Lookup_row4.put(row4_HashRow);
			
            




 


	tos_count_tAdvancedHash_row4++;

/**
 * [tAdvancedHash_row4 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";
	
	

 



/**
 * [tAdvancedHash_row4 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";
	
	

 



/**
 * [tAdvancedHash_row4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";
	
	

tHash_Lookup_row4.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_1","\"mad_correction\"","tMysqlInput","tAdvancedHash_row4","tAdvancedHash_row4","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row4", true);
end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());




/**
 * [tAdvancedHash_row4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mad_correction\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";
	
	

 



/**
 * [tAdvancedHash_row4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableComparableLookupRow<row3Struct> {
    final static byte[] commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
    static byte[] commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String Tournee;

				public String getTournee () {
					return this.Tournee;
				}

				public Boolean TourneeIsNullable(){
				    return true;
				}
				public Boolean TourneeIsKey(){
				    return false;
				}
				public Integer TourneeLength(){
				    return 5;
				}
				public Integer TourneePrecision(){
				    return 0;
				}
				public String TourneeDefault(){
				
					return null;
				
				}
				public String TourneeComment(){
				
				    return "";
				
				}
				public String TourneePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TourneeOriginalDbColumnName(){
				
					return "Tournee";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return false;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 255;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String Date;

				public String getDate () {
					return this.Date;
				}

				public Boolean DateIsNullable(){
				    return true;
				}
				public Boolean DateIsKey(){
				    return false;
				}
				public Integer DateLength(){
				    return 10;
				}
				public Integer DatePrecision(){
				    return 0;
				}
				public String DateDefault(){
				
					return null;
				
				}
				public String DateComment(){
				
				    return "";
				
				}
				public String DatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOriginalDbColumnName(){
				
					return "Date";
				
				}

				
			    public String Expediteur;

				public String getExpediteur () {
					return this.Expediteur;
				}

				public Boolean ExpediteurIsNullable(){
				    return true;
				}
				public Boolean ExpediteurIsKey(){
				    return false;
				}
				public Integer ExpediteurLength(){
				    return 28;
				}
				public Integer ExpediteurPrecision(){
				    return 0;
				}
				public String ExpediteurDefault(){
				
					return null;
				
				}
				public String ExpediteurComment(){
				
				    return "";
				
				}
				public String ExpediteurPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpediteurOriginalDbColumnName(){
				
					return "Expediteur";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.Tournee == null) ? 0 : this.Tournee.hashCode());
					
						result = prime * result + ((this.Date == null) ? 0 : this.Date.hashCode());
					
						result = prime * result + ((this.Expediteur == null) ? 0 : this.Expediteur.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.Tournee == null) {
							if (other.Tournee != null)
								return false;
						
						} else if (!this.Tournee.equals(other.Tournee))
						
							return false;
					
						if (this.Date == null) {
							if (other.Date != null)
								return false;
						
						} else if (!this.Date.equals(other.Date))
						
							return false;
					
						if (this.Expediteur == null) {
							if (other.Expediteur != null)
								return false;
						
						} else if (!this.Expediteur.equals(other.Expediteur))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.Tournee = this.Tournee;
	            other.taskId = this.taskId;
	            other.Date = this.Date;
	            other.Expediteur = this.Expediteur;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.Tournee = this.Tournee;
	            	other.Date = this.Date;
	            	other.Expediteur = this.Expediteur;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length) {
				if(length < 1024 && commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.length == 0) {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[1024];
				} else {
   					commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length);
			strReturn = new String(commonByteArray_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_CAJOO_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1) {

        	try {

        		int length = 0;
		
					this.Tournee = readString(dis);
					
					this.Date = readString(dis);
					
					this.Expediteur = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Tournee,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.Expediteur,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.taskId = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.taskId = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.taskId, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.taskId, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Tournee="+Tournee);
		sb.append(",taskId="+taskId);
		sb.append(",Date="+Date);
		sb.append(",Expediteur="+Expediteur);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Tournee == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Tournee);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(Date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Date);
            			}
            		
        			sb.append("|");
        		
        				if(Expediteur == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Expediteur);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Tournee, other.Tournee);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.Date, other.Date);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.Expediteur, other.Expediteur);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tHashInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_2");
		org.slf4j.MDC.put("_subJobPid", "fVYaqf_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tAdvancedHash_row3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row3", false);
		start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tAdvancedHash_row3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row3", "tAdvancedHash_row3", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row3
			   		// source node:tHashInput_2 - inputs:(after_tHashInput_1) outputs:(row3,row3) | target node:tAdvancedHash_row3 - inputs:(row3) outputs:()
			   		// linked node: tMap_2 - inputs:(row2,row3) outputs:(TO_DELETE)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_MATCHES;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row3Struct>getLookup(matchingModeEnum_row3);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row3 begin ] stop
 */



	
	/**
	 * [tHashInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_2", false);
		start_Hash.put("tHashInput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_2";
	
	
		int tos_count_tHashInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tHashInput_2", "tHashInput_2", "tHashInput");
				talendJobLogProcess(globalMap);
			}
			


int nb_line_tHashInput_2 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ALL_TASKSStruct> tHashFile_tHashInput_2 = mf_tHashInput_2.getAdvancedMemoryHashFile("tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid +"_tHashOutput_1");
if(tHashFile_tHashInput_2==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<ALL_TASKSStruct> iterator_tHashInput_2 = tHashFile_tHashInput_2.iterator();
while (iterator_tHashInput_2.hasNext()) {
    ALL_TASKSStruct next_tHashInput_2 = iterator_tHashInput_2.next();

	row3.Tournee = next_tHashInput_2.Tournee;
	row3.taskId = next_tHashInput_2.taskId;
	row3.Date = next_tHashInput_2.Date;
	row3.Expediteur = next_tHashInput_2.Expediteur;

 



/**
 * [tHashInput_2 begin ] stop
 */
	
	/**
	 * [tHashInput_2 main ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 


	tos_count_tHashInput_2++;

/**
 * [tHashInput_2 main ] stop
 */
	
	/**
	 * [tHashInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tHashInput_2","tHashInput_2","tHashInput","tAdvancedHash_row3","tAdvancedHash_row3","tAdvancedHash"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		


			   
			   

					row3Struct row3_HashRow = new row3Struct();
		   	   	   
				
				row3_HashRow.Tournee = row3.Tournee;
				
				row3_HashRow.taskId = row3.taskId;
				
				row3_HashRow.Date = row3.Date;
				
				row3_HashRow.Expediteur = row3.Expediteur;
				
			tHash_Lookup_row3.put(row3_HashRow);
			
            




 


	tos_count_tAdvancedHash_row3++;

/**
 * [tAdvancedHash_row3 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 process_data_end ] stop
 */



	
	/**
	 * [tHashInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 process_data_end ] stop
 */
	
	/**
	 * [tHashInput_2 end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	
    

		
			nb_line_tHashInput_2++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1_" + pid +"_tHashOutput_1");
	


	globalMap.put("tHashInput_2_NB_LINE", nb_line_tHashInput_2);       

 

ok_Hash.put("tHashInput_2", true);
end_Hash.put("tHashInput_2", System.currentTimeMillis());




/**
 * [tHashInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

tHash_Lookup_row3.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tHashInput_2","tHashInput_2","tHashInput","tAdvancedHash_row3","tAdvancedHash_row3","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row3", true);
end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());




/**
 * [tAdvancedHash_row3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_2";
	
	

 



/**
 * [tHashInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "fRGL8e_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1 URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1Class = new URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1();

        int exitCode = URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_XrfksHOEEeyMP6NhmRAVjA");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-04-17T08:59:34.858155600Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.class.getClassLoader().getResourceAsStream("cajoo/urbantz_to_hub_mad_correction_prod_v1_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("ODS_Database", "id_String");
                        if(context.getStringValue("ODS_Database") == null) {
                            context.ODS_Database = null;
                        } else {
                            context.ODS_Database=(String) context.getProperty("ODS_Database");
                        }
                        context.setContextType("PBI_Database", "id_String");
                        if(context.getStringValue("PBI_Database") == null) {
                            context.PBI_Database = null;
                        } else {
                            context.PBI_Database=(String) context.getProperty("PBI_Database");
                        }
                        context.setContextType("PBI_RT_Database", "id_String");
                        if(context.getStringValue("PBI_RT_Database") == null) {
                            context.PBI_RT_Database = null;
                        } else {
                            context.PBI_RT_Database=(String) context.getProperty("PBI_RT_Database");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("Clients_Masque", "id_String");
                        if(context.getStringValue("Clients_Masque") == null) {
                            context.Clients_Masque = null;
                        } else {
                            context.Clients_Masque=(String) context.getProperty("Clients_Masque");
                        }
                        context.setContextType("Code_client_masque", "id_String");
                        if(context.getStringValue("Code_client_masque") == null) {
                            context.Code_client_masque = null;
                        } else {
                            context.Code_client_masque=(String) context.getProperty("Code_client_masque");
                        }
                        context.setContextType("Command_Logistic_Invalid_Date", "id_String");
                        if(context.getStringValue("Command_Logistic_Invalid_Date") == null) {
                            context.Command_Logistic_Invalid_Date = null;
                        } else {
                            context.Command_Logistic_Invalid_Date=(String) context.getProperty("Command_Logistic_Invalid_Date");
                        }
                        context.setContextType("Command_Logistic_Masque", "id_String");
                        if(context.getStringValue("Command_Logistic_Masque") == null) {
                            context.Command_Logistic_Masque = null;
                        } else {
                            context.Command_Logistic_Masque=(String) context.getProperty("Command_Logistic_Masque");
                        }
                        context.setContextType("Command_Transport_Masque", "id_String");
                        if(context.getStringValue("Command_Transport_Masque") == null) {
                            context.Command_Transport_Masque = null;
                        } else {
                            context.Command_Transport_Masque=(String) context.getProperty("Command_Transport_Masque");
                        }
                        context.setContextType("Command_Transport_Masque_Express", "id_String");
                        if(context.getStringValue("Command_Transport_Masque_Express") == null) {
                            context.Command_Transport_Masque_Express = null;
                        } else {
                            context.Command_Transport_Masque_Express=(String) context.getProperty("Command_Transport_Masque_Express");
                        }
                        context.setContextType("Ecolotrans_JP", "id_String");
                        if(context.getStringValue("Ecolotrans_JP") == null) {
                            context.Ecolotrans_JP = null;
                        } else {
                            context.Ecolotrans_JP=(String) context.getProperty("Ecolotrans_JP");
                        }
                        context.setContextType("Holiday_Days_Masque", "id_String");
                        if(context.getStringValue("Holiday_Days_Masque") == null) {
                            context.Holiday_Days_Masque = null;
                        } else {
                            context.Holiday_Days_Masque=(String) context.getProperty("Holiday_Days_Masque");
                        }
                        context.setContextType("Livraisons_Exception", "id_String");
                        if(context.getStringValue("Livraisons_Exception") == null) {
                            context.Livraisons_Exception = null;
                        } else {
                            context.Livraisons_Exception=(String) context.getProperty("Livraisons_Exception");
                        }
                        context.setContextType("Livraisons_Masque", "id_String");
                        if(context.getStringValue("Livraisons_Masque") == null) {
                            context.Livraisons_Masque = null;
                        } else {
                            context.Livraisons_Masque=(String) context.getProperty("Livraisons_Masque");
                        }
                        context.setContextType("Livraisons_Ok", "id_String");
                        if(context.getStringValue("Livraisons_Ok") == null) {
                            context.Livraisons_Ok = null;
                        } else {
                            context.Livraisons_Ok=(String) context.getProperty("Livraisons_Ok");
                        }
                        context.setContextType("ST_Drivers", "id_String");
                        if(context.getStringValue("ST_Drivers") == null) {
                            context.ST_Drivers = null;
                        } else {
                            context.ST_Drivers=(String) context.getProperty("ST_Drivers");
                        }
                        context.setContextType("Tarification_Logistic_Masque", "id_String");
                        if(context.getStringValue("Tarification_Logistic_Masque") == null) {
                            context.Tarification_Logistic_Masque = null;
                        } else {
                            context.Tarification_Logistic_Masque=(String) context.getProperty("Tarification_Logistic_Masque");
                        }
                        context.setContextType("Tarification_Transport_Masque", "id_String");
                        if(context.getStringValue("Tarification_Transport_Masque") == null) {
                            context.Tarification_Transport_Masque = null;
                        } else {
                            context.Tarification_Transport_Masque=(String) context.getProperty("Tarification_Transport_Masque");
                        }
                        context.setContextType("Tournee_Masque", "id_String");
                        if(context.getStringValue("Tournee_Masque") == null) {
                            context.Tournee_Masque = null;
                        } else {
                            context.Tournee_Masque=(String) context.getProperty("Tournee_Masque");
                        }
                        context.setContextType("TVA_Exceptions", "id_String");
                        if(context.getStringValue("TVA_Exceptions") == null) {
                            context.TVA_Exceptions = null;
                        } else {
                            context.TVA_Exceptions=(String) context.getProperty("TVA_Exceptions");
                        }
                        context.setContextType("Backup", "id_String");
                        if(context.getStringValue("Backup") == null) {
                            context.Backup = null;
                        } else {
                            context.Backup=(String) context.getProperty("Backup");
                        }
                        context.setContextType("Server_Clean", "id_String");
                        if(context.getStringValue("Server_Clean") == null) {
                            context.Server_Clean = null;
                        } else {
                            context.Server_Clean=(String) context.getProperty("Server_Clean");
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Server_Out", "id_String");
                        if(context.getStringValue("Server_Out") == null) {
                            context.Server_Out = null;
                        } else {
                            context.Server_Out=(String) context.getProperty("Server_Out");
                        }
                        context.setContextType("Server_Out_DataMart", "id_String");
                        if(context.getStringValue("Server_Out_DataMart") == null) {
                            context.Server_Out_DataMart = null;
                        } else {
                            context.Server_Out_DataMart=(String) context.getProperty("Server_Out_DataMart");
                        }
                        context.setContextType("transaction_id", "id_String");
                        if(context.getStringValue("transaction_id") == null) {
                            context.transaction_id = null;
                        } else {
                            context.transaction_id=(String) context.getProperty("transaction_id");
                        }
                        context.setContextType("ondemand_server_directory", "id_String");
                        if(context.getStringValue("ondemand_server_directory") == null) {
                            context.ondemand_server_directory = null;
                        } else {
                            context.ondemand_server_directory=(String) context.getProperty("ondemand_server_directory");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("ODS_Database")) {
                context.ODS_Database = (String) parentContextMap.get("ODS_Database");
            }if (parentContextMap.containsKey("PBI_Database")) {
                context.PBI_Database = (String) parentContextMap.get("PBI_Database");
            }if (parentContextMap.containsKey("PBI_RT_Database")) {
                context.PBI_RT_Database = (String) parentContextMap.get("PBI_RT_Database");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("Clients_Masque")) {
                context.Clients_Masque = (String) parentContextMap.get("Clients_Masque");
            }if (parentContextMap.containsKey("Code_client_masque")) {
                context.Code_client_masque = (String) parentContextMap.get("Code_client_masque");
            }if (parentContextMap.containsKey("Command_Logistic_Invalid_Date")) {
                context.Command_Logistic_Invalid_Date = (String) parentContextMap.get("Command_Logistic_Invalid_Date");
            }if (parentContextMap.containsKey("Command_Logistic_Masque")) {
                context.Command_Logistic_Masque = (String) parentContextMap.get("Command_Logistic_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque")) {
                context.Command_Transport_Masque = (String) parentContextMap.get("Command_Transport_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque_Express")) {
                context.Command_Transport_Masque_Express = (String) parentContextMap.get("Command_Transport_Masque_Express");
            }if (parentContextMap.containsKey("Ecolotrans_JP")) {
                context.Ecolotrans_JP = (String) parentContextMap.get("Ecolotrans_JP");
            }if (parentContextMap.containsKey("Holiday_Days_Masque")) {
                context.Holiday_Days_Masque = (String) parentContextMap.get("Holiday_Days_Masque");
            }if (parentContextMap.containsKey("Livraisons_Exception")) {
                context.Livraisons_Exception = (String) parentContextMap.get("Livraisons_Exception");
            }if (parentContextMap.containsKey("Livraisons_Masque")) {
                context.Livraisons_Masque = (String) parentContextMap.get("Livraisons_Masque");
            }if (parentContextMap.containsKey("Livraisons_Ok")) {
                context.Livraisons_Ok = (String) parentContextMap.get("Livraisons_Ok");
            }if (parentContextMap.containsKey("ST_Drivers")) {
                context.ST_Drivers = (String) parentContextMap.get("ST_Drivers");
            }if (parentContextMap.containsKey("Tarification_Logistic_Masque")) {
                context.Tarification_Logistic_Masque = (String) parentContextMap.get("Tarification_Logistic_Masque");
            }if (parentContextMap.containsKey("Tarification_Transport_Masque")) {
                context.Tarification_Transport_Masque = (String) parentContextMap.get("Tarification_Transport_Masque");
            }if (parentContextMap.containsKey("Tournee_Masque")) {
                context.Tournee_Masque = (String) parentContextMap.get("Tournee_Masque");
            }if (parentContextMap.containsKey("TVA_Exceptions")) {
                context.TVA_Exceptions = (String) parentContextMap.get("TVA_Exceptions");
            }if (parentContextMap.containsKey("Backup")) {
                context.Backup = (String) parentContextMap.get("Backup");
            }if (parentContextMap.containsKey("Server_Clean")) {
                context.Server_Clean = (String) parentContextMap.get("Server_Clean");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Server_Out")) {
                context.Server_Out = (String) parentContextMap.get("Server_Out");
            }if (parentContextMap.containsKey("Server_Out_DataMart")) {
                context.Server_Out_DataMart = (String) parentContextMap.get("Server_Out_DataMart");
            }if (parentContextMap.containsKey("transaction_id")) {
                context.transaction_id = (String) parentContextMap.get("transaction_id");
            }if (parentContextMap.containsKey("ondemand_server_directory")) {
                context.ondemand_server_directory = (String) parentContextMap.get("ondemand_server_directory");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob




		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSetGlobalVar_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSetGlobalVar_1) {
globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'URBANTZ_TO_HUB_MAD_CORRECTION_PROD_V1' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     356622 characters generated by Talend Cloud Data Integration 
 *     on the 17 avril 2024 à 09:59:34 CET
 ************************************************************************************************/

package atelier_facturation.ecolotrans_urbantz_users_import_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	import java.util.Arrays;


@SuppressWarnings("unused")

/**
 * Job: ECOLOTRANS_URBANTZ_USERS_IMPORT Purpose: Transfer users from api to database<br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ECOLOTRANS_URBANTZ_USERS_IMPORT implements TalendJob {
	static {System.setProperty("TalendJob.log", "ECOLOTRANS_URBANTZ_USERS_IMPORT.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ECOLOTRANS_URBANTZ_USERS_IMPORT.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ECOLOTRANS_URBANTZ_USERS_IMPORT";
	private final String projectName = "ATELIER_FACTURATION";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_5A7MkDuhEeqtgIRm2Fx7-Q", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ECOLOTRANS_URBANTZ_USERS_IMPORT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ECOLOTRANS_URBANTZ_USERS_IMPORT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRESTClient_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRESTClient_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRESTClient_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRESTClient_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRESTClient_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tXMLMap_2_TXMLMAP_OUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tXMLMap_2_TXMLMAP_IN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tXMLMap_2_TXMLMAP_IN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRESTClient_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRESTClient_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "ocJJrO_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tWarn_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "bsoYRo_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "8aZJ5W_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "datahub", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tRESTClient_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="datahub";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class usersStruct implements routines.system.IPersistableRow<usersStruct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String userId;

				public String getUserId () {
					return this.userId;
				}

				public Boolean userIdIsNullable(){
				    return false;
				}
				public Boolean userIdIsKey(){
				    return true;
				}
				public Integer userIdLength(){
				    return 255;
				}
				public Integer userIdPrecision(){
				    return 0;
				}
				public String userIdDefault(){
				
					return null;
				
				}
				public String userIdComment(){
				
				    return "";
				
				}
				public String userIdPattern(){
				
					return "";
				
				}
				public String userIdOriginalDbColumnName(){
				
					return "userId";
				
				}

				
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}

				public Boolean firstNameIsNullable(){
				    return true;
				}
				public Boolean firstNameIsKey(){
				    return false;
				}
				public Integer firstNameLength(){
				    return 255;
				}
				public Integer firstNamePrecision(){
				    return 0;
				}
				public String firstNameDefault(){
				
					return null;
				
				}
				public String firstNameComment(){
				
				    return "";
				
				}
				public String firstNamePattern(){
				
					return "";
				
				}
				public String firstNameOriginalDbColumnName(){
				
					return "firstName";
				
				}

				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}

				public Boolean lastNameIsNullable(){
				    return true;
				}
				public Boolean lastNameIsKey(){
				    return false;
				}
				public Integer lastNameLength(){
				    return 255;
				}
				public Integer lastNamePrecision(){
				    return 0;
				}
				public String lastNameDefault(){
				
					return null;
				
				}
				public String lastNameComment(){
				
				    return "";
				
				}
				public String lastNamePattern(){
				
					return "";
				
				}
				public String lastNameOriginalDbColumnName(){
				
					return "lastName";
				
				}

				
			    public String email;

				public String getEmail () {
					return this.email;
				}

				public Boolean emailIsNullable(){
				    return true;
				}
				public Boolean emailIsKey(){
				    return false;
				}
				public Integer emailLength(){
				    return 255;
				}
				public Integer emailPrecision(){
				    return 0;
				}
				public String emailDefault(){
				
					return null;
				
				}
				public String emailComment(){
				
				    return "";
				
				}
				public String emailPattern(){
				
					return "";
				
				}
				public String emailOriginalDbColumnName(){
				
					return "email";
				
				}

				
			    public Object status;

				public Object getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 10;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public String role;

				public String getRole () {
					return this.role;
				}

				public Boolean roleIsNullable(){
				    return true;
				}
				public Boolean roleIsKey(){
				    return false;
				}
				public Integer roleLength(){
				    return 255;
				}
				public Integer rolePrecision(){
				    return 0;
				}
				public String roleDefault(){
				
					return null;
				
				}
				public String roleComment(){
				
				    return "";
				
				}
				public String rolePattern(){
				
					return "";
				
				}
				public String roleOriginalDbColumnName(){
				
					return "role";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return null;
				}
				public Integer is_deletedPrecision(){
				    return null;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.userId == null) ? 0 : this.userId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final usersStruct other = (usersStruct) obj;
		
						if (this.userId == null) {
							if (other.userId != null)
								return false;
						
						} else if (!this.userId.equals(other.userId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(usersStruct other) {

		other.userId = this.userId;
	            other.firstName = this.firstName;
	            other.lastName = this.lastName;
	            other.email = this.email;
	            other.status = this.status;
	            other.role = this.role;
	            other.is_deleted = this.is_deleted;
	            
	}

	public void copyKeysDataTo(usersStruct other) {

		other.userId = this.userId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
       			    	dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
						dos.clearInstanceCache();
						dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("userId="+userId);
		sb.append(",firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",email="+email);
		sb.append(",status="+String.valueOf(status));
		sb.append(",role="+role);
		sb.append(",is_deleted="+String.valueOf(is_deleted));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(userId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(userId);
            			}
            		
        			sb.append("|");
        		
        				if(firstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(firstName);
            			}
            		
        			sb.append("|");
        		
        				if(lastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastName);
            			}
            		
        			sb.append("|");
        		
        				if(email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(email);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(role == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(usersStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.userId, other.userId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];

	
			    public String userId;

				public String getUserId () {
					return this.userId;
				}

				public Boolean userIdIsNullable(){
				    return false;
				}
				public Boolean userIdIsKey(){
				    return true;
				}
				public Integer userIdLength(){
				    return 255;
				}
				public Integer userIdPrecision(){
				    return 0;
				}
				public String userIdDefault(){
				
					return null;
				
				}
				public String userIdComment(){
				
				    return "";
				
				}
				public String userIdPattern(){
				
					return "";
				
				}
				public String userIdOriginalDbColumnName(){
				
					return "userId";
				
				}

				
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}

				public Boolean firstNameIsNullable(){
				    return true;
				}
				public Boolean firstNameIsKey(){
				    return false;
				}
				public Integer firstNameLength(){
				    return 255;
				}
				public Integer firstNamePrecision(){
				    return 0;
				}
				public String firstNameDefault(){
				
					return null;
				
				}
				public String firstNameComment(){
				
				    return "";
				
				}
				public String firstNamePattern(){
				
					return "";
				
				}
				public String firstNameOriginalDbColumnName(){
				
					return "firstName";
				
				}

				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}

				public Boolean lastNameIsNullable(){
				    return true;
				}
				public Boolean lastNameIsKey(){
				    return false;
				}
				public Integer lastNameLength(){
				    return 255;
				}
				public Integer lastNamePrecision(){
				    return 0;
				}
				public String lastNameDefault(){
				
					return null;
				
				}
				public String lastNameComment(){
				
				    return "";
				
				}
				public String lastNamePattern(){
				
					return "";
				
				}
				public String lastNameOriginalDbColumnName(){
				
					return "lastName";
				
				}

				
			    public String email;

				public String getEmail () {
					return this.email;
				}

				public Boolean emailIsNullable(){
				    return true;
				}
				public Boolean emailIsKey(){
				    return false;
				}
				public Integer emailLength(){
				    return 255;
				}
				public Integer emailPrecision(){
				    return 0;
				}
				public String emailDefault(){
				
					return null;
				
				}
				public String emailComment(){
				
				    return "";
				
				}
				public String emailPattern(){
				
					return "";
				
				}
				public String emailOriginalDbColumnName(){
				
					return "email";
				
				}

				
			    public Object status;

				public Object getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 10;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public String role;

				public String getRole () {
					return this.role;
				}

				public Boolean roleIsNullable(){
				    return true;
				}
				public Boolean roleIsKey(){
				    return false;
				}
				public Integer roleLength(){
				    return 255;
				}
				public Integer rolePrecision(){
				    return 0;
				}
				public String roleDefault(){
				
					return null;
				
				}
				public String roleComment(){
				
				    return "";
				
				}
				public String rolePattern(){
				
					return "";
				
				}
				public String roleOriginalDbColumnName(){
				
					return "role";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
       			    	dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
						dos.clearInstanceCache();
						dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("userId="+userId);
		sb.append(",firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",email="+email);
		sb.append(",status="+String.valueOf(status));
		sb.append(",role="+role);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(userId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(userId);
            			}
            		
        			sb.append("|");
        		
        				if(firstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(firstName);
            			}
            		
        			sb.append("|");
        		
        				if(lastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastName);
            			}
            		
        			sb.append("|");
        		
        				if(email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(email);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(role == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];

	
			    public String userId;

				public String getUserId () {
					return this.userId;
				}

				public Boolean userIdIsNullable(){
				    return false;
				}
				public Boolean userIdIsKey(){
				    return false;
				}
				public Integer userIdLength(){
				    return 255;
				}
				public Integer userIdPrecision(){
				    return 0;
				}
				public String userIdDefault(){
				
					return null;
				
				}
				public String userIdComment(){
				
				    return "";
				
				}
				public String userIdPattern(){
				
					return "";
				
				}
				public String userIdOriginalDbColumnName(){
				
					return "userId";
				
				}

				
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}

				public Boolean firstNameIsNullable(){
				    return true;
				}
				public Boolean firstNameIsKey(){
				    return false;
				}
				public Integer firstNameLength(){
				    return 255;
				}
				public Integer firstNamePrecision(){
				    return 0;
				}
				public String firstNameDefault(){
				
					return null;
				
				}
				public String firstNameComment(){
				
				    return "";
				
				}
				public String firstNamePattern(){
				
					return "";
				
				}
				public String firstNameOriginalDbColumnName(){
				
					return "firstName";
				
				}

				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}

				public Boolean lastNameIsNullable(){
				    return true;
				}
				public Boolean lastNameIsKey(){
				    return false;
				}
				public Integer lastNameLength(){
				    return 255;
				}
				public Integer lastNamePrecision(){
				    return 0;
				}
				public String lastNameDefault(){
				
					return null;
				
				}
				public String lastNameComment(){
				
				    return "";
				
				}
				public String lastNamePattern(){
				
					return "";
				
				}
				public String lastNameOriginalDbColumnName(){
				
					return "lastName";
				
				}

				
			    public String email;

				public String getEmail () {
					return this.email;
				}

				public Boolean emailIsNullable(){
				    return true;
				}
				public Boolean emailIsKey(){
				    return false;
				}
				public Integer emailLength(){
				    return 255;
				}
				public Integer emailPrecision(){
				    return 0;
				}
				public String emailDefault(){
				
					return null;
				
				}
				public String emailComment(){
				
				    return "";
				
				}
				public String emailPattern(){
				
					return "";
				
				}
				public String emailOriginalDbColumnName(){
				
					return "email";
				
				}

				
			    public Object status;

				public Object getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 10;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public String role;

				public String getRole () {
					return this.role;
				}

				public Boolean roleIsNullable(){
				    return true;
				}
				public Boolean roleIsKey(){
				    return false;
				}
				public Integer roleLength(){
				    return 255;
				}
				public Integer rolePrecision(){
				    return 0;
				}
				public String roleDefault(){
				
					return null;
				
				}
				public String roleComment(){
				
				    return "";
				
				}
				public String rolePattern(){
				
					return "";
				
				}
				public String roleOriginalDbColumnName(){
				
					return "role";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.userId = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.email = readString(dis);
					
						this.status = (Object) dis.readObject();
					
					this.role = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
       			    	dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.userId,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// Object
				
						dos.clearInstanceCache();
						dos.writeObject(this.status);
					
					// String
				
						writeString(this.role,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("userId="+userId);
		sb.append(",firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",email="+email);
		sb.append(",status="+String.valueOf(status));
		sb.append(",role="+role);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(userId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(userId);
            			}
            		
        			sb.append("|");
        		
        				if(firstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(firstName);
            			}
            		
        			sb.append("|");
        		
        				if(lastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastName);
            			}
            		
        			sb.append("|");
        		
        				if(email == null){
        					sb.append("<null>");
        				}else{
            				sb.append(email);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(role == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[0];

	
			    public String errorMessage;

				public String getErrorMessage () {
					return this.errorMessage;
				}

				public Boolean errorMessageIsNullable(){
				    return true;
				}
				public Boolean errorMessageIsKey(){
				    return false;
				}
				public Integer errorMessageLength(){
				    return null;
				}
				public Integer errorMessagePrecision(){
				    return null;
				}
				public String errorMessageDefault(){
				
					return null;
				
				}
				public String errorMessageComment(){
				
				    return "";
				
				}
				public String errorMessagePattern(){
				
					return "";
				
				}
				public String errorMessageOriginalDbColumnName(){
				
					return "errorMessage";
				
				}

				
			    public Integer errorCode;

				public Integer getErrorCode () {
					return this.errorCode;
				}

				public Boolean errorCodeIsNullable(){
				    return true;
				}
				public Boolean errorCodeIsKey(){
				    return false;
				}
				public Integer errorCodeLength(){
				    return null;
				}
				public Integer errorCodePrecision(){
				    return null;
				}
				public String errorCodeDefault(){
				
					return null;
				
				}
				public String errorCodeComment(){
				
				    return "";
				
				}
				public String errorCodePattern(){
				
					return "";
				
				}
				public String errorCodeOriginalDbColumnName(){
				
					return "errorCode";
				
				}

				
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}

				public Boolean statusCodeIsNullable(){
				    return true;
				}
				public Boolean statusCodeIsKey(){
				    return false;
				}
				public Integer statusCodeLength(){
				    return null;
				}
				public Integer statusCodePrecision(){
				    return null;
				}
				public String statusCodeDefault(){
				
					return null;
				
				}
				public String statusCodeComment(){
				
				    return "";
				
				}
				public String statusCodePattern(){
				
					return "";
				
				}
				public String statusCodeOriginalDbColumnName(){
				
					return "statusCode";
				
				}

				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return 0;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				
			    public String string;

				public String getString () {
					return this.string;
				}

				public Boolean stringIsNullable(){
				    return true;
				}
				public Boolean stringIsKey(){
				    return false;
				}
				public Integer stringLength(){
				    return 4048;
				}
				public Integer stringPrecision(){
				    return null;
				}
				public String stringDefault(){
				
					return null;
				
				}
				public String stringComment(){
				
				    return "";
				
				}
				public String stringPattern(){
				
					return "";
				
				}
				public String stringOriginalDbColumnName(){
				
					return "string";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.errorMessage = readString(dis);
					
						this.errorCode = readInteger(dis);
					
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_USERS_IMPORT) {

        	try {

        		int length = 0;
		
					this.errorMessage = readString(dis);
					
						this.errorCode = readInteger(dis);
					
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.errorMessage,dos);
					
					// Integer
				
						writeInteger(this.errorCode,dos);
					
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.errorMessage,dos);
					
					// Integer
				
						writeInteger(this.errorCode,dos);
					
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
						dos.clearInstanceCache();
						dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("errorMessage="+errorMessage);
		sb.append(",errorCode="+String.valueOf(errorCode));
		sb.append(",statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(errorMessage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(errorMessage);
            			}
            		
        			sb.append("|");
        		
        				if(errorCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(errorCode);
            			}
            		
        			sb.append("|");
        		
        				if(statusCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statusCode);
            			}
            		
        			sb.append("|");
        		
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        				if(string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tRESTClient_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRESTClient_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRESTClient_2");
		org.slf4j.MDC.put("_subJobPid", "tfxzut_" + subJobPidCounter.getAndIncrement());
	

		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
out1Struct out1 = new out1Struct();
row1Struct row1 = new row1Struct();
usersStruct users = new usersStruct();




	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT begin ] start
	 */

	

	
		
		ok_Hash.put("tXMLMap_2_TXMLMAP_OUT", false);
		start_Hash.put("tXMLMap_2_TXMLMAP_OUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tXMLMap_2_TXMLMAP_OUT = 0;
		
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_OUT - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tXMLMap_2_TXMLMAP_OUT{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tXMLMap_2_TXMLMAP_OUT = new StringBuilder();
                    log4jParamters_tXMLMap_2_TXMLMAP_OUT.append("Parameters:");
                            log4jParamters_tXMLMap_2_TXMLMAP_OUT.append("KEEP_ORDER_FOR_DOCUMENT" + " = " + "false");
                        log4jParamters_tXMLMap_2_TXMLMAP_OUT.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_OUT - "  + (log4jParamters_tXMLMap_2_TXMLMAP_OUT) );
                    } 
                } 
            new BytesLimit65535_tXMLMap_2_TXMLMAP_OUT().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tXMLMap_2_TXMLMAP_OUT", "tXMLMap_1_TXMLMAP_OUT", "tXMLMapOut");
				talendJobLogProcess(globalMap);
			}
			

	
	
//===============================input xml init part===============================
class XML_API_tXMLMap_2_TXMLMAP_OUT{
	public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null && node instanceof org.dom4j.Element) {
        	org.dom4j.Attribute attri = ((org.dom4j.Element)node).attribute("nil");
        	if(attri != null && ("true").equals(attri.getText())){
            	return true;
            }
        }
        return false;
    }

    public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        return node == null ? true : false;
    }

    public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null) {
            return node.getText().length() == 0;
        }
        return false;
    }
}
	class Var__tXMLMap_2_TXMLMAP_OUT__Struct {
	}
	Var__tXMLMap_2_TXMLMAP_OUT__Struct Var__tXMLMap_2_TXMLMAP_OUT = new Var__tXMLMap_2_TXMLMAP_OUT__Struct();
// ###############################
// # Outputs initialization
out1Struct out1_tmp = new out1Struct();
out1Struct out1_save = null;
//the aggregate variable
out1Struct out1_aggregate = null;
int count_out1_tXMLMap_2_TXMLMAP_OUT = 0;
//init the resultset for aggregate
java.util.List<Object> allOutsForAggregate_tXMLMap_2 = new java.util.ArrayList<Object>();
globalMap.put("allOutsForAggregate_tXMLMap_2",allOutsForAggregate_tXMLMap_2);
// ###############################
class TreeNode_API_tXMLMap_2_TXMLMAP_OUT {
	java.util.Map<String, String> xpath_value_map = new java.util.HashMap<String, String>();
	
	void clear(){
		xpath_value_map.clear();
	}
	
	void put(String xpath, String value){
		xpath_value_map.put(xpath, value);
	}
	String get_null(String xpath) {
		return null;
	}
	String get_String(String xpath){
		return xpath_value_map.get(xpath);
	}
}
			TreeNode_API_tXMLMap_2_TXMLMAP_OUT treeNodeAPI_tXMLMap_2_TXMLMAP_OUT = new TreeNode_API_tXMLMap_2_TXMLMAP_OUT();
			NameSpaceTool nsTool_tXMLMap_2_TXMLMAP_OUT = new NameSpaceTool();
		int nb_line_tXMLMap_2_TXMLMAP_OUT = 0; 
	
    XML_API_tXMLMap_2_TXMLMAP_OUT xml_api_tXMLMap_2_TXMLMAP_OUT = new XML_API_tXMLMap_2_TXMLMAP_OUT();

	//the map store the previous value of aggregate columns
	java.util.Map<String,Object> aggregateCacheMap_tXMLMap_2_TXMLMAP_OUT = new java.util.HashMap<String,Object>();

	            

 



/**
 * [tXMLMap_2_TXMLMAP_OUT begin ] stop
 */



	
	/**
	 * [tRESTClient_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRESTClient_2", false);
		start_Hash.put("tRESTClient_2", System.currentTimeMillis());
		
	
	currentComponent="tRESTClient_2";
	
	
		int tos_count_tRESTClient_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tRESTClient_2", "tRESTClient_1", "tRESTClient");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tRESTClient_2 begin ] stop
 */
	
	/**
	 * [tRESTClient_2 main ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";
	
	
	row5 = null;

// expected response body
Object responseDoc_tRESTClient_2 = null;

try {
	// request body
	org.dom4j.Document requestDoc_tRESTClient_2 = null;
	String requestString_tRESTClient_2 = null;

	Object requestBody_tRESTClient_2 = requestDoc_tRESTClient_2 != null ? requestDoc_tRESTClient_2 : requestString_tRESTClient_2;

	

    //resposne class name
	Class<?> responseClass_tRESTClient_2
		= org.dom4j.Document.class;

	// create web client instance
	org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean factoryBean_tRESTClient_2 =
			new org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean();

	boolean inOSGi = routines.system.BundleUtils.inOSGi();

	final java.util.List<org.apache.cxf.feature.Feature> features_tRESTClient_2 =
			new java.util.ArrayList<org.apache.cxf.feature.Feature>();

	String url = null;
	
		url = "https://api.urbantz.com/v2/user";
		// {baseUri}tRESTClient
		factoryBean_tRESTClient_2.setServiceName(new javax.xml.namespace.QName(url, "tRESTClient"));
		factoryBean_tRESTClient_2.setAddress(url);
	

	

    boolean log_messages_tRESTClient_2 = Boolean.valueOf(false);
	if (log_messages_tRESTClient_2) {
		org.apache.cxf.ext.logging.LoggingFeature loggingFeature = new  org.apache.cxf.ext.logging.LoggingFeature();
		loggingFeature.addSensitiveProtocolHeaderNames(new java.util.HashSet<>(java.util.Arrays.asList(org.apache.cxf.helpers.HttpHeaderHelper.AUTHORIZATION)));
		loggingFeature.addSensitiveElementNames(new java.util.HashSet<>(java.util.Arrays.asList("password")));
		features_tRESTClient_2.add(loggingFeature);
	}

	

	factoryBean_tRESTClient_2.setFeatures(features_tRESTClient_2);


	java.util.List<Object> providers_tRESTClient_2 = new java.util.ArrayList<Object>();
	providers_tRESTClient_2.add(new org.apache.cxf.jaxrs.provider.dom4j.DOM4JProvider() {
		// workaround for https://jira.talendforge.org/browse/TESB-7276
		public org.dom4j.Document readFrom(Class<org.dom4j.Document> cls,
											java.lang.reflect.Type type,
											java.lang.annotation.Annotation[] anns,
											javax.ws.rs.core.MediaType mt,
											javax.ws.rs.core.MultivaluedMap<String, String> headers,
											java.io.InputStream is)
				throws IOException, javax.ws.rs.WebApplicationException {
			String contentLength = headers.getFirst("Content-Length");
			if (!org.apache.cxf.common.util.StringUtils.isEmpty(contentLength)
					&& Integer.valueOf(contentLength) <= 0) {
				try {
					return org.dom4j.DocumentHelper.parseText("<root/>");
				} catch (org.dom4j.DocumentException e_tRESTClient_2) {
					e_tRESTClient_2.printStackTrace();
				}
				return null;
			}
			return super.readFrom(cls, type, anns, mt, headers, is);
		}
	});
	org.apache.cxf.jaxrs.provider.json.JSONProvider jsonProvider_tRESTClient_2 =
			new org.apache.cxf.jaxrs.provider.json.JSONProvider();
		jsonProvider_tRESTClient_2.setIgnoreNamespaces(true);
		jsonProvider_tRESTClient_2.setAttributesToElements(true);
	
	
	
		jsonProvider_tRESTClient_2.setSupportUnwrapped(true);
		jsonProvider_tRESTClient_2.setWrapperName("root");
	
	
		jsonProvider_tRESTClient_2.setDropRootElement(false);
		jsonProvider_tRESTClient_2.setConvertTypesToStrings(false);
	providers_tRESTClient_2.add(jsonProvider_tRESTClient_2);
	factoryBean_tRESTClient_2.setProviders(providers_tRESTClient_2);
	factoryBean_tRESTClient_2.setTransportId("http://cxf.apache.org/transports/http");

	boolean use_auth_tRESTClient_2 = false;

	

	org.apache.cxf.jaxrs.client.WebClient webClient_tRESTClient_2 = null;
	
		webClient_tRESTClient_2 = factoryBean_tRESTClient_2.createWebClient();
		// set request path
		webClient_tRESTClient_2.path("");
	

	// set connection properties
	org.apache.cxf.jaxrs.client.ClientConfiguration clientConfig_tRESTClient_2 = org.apache.cxf.jaxrs.client.WebClient.getConfig(webClient_tRESTClient_2);
	org.apache.cxf.transport.http.auth.HttpAuthSupplier httpAuthSupplerHttpConduit = null;
	org.apache.cxf.transport.http.HTTPConduit conduit_tRESTClient_2 = null;

	
		conduit_tRESTClient_2 = clientConfig_tRESTClient_2.getHttpConduit();
	
	
    if (clientConfig_tRESTClient_2.getEndpoint() != null) {
		org.apache.cxf.service.model.EndpointInfo endpointInfo_tRESTClient_2 = clientConfig_tRESTClient_2.getEndpoint().getEndpointInfo();
		if(endpointInfo_tRESTClient_2 != null) {
			endpointInfo_tRESTClient_2.setProperty("enable.webclient.operation.reporting", true);
		}
    }

	

	

	if (!inOSGi) {
		conduit_tRESTClient_2.getClient().setReceiveTimeout((long)(60 * 1000L));
		conduit_tRESTClient_2.getClient().setConnectionTimeout((long)(30 * 1000L));
	}
	
	
	
		

	

	

	
		// set Accept-Type
		webClient_tRESTClient_2.accept("application/json");
	

	
		// set optional query and header properties if any
	
		webClient_tRESTClient_2.header("x-api-key", "0OCDfeE0zXfOjWYnV9rBaXepnJFnoPJngNLGSaGhhBCpCU6U");
	
	if (use_auth_tRESTClient_2 && "OAUTH2_BEARER".equals("BASIC")) {
		// set oAuth2 bearer token
		org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier authSupplier = new org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier();
		authSupplier.setAccessToken((String) "");
		conduit_tRESTClient_2.setAuthSupplier(authSupplier);
	}

	

	// if FORM request then capture query parameters into Form, otherwise set them as queries
	
		
		
	


	try {
		// start send request
		
			responseDoc_tRESTClient_2 = webClient_tRESTClient_2.get();
			javax.ws.rs.core.Response responseObjBase_tRESTClient_2 = (javax.ws.rs.core.Response)responseDoc_tRESTClient_2;
            int status_tRESTClient_2 = responseObjBase_tRESTClient_2.getStatus();
            if (status_tRESTClient_2 != 304 && status_tRESTClient_2 >= 300 && responseClass_tRESTClient_2 != javax.ws.rs.core.Response.class) {
                throw org.apache.cxf.jaxrs.utils.ExceptionUtils.toWebApplicationException((javax.ws.rs.core.Response)responseObjBase_tRESTClient_2);
            }
            if (status_tRESTClient_2 != 204 && responseObjBase_tRESTClient_2.getEntity() != null) {
				responseDoc_tRESTClient_2 = responseObjBase_tRESTClient_2.readEntity(responseClass_tRESTClient_2);
			}
		


		int webClientResponseStatus_tRESTClient_2 = webClient_tRESTClient_2.getResponse().getStatus();
		if (webClientResponseStatus_tRESTClient_2 >= 300) {
			throw new javax.ws.rs.WebApplicationException(webClient_tRESTClient_2.getResponse());
		}

		
			if (row5 == null) {
				row5 = new row5Struct();
			}

			row5.statusCode = webClientResponseStatus_tRESTClient_2;
			row5.string = "";
			
				
				{
					Object responseObj_tRESTClient_2 = responseDoc_tRESTClient_2;
				
				if(responseObj_tRESTClient_2 != null){
					if (responseClass_tRESTClient_2 == String.class && responseObj_tRESTClient_2 instanceof String) {
							row5.string = (String) responseObj_tRESTClient_2;
					} else {
						routines.system.Document responseTalendDoc_tRESTClient_2 = null;
						if (null != responseObj_tRESTClient_2) {
							responseTalendDoc_tRESTClient_2 = new routines.system.Document();
							if (responseObj_tRESTClient_2 instanceof org.dom4j.Document) {
								responseTalendDoc_tRESTClient_2.setDocument((org.dom4j.Document) responseObj_tRESTClient_2);
							}
						}
						row5.body = responseTalendDoc_tRESTClient_2;
					}
				}
			}
			

			java.util.Map<String, javax.ws.rs.core.NewCookie> cookies_tRESTClient_2 = new java.util.HashMap<String, javax.ws.rs.core.NewCookie>();

			if (webClient_tRESTClient_2.getResponse() != null && webClient_tRESTClient_2.getResponse().getCookies() != null ) { 
				cookies_tRESTClient_2.putAll(webClient_tRESTClient_2.getResponse().getCookies());
			}

			


			globalMap.put("tRESTClient_2_HEADERS", webClient_tRESTClient_2.getResponse().getHeaders());
			globalMap.put("tRESTClient_2_COOKIES", cookies_tRESTClient_2);
			
		

	} catch (javax.ws.rs.WebApplicationException ex_tRESTClient_2) {
	    globalMap.put("tRESTClient_2_ERROR_MESSAGE",ex_tRESTClient_2.getMessage());
		
			throw ex_tRESTClient_2;
		
	}

} catch(Exception e_tRESTClient_2) {
    globalMap.put("tRESTClient_2_ERROR_MESSAGE",e_tRESTClient_2.getMessage());
	
		new TalendException(e_tRESTClient_2, currentComponent, globalMap).printStackTrace();
	
}


 


	tos_count_tRESTClient_2++;

/**
 * [tRESTClient_2 main ] stop
 */
	
	/**
	 * [tRESTClient_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";
	
	

 



/**
 * [tRESTClient_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tRESTClient_2","tRESTClient_1","tRESTClient","tXMLMap_2_TXMLMAP_OUT","tXMLMap_1_TXMLMAP_OUT","tXMLMapOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

	boolean rejectedInnerJoin_tXMLMap_2_TXMLMAP_OUT = false;
	boolean rejectedDocInnerJoin_tXMLMap_2_TXMLMAP_OUT = false;
	boolean mainRowRejected_tXMLMap_2_TXMLMAP_OUT = false;
	boolean isMatchDocRowtXMLMap_2_TXMLMAP_OUT = false;
	  
	
			

		
		
				//init document to flat tool
				routines.system.DocumentToFlat docToFlat_tXMLMap_2_TXMLMAP_OUT = new routines.system.DocumentToFlat();
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setOriginalLoop("/root/root");
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setIsOptional(false);
				if(row5.body == null || row5.body.getDocument() == null) {
					throw new RuntimeException("row5.body can't be empty");
				}
				org.dom4j.Document doc_tXMLMap_2_TXMLMAP_OUT = row5.body.getDocument();
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setDoc(doc_tXMLMap_2_TXMLMAP_OUT);
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setDefineNS(false);
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setNamespaceTool(nsTool_tXMLMap_2_TXMLMAP_OUT);
				
					//old version, find NS from doc
					nsTool_tXMLMap_2_TXMLMAP_OUT.countNSMap(doc_tXMLMap_2_TXMLMAP_OUT.getRootElement());
					java.util.HashMap<String,String> xmlNameSpaceMap_tXMLMap_2_TXMLMAP_OUT = nsTool_tXMLMap_2_TXMLMAP_OUT.xmlNameSpaceMap;
				
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setXmlNameSpaceMap(xmlNameSpaceMap_tXMLMap_2_TXMLMAP_OUT);
				
				String[] absolutePathMappings_tXMLMap_2_TXMLMAP_OUT = new String[6];
				String[] relativePathMappings_tXMLMap_2_TXMLMAP_OUT = new String[6];
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[0] = "row5.body:/root/root/firstName";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[0] = "firstName";
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[1] = "row5.body:/root/root/lastName";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[1] = "lastName";
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[2] = "row5.body:/root/root/id";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[2] = "id";
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[3] = "row5.body:/root/root/status";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[3] = "status";
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[4] = "row5.body:/root/root/email";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[4] = "email";
				
				absolutePathMappings_tXMLMap_2_TXMLMAP_OUT[5] = "row5.body:/root/root/role";
				relativePathMappings_tXMLMap_2_TXMLMAP_OUT[5] = "role";
				
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setAbsolutePathMappings(absolutePathMappings_tXMLMap_2_TXMLMAP_OUT);
				docToFlat_tXMLMap_2_TXMLMAP_OUT.setCurrentRelativePathMappings(relativePathMappings_tXMLMap_2_TXMLMAP_OUT);
				//generate document to flat data
				docToFlat_tXMLMap_2_TXMLMAP_OUT.flat();
				//get flat data
				java.util.List<java.util.Map<String, String>> resultSet_tXMLMap_2_TXMLMAP_OUT = docToFlat_tXMLMap_2_TXMLMAP_OUT.getResultSet();
				
				for (java.util.Map<String,String> oneRow_tXMLMap_2_TXMLMAP_OUT: resultSet_tXMLMap_2_TXMLMAP_OUT) { // G_TXM_M_001
					nb_line_tXMLMap_2_TXMLMAP_OUT++;
			    	rejectedInnerJoin_tXMLMap_2_TXMLMAP_OUT = false;
			    	rejectedDocInnerJoin_tXMLMap_2_TXMLMAP_OUT = false;
					mainRowRejected_tXMLMap_2_TXMLMAP_OUT=false;
				    isMatchDocRowtXMLMap_2_TXMLMAP_OUT = false;
					
			    	treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.clear();
			    	for(java.util.Map.Entry<String, String> entry_tXMLMap_2_TXMLMAP_OUT : oneRow_tXMLMap_2_TXMLMAP_OUT.entrySet()) {
						treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.put(entry_tXMLMap_2_TXMLMAP_OUT.getKey(),entry_tXMLMap_2_TXMLMAP_OUT.getValue());
					}
					


			
{ // start of Var scope

	// ###############################
	// # Vars tables

Var__tXMLMap_2_TXMLMAP_OUT__Struct Var = Var__tXMLMap_2_TXMLMAP_OUT;
		// ###############################
		// # Output tables

out1 = null;


// # Output table : 'out1'
count_out1_tXMLMap_2_TXMLMAP_OUT++;


out1_tmp = new out1Struct();
out1_tmp.userId = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/id");
out1_tmp.firstName = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/firstName");
out1_tmp.lastName = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/lastName");
out1_tmp.email = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/email");
out1_tmp.status = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/status");
out1_tmp.role = treeNodeAPI_tXMLMap_2_TXMLMAP_OUT.get_String("row5.body:/root/root/role");allOutsForAggregate_tXMLMap_2.add(out1_tmp);

log.debug("tXMLMap_2 - Outputting the record " + count_out1_tXMLMap_2_TXMLMAP_OUT + " of the output table 'out1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tXMLMap_2_TXMLMAP_OUT = false;


		}//G_TXM_M_001 close
	

 


	tos_count_tXMLMap_2_TXMLMAP_OUT++;

/**
 * [tXMLMap_2_TXMLMAP_OUT main ] stop
 */
	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_OUT process_data_begin ] stop
 */
	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_OUT process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tRESTClient_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";
	
	

 



/**
 * [tRESTClient_2 process_data_end ] stop
 */
	
	/**
	 * [tRESTClient_2 end ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";
	
	


if (globalMap.get("tRESTClient_2_NB_LINE") == null) {
	globalMap.put("tRESTClient_2_NB_LINE", 1);
}

// [tRESTCliend_end]
 

ok_Hash.put("tRESTClient_2", true);
end_Hash.put("tRESTClient_2", System.currentTimeMillis());




/**
 * [tRESTClient_2 end ] stop
 */

	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	
		log.debug("tXMLMap_2 - Written records count in the table 'out1': " + count_out1_tXMLMap_2_TXMLMAP_OUT + ".");



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tRESTClient_2","tRESTClient_1","tRESTClient","tXMLMap_2_TXMLMAP_OUT","tXMLMap_1_TXMLMAP_OUT","tXMLMapOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_OUT - "  + ("Done.") );

ok_Hash.put("tXMLMap_2_TXMLMAP_OUT", true);
end_Hash.put("tXMLMap_2_TXMLMAP_OUT", System.currentTimeMillis());




/**
 * [tXMLMap_2_TXMLMAP_OUT end ] stop
 */




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"users");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"urbantz_user\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "UPDATE_OR_INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"urbantz_user\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
        if(updateKeyCount_tDBOutput_1 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_1 == 7 && true) {
                    log.warn("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "urbantz_user";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String update_tDBOutput_1 = "UPDATE `" + "urbantz_user" + "` SET `firstName` = ?,`lastName` = ?,`email` = ?,`status` = ?,`role` = ?,`is_deleted` = ? WHERE `userId` = ?";
				
				java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(update_tDBOutput_1);
				resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);
				String insert_tDBOutput_1 = "INSERT INTO `" + "urbantz_user" + "` (`userId`,`firstName`,`lastName`,`email`,`status`,`role`,`is_deleted`) VALUES (?,?,?,?,?,?,?)";
				    
				java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row1_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_users_tMap_1 = 0;
				
usersStruct users_tmp = new usersStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out1");
			
		int tos_count_tJavaRow_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJavaRow_1", "tJavaRow_1", "tJavaRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tXMLMap_2_TXMLMAP_IN begin ] start
	 */

	

	
		
		ok_Hash.put("tXMLMap_2_TXMLMAP_IN", false);
		start_Hash.put("tXMLMap_2_TXMLMAP_IN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	
		int tos_count_tXMLMap_2_TXMLMAP_IN = 0;
		
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_IN - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tXMLMap_2_TXMLMAP_IN{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tXMLMap_2_TXMLMAP_IN = new StringBuilder();
                    log4jParamters_tXMLMap_2_TXMLMAP_IN.append("Parameters:");
                            log4jParamters_tXMLMap_2_TXMLMAP_IN.append("KEEP_ORDER_FOR_DOCUMENT" + " = " + "false");
                        log4jParamters_tXMLMap_2_TXMLMAP_IN.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_IN - "  + (log4jParamters_tXMLMap_2_TXMLMAP_IN) );
                    } 
                } 
            new BytesLimit65535_tXMLMap_2_TXMLMAP_IN().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tXMLMap_2_TXMLMAP_IN", "tXMLMap_1_TXMLMAP_IN", "tXMLMapIn");
				talendJobLogProcess(globalMap);
			}
			
java.util.List<Object> outs_tXMLMap_2 = (java.util.List<Object>)globalMap.get("allOutsForAggregate_tXMLMap_2");
for(Object  row_out_tXMLMap_2_TXMLMAP_IN : outs_tXMLMap_2) {//TD512
 



/**
 * [tXMLMap_2_TXMLMAP_IN begin ] stop
 */
	
	/**
	 * [tXMLMap_2_TXMLMAP_IN main ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	

	out1 = null;
	if(row_out_tXMLMap_2_TXMLMAP_IN!=null && row_out_tXMLMap_2_TXMLMAP_IN instanceof out1Struct) {
		out1 = (out1Struct)row_out_tXMLMap_2_TXMLMAP_IN;		
	}
 


	tos_count_tXMLMap_2_TXMLMAP_IN++;

/**
 * [tXMLMap_2_TXMLMAP_IN main ] stop
 */
	
	/**
	 * [tXMLMap_2_TXMLMAP_IN process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_IN process_data_begin ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"out1","tXMLMap_2_TXMLMAP_IN","tXMLMap_1_TXMLMAP_IN","tXMLMapIn","tJavaRow_1","tJavaRow_1","tJavaRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		

    //Code generated according to input schema and output schema
row1.userId = out1.userId;
row1.firstName = out1.firstName;
row1.lastName = out1.lastName;
row1.email = out1.email;
row1.role = out1.role;

String status = ((String) out1.status).toUpperCase();
if (Arrays.asList("VALIDATED", "DENIED", "BANNED", "INCOMPLETE", "CREATED").contains(status)) {
	row1.status = out1.status;
} else {
	row1.status = "INCOMPLETE";
}
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */
	
	/**
	 * [tJavaRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tJavaRow_1","tJavaRow_1","tJavaRow","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

users = null;


// # Output table : 'users'
count_users_tMap_1++;

users_tmp.userId = row1.userId;
users_tmp.firstName = row1.firstName;
users_tmp.lastName = row1.lastName;
users_tmp.email = row1.email;
users_tmp.status = row1.status;
users_tmp.role = row1.role;
users_tmp.is_deleted = 0;
users = users_tmp;
log.debug("tMap_1 - Outputting the record " + count_users_tMap_1 + " of the output table 'users'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "users"
if(users != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"users","tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_user\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("users - " + (users==null? "": users.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
            int updateFlag_tDBOutput_1=0;
                    if(users.firstName == null) {
pstmtUpdate_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(1, users.firstName);
}

                    if(users.lastName == null) {
pstmtUpdate_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(2, users.lastName);
}

                    if(users.email == null) {
pstmtUpdate_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(3, users.email);
}

                    if(users.status == null) {
pstmtUpdate_tDBOutput_1.setNull(4, java.sql.Types.OTHER);
} else {pstmtUpdate_tDBOutput_1.setObject(4, users.status);
}

                    if(users.role == null) {
pstmtUpdate_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(5, users.role);
}

                    if(users.is_deleted == null) {
pstmtUpdate_tDBOutput_1.setNull(6, java.sql.Types.INTEGER);
} else {pstmtUpdate_tDBOutput_1.setInt(6, users.is_deleted);
}


                    if(users.userId == null) {
pstmtUpdate_tDBOutput_1.setNull(7 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(7 + count_tDBOutput_1, users.userId);
}


            try {
                updateFlag_tDBOutput_1=pstmtUpdate_tDBOutput_1.executeUpdate();
                updatedCount_tDBOutput_1 = updatedCount_tDBOutput_1+updateFlag_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += updateFlag_tDBOutput_1;

            if(updateFlag_tDBOutput_1 == 0) {

                        if(users.userId == null) {
pstmtInsert_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(1, users.userId);
}

                        if(users.firstName == null) {
pstmtInsert_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(2, users.firstName);
}

                        if(users.lastName == null) {
pstmtInsert_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(3, users.lastName);
}

                        if(users.email == null) {
pstmtInsert_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(4, users.email);
}

                        if(users.status == null) {
pstmtInsert_tDBOutput_1.setNull(5, java.sql.Types.OTHER);
} else {pstmtInsert_tDBOutput_1.setObject(5, users.status);
}

                        if(users.role == null) {
pstmtInsert_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(6, users.role);
}

                        if(users.is_deleted == null) {
pstmtInsert_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmtInsert_tDBOutput_1.setInt(7, users.is_deleted);
}

                    int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1.executeUpdate();
                    insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting")  + (" the record ")  + (nb_line_tDBOutput_1)  + (".") );
                }else{
                    nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Updating")  + (" the record ")  + (nb_line_tDBOutput_1)  + (".") );
             }
                } catch(java.lang.Exception e) {
                    globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                    whetherReject_tDBOutput_1 = true;
                        throw(e);
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "users"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tJavaRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 process_data_end ] stop
 */

} // End of branch "out1"




	
	/**
	 * [tXMLMap_2_TXMLMAP_IN process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_IN process_data_end ] stop
 */
	
	/**
	 * [tXMLMap_2_TXMLMAP_IN end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	

}//TD512
 
                if(log.isDebugEnabled())
            log.debug("tXMLMap_2_TXMLMAP_IN - "  + ("Done.") );

ok_Hash.put("tXMLMap_2_TXMLMAP_IN", true);
end_Hash.put("tXMLMap_2_TXMLMAP_IN", System.currentTimeMillis());




/**
 * [tXMLMap_2_TXMLMAP_IN end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out1",2,0,
			 			"tXMLMap_2_TXMLMAP_IN","tXMLMap_1_TXMLMAP_IN","tXMLMapIn","tJavaRow_1","tJavaRow_1","tJavaRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'users': " + count_users_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tJavaRow_1","tJavaRow_1","tJavaRow","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		



		if(pstmtUpdate_tDBOutput_1 != null){
			pstmtUpdate_tDBOutput_1.close();
			resourceMap.remove("pstmtUpdate_tDBOutput_1");
		}
		if(pstmtInsert_tDBOutput_1 != null){
			pstmtInsert_tDBOutput_1.close();
			resourceMap.remove("pstmtInsert_tDBOutput_1");
		}
	
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("updated")  + (" ")  + (nb_line_update_tDBOutput_1)  + (" record(s).") );
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"users",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_user\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */















				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRESTClient_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tDBClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRESTClient_2 finally ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";
	
	

 



/**
 * [tRESTClient_2 finally ] stop
 */

	
	/**
	 * [tXMLMap_2_TXMLMAP_OUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_OUT";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_OUT finally ] stop
 */

	
	/**
	 * [tXMLMap_2_TXMLMAP_IN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_2";
	
	currentComponent="tXMLMap_2_TXMLMAP_IN";
	
	

 



/**
 * [tXMLMap_2_TXMLMAP_IN finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_user\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
                if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_1")) != null) {
                    pstmtUpdateToClose_tDBOutput_1.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
                if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_1")) != null) {
                    pstmtInsertToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRESTClient_2_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "XafoW6_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "RC7kbW_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tWarn_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_2");
		org.slf4j.MDC.put("_subJobPid", "gZf1pY_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";
	
	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
                    log4jParamters_tWarn_2.append("Parameters:");
                            log4jParamters_tWarn_2.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
                    } 
                } 
            new BytesLimit65535_tWarn_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_2", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_2 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_2_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_2_WARN_PRIORITY", 4);
	globalMap.put("tWarn_2_WARN_CODE", 42);
	
} catch (Exception e_tWarn_2) {
globalMap.put("tWarn_2_ERROR_MESSAGE",e_tWarn_2.getMessage());
	logIgnoredError(String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2), e_tWarn_2);
}


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_end ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "GTDKQm_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ECOLOTRANS_URBANTZ_USERS_IMPORT ECOLOTRANS_URBANTZ_USERS_IMPORTClass = new ECOLOTRANS_URBANTZ_USERS_IMPORT();

        int exitCode = ECOLOTRANS_URBANTZ_USERS_IMPORTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_USERS_IMPORT' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ECOLOTRANS_URBANTZ_USERS_IMPORT' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_5A7MkDuhEeqtgIRm2Fx7-Q");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-03-05T16:44:22.817470400Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ECOLOTRANS_URBANTZ_USERS_IMPORT.class.getClassLoader().getResourceAsStream("atelier_facturation/ecolotrans_urbantz_users_import_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ECOLOTRANS_URBANTZ_USERS_IMPORT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ECOLOTRANS_URBANTZ_USERS_IMPORT' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs


this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ECOLOTRANS_URBANTZ_USERS_IMPORT");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_USERS_IMPORT' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     182944 characters generated by Talend Cloud Data Integration 
 *     on the 5 mars 2024 à 17:44:22 WAT
 ************************************************************************************************/
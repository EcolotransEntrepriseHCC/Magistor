
package atelier_facturation.ecolotrans_urbantz_tasks_import_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: ECOLOTRANS_URBANTZ_TASKS_IMPORT Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ECOLOTRANS_URBANTZ_TASKS_IMPORT implements TalendJob {
	static {System.setProperty("TalendJob.log", "ECOLOTRANS_URBANTZ_TASKS_IMPORT.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ECOLOTRANS_URBANTZ_TASKS_IMPORT.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Billing_Comptabilite_File != null){
				
					this.setProperty("Billing_Comptabilite_File", Billing_Comptabilite_File.toString());
				
			}
			
			if(Billing_Comptabilite_Folder != null){
				
					this.setProperty("Billing_Comptabilite_Folder", Billing_Comptabilite_Folder.toString());
				
			}
			
			if(Billing_Distant_Rep != null){
				
					this.setProperty("Billing_Distant_Rep", Billing_Distant_Rep.toString());
				
			}
			
			if(Billing_File_Masque != null){
				
					this.setProperty("Billing_File_Masque", Billing_File_Masque.toString());
				
			}
			
			if(Billing_Local_Rep != null){
				
					this.setProperty("Billing_Local_Rep", Billing_Local_Rep.toString());
				
			}
			
			if(Billing_Name != null){
				
					this.setProperty("Billing_Name", Billing_Name.toString());
				
			}
			
			if(Billing_Start_Number != null){
				
					this.setProperty("Billing_Start_Number", Billing_Start_Number.toString());
				
			}
			
			if(Billing_TVA_default_value != null){
				
					this.setProperty("Billing_TVA_default_value", Billing_TVA_default_value.toString());
				
			}
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(FTP_DistantRep != null){
				
					this.setProperty("FTP_DistantRep", FTP_DistantRep.toString());
				
			}
			
			if(FTP_FileMasque != null){
				
					this.setProperty("FTP_FileMasque", FTP_FileMasque.toString());
				
			}
			
			if(FTP_Hote != null){
				
					this.setProperty("FTP_Hote", FTP_Hote.toString());
				
			}
			
			if(FTP_Password != null){
				
					this.setProperty("FTP_Password", FTP_Password.toString());
				
			}
			
			if(FTP_Port != null){
				
					this.setProperty("FTP_Port", FTP_Port.toString());
				
			}
			
			if(FTP_User != null){
				
					this.setProperty("FTP_User", FTP_User.toString());
				
			}
			
			if(keyStore_file_name != null){
				
					this.setProperty("keyStore_file_name", keyStore_file_name.toString());
				
			}
			
			if(KeyStore_Repo != null){
				
					this.setProperty("KeyStore_Repo", KeyStore_Repo.toString());
				
			}
			
			if(mail_password != null){
				
					this.setProperty("mail_password", mail_password.toString());
				
			}
			
			if(send_mail_from != null){
				
					this.setProperty("send_mail_from", send_mail_from.toString());
				
			}
			
			if(send_mail_to != null){
				
					this.setProperty("send_mail_to", send_mail_to.toString());
				
			}
			
			if(send_to_second_mail != null){
				
					this.setProperty("send_to_second_mail", send_to_second_mail.toString());
				
			}
			
			if(send_to_third_mail != null){
				
					this.setProperty("send_to_third_mail", send_to_third_mail.toString());
				
			}
			
			if(Clients_Masque != null){
				
					this.setProperty("Clients_Masque", Clients_Masque.toString());
				
			}
			
			if(Code_client_masque != null){
				
					this.setProperty("Code_client_masque", Code_client_masque.toString());
				
			}
			
			if(Command_Logistic_Invalid_Date != null){
				
					this.setProperty("Command_Logistic_Invalid_Date", Command_Logistic_Invalid_Date.toString());
				
			}
			
			if(Command_Logistic_Masque != null){
				
					this.setProperty("Command_Logistic_Masque", Command_Logistic_Masque.toString());
				
			}
			
			if(Command_Transport_Masque != null){
				
					this.setProperty("Command_Transport_Masque", Command_Transport_Masque.toString());
				
			}
			
			if(Command_Transport_Masque_Express != null){
				
					this.setProperty("Command_Transport_Masque_Express", Command_Transport_Masque_Express.toString());
				
			}
			
			if(Holiday_Days_Masque != null){
				
					this.setProperty("Holiday_Days_Masque", Holiday_Days_Masque.toString());
				
			}
			
			if(Livraisons_Exception != null){
				
					this.setProperty("Livraisons_Exception", Livraisons_Exception.toString());
				
			}
			
			if(Livraisons_Masque != null){
				
					this.setProperty("Livraisons_Masque", Livraisons_Masque.toString());
				
			}
			
			if(Livraisons_Ok != null){
				
					this.setProperty("Livraisons_Ok", Livraisons_Ok.toString());
				
			}
			
			if(Tarification_Logistic_Masque != null){
				
					this.setProperty("Tarification_Logistic_Masque", Tarification_Logistic_Masque.toString());
				
			}
			
			if(Tarification_Transport_Masque != null){
				
					this.setProperty("Tarification_Transport_Masque", Tarification_Transport_Masque.toString());
				
			}
			
			if(Tournee_Masque != null){
				
					this.setProperty("Tournee_Masque", Tournee_Masque.toString());
				
			}
			
			if(TVA_Exceptions != null){
				
					this.setProperty("TVA_Exceptions", TVA_Exceptions.toString());
				
			}
			
			if(Backup != null){
				
					this.setProperty("Backup", Backup.toString());
				
			}
			
			if(Server_Clean != null){
				
					this.setProperty("Server_Clean", Server_Clean.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Server_Out != null){
				
					this.setProperty("Server_Out", Server_Out.toString());
				
			}
			
			if(Cleaning_Reject_Logistic_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Logistic_price_is_zero", Cleaning_Reject_Logistic_price_is_zero.toString());
				
			}
			
			if(Cleaning_Reject_Rep != null){
				
					this.setProperty("Cleaning_Reject_Rep", Cleaning_Reject_Rep.toString());
				
			}
			
			if(Cleaning_Reject_Transport_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Transport_price_is_zero", Cleaning_Reject_Transport_price_is_zero.toString());
				
			}
			
			if(Cleaning_Transport_no_PostalCode != null){
				
					this.setProperty("Cleaning_Transport_no_PostalCode", Cleaning_Transport_no_PostalCode.toString());
				
			}
			
			if(Csv_File_Masque != null){
				
					this.setProperty("Csv_File_Masque", Csv_File_Masque.toString());
				
			}
			
			if(Diagnostic_Reject_Command_Error != null){
				
					this.setProperty("Diagnostic_Reject_Command_Error", Diagnostic_Reject_Command_Error.toString());
				
			}
			
			if(Diagnostic_Reject_Day_Not_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Day_Not_Ok", Diagnostic_Reject_Day_Not_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Postal_Code_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Postal_Code_Ok", Diagnostic_Reject_Postal_Code_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Rep != null){
				
					this.setProperty("Diagnostic_Reject_Rep", Diagnostic_Reject_Rep.toString());
				
			}
			
			if(Excel_File_Masque != null){
				
					this.setProperty("Excel_File_Masque", Excel_File_Masque.toString());
				
			}
			
			if(Migration_Billing_Not_Ok != null){
				
					this.setProperty("Migration_Billing_Not_Ok", Migration_Billing_Not_Ok.toString());
				
			}
			
			if(Reject_Client_File != null){
				
					this.setProperty("Reject_Client_File", Reject_Client_File.toString());
				
			}
			
			if(Reject_Client_Local_Rep != null){
				
					this.setProperty("Reject_Client_Local_Rep", Reject_Client_Local_Rep.toString());
				
			}
			
			if(Reject_Command_Logisitc_Code_Client != null){
				
					this.setProperty("Reject_Command_Logisitc_Code_Client", Reject_Command_Logisitc_Code_Client.toString());
				
			}
			
			if(Reject_Command_Transport_Code_Client != null){
				
					this.setProperty("Reject_Command_Transport_Code_Client", Reject_Command_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Distant_Rep != null){
				
					this.setProperty("Reject_Distant_Rep", Reject_Distant_Rep.toString());
				
			}
			
			if(Reject_Duplicated_Client_File != null){
				
					this.setProperty("Reject_Duplicated_Client_File", Reject_Duplicated_Client_File.toString());
				
			}
			
			if(Reject_Migration_Local_Rep != null){
				
					this.setProperty("Reject_Migration_Local_Rep", Reject_Migration_Local_Rep.toString());
				
			}
			
			if(Reject_Not_Complet_Client != null){
				
					this.setProperty("Reject_Not_Complet_Client", Reject_Not_Complet_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Local_Rep != null){
				
					this.setProperty("Reject_Service_Detail_Local_Rep", Reject_Service_Detail_Local_Rep.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_DB != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_DB", Reject_Service_Detail_Logistic_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_Unknown_Client", Reject_Service_Detail_Logistic_Unknown_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_DB != null){
				
					this.setProperty("Reject_Service_Detail_Transport_DB", Reject_Service_Detail_Transport_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Transport_Unknown_Client", Reject_Service_Detail_Transport_Unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Local_Rep != null){
				
					this.setProperty("Reject_Tarification_Local_Rep", Reject_Tarification_Local_Rep.toString());
				
			}
			
			if(Reject_Tarification_Logistic_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_Code_Client", Reject_Tarification_Logistic_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Logistic_DB != null){
				
					this.setProperty("Reject_Tarification_Logistic_DB", Reject_Tarification_Logistic_DB.toString());
				
			}
			
			if(Reject_Tarification_Logistic_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_unknown_Client", Reject_Tarification_Logistic_unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_Code_Client", Reject_Tarification_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_DB != null){
				
					this.setProperty("Reject_Tarification_Transport_DB", Reject_Tarification_Transport_DB.toString());
				
			}
			
			if(Reject_Tarification_Transport_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_unknown_Client", Reject_Tarification_Transport_unknown_Client.toString());
				
			}
			
			if(code_client_length != null){
				
					this.setProperty("code_client_length", code_client_length.toString());
				
			}
			
			if(code_client_regex != null){
				
					this.setProperty("code_client_regex", code_client_regex.toString());
				
			}
			
			if(Livraison_directory != null){
				
					this.setProperty("Livraison_directory", Livraison_directory.toString());
				
			}
			
			if(Round_directory != null){
				
					this.setProperty("Round_directory", Round_directory.toString());
				
			}
			
			if(Round_file_name != null){
				
					this.setProperty("Round_file_name", Round_file_name.toString());
				
			}
			
			if(Round_Minus_Days != null){
				
					this.setProperty("Round_Minus_Days", Round_Minus_Days.toString());
				
			}
			
			if(start_date != null){
				
					this.setProperty("start_date", start_date.toString());
				
			}
			
			if(Urbantz_directory != null){
				
					this.setProperty("Urbantz_directory", Urbantz_directory.toString());
				
			}
			
			if(urbantz_extraction_date != null){
				
					this.setProperty("urbantz_extraction_date", urbantz_extraction_date.toString());
				
			}
			
			if(Max_Extarction_Hour_HH != null){
				
					this.setProperty("Max_Extarction_Hour_HH", Max_Extarction_Hour_HH.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Billing_Comptabilite_File;
public String getBilling_Comptabilite_File(){
	return this.Billing_Comptabilite_File;
}
public String Billing_Comptabilite_Folder;
public String getBilling_Comptabilite_Folder(){
	return this.Billing_Comptabilite_Folder;
}
public String Billing_Distant_Rep;
public String getBilling_Distant_Rep(){
	return this.Billing_Distant_Rep;
}
public String Billing_File_Masque;
public String getBilling_File_Masque(){
	return this.Billing_File_Masque;
}
public String Billing_Local_Rep;
public String getBilling_Local_Rep(){
	return this.Billing_Local_Rep;
}
public String Billing_Name;
public String getBilling_Name(){
	return this.Billing_Name;
}
public Integer Billing_Start_Number;
public Integer getBilling_Start_Number(){
	return this.Billing_Start_Number;
}
public Float Billing_TVA_default_value;
public Float getBilling_TVA_default_value(){
	return this.Billing_TVA_default_value;
}
public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
		public String FTP_DistantRep;
		public String getFTP_DistantRep(){
			return this.FTP_DistantRep;
		}
		
public String FTP_FileMasque;
public String getFTP_FileMasque(){
	return this.FTP_FileMasque;
}
public String FTP_Hote;
public String getFTP_Hote(){
	return this.FTP_Hote;
}
public java.lang.String FTP_Password;
public java.lang.String getFTP_Password(){
	return this.FTP_Password;
}
public Integer FTP_Port;
public Integer getFTP_Port(){
	return this.FTP_Port;
}
public String FTP_User;
public String getFTP_User(){
	return this.FTP_User;
}
public String keyStore_file_name;
public String getKeyStore_file_name(){
	return this.keyStore_file_name;
}
public String KeyStore_Repo;
public String getKeyStore_Repo(){
	return this.KeyStore_Repo;
}
public java.lang.String mail_password;
public java.lang.String getMail_password(){
	return this.mail_password;
}
public String send_mail_from;
public String getSend_mail_from(){
	return this.send_mail_from;
}
public String send_mail_to;
public String getSend_mail_to(){
	return this.send_mail_to;
}
public String send_to_second_mail;
public String getSend_to_second_mail(){
	return this.send_to_second_mail;
}
public String send_to_third_mail;
public String getSend_to_third_mail(){
	return this.send_to_third_mail;
}
public String Clients_Masque;
public String getClients_Masque(){
	return this.Clients_Masque;
}
public String Code_client_masque;
public String getCode_client_masque(){
	return this.Code_client_masque;
}
public String Command_Logistic_Invalid_Date;
public String getCommand_Logistic_Invalid_Date(){
	return this.Command_Logistic_Invalid_Date;
}
public String Command_Logistic_Masque;
public String getCommand_Logistic_Masque(){
	return this.Command_Logistic_Masque;
}
public String Command_Transport_Masque;
public String getCommand_Transport_Masque(){
	return this.Command_Transport_Masque;
}
public String Command_Transport_Masque_Express;
public String getCommand_Transport_Masque_Express(){
	return this.Command_Transport_Masque_Express;
}
public String Holiday_Days_Masque;
public String getHoliday_Days_Masque(){
	return this.Holiday_Days_Masque;
}
public String Livraisons_Exception;
public String getLivraisons_Exception(){
	return this.Livraisons_Exception;
}
public String Livraisons_Masque;
public String getLivraisons_Masque(){
	return this.Livraisons_Masque;
}
public String Livraisons_Ok;
public String getLivraisons_Ok(){
	return this.Livraisons_Ok;
}
public String Tarification_Logistic_Masque;
public String getTarification_Logistic_Masque(){
	return this.Tarification_Logistic_Masque;
}
public String Tarification_Transport_Masque;
public String getTarification_Transport_Masque(){
	return this.Tarification_Transport_Masque;
}
public String Tournee_Masque;
public String getTournee_Masque(){
	return this.Tournee_Masque;
}
public String TVA_Exceptions;
public String getTVA_Exceptions(){
	return this.TVA_Exceptions;
}
public String Backup;
public String getBackup(){
	return this.Backup;
}
public String Server_Clean;
public String getServer_Clean(){
	return this.Server_Clean;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Server_Out;
public String getServer_Out(){
	return this.Server_Out;
}
public String Cleaning_Reject_Logistic_price_is_zero;
public String getCleaning_Reject_Logistic_price_is_zero(){
	return this.Cleaning_Reject_Logistic_price_is_zero;
}
public String Cleaning_Reject_Rep;
public String getCleaning_Reject_Rep(){
	return this.Cleaning_Reject_Rep;
}
public String Cleaning_Reject_Transport_price_is_zero;
public String getCleaning_Reject_Transport_price_is_zero(){
	return this.Cleaning_Reject_Transport_price_is_zero;
}
public String Cleaning_Transport_no_PostalCode;
public String getCleaning_Transport_no_PostalCode(){
	return this.Cleaning_Transport_no_PostalCode;
}
public String Csv_File_Masque;
public String getCsv_File_Masque(){
	return this.Csv_File_Masque;
}
public String Diagnostic_Reject_Command_Error;
public String getDiagnostic_Reject_Command_Error(){
	return this.Diagnostic_Reject_Command_Error;
}
public String Diagnostic_Reject_Day_Not_Ok;
public String getDiagnostic_Reject_Day_Not_Ok(){
	return this.Diagnostic_Reject_Day_Not_Ok;
}
public String Diagnostic_Reject_Postal_Code_Ok;
public String getDiagnostic_Reject_Postal_Code_Ok(){
	return this.Diagnostic_Reject_Postal_Code_Ok;
}
public String Diagnostic_Reject_Rep;
public String getDiagnostic_Reject_Rep(){
	return this.Diagnostic_Reject_Rep;
}
public String Excel_File_Masque;
public String getExcel_File_Masque(){
	return this.Excel_File_Masque;
}
public String Migration_Billing_Not_Ok;
public String getMigration_Billing_Not_Ok(){
	return this.Migration_Billing_Not_Ok;
}
public String Reject_Client_File;
public String getReject_Client_File(){
	return this.Reject_Client_File;
}
public String Reject_Client_Local_Rep;
public String getReject_Client_Local_Rep(){
	return this.Reject_Client_Local_Rep;
}
public String Reject_Command_Logisitc_Code_Client;
public String getReject_Command_Logisitc_Code_Client(){
	return this.Reject_Command_Logisitc_Code_Client;
}
public String Reject_Command_Transport_Code_Client;
public String getReject_Command_Transport_Code_Client(){
	return this.Reject_Command_Transport_Code_Client;
}
public String Reject_Distant_Rep;
public String getReject_Distant_Rep(){
	return this.Reject_Distant_Rep;
}
public String Reject_Duplicated_Client_File;
public String getReject_Duplicated_Client_File(){
	return this.Reject_Duplicated_Client_File;
}
public String Reject_Migration_Local_Rep;
public String getReject_Migration_Local_Rep(){
	return this.Reject_Migration_Local_Rep;
}
public String Reject_Not_Complet_Client;
public String getReject_Not_Complet_Client(){
	return this.Reject_Not_Complet_Client;
}
public String Reject_Service_Detail_Local_Rep;
public String getReject_Service_Detail_Local_Rep(){
	return this.Reject_Service_Detail_Local_Rep;
}
public String Reject_Service_Detail_Logistic_DB;
public String getReject_Service_Detail_Logistic_DB(){
	return this.Reject_Service_Detail_Logistic_DB;
}
public String Reject_Service_Detail_Logistic_Unknown_Client;
public String getReject_Service_Detail_Logistic_Unknown_Client(){
	return this.Reject_Service_Detail_Logistic_Unknown_Client;
}
public String Reject_Service_Detail_Transport_DB;
public String getReject_Service_Detail_Transport_DB(){
	return this.Reject_Service_Detail_Transport_DB;
}
public String Reject_Service_Detail_Transport_Unknown_Client;
public String getReject_Service_Detail_Transport_Unknown_Client(){
	return this.Reject_Service_Detail_Transport_Unknown_Client;
}
public String Reject_Tarification_Local_Rep;
public String getReject_Tarification_Local_Rep(){
	return this.Reject_Tarification_Local_Rep;
}
public String Reject_Tarification_Logistic_Code_Client;
public String getReject_Tarification_Logistic_Code_Client(){
	return this.Reject_Tarification_Logistic_Code_Client;
}
public String Reject_Tarification_Logistic_DB;
public String getReject_Tarification_Logistic_DB(){
	return this.Reject_Tarification_Logistic_DB;
}
public String Reject_Tarification_Logistic_unknown_Client;
public String getReject_Tarification_Logistic_unknown_Client(){
	return this.Reject_Tarification_Logistic_unknown_Client;
}
public String Reject_Tarification_Transport_Code_Client;
public String getReject_Tarification_Transport_Code_Client(){
	return this.Reject_Tarification_Transport_Code_Client;
}
public String Reject_Tarification_Transport_DB;
public String getReject_Tarification_Transport_DB(){
	return this.Reject_Tarification_Transport_DB;
}
public String Reject_Tarification_Transport_unknown_Client;
public String getReject_Tarification_Transport_unknown_Client(){
	return this.Reject_Tarification_Transport_unknown_Client;
}
public Integer code_client_length;
public Integer getCode_client_length(){
	return this.code_client_length;
}
public String code_client_regex;
public String getCode_client_regex(){
	return this.code_client_regex;
}
public String Livraison_directory;
public String getLivraison_directory(){
	return this.Livraison_directory;
}
public String Round_directory;
public String getRound_directory(){
	return this.Round_directory;
}
public String Round_file_name;
public String getRound_file_name(){
	return this.Round_file_name;
}
public Integer Round_Minus_Days;
public Integer getRound_Minus_Days(){
	return this.Round_Minus_Days;
}
public String start_date;
public String getStart_date(){
	return this.start_date;
}
public String Urbantz_directory;
public String getUrbantz_directory(){
	return this.Urbantz_directory;
}
public String urbantz_extraction_date;
public String getUrbantz_extraction_date(){
	return this.urbantz_extraction_date;
}
public Integer Max_Extarction_Hour_HH;
public Integer getMax_Extarction_Hour_HH(){
	return this.Max_Extarction_Hour_HH;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ECOLOTRANS_URBANTZ_TASKS_IMPORT";
	private final String projectName = "ATELIER_FACTURATION";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_6dAgwJiwEeyH_6mQlKsMew", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ECOLOTRANS_URBANTZ_TASKS_IMPORT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ECOLOTRANS_URBANTZ_TASKS_IMPORT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLoop_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLoop_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRESTClient_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tReplicate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLoop_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLoop_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "K0jGae_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tWarn_4Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_4");
		org.slf4j.MDC.put("_subJobPid", "eGHyUe_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_4", false);
		start_Hash.put("tWarn_4", System.currentTimeMillis());
		
	
	currentComponent="tWarn_4";
	
	
		int tos_count_tWarn_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_4 = new StringBuilder();
                    log4jParamters_tWarn_4.append("Parameters:");
                            log4jParamters_tWarn_4.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_4.append(" | ");
                            log4jParamters_tWarn_4.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_4.append(" | ");
                            log4jParamters_tWarn_4.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + (log4jParamters_tWarn_4) );
                    } 
                } 
            new BytesLimit65535_tWarn_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_4", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_4 begin ] stop
 */
	
	/**
	 * [tWarn_4 main ] start
	 */

	

	
	
	currentComponent="tWarn_4";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_4", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_4 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_4_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_4_WARN_PRIORITY", 4);
	globalMap.put("tWarn_4_WARN_CODE", 42);
	
} catch (Exception e_tWarn_4) {
globalMap.put("tWarn_4_ERROR_MESSAGE",e_tWarn_4.getMessage());
	logIgnoredError(String.format("tWarn_4 - tWarn failed to log message due to internal error: %s", e_tWarn_4), e_tWarn_4);
}


 


	tos_count_tWarn_4++;

/**
 * [tWarn_4 main ] stop
 */
	
	/**
	 * [tWarn_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_4";
	
	

 



/**
 * [tWarn_4 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_4";
	
	

 



/**
 * [tWarn_4 process_data_end ] stop
 */
	
	/**
	 * [tWarn_4 end ] start
	 */

	

	
	
	currentComponent="tWarn_4";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Done.") );

ok_Hash.put("tWarn_4", true);
end_Hash.put("tWarn_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tWarn_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_4 finally ] start
	 */

	

	
	
	currentComponent="tWarn_4";
	
	

 



/**
 * [tWarn_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_4_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "t0SOWN_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tSetGlobalVar_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tSetGlobalVar_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_2");
		org.slf4j.MDC.put("_subJobPid", "dWte8Y_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";
	
	
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_2.append("Parameters:");
                            log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(new Date(),+3,\"dd\"))")+", KEY="+("\"end_date_plus_one\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(new Date(),-1,\"dd\"))")+", KEY="+("\"start_date\"")+"}]");
                        log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_2", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

globalMap.put("end_date_plus_one", TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(new Date(),+3,"dd")));
globalMap.put("start_date", TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(new Date(),-1,"dd")));

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tLoop_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 1);
	}
	


public void tLoop_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLoop_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tLoop_2");
		org.slf4j.MDC.put("_subJobPid", "GTX4F4_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tLoop_2 begin ] start
	 */

				
			int NB_ITERATE_tJava_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tLoop_2", false);
		start_Hash.put("tLoop_2", System.currentTimeMillis());
		
	
	currentComponent="tLoop_2";
	
	
		int tos_count_tLoop_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLoop_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLoop_2 = new StringBuilder();
                    log4jParamters_tLoop_2.append("Parameters:");
                            log4jParamters_tLoop_2.append("FORLOOP" + " = " + "false");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("WHILELOOP" + " = " + "true");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("DECLARATION" + " = " + "int i = 0 ;");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("CONDITION" + " = " + "!TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy/MM/dd\", (String)globalMap.get(\"start_date\")),+i,\"dd\")).equals((String)globalMap.get(\"end_date_plus_one\"))");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("ITERATION" + " = " + "i++;");
                        log4jParamters_tLoop_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + (log4jParamters_tLoop_2) );
                    } 
                } 
            new BytesLimit65535_tLoop_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLoop_2", "tLoop_2", "tLoop");
				talendJobLogProcess(globalMap);
			}
			

int current_iteration_tLoop_2 = 0;

int i = 0 ;;
	
		log.info("tLoop_2 - Start to loop using a while loop. Initial declaration: '" + "int i = 0 ;" + "'. Condition: '" + "!TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy/MM/dd\", (String)globalMap.get(\"start_date\")),+i,\"dd\")).equals((String)globalMap.get(\"end_date_plus_one\"))" + "'.");
	
while(!TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(TalendDate.parseDate("yyyy/MM/dd", (String)globalMap.get("start_date")),+i,"dd")).equals((String)globalMap.get("end_date_plus_one"))){
	
		log.debug("tLoop_2 - Current iteration value: " + current_iteration_tLoop_2);
	
current_iteration_tLoop_2++;
globalMap.put("tLoop_2_CURRENT_ITERATION",current_iteration_tLoop_2);


 



/**
 * [tLoop_2 begin ] stop
 */
	
	/**
	 * [tLoop_2 main ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 


	tos_count_tLoop_2++;

/**
 * [tLoop_2 main ] stop
 */
	
	/**
	 * [tLoop_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 process_data_begin ] stop
 */
	NB_ITERATE_tJava_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("out2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("task_db", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tJava_3);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";
	
	
		int tos_count_tJava_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_3", "tJava_3", "tJava");
				talendJobLogProcess(globalMap);
			}
			


 System.out.println ((Integer)globalMap.get("tLoop_2_CURRENT_ITERATION"));

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_begin ] stop
 */
	
	/**
	 * [tJava_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_end ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tSetGlobalVar_1Process(globalMap);



/**
 * [tJava_3 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tJava_3);
						}				
					




	
	/**
	 * [tLoop_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 process_data_end ] stop
 */
	
	/**
	 * [tLoop_2 end ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	




i++;;


}


 
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + ("Done.") );

ok_Hash.put("tLoop_2", true);
end_Hash.put("tLoop_2", System.currentTimeMillis());




/**
 * [tLoop_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLoop_2 finally ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 finally ] stop
 */

	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLoop_2_SUBPROCESS_STATE", 1);
	}
	


public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_1");
		org.slf4j.MDC.put("_subJobPid", "pU7VVg_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";
	
	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_1.append("Parameters:");
                            log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("50")+", KEY="+("\"numberOfElementsInPage\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyy-MM-dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy-MM-dd\", (String)globalMap.get(\"start_date\")),+( (Integer)globalMap.get(\"tLoop_2_CURRENT_ITERATION\")-1),\"dd\"))")+", KEY="+("\"day_to_retrieve\"")+"}]");
                        log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_1", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

globalMap.put("numberOfElementsInPage", 50);
globalMap.put("day_to_retrieve", TalendDate.formatDate("yyyy-MM-dd",TalendDate.addDate(TalendDate.parseDate("yyyy-MM-dd", (String)globalMap.get("start_date")),+( (Integer)globalMap.get("tLoop_2_CURRENT_ITERATION")-1),"dd")));

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tLoop_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return true;
				}
				public Integer itemIdLength(){
				    return 24;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public Boolean confirmed;

				public Boolean getConfirmed () {
					return this.confirmed;
				}

				public Boolean confirmedIsNullable(){
				    return true;
				}
				public Boolean confirmedIsKey(){
				    return false;
				}
				public Integer confirmedLength(){
				    return 5;
				}
				public Integer confirmedPrecision(){
				    return 0;
				}
				public String confirmedDefault(){
				
					return null;
				
				}
				public String confirmedComment(){
				
				    return "";
				
				}
				public String confirmedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String confirmedOriginalDbColumnName(){
				
					return "confirmed";
				
				}

				
			    public String pictures___;

				public String getPictures___ () {
					return this.pictures___;
				}

				public Boolean pictures___IsNullable(){
				    return true;
				}
				public Boolean pictures___IsKey(){
				    return false;
				}
				public Integer pictures___Length(){
				    return 2;
				}
				public Integer pictures___Precision(){
				    return 0;
				}
				public String pictures___Default(){
				
					return null;
				
				}
				public String pictures___Comment(){
				
				    return "";
				
				}
				public String pictures___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String pictures___OriginalDbColumnName(){
				
					return "pictures___";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 9;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return null;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public String labels;

				public String getLabels () {
					return this.labels;
				}

				public Boolean labelsIsNullable(){
				    return true;
				}
				public Boolean labelsIsKey(){
				    return false;
				}
				public Integer labelsLength(){
				    return 9;
				}
				public Integer labelsPrecision(){
				    return 0;
				}
				public String labelsDefault(){
				
					return null;
				
				}
				public String labelsComment(){
				
				    return "";
				
				}
				public String labelsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String labelsOriginalDbColumnName(){
				
					return "labels";
				
				}

				
			    public String skills;

				public String getSkills () {
					return this.skills;
				}

				public Boolean skillsIsNullable(){
				    return true;
				}
				public Boolean skillsIsKey(){
				    return false;
				}
				public Integer skillsLength(){
				    return 2;
				}
				public Integer skillsPrecision(){
				    return 0;
				}
				public String skillsDefault(){
				
					return null;
				
				}
				public String skillsComment(){
				
				    return "";
				
				}
				public String skillsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String skillsOriginalDbColumnName(){
				
					return "skills";
				
				}

				
			    public String lastOfflineUpdatedAt;

				public String getLastOfflineUpdatedAt () {
					return this.lastOfflineUpdatedAt;
				}

				public Boolean lastOfflineUpdatedAtIsNullable(){
				    return true;
				}
				public Boolean lastOfflineUpdatedAtIsKey(){
				    return false;
				}
				public Integer lastOfflineUpdatedAtLength(){
				    return 0;
				}
				public Integer lastOfflineUpdatedAtPrecision(){
				    return 0;
				}
				public String lastOfflineUpdatedAtDefault(){
				
					return null;
				
				}
				public String lastOfflineUpdatedAtComment(){
				
				    return "";
				
				}
				public String lastOfflineUpdatedAtPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String lastOfflineUpdatedAtOriginalDbColumnName(){
				
					return "lastOfflineUpdatedAt";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 5;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 5;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String barcode;

				public String getBarcode () {
					return this.barcode;
				}

				public Boolean barcodeIsNullable(){
				    return true;
				}
				public Boolean barcodeIsKey(){
				    return false;
				}
				public Integer barcodeLength(){
				    return 0;
				}
				public Integer barcodePrecision(){
				    return 0;
				}
				public String barcodeDefault(){
				
					return null;
				
				}
				public String barcodeComment(){
				
				    return "";
				
				}
				public String barcodePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeOriginalDbColumnName(){
				
					return "barcode";
				
				}

				
			    public String barcodeEncoding;

				public String getBarcodeEncoding () {
					return this.barcodeEncoding;
				}

				public Boolean barcodeEncodingIsNullable(){
				    return true;
				}
				public Boolean barcodeEncodingIsKey(){
				    return false;
				}
				public Integer barcodeEncodingLength(){
				    return 7;
				}
				public Integer barcodeEncodingPrecision(){
				    return 0;
				}
				public String barcodeEncodingDefault(){
				
					return null;
				
				}
				public String barcodeEncodingComment(){
				
				    return "";
				
				}
				public String barcodeEncodingPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeEncodingOriginalDbColumnName(){
				
					return "barcodeEncoding";
				
				}

				
			    public Double weight;

				public Double getWeight () {
					return this.weight;
				}

				public Boolean weightIsNullable(){
				    return true;
				}
				public Boolean weightIsKey(){
				    return false;
				}
				public Integer weightLength(){
				    return null;
				}
				public Integer weightPrecision(){
				    return 0;
				}
				public String weightDefault(){
				
					return null;
				
				}
				public String weightComment(){
				
				    return "";
				
				}
				public String weightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String weightOriginalDbColumnName(){
				
					return "weight";
				
				}

				
			    public Double volume;

				public Double getVolume () {
					return this.volume;
				}

				public Boolean volumeIsNullable(){
				    return true;
				}
				public Boolean volumeIsKey(){
				    return false;
				}
				public Integer volumeLength(){
				    return null;
				}
				public Integer volumePrecision(){
				    return 3;
				}
				public String volumeDefault(){
				
					return null;
				
				}
				public String volumeComment(){
				
				    return "";
				
				}
				public String volumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String volumeOriginalDbColumnName(){
				
					return "volume";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return true;
				}
				public Integer taskIdLength(){
				    return 24;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String reference;

				public String getReference () {
					return this.reference;
				}

				public Boolean referenceIsNullable(){
				    return true;
				}
				public Boolean referenceIsKey(){
				    return false;
				}
				public Integer referenceLength(){
				    return null;
				}
				public Integer referencePrecision(){
				    return null;
				}
				public String referenceDefault(){
				
					return null;
				
				}
				public String referenceComment(){
				
				    return "";
				
				}
				public String referencePattern(){
				
					return "";
				
				}
				public String referenceOriginalDbColumnName(){
				
					return "reference";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.itemId == null) ? 0 : this.itemId.hashCode());
					
						result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.itemId == null) {
							if (other.itemId != null)
								return false;
						
						} else if (!this.itemId.equals(other.itemId))
						
							return false;
					
						if (this.taskId == null) {
							if (other.taskId != null)
								return false;
						
						} else if (!this.taskId.equals(other.taskId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.itemId = this.itemId;
	            other.confirmed = this.confirmed;
	            other.pictures___ = this.pictures___;
	            other.status = this.status;
	            other.quantity = this.quantity;
	            other.labels = this.labels;
	            other.skills = this.skills;
	            other.lastOfflineUpdatedAt = this.lastOfflineUpdatedAt;
	            other.name = this.name;
	            other.type = this.type;
	            other.barcode = this.barcode;
	            other.barcodeEncoding = this.barcodeEncoding;
	            other.weight = this.weight;
	            other.volume = this.volume;
	            other.taskId = this.taskId;
	            other.reference = this.reference;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.itemId = this.itemId;
	            	other.taskId = this.taskId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",confirmed="+String.valueOf(confirmed));
		sb.append(",pictures___="+pictures___);
		sb.append(",status="+status);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",labels="+labels);
		sb.append(",skills="+skills);
		sb.append(",lastOfflineUpdatedAt="+lastOfflineUpdatedAt);
		sb.append(",name="+name);
		sb.append(",type="+type);
		sb.append(",barcode="+barcode);
		sb.append(",barcodeEncoding="+barcodeEncoding);
		sb.append(",weight="+String.valueOf(weight));
		sb.append(",volume="+String.valueOf(volume));
		sb.append(",taskId="+taskId);
		sb.append(",reference="+reference);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(confirmed == null){
        					sb.append("<null>");
        				}else{
            				sb.append(confirmed);
            			}
            		
        			sb.append("|");
        		
        				if(pictures___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pictures___);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(labels == null){
        					sb.append("<null>");
        				}else{
            				sb.append(labels);
            			}
            		
        			sb.append("|");
        		
        				if(skills == null){
        					sb.append("<null>");
        				}else{
            				sb.append(skills);
            			}
            		
        			sb.append("|");
        		
        				if(lastOfflineUpdatedAt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastOfflineUpdatedAt);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(barcode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcode);
            			}
            		
        			sb.append("|");
        		
        				if(barcodeEncoding == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcodeEncoding);
            			}
            		
        			sb.append("|");
        		
        				if(weight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weight);
            			}
            		
        			sb.append("|");
        		
        				if(volume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(volume);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.itemId, other.itemId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.taskId, other.taskId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class out2Struct implements routines.system.IPersistableRow<out2Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return true;
				}
				public Integer itemIdLength(){
				    return 24;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public Boolean confirmed;

				public Boolean getConfirmed () {
					return this.confirmed;
				}

				public Boolean confirmedIsNullable(){
				    return true;
				}
				public Boolean confirmedIsKey(){
				    return false;
				}
				public Integer confirmedLength(){
				    return 5;
				}
				public Integer confirmedPrecision(){
				    return 0;
				}
				public String confirmedDefault(){
				
					return null;
				
				}
				public String confirmedComment(){
				
				    return "";
				
				}
				public String confirmedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String confirmedOriginalDbColumnName(){
				
					return "confirmed";
				
				}

				
			    public String pictures___;

				public String getPictures___ () {
					return this.pictures___;
				}

				public Boolean pictures___IsNullable(){
				    return true;
				}
				public Boolean pictures___IsKey(){
				    return false;
				}
				public Integer pictures___Length(){
				    return 2;
				}
				public Integer pictures___Precision(){
				    return 0;
				}
				public String pictures___Default(){
				
					return null;
				
				}
				public String pictures___Comment(){
				
				    return "";
				
				}
				public String pictures___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String pictures___OriginalDbColumnName(){
				
					return "pictures___";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 9;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return null;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public String labels;

				public String getLabels () {
					return this.labels;
				}

				public Boolean labelsIsNullable(){
				    return true;
				}
				public Boolean labelsIsKey(){
				    return false;
				}
				public Integer labelsLength(){
				    return 9;
				}
				public Integer labelsPrecision(){
				    return 0;
				}
				public String labelsDefault(){
				
					return null;
				
				}
				public String labelsComment(){
				
				    return "";
				
				}
				public String labelsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String labelsOriginalDbColumnName(){
				
					return "labels";
				
				}

				
			    public String skills;

				public String getSkills () {
					return this.skills;
				}

				public Boolean skillsIsNullable(){
				    return true;
				}
				public Boolean skillsIsKey(){
				    return false;
				}
				public Integer skillsLength(){
				    return 2;
				}
				public Integer skillsPrecision(){
				    return 0;
				}
				public String skillsDefault(){
				
					return null;
				
				}
				public String skillsComment(){
				
				    return "";
				
				}
				public String skillsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String skillsOriginalDbColumnName(){
				
					return "skills";
				
				}

				
			    public String lastOfflineUpdatedAt;

				public String getLastOfflineUpdatedAt () {
					return this.lastOfflineUpdatedAt;
				}

				public Boolean lastOfflineUpdatedAtIsNullable(){
				    return true;
				}
				public Boolean lastOfflineUpdatedAtIsKey(){
				    return false;
				}
				public Integer lastOfflineUpdatedAtLength(){
				    return 0;
				}
				public Integer lastOfflineUpdatedAtPrecision(){
				    return 0;
				}
				public String lastOfflineUpdatedAtDefault(){
				
					return null;
				
				}
				public String lastOfflineUpdatedAtComment(){
				
				    return "";
				
				}
				public String lastOfflineUpdatedAtPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String lastOfflineUpdatedAtOriginalDbColumnName(){
				
					return "lastOfflineUpdatedAt";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 5;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 5;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String barcode;

				public String getBarcode () {
					return this.barcode;
				}

				public Boolean barcodeIsNullable(){
				    return true;
				}
				public Boolean barcodeIsKey(){
				    return false;
				}
				public Integer barcodeLength(){
				    return 0;
				}
				public Integer barcodePrecision(){
				    return 0;
				}
				public String barcodeDefault(){
				
					return null;
				
				}
				public String barcodeComment(){
				
				    return "";
				
				}
				public String barcodePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeOriginalDbColumnName(){
				
					return "barcode";
				
				}

				
			    public String barcodeEncoding;

				public String getBarcodeEncoding () {
					return this.barcodeEncoding;
				}

				public Boolean barcodeEncodingIsNullable(){
				    return true;
				}
				public Boolean barcodeEncodingIsKey(){
				    return false;
				}
				public Integer barcodeEncodingLength(){
				    return 7;
				}
				public Integer barcodeEncodingPrecision(){
				    return 0;
				}
				public String barcodeEncodingDefault(){
				
					return null;
				
				}
				public String barcodeEncodingComment(){
				
				    return "";
				
				}
				public String barcodeEncodingPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeEncodingOriginalDbColumnName(){
				
					return "barcodeEncoding";
				
				}

				
			    public Double weight;

				public Double getWeight () {
					return this.weight;
				}

				public Boolean weightIsNullable(){
				    return true;
				}
				public Boolean weightIsKey(){
				    return false;
				}
				public Integer weightLength(){
				    return null;
				}
				public Integer weightPrecision(){
				    return 0;
				}
				public String weightDefault(){
				
					return null;
				
				}
				public String weightComment(){
				
				    return "";
				
				}
				public String weightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String weightOriginalDbColumnName(){
				
					return "weight";
				
				}

				
			    public Double volume;

				public Double getVolume () {
					return this.volume;
				}

				public Boolean volumeIsNullable(){
				    return true;
				}
				public Boolean volumeIsKey(){
				    return false;
				}
				public Integer volumeLength(){
				    return null;
				}
				public Integer volumePrecision(){
				    return 3;
				}
				public String volumeDefault(){
				
					return null;
				
				}
				public String volumeComment(){
				
				    return "";
				
				}
				public String volumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String volumeOriginalDbColumnName(){
				
					return "volume";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return true;
				}
				public Integer taskIdLength(){
				    return 24;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String reference;

				public String getReference () {
					return this.reference;
				}

				public Boolean referenceIsNullable(){
				    return true;
				}
				public Boolean referenceIsKey(){
				    return false;
				}
				public Integer referenceLength(){
				    return null;
				}
				public Integer referencePrecision(){
				    return null;
				}
				public String referenceDefault(){
				
					return null;
				
				}
				public String referenceComment(){
				
				    return "";
				
				}
				public String referencePattern(){
				
					return "";
				
				}
				public String referenceOriginalDbColumnName(){
				
					return "reference";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.itemId == null) ? 0 : this.itemId.hashCode());
					
						result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out2Struct other = (out2Struct) obj;
		
						if (this.itemId == null) {
							if (other.itemId != null)
								return false;
						
						} else if (!this.itemId.equals(other.itemId))
						
							return false;
					
						if (this.taskId == null) {
							if (other.taskId != null)
								return false;
						
						} else if (!this.taskId.equals(other.taskId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(out2Struct other) {

		other.itemId = this.itemId;
	            other.confirmed = this.confirmed;
	            other.pictures___ = this.pictures___;
	            other.status = this.status;
	            other.quantity = this.quantity;
	            other.labels = this.labels;
	            other.skills = this.skills;
	            other.lastOfflineUpdatedAt = this.lastOfflineUpdatedAt;
	            other.name = this.name;
	            other.type = this.type;
	            other.barcode = this.barcode;
	            other.barcodeEncoding = this.barcodeEncoding;
	            other.weight = this.weight;
	            other.volume = this.volume;
	            other.taskId = this.taskId;
	            other.reference = this.reference;
	            
	}

	public void copyKeysDataTo(out2Struct other) {

		other.itemId = this.itemId;
	            	other.taskId = this.taskId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",confirmed="+String.valueOf(confirmed));
		sb.append(",pictures___="+pictures___);
		sb.append(",status="+status);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",labels="+labels);
		sb.append(",skills="+skills);
		sb.append(",lastOfflineUpdatedAt="+lastOfflineUpdatedAt);
		sb.append(",name="+name);
		sb.append(",type="+type);
		sb.append(",barcode="+barcode);
		sb.append(",barcodeEncoding="+barcodeEncoding);
		sb.append(",weight="+String.valueOf(weight));
		sb.append(",volume="+String.valueOf(volume));
		sb.append(",taskId="+taskId);
		sb.append(",reference="+reference);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(confirmed == null){
        					sb.append("<null>");
        				}else{
            				sb.append(confirmed);
            			}
            		
        			sb.append("|");
        		
        				if(pictures___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pictures___);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(labels == null){
        					sb.append("<null>");
        				}else{
            				sb.append(labels);
            			}
            		
        			sb.append("|");
        		
        				if(skills == null){
        					sb.append("<null>");
        				}else{
            				sb.append(skills);
            			}
            		
        			sb.append("|");
        		
        				if(lastOfflineUpdatedAt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastOfflineUpdatedAt);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(barcode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcode);
            			}
            		
        			sb.append("|");
        		
        				if(barcodeEncoding == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcodeEncoding);
            			}
            		
        			sb.append("|");
        		
        				if(weight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weight);
            			}
            		
        			sb.append("|");
        		
        				if(volume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(volume);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.itemId, other.itemId);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.taskId, other.taskId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}

				public Boolean itemIdIsNullable(){
				    return true;
				}
				public Boolean itemIdIsKey(){
				    return false;
				}
				public Integer itemIdLength(){
				    return 24;
				}
				public Integer itemIdPrecision(){
				    return 0;
				}
				public String itemIdDefault(){
				
					return null;
				
				}
				public String itemIdComment(){
				
				    return "";
				
				}
				public String itemIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String itemIdOriginalDbColumnName(){
				
					return "itemId";
				
				}

				
			    public Boolean confirmed;

				public Boolean getConfirmed () {
					return this.confirmed;
				}

				public Boolean confirmedIsNullable(){
				    return true;
				}
				public Boolean confirmedIsKey(){
				    return false;
				}
				public Integer confirmedLength(){
				    return 5;
				}
				public Integer confirmedPrecision(){
				    return 0;
				}
				public String confirmedDefault(){
				
					return null;
				
				}
				public String confirmedComment(){
				
				    return "";
				
				}
				public String confirmedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String confirmedOriginalDbColumnName(){
				
					return "confirmed";
				
				}

				
			    public String pictures___;

				public String getPictures___ () {
					return this.pictures___;
				}

				public Boolean pictures___IsNullable(){
				    return true;
				}
				public Boolean pictures___IsKey(){
				    return false;
				}
				public Integer pictures___Length(){
				    return 2;
				}
				public Integer pictures___Precision(){
				    return 0;
				}
				public String pictures___Default(){
				
					return null;
				
				}
				public String pictures___Comment(){
				
				    return "";
				
				}
				public String pictures___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String pictures___OriginalDbColumnName(){
				
					return "pictures___";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 9;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Double quantity;

				public Double getQuantity () {
					return this.quantity;
				}

				public Boolean quantityIsNullable(){
				    return true;
				}
				public Boolean quantityIsKey(){
				    return false;
				}
				public Integer quantityLength(){
				    return null;
				}
				public Integer quantityPrecision(){
				    return 0;
				}
				public String quantityDefault(){
				
					return null;
				
				}
				public String quantityComment(){
				
				    return "";
				
				}
				public String quantityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String quantityOriginalDbColumnName(){
				
					return "quantity";
				
				}

				
			    public String labels;

				public String getLabels () {
					return this.labels;
				}

				public Boolean labelsIsNullable(){
				    return true;
				}
				public Boolean labelsIsKey(){
				    return false;
				}
				public Integer labelsLength(){
				    return 9;
				}
				public Integer labelsPrecision(){
				    return 0;
				}
				public String labelsDefault(){
				
					return null;
				
				}
				public String labelsComment(){
				
				    return "";
				
				}
				public String labelsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String labelsOriginalDbColumnName(){
				
					return "labels";
				
				}

				
			    public String skills;

				public String getSkills () {
					return this.skills;
				}

				public Boolean skillsIsNullable(){
				    return true;
				}
				public Boolean skillsIsKey(){
				    return false;
				}
				public Integer skillsLength(){
				    return 2;
				}
				public Integer skillsPrecision(){
				    return 0;
				}
				public String skillsDefault(){
				
					return null;
				
				}
				public String skillsComment(){
				
				    return "";
				
				}
				public String skillsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String skillsOriginalDbColumnName(){
				
					return "skills";
				
				}

				
			    public String lastOfflineUpdatedAt;

				public String getLastOfflineUpdatedAt () {
					return this.lastOfflineUpdatedAt;
				}

				public Boolean lastOfflineUpdatedAtIsNullable(){
				    return true;
				}
				public Boolean lastOfflineUpdatedAtIsKey(){
				    return false;
				}
				public Integer lastOfflineUpdatedAtLength(){
				    return 0;
				}
				public Integer lastOfflineUpdatedAtPrecision(){
				    return 0;
				}
				public String lastOfflineUpdatedAtDefault(){
				
					return null;
				
				}
				public String lastOfflineUpdatedAtComment(){
				
				    return "";
				
				}
				public String lastOfflineUpdatedAtPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String lastOfflineUpdatedAtOriginalDbColumnName(){
				
					return "lastOfflineUpdatedAt";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 5;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 5;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String barcode;

				public String getBarcode () {
					return this.barcode;
				}

				public Boolean barcodeIsNullable(){
				    return true;
				}
				public Boolean barcodeIsKey(){
				    return false;
				}
				public Integer barcodeLength(){
				    return 0;
				}
				public Integer barcodePrecision(){
				    return 0;
				}
				public String barcodeDefault(){
				
					return null;
				
				}
				public String barcodeComment(){
				
				    return "";
				
				}
				public String barcodePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeOriginalDbColumnName(){
				
					return "barcode";
				
				}

				
			    public String barcodeEncoding;

				public String getBarcodeEncoding () {
					return this.barcodeEncoding;
				}

				public Boolean barcodeEncodingIsNullable(){
				    return true;
				}
				public Boolean barcodeEncodingIsKey(){
				    return false;
				}
				public Integer barcodeEncodingLength(){
				    return 7;
				}
				public Integer barcodeEncodingPrecision(){
				    return 0;
				}
				public String barcodeEncodingDefault(){
				
					return null;
				
				}
				public String barcodeEncodingComment(){
				
				    return "";
				
				}
				public String barcodeEncodingPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String barcodeEncodingOriginalDbColumnName(){
				
					return "barcodeEncoding";
				
				}

				
			    public Double weight;

				public Double getWeight () {
					return this.weight;
				}

				public Boolean weightIsNullable(){
				    return true;
				}
				public Boolean weightIsKey(){
				    return false;
				}
				public Integer weightLength(){
				    return null;
				}
				public Integer weightPrecision(){
				    return 0;
				}
				public String weightDefault(){
				
					return null;
				
				}
				public String weightComment(){
				
				    return "";
				
				}
				public String weightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String weightOriginalDbColumnName(){
				
					return "weight";
				
				}

				
			    public Double volume;

				public Double getVolume () {
					return this.volume;
				}

				public Boolean volumeIsNullable(){
				    return true;
				}
				public Boolean volumeIsKey(){
				    return false;
				}
				public Integer volumeLength(){
				    return null;
				}
				public Integer volumePrecision(){
				    return 3;
				}
				public String volumeDefault(){
				
					return null;
				
				}
				public String volumeComment(){
				
				    return "";
				
				}
				public String volumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String volumeOriginalDbColumnName(){
				
					return "volume";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 24;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String reference;

				public String getReference () {
					return this.reference;
				}

				public Boolean referenceIsNullable(){
				    return true;
				}
				public Boolean referenceIsKey(){
				    return false;
				}
				public Integer referenceLength(){
				    return null;
				}
				public Integer referencePrecision(){
				    return null;
				}
				public String referenceDefault(){
				
					return null;
				
				}
				public String referenceComment(){
				
				    return "";
				
				}
				public String referencePattern(){
				
					return "";
				
				}
				public String referenceOriginalDbColumnName(){
				
					return "reference";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.confirmed = null;
           				} else {
           			    	this.confirmed = dis.readBoolean();
           				}
					
					this.pictures___ = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.quantity = null;
           				} else {
           			    	this.quantity = dis.readDouble();
           				}
					
					this.labels = readString(dis);
					
					this.skills = readString(dis);
					
					this.lastOfflineUpdatedAt = readString(dis);
					
					this.name = readString(dis);
					
					this.type = readString(dis);
					
					this.barcode = readString(dis);
					
					this.barcodeEncoding = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
					this.reference = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Boolean
				
						if(this.confirmed == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.confirmed);
		            	}
					
					// String
				
						writeString(this.pictures___,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.quantity == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.quantity);
		            	}
					
					// String
				
						writeString(this.labels,dos);
					
					// String
				
						writeString(this.skills,dos);
					
					// String
				
						writeString(this.lastOfflineUpdatedAt,dos);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.barcode,dos);
					
					// String
				
						writeString(this.barcodeEncoding,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",confirmed="+String.valueOf(confirmed));
		sb.append(",pictures___="+pictures___);
		sb.append(",status="+status);
		sb.append(",quantity="+String.valueOf(quantity));
		sb.append(",labels="+labels);
		sb.append(",skills="+skills);
		sb.append(",lastOfflineUpdatedAt="+lastOfflineUpdatedAt);
		sb.append(",name="+name);
		sb.append(",type="+type);
		sb.append(",barcode="+barcode);
		sb.append(",barcodeEncoding="+barcodeEncoding);
		sb.append(",weight="+String.valueOf(weight));
		sb.append(",volume="+String.valueOf(volume));
		sb.append(",taskId="+taskId);
		sb.append(",reference="+reference);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(confirmed == null){
        					sb.append("<null>");
        				}else{
            				sb.append(confirmed);
            			}
            		
        			sb.append("|");
        		
        				if(pictures___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pictures___);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(quantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(quantity);
            			}
            		
        			sb.append("|");
        		
        				if(labels == null){
        					sb.append("<null>");
        				}else{
            				sb.append(labels);
            			}
            		
        			sb.append("|");
        		
        				if(skills == null){
        					sb.append("<null>");
        				}else{
            				sb.append(skills);
            			}
            		
        			sb.append("|");
        		
        				if(lastOfflineUpdatedAt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lastOfflineUpdatedAt);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(barcode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcode);
            			}
            		
        			sb.append("|");
        		
        				if(barcodeEncoding == null){
        					sb.append("<null>");
        				}else{
            				sb.append(barcodeEncoding);
            			}
            		
        			sb.append("|");
        		
        				if(weight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weight);
            			}
            		
        			sb.append("|");
        		
        				if(volume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(volume);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class task_dbStruct implements routines.system.IPersistableRow<task_dbStruct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return true;
				}
				public Integer sourceIdLength(){
				    return 150;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public String sourceLocationType;

				public String getSourceLocationType () {
					return this.sourceLocationType;
				}

				public Boolean sourceLocationTypeIsNullable(){
				    return true;
				}
				public Boolean sourceLocationTypeIsKey(){
				    return false;
				}
				public Integer sourceLocationTypeLength(){
				    return 150;
				}
				public Integer sourceLocationTypePrecision(){
				    return 0;
				}
				public String sourceLocationTypeDefault(){
				
					return null;
				
				}
				public String sourceLocationTypeComment(){
				
				    return "";
				
				}
				public String sourceLocationTypePattern(){
				
					return "";
				
				}
				public String sourceLocationTypeOriginalDbColumnName(){
				
					return "sourceLocationType";
				
				}

				
			    public String sourceLocationGeometry;

				public String getSourceLocationGeometry () {
					return this.sourceLocationGeometry;
				}

				public Boolean sourceLocationGeometryIsNullable(){
				    return true;
				}
				public Boolean sourceLocationGeometryIsKey(){
				    return false;
				}
				public Integer sourceLocationGeometryLength(){
				    return 150;
				}
				public Integer sourceLocationGeometryPrecision(){
				    return 0;
				}
				public String sourceLocationGeometryDefault(){
				
					return null;
				
				}
				public String sourceLocationGeometryComment(){
				
				    return "";
				
				}
				public String sourceLocationGeometryPattern(){
				
					return "";
				
				}
				public String sourceLocationGeometryOriginalDbColumnName(){
				
					return "sourceLocationGeometry";
				
				}

				
			    public String sourceAddressLines;

				public String getSourceAddressLines () {
					return this.sourceAddressLines;
				}

				public Boolean sourceAddressLinesIsNullable(){
				    return true;
				}
				public Boolean sourceAddressLinesIsKey(){
				    return false;
				}
				public Integer sourceAddressLinesLength(){
				    return 150;
				}
				public Integer sourceAddressLinesPrecision(){
				    return 0;
				}
				public String sourceAddressLinesDefault(){
				
					return null;
				
				}
				public String sourceAddressLinesComment(){
				
				    return "";
				
				}
				public String sourceAddressLinesPattern(){
				
					return "";
				
				}
				public String sourceAddressLinesOriginalDbColumnName(){
				
					return "sourceAddressLines";
				
				}

				
			    public Double sourceGeocodeScore;

				public Double getSourceGeocodeScore () {
					return this.sourceGeocodeScore;
				}

				public Boolean sourceGeocodeScoreIsNullable(){
				    return true;
				}
				public Boolean sourceGeocodeScoreIsKey(){
				    return false;
				}
				public Integer sourceGeocodeScoreLength(){
				    return 22;
				}
				public Integer sourceGeocodeScorePrecision(){
				    return 0;
				}
				public String sourceGeocodeScoreDefault(){
				
					return null;
				
				}
				public String sourceGeocodeScoreComment(){
				
				    return "";
				
				}
				public String sourceGeocodeScorePattern(){
				
					return "";
				
				}
				public String sourceGeocodeScoreOriginalDbColumnName(){
				
					return "sourceGeocodeScore";
				
				}

				
			    public Double sourceCleanScore;

				public Double getSourceCleanScore () {
					return this.sourceCleanScore;
				}

				public Boolean sourceCleanScoreIsNullable(){
				    return true;
				}
				public Boolean sourceCleanScoreIsKey(){
				    return false;
				}
				public Integer sourceCleanScoreLength(){
				    return 22;
				}
				public Integer sourceCleanScorePrecision(){
				    return 0;
				}
				public String sourceCleanScoreDefault(){
				
					return null;
				
				}
				public String sourceCleanScoreComment(){
				
				    return "";
				
				}
				public String sourceCleanScorePattern(){
				
					return "";
				
				}
				public String sourceCleanScoreOriginalDbColumnName(){
				
					return "sourceCleanScore";
				
				}

				
			    public String sourceStreet;

				public String getSourceStreet () {
					return this.sourceStreet;
				}

				public Boolean sourceStreetIsNullable(){
				    return true;
				}
				public Boolean sourceStreetIsKey(){
				    return false;
				}
				public Integer sourceStreetLength(){
				    return 500;
				}
				public Integer sourceStreetPrecision(){
				    return 0;
				}
				public String sourceStreetDefault(){
				
					return null;
				
				}
				public String sourceStreetComment(){
				
				    return "";
				
				}
				public String sourceStreetPattern(){
				
					return "";
				
				}
				public String sourceStreetOriginalDbColumnName(){
				
					return "sourceStreet";
				
				}

				
			    public String sourceCity;

				public String getSourceCity () {
					return this.sourceCity;
				}

				public Boolean sourceCityIsNullable(){
				    return true;
				}
				public Boolean sourceCityIsKey(){
				    return false;
				}
				public Integer sourceCityLength(){
				    return 150;
				}
				public Integer sourceCityPrecision(){
				    return 0;
				}
				public String sourceCityDefault(){
				
					return null;
				
				}
				public String sourceCityComment(){
				
				    return "";
				
				}
				public String sourceCityPattern(){
				
					return "";
				
				}
				public String sourceCityOriginalDbColumnName(){
				
					return "sourceCity";
				
				}

				
			    public Integer sourceZip;

				public Integer getSourceZip () {
					return this.sourceZip;
				}

				public Boolean sourceZipIsNullable(){
				    return true;
				}
				public Boolean sourceZipIsKey(){
				    return false;
				}
				public Integer sourceZipLength(){
				    return 10;
				}
				public Integer sourceZipPrecision(){
				    return 0;
				}
				public String sourceZipDefault(){
				
					return null;
				
				}
				public String sourceZipComment(){
				
				    return "";
				
				}
				public String sourceZipPattern(){
				
					return "";
				
				}
				public String sourceZipOriginalDbColumnName(){
				
					return "sourceZip";
				
				}

				
			    public String sourceCountry;

				public String getSourceCountry () {
					return this.sourceCountry;
				}

				public Boolean sourceCountryIsNullable(){
				    return true;
				}
				public Boolean sourceCountryIsKey(){
				    return false;
				}
				public Integer sourceCountryLength(){
				    return 150;
				}
				public Integer sourceCountryPrecision(){
				    return 0;
				}
				public String sourceCountryDefault(){
				
					return null;
				
				}
				public String sourceCountryComment(){
				
				    return "";
				
				}
				public String sourceCountryPattern(){
				
					return "";
				
				}
				public String sourceCountryOriginalDbColumnName(){
				
					return "sourceCountry";
				
				}

				
			    public String sourceAddress;

				public String getSourceAddress () {
					return this.sourceAddress;
				}

				public Boolean sourceAddressIsNullable(){
				    return true;
				}
				public Boolean sourceAddressIsKey(){
				    return false;
				}
				public Integer sourceAddressLength(){
				    return 150;
				}
				public Integer sourceAddressPrecision(){
				    return 0;
				}
				public String sourceAddressDefault(){
				
					return null;
				
				}
				public String sourceAddressComment(){
				
				    return "";
				
				}
				public String sourceAddressPattern(){
				
					return "";
				
				}
				public String sourceAddressOriginalDbColumnName(){
				
					return "sourceAddress";
				
				}

				
			    public String locationType;

				public String getLocationType () {
					return this.locationType;
				}

				public Boolean locationTypeIsNullable(){
				    return true;
				}
				public Boolean locationTypeIsKey(){
				    return false;
				}
				public Integer locationTypeLength(){
				    return 150;
				}
				public Integer locationTypePrecision(){
				    return 0;
				}
				public String locationTypeDefault(){
				
					return null;
				
				}
				public String locationTypeComment(){
				
				    return "";
				
				}
				public String locationTypePattern(){
				
					return "";
				
				}
				public String locationTypeOriginalDbColumnName(){
				
					return "locationType";
				
				}

				
			    public String locationGeometry;

				public String getLocationGeometry () {
					return this.locationGeometry;
				}

				public Boolean locationGeometryIsNullable(){
				    return true;
				}
				public Boolean locationGeometryIsKey(){
				    return false;
				}
				public Integer locationGeometryLength(){
				    return 150;
				}
				public Integer locationGeometryPrecision(){
				    return 0;
				}
				public String locationGeometryDefault(){
				
					return null;
				
				}
				public String locationGeometryComment(){
				
				    return "";
				
				}
				public String locationGeometryPattern(){
				
					return "";
				
				}
				public String locationGeometryOriginalDbColumnName(){
				
					return "locationGeometry";
				
				}

				
			    public String locationAddressLines;

				public String getLocationAddressLines () {
					return this.locationAddressLines;
				}

				public Boolean locationAddressLinesIsNullable(){
				    return true;
				}
				public Boolean locationAddressLinesIsKey(){
				    return false;
				}
				public Integer locationAddressLinesLength(){
				    return 150;
				}
				public Integer locationAddressLinesPrecision(){
				    return 0;
				}
				public String locationAddressLinesDefault(){
				
					return null;
				
				}
				public String locationAddressLinesComment(){
				
				    return "";
				
				}
				public String locationAddressLinesPattern(){
				
					return "";
				
				}
				public String locationAddressLinesOriginalDbColumnName(){
				
					return "locationAddressLines";
				
				}

				
			    public Double locationGeocodeScore;

				public Double getLocationGeocodeScore () {
					return this.locationGeocodeScore;
				}

				public Boolean locationGeocodeScoreIsNullable(){
				    return true;
				}
				public Boolean locationGeocodeScoreIsKey(){
				    return false;
				}
				public Integer locationGeocodeScoreLength(){
				    return 22;
				}
				public Integer locationGeocodeScorePrecision(){
				    return 0;
				}
				public String locationGeocodeScoreDefault(){
				
					return null;
				
				}
				public String locationGeocodeScoreComment(){
				
				    return "";
				
				}
				public String locationGeocodeScorePattern(){
				
					return "";
				
				}
				public String locationGeocodeScoreOriginalDbColumnName(){
				
					return "locationGeocodeScore";
				
				}

				
			    public Double locationCleanScore;

				public Double getLocationCleanScore () {
					return this.locationCleanScore;
				}

				public Boolean locationCleanScoreIsNullable(){
				    return true;
				}
				public Boolean locationCleanScoreIsKey(){
				    return false;
				}
				public Integer locationCleanScoreLength(){
				    return 22;
				}
				public Integer locationCleanScorePrecision(){
				    return 0;
				}
				public String locationCleanScoreDefault(){
				
					return null;
				
				}
				public String locationCleanScoreComment(){
				
				    return "";
				
				}
				public String locationCleanScorePattern(){
				
					return "";
				
				}
				public String locationCleanScoreOriginalDbColumnName(){
				
					return "locationCleanScore";
				
				}

				
			    public String locationStreet;

				public String getLocationStreet () {
					return this.locationStreet;
				}

				public Boolean locationStreetIsNullable(){
				    return true;
				}
				public Boolean locationStreetIsKey(){
				    return false;
				}
				public Integer locationStreetLength(){
				    return 150;
				}
				public Integer locationStreetPrecision(){
				    return 0;
				}
				public String locationStreetDefault(){
				
					return null;
				
				}
				public String locationStreetComment(){
				
				    return "";
				
				}
				public String locationStreetPattern(){
				
					return "";
				
				}
				public String locationStreetOriginalDbColumnName(){
				
					return "locationStreet";
				
				}

				
			    public String locationAddress;

				public String getLocationAddress () {
					return this.locationAddress;
				}

				public Boolean locationAddressIsNullable(){
				    return true;
				}
				public Boolean locationAddressIsKey(){
				    return false;
				}
				public Integer locationAddressLength(){
				    return 150;
				}
				public Integer locationAddressPrecision(){
				    return 0;
				}
				public String locationAddressDefault(){
				
					return null;
				
				}
				public String locationAddressComment(){
				
				    return "";
				
				}
				public String locationAddressPattern(){
				
					return "";
				
				}
				public String locationAddressOriginalDbColumnName(){
				
					return "locationAddress";
				
				}

				
			    public Integer locationZip;

				public Integer getLocationZip () {
					return this.locationZip;
				}

				public Boolean locationZipIsNullable(){
				    return true;
				}
				public Boolean locationZipIsKey(){
				    return false;
				}
				public Integer locationZipLength(){
				    return 10;
				}
				public Integer locationZipPrecision(){
				    return 0;
				}
				public String locationZipDefault(){
				
					return null;
				
				}
				public String locationZipComment(){
				
				    return "";
				
				}
				public String locationZipPattern(){
				
					return "";
				
				}
				public String locationZipOriginalDbColumnName(){
				
					return "locationZip";
				
				}

				
			    public String locationCity;

				public String getLocationCity () {
					return this.locationCity;
				}

				public Boolean locationCityIsNullable(){
				    return true;
				}
				public Boolean locationCityIsKey(){
				    return false;
				}
				public Integer locationCityLength(){
				    return 150;
				}
				public Integer locationCityPrecision(){
				    return 0;
				}
				public String locationCityDefault(){
				
					return null;
				
				}
				public String locationCityComment(){
				
				    return "";
				
				}
				public String locationCityPattern(){
				
					return "";
				
				}
				public String locationCityOriginalDbColumnName(){
				
					return "locationCity";
				
				}

				
			    public String locationCountry;

				public String getLocationCountry () {
					return this.locationCountry;
				}

				public Boolean locationCountryIsNullable(){
				    return true;
				}
				public Boolean locationCountryIsKey(){
				    return false;
				}
				public Integer locationCountryLength(){
				    return 150;
				}
				public Integer locationCountryPrecision(){
				    return 0;
				}
				public String locationCountryDefault(){
				
					return null;
				
				}
				public String locationCountryComment(){
				
				    return "";
				
				}
				public String locationCountryPattern(){
				
					return "";
				
				}
				public String locationCountryOriginalDbColumnName(){
				
					return "locationCountry";
				
				}

				
			    public String locationOrigin;

				public String getLocationOrigin () {
					return this.locationOrigin;
				}

				public Boolean locationOriginIsNullable(){
				    return true;
				}
				public Boolean locationOriginIsKey(){
				    return false;
				}
				public Integer locationOriginLength(){
				    return 150;
				}
				public Integer locationOriginPrecision(){
				    return 0;
				}
				public String locationOriginDefault(){
				
					return null;
				
				}
				public String locationOriginComment(){
				
				    return "";
				
				}
				public String locationOriginPattern(){
				
					return "";
				
				}
				public String locationOriginOriginalDbColumnName(){
				
					return "locationOrigin";
				
				}

				
			    public String contactBuildingInfo;

				public String getContactBuildingInfo () {
					return this.contactBuildingInfo;
				}

				public Boolean contactBuildingInfoIsNullable(){
				    return true;
				}
				public Boolean contactBuildingInfoIsKey(){
				    return false;
				}
				public Integer contactBuildingInfoLength(){
				    return 500;
				}
				public Integer contactBuildingInfoPrecision(){
				    return 0;
				}
				public String contactBuildingInfoDefault(){
				
					return null;
				
				}
				public String contactBuildingInfoComment(){
				
				    return "";
				
				}
				public String contactBuildingInfoPattern(){
				
					return "";
				
				}
				public String contactBuildingInfoOriginalDbColumnName(){
				
					return "contactBuildingInfo";
				
				}

				
			    public String contactPerson;

				public String getContactPerson () {
					return this.contactPerson;
				}

				public Boolean contactPersonIsNullable(){
				    return true;
				}
				public Boolean contactPersonIsKey(){
				    return false;
				}
				public Integer contactPersonLength(){
				    return 150;
				}
				public Integer contactPersonPrecision(){
				    return 0;
				}
				public String contactPersonDefault(){
				
					return null;
				
				}
				public String contactPersonComment(){
				
				    return "";
				
				}
				public String contactPersonPattern(){
				
					return "";
				
				}
				public String contactPersonOriginalDbColumnName(){
				
					return "contactPerson";
				
				}

				
			    public String contactPhone;

				public String getContactPhone () {
					return this.contactPhone;
				}

				public Boolean contactPhoneIsNullable(){
				    return true;
				}
				public Boolean contactPhoneIsKey(){
				    return false;
				}
				public Integer contactPhoneLength(){
				    return 150;
				}
				public Integer contactPhonePrecision(){
				    return 0;
				}
				public String contactPhoneDefault(){
				
					return null;
				
				}
				public String contactPhoneComment(){
				
				    return "";
				
				}
				public String contactPhonePattern(){
				
					return "";
				
				}
				public String contactPhoneOriginalDbColumnName(){
				
					return "contactPhone";
				
				}

				
			    public String contactEmail;

				public String getContactEmail () {
					return this.contactEmail;
				}

				public Boolean contactEmailIsNullable(){
				    return true;
				}
				public Boolean contactEmailIsKey(){
				    return false;
				}
				public Integer contactEmailLength(){
				    return 150;
				}
				public Integer contactEmailPrecision(){
				    return 0;
				}
				public String contactEmailDefault(){
				
					return null;
				
				}
				public String contactEmailComment(){
				
				    return "";
				
				}
				public String contactEmailPattern(){
				
					return "";
				
				}
				public String contactEmailOriginalDbColumnName(){
				
					return "contactEmail";
				
				}

				
			    public String timeWindowStart;

				public String getTimeWindowStart () {
					return this.timeWindowStart;
				}

				public Boolean timeWindowStartIsNullable(){
				    return true;
				}
				public Boolean timeWindowStartIsKey(){
				    return false;
				}
				public Integer timeWindowStartLength(){
				    return 150;
				}
				public Integer timeWindowStartPrecision(){
				    return 0;
				}
				public String timeWindowStartDefault(){
				
					return null;
				
				}
				public String timeWindowStartComment(){
				
				    return "";
				
				}
				public String timeWindowStartPattern(){
				
					return "";
				
				}
				public String timeWindowStartOriginalDbColumnName(){
				
					return "timeWindowStart";
				
				}

				
			    public String timeWindowStop;

				public String getTimeWindowStop () {
					return this.timeWindowStop;
				}

				public Boolean timeWindowStopIsNullable(){
				    return true;
				}
				public Boolean timeWindowStopIsKey(){
				    return false;
				}
				public Integer timeWindowStopLength(){
				    return 150;
				}
				public Integer timeWindowStopPrecision(){
				    return 0;
				}
				public String timeWindowStopDefault(){
				
					return null;
				
				}
				public String timeWindowStopComment(){
				
				    return "";
				
				}
				public String timeWindowStopPattern(){
				
					return "";
				
				}
				public String timeWindowStopOriginalDbColumnName(){
				
					return "timeWindowStop";
				
				}

				
			    public String sourceStatus;

				public String getSourceStatus () {
					return this.sourceStatus;
				}

				public Boolean sourceStatusIsNullable(){
				    return true;
				}
				public Boolean sourceStatusIsKey(){
				    return false;
				}
				public Integer sourceStatusLength(){
				    return 150;
				}
				public Integer sourceStatusPrecision(){
				    return 0;
				}
				public String sourceStatusDefault(){
				
					return null;
				
				}
				public String sourceStatusComment(){
				
				    return "";
				
				}
				public String sourceStatusPattern(){
				
					return "";
				
				}
				public String sourceStatusOriginalDbColumnName(){
				
					return "sourceStatus";
				
				}

				
			    public String sourceActivity;

				public String getSourceActivity () {
					return this.sourceActivity;
				}

				public Boolean sourceActivityIsNullable(){
				    return true;
				}
				public Boolean sourceActivityIsKey(){
				    return false;
				}
				public Integer sourceActivityLength(){
				    return 150;
				}
				public Integer sourceActivityPrecision(){
				    return 0;
				}
				public String sourceActivityDefault(){
				
					return null;
				
				}
				public String sourceActivityComment(){
				
				    return "";
				
				}
				public String sourceActivityPattern(){
				
					return "";
				
				}
				public String sourceActivityOriginalDbColumnName(){
				
					return "sourceActivity";
				
				}

				
			    public String sourceSkills;

				public String getSourceSkills () {
					return this.sourceSkills;
				}

				public Boolean sourceSkillsIsNullable(){
				    return true;
				}
				public Boolean sourceSkillsIsKey(){
				    return false;
				}
				public Integer sourceSkillsLength(){
				    return 150;
				}
				public Integer sourceSkillsPrecision(){
				    return 0;
				}
				public String sourceSkillsDefault(){
				
					return null;
				
				}
				public String sourceSkillsComment(){
				
				    return "";
				
				}
				public String sourceSkillsPattern(){
				
					return "";
				
				}
				public String sourceSkillsOriginalDbColumnName(){
				
					return "sourceSkills";
				
				}

				
			    public String sourceLabels;

				public String getSourceLabels () {
					return this.sourceLabels;
				}

				public Boolean sourceLabelsIsNullable(){
				    return true;
				}
				public Boolean sourceLabelsIsKey(){
				    return false;
				}
				public Integer sourceLabelsLength(){
				    return 150;
				}
				public Integer sourceLabelsPrecision(){
				    return 0;
				}
				public String sourceLabelsDefault(){
				
					return null;
				
				}
				public String sourceLabelsComment(){
				
				    return "";
				
				}
				public String sourceLabelsPattern(){
				
					return "";
				
				}
				public String sourceLabelsOriginalDbColumnName(){
				
					return "sourceLabels";
				
				}

				
			    public Double sourceAttempts;

				public Double getSourceAttempts () {
					return this.sourceAttempts;
				}

				public Boolean sourceAttemptsIsNullable(){
				    return true;
				}
				public Boolean sourceAttemptsIsKey(){
				    return false;
				}
				public Integer sourceAttemptsLength(){
				    return 22;
				}
				public Integer sourceAttemptsPrecision(){
				    return 0;
				}
				public String sourceAttemptsDefault(){
				
					return null;
				
				}
				public String sourceAttemptsComment(){
				
				    return "";
				
				}
				public String sourceAttemptsPattern(){
				
					return "";
				
				}
				public String sourceAttemptsOriginalDbColumnName(){
				
					return "sourceAttempts";
				
				}

				
			    public String sourceHasBeenPaid;

				public String getSourceHasBeenPaid () {
					return this.sourceHasBeenPaid;
				}

				public Boolean sourceHasBeenPaidIsNullable(){
				    return true;
				}
				public Boolean sourceHasBeenPaidIsKey(){
				    return false;
				}
				public Integer sourceHasBeenPaidLength(){
				    return 150;
				}
				public Integer sourceHasBeenPaidPrecision(){
				    return 0;
				}
				public String sourceHasBeenPaidDefault(){
				
					return null;
				
				}
				public String sourceHasBeenPaidComment(){
				
				    return "";
				
				}
				public String sourceHasBeenPaidPattern(){
				
					return "";
				
				}
				public String sourceHasBeenPaidOriginalDbColumnName(){
				
					return "sourceHasBeenPaid";
				
				}

				
			    public String sourceClosureDate;

				public String getSourceClosureDate () {
					return this.sourceClosureDate;
				}

				public Boolean sourceClosureDateIsNullable(){
				    return true;
				}
				public Boolean sourceClosureDateIsKey(){
				    return false;
				}
				public Integer sourceClosureDateLength(){
				    return 150;
				}
				public Integer sourceClosureDatePrecision(){
				    return 0;
				}
				public String sourceClosureDateDefault(){
				
					return null;
				
				}
				public String sourceClosureDateComment(){
				
				    return "";
				
				}
				public String sourceClosureDatePattern(){
				
					return "";
				
				}
				public String sourceClosureDateOriginalDbColumnName(){
				
					return "sourceClosureDate";
				
				}

				
			    public String sourcePaymentType;

				public String getSourcePaymentType () {
					return this.sourcePaymentType;
				}

				public Boolean sourcePaymentTypeIsNullable(){
				    return true;
				}
				public Boolean sourcePaymentTypeIsKey(){
				    return false;
				}
				public Integer sourcePaymentTypeLength(){
				    return 150;
				}
				public Integer sourcePaymentTypePrecision(){
				    return 0;
				}
				public String sourcePaymentTypeDefault(){
				
					return null;
				
				}
				public String sourcePaymentTypeComment(){
				
				    return "";
				
				}
				public String sourcePaymentTypePattern(){
				
					return "";
				
				}
				public String sourcePaymentTypeOriginalDbColumnName(){
				
					return "sourcePaymentType";
				
				}

				
			    public Double sourceCollectedAmount;

				public Double getSourceCollectedAmount () {
					return this.sourceCollectedAmount;
				}

				public Boolean sourceCollectedAmountIsNullable(){
				    return true;
				}
				public Boolean sourceCollectedAmountIsKey(){
				    return false;
				}
				public Integer sourceCollectedAmountLength(){
				    return 22;
				}
				public Integer sourceCollectedAmountPrecision(){
				    return 0;
				}
				public String sourceCollectedAmountDefault(){
				
					return null;
				
				}
				public String sourceCollectedAmountComment(){
				
				    return "";
				
				}
				public String sourceCollectedAmountPattern(){
				
					return "";
				
				}
				public String sourceCollectedAmountOriginalDbColumnName(){
				
					return "sourceCollectedAmount";
				
				}

				
			    public Object metadataCodeArticle;

				public Object getMetadataCodeArticle () {
					return this.metadataCodeArticle;
				}

				public Boolean metadataCodeArticleIsNullable(){
				    return true;
				}
				public Boolean metadataCodeArticleIsKey(){
				    return false;
				}
				public Integer metadataCodeArticleLength(){
				    return null;
				}
				public Integer metadataCodeArticlePrecision(){
				    return 0;
				}
				public String metadataCodeArticleDefault(){
				
					return "";
				
				}
				public String metadataCodeArticleComment(){
				
				    return "";
				
				}
				public String metadataCodeArticlePattern(){
				
					return "";
				
				}
				public String metadataCodeArticleOriginalDbColumnName(){
				
					return "metadataCodeArticle";
				
				}

				
			    public String metadataTypePrestation;

				public String getMetadataTypePrestation () {
					return this.metadataTypePrestation;
				}

				public Boolean metadataTypePrestationIsNullable(){
				    return true;
				}
				public Boolean metadataTypePrestationIsKey(){
				    return false;
				}
				public Integer metadataTypePrestationLength(){
				    return null;
				}
				public Integer metadataTypePrestationPrecision(){
				    return null;
				}
				public String metadataTypePrestationDefault(){
				
					return null;
				
				}
				public String metadataTypePrestationComment(){
				
				    return "";
				
				}
				public String metadataTypePrestationPattern(){
				
					return "";
				
				}
				public String metadataTypePrestationOriginalDbColumnName(){
				
					return "metadataTypePrestation";
				
				}

				
			    public String sourceIssues;

				public String getSourceIssues () {
					return this.sourceIssues;
				}

				public Boolean sourceIssuesIsNullable(){
				    return true;
				}
				public Boolean sourceIssuesIsKey(){
				    return false;
				}
				public Integer sourceIssuesLength(){
				    return 300;
				}
				public Integer sourceIssuesPrecision(){
				    return 0;
				}
				public String sourceIssuesDefault(){
				
					return null;
				
				}
				public String sourceIssuesComment(){
				
				    return "";
				
				}
				public String sourceIssuesPattern(){
				
					return "";
				
				}
				public String sourceIssuesOriginalDbColumnName(){
				
					return "sourceIssues";
				
				}

				
			    public String sourceWhen;

				public String getSourceWhen () {
					return this.sourceWhen;
				}

				public Boolean sourceWhenIsNullable(){
				    return true;
				}
				public Boolean sourceWhenIsKey(){
				    return false;
				}
				public Integer sourceWhenLength(){
				    return 150;
				}
				public Integer sourceWhenPrecision(){
				    return 0;
				}
				public String sourceWhenDefault(){
				
					return null;
				
				}
				public String sourceWhenComment(){
				
				    return "";
				
				}
				public String sourceWhenPattern(){
				
					return "";
				
				}
				public String sourceWhenOriginalDbColumnName(){
				
					return "sourceWhen";
				
				}

				
			    public String sourceUpdated;

				public String getSourceUpdated () {
					return this.sourceUpdated;
				}

				public Boolean sourceUpdatedIsNullable(){
				    return true;
				}
				public Boolean sourceUpdatedIsKey(){
				    return false;
				}
				public Integer sourceUpdatedLength(){
				    return 150;
				}
				public Integer sourceUpdatedPrecision(){
				    return 0;
				}
				public String sourceUpdatedDefault(){
				
					return null;
				
				}
				public String sourceUpdatedComment(){
				
				    return "";
				
				}
				public String sourceUpdatedPattern(){
				
					return "";
				
				}
				public String sourceUpdatedOriginalDbColumnName(){
				
					return "sourceUpdated";
				
				}

				
			    public String sourceItems;

				public String getSourceItems () {
					return this.sourceItems;
				}

				public Boolean sourceItemsIsNullable(){
				    return true;
				}
				public Boolean sourceItemsIsKey(){
				    return false;
				}
				public Integer sourceItemsLength(){
				    return 10000;
				}
				public Integer sourceItemsPrecision(){
				    return 0;
				}
				public String sourceItemsDefault(){
				
					return null;
				
				}
				public String sourceItemsComment(){
				
				    return "";
				
				}
				public String sourceItemsPattern(){
				
					return "";
				
				}
				public String sourceItemsOriginalDbColumnName(){
				
					return "sourceItems";
				
				}

				
			    public String sourceProducts;

				public String getSourceProducts () {
					return this.sourceProducts;
				}

				public Boolean sourceProductsIsNullable(){
				    return true;
				}
				public Boolean sourceProductsIsKey(){
				    return false;
				}
				public Integer sourceProductsLength(){
				    return 150;
				}
				public Integer sourceProductsPrecision(){
				    return 0;
				}
				public String sourceProductsDefault(){
				
					return null;
				
				}
				public String sourceProductsComment(){
				
				    return "";
				
				}
				public String sourceProductsPattern(){
				
					return "";
				
				}
				public String sourceProductsOriginalDbColumnName(){
				
					return "sourceProducts";
				
				}

				
			    public String sourceAnnouncement;

				public String getSourceAnnouncement () {
					return this.sourceAnnouncement;
				}

				public Boolean sourceAnnouncementIsNullable(){
				    return true;
				}
				public Boolean sourceAnnouncementIsKey(){
				    return false;
				}
				public Integer sourceAnnouncementLength(){
				    return 150;
				}
				public Integer sourceAnnouncementPrecision(){
				    return 0;
				}
				public String sourceAnnouncementDefault(){
				
					return null;
				
				}
				public String sourceAnnouncementComment(){
				
				    return "";
				
				}
				public String sourceAnnouncementPattern(){
				
					return "";
				
				}
				public String sourceAnnouncementOriginalDbColumnName(){
				
					return "sourceAnnouncement";
				
				}

				
			    public String sourceDate;

				public String getSourceDate () {
					return this.sourceDate;
				}

				public Boolean sourceDateIsNullable(){
				    return true;
				}
				public Boolean sourceDateIsKey(){
				    return false;
				}
				public Integer sourceDateLength(){
				    return 150;
				}
				public Integer sourceDatePrecision(){
				    return 0;
				}
				public String sourceDateDefault(){
				
					return null;
				
				}
				public String sourceDateComment(){
				
				    return "";
				
				}
				public String sourceDatePattern(){
				
					return "";
				
				}
				public String sourceDateOriginalDbColumnName(){
				
					return "sourceDate";
				
				}

				
			    public String sourceEndpoint;

				public String getSourceEndpoint () {
					return this.sourceEndpoint;
				}

				public Boolean sourceEndpointIsNullable(){
				    return true;
				}
				public Boolean sourceEndpointIsKey(){
				    return false;
				}
				public Integer sourceEndpointLength(){
				    return 150;
				}
				public Integer sourceEndpointPrecision(){
				    return 0;
				}
				public String sourceEndpointDefault(){
				
					return null;
				
				}
				public String sourceEndpointComment(){
				
				    return "";
				
				}
				public String sourceEndpointPattern(){
				
					return "";
				
				}
				public String sourceEndpointOriginalDbColumnName(){
				
					return "sourceEndpoint";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 150;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 150;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceBy;

				public String getSourceBy () {
					return this.sourceBy;
				}

				public Boolean sourceByIsNullable(){
				    return true;
				}
				public Boolean sourceByIsKey(){
				    return false;
				}
				public Integer sourceByLength(){
				    return 150;
				}
				public Integer sourceByPrecision(){
				    return 0;
				}
				public String sourceByDefault(){
				
					return null;
				
				}
				public String sourceByComment(){
				
				    return "";
				
				}
				public String sourceByPattern(){
				
					return "";
				
				}
				public String sourceByOriginalDbColumnName(){
				
					return "sourceBy";
				
				}

				
			    public String sourceCategory;

				public String getSourceCategory () {
					return this.sourceCategory;
				}

				public Boolean sourceCategoryIsNullable(){
				    return true;
				}
				public Boolean sourceCategoryIsKey(){
				    return false;
				}
				public Integer sourceCategoryLength(){
				    return 150;
				}
				public Integer sourceCategoryPrecision(){
				    return 0;
				}
				public String sourceCategoryDefault(){
				
					return null;
				
				}
				public String sourceCategoryComment(){
				
				    return "";
				
				}
				public String sourceCategoryPattern(){
				
					return "";
				
				}
				public String sourceCategoryOriginalDbColumnName(){
				
					return "sourceCategory";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 150;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String createdBy_id;

				public String getCreatedBy_id () {
					return this.createdBy_id;
				}

				public Boolean createdBy_idIsNullable(){
				    return true;
				}
				public Boolean createdBy_idIsKey(){
				    return false;
				}
				public Integer createdBy_idLength(){
				    return 150;
				}
				public Integer createdBy_idPrecision(){
				    return 0;
				}
				public String createdBy_idDefault(){
				
					return null;
				
				}
				public String createdBy_idComment(){
				
				    return "";
				
				}
				public String createdBy_idPattern(){
				
					return "";
				
				}
				public String createdBy_idOriginalDbColumnName(){
				
					return "createdBy_id";
				
				}

				
			    public String createdByFirstName;

				public String getCreatedByFirstName () {
					return this.createdByFirstName;
				}

				public Boolean createdByFirstNameIsNullable(){
				    return true;
				}
				public Boolean createdByFirstNameIsKey(){
				    return false;
				}
				public Integer createdByFirstNameLength(){
				    return 150;
				}
				public Integer createdByFirstNamePrecision(){
				    return 0;
				}
				public String createdByFirstNameDefault(){
				
					return null;
				
				}
				public String createdByFirstNameComment(){
				
				    return "";
				
				}
				public String createdByFirstNamePattern(){
				
					return "";
				
				}
				public String createdByFirstNameOriginalDbColumnName(){
				
					return "createdByFirstName";
				
				}

				
			    public String createdByLastName;

				public String getCreatedByLastName () {
					return this.createdByLastName;
				}

				public Boolean createdByLastNameIsNullable(){
				    return true;
				}
				public Boolean createdByLastNameIsKey(){
				    return false;
				}
				public Integer createdByLastNameLength(){
				    return 150;
				}
				public Integer createdByLastNamePrecision(){
				    return 0;
				}
				public String createdByLastNameDefault(){
				
					return null;
				
				}
				public String createdByLastNameComment(){
				
				    return "";
				
				}
				public String createdByLastNamePattern(){
				
					return "";
				
				}
				public String createdByLastNameOriginalDbColumnName(){
				
					return "createdByLastName";
				
				}

				
			    public String createdByExternalId;

				public String getCreatedByExternalId () {
					return this.createdByExternalId;
				}

				public Boolean createdByExternalIdIsNullable(){
				    return true;
				}
				public Boolean createdByExternalIdIsKey(){
				    return false;
				}
				public Integer createdByExternalIdLength(){
				    return 150;
				}
				public Integer createdByExternalIdPrecision(){
				    return 0;
				}
				public String createdByExternalIdDefault(){
				
					return null;
				
				}
				public String createdByExternalIdComment(){
				
				    return "";
				
				}
				public String createdByExternalIdPattern(){
				
					return "";
				
				}
				public String createdByExternalIdOriginalDbColumnName(){
				
					return "createdByExternalId";
				
				}

				
			    public String createdById;

				public String getCreatedById () {
					return this.createdById;
				}

				public Boolean createdByIdIsNullable(){
				    return true;
				}
				public Boolean createdByIdIsKey(){
				    return false;
				}
				public Integer createdByIdLength(){
				    return 150;
				}
				public Integer createdByIdPrecision(){
				    return 0;
				}
				public String createdByIdDefault(){
				
					return null;
				
				}
				public String createdByIdComment(){
				
				    return "";
				
				}
				public String createdByIdPattern(){
				
					return "";
				
				}
				public String createdByIdOriginalDbColumnName(){
				
					return "createdById";
				
				}

				
			    public Double dimensionsWeight;

				public Double getDimensionsWeight () {
					return this.dimensionsWeight;
				}

				public Boolean dimensionsWeightIsNullable(){
				    return true;
				}
				public Boolean dimensionsWeightIsKey(){
				    return false;
				}
				public Integer dimensionsWeightLength(){
				    return 22;
				}
				public Integer dimensionsWeightPrecision(){
				    return 0;
				}
				public String dimensionsWeightDefault(){
				
					return null;
				
				}
				public String dimensionsWeightComment(){
				
				    return "";
				
				}
				public String dimensionsWeightPattern(){
				
					return "";
				
				}
				public String dimensionsWeightOriginalDbColumnName(){
				
					return "dimensionsWeight";
				
				}

				
			    public Double dimensionsVolume;

				public Double getDimensionsVolume () {
					return this.dimensionsVolume;
				}

				public Boolean dimensionsVolumeIsNullable(){
				    return true;
				}
				public Boolean dimensionsVolumeIsKey(){
				    return false;
				}
				public Integer dimensionsVolumeLength(){
				    return 22;
				}
				public Integer dimensionsVolumePrecision(){
				    return 0;
				}
				public String dimensionsVolumeDefault(){
				
					return null;
				
				}
				public String dimensionsVolumeComment(){
				
				    return "";
				
				}
				public String dimensionsVolumePattern(){
				
					return "";
				
				}
				public String dimensionsVolumeOriginalDbColumnName(){
				
					return "dimensionsVolume";
				
				}

				
			    public String sourceFlux;

				public String getSourceFlux () {
					return this.sourceFlux;
				}

				public Boolean sourceFluxIsNullable(){
				    return true;
				}
				public Boolean sourceFluxIsKey(){
				    return false;
				}
				public Integer sourceFluxLength(){
				    return 150;
				}
				public Integer sourceFluxPrecision(){
				    return 0;
				}
				public String sourceFluxDefault(){
				
					return null;
				
				}
				public String sourceFluxComment(){
				
				    return "";
				
				}
				public String sourceFluxPattern(){
				
					return "";
				
				}
				public String sourceFluxOriginalDbColumnName(){
				
					return "sourceFlux";
				
				}

				
			    public String sourceInstructions;

				public String getSourceInstructions () {
					return this.sourceInstructions;
				}

				public Boolean sourceInstructionsIsNullable(){
				    return true;
				}
				public Boolean sourceInstructionsIsKey(){
				    return false;
				}
				public Integer sourceInstructionsLength(){
				    return 65535;
				}
				public Integer sourceInstructionsPrecision(){
				    return 0;
				}
				public String sourceInstructionsDefault(){
				
					return null;
				
				}
				public String sourceInstructionsComment(){
				
				    return "";
				
				}
				public String sourceInstructionsPattern(){
				
					return "";
				
				}
				public String sourceInstructionsOriginalDbColumnName(){
				
					return "sourceInstructions";
				
				}

				
			    public String sourcePlatform;

				public String getSourcePlatform () {
					return this.sourcePlatform;
				}

				public Boolean sourcePlatformIsNullable(){
				    return true;
				}
				public Boolean sourcePlatformIsKey(){
				    return false;
				}
				public Integer sourcePlatformLength(){
				    return 150;
				}
				public Integer sourcePlatformPrecision(){
				    return 0;
				}
				public String sourcePlatformDefault(){
				
					return null;
				
				}
				public String sourcePlatformComment(){
				
				    return "";
				
				}
				public String sourcePlatformPattern(){
				
					return "";
				
				}
				public String sourcePlatformOriginalDbColumnName(){
				
					return "sourcePlatform";
				
				}

				
			    public String sourcePlatformName;

				public String getSourcePlatformName () {
					return this.sourcePlatformName;
				}

				public Boolean sourcePlatformNameIsNullable(){
				    return true;
				}
				public Boolean sourcePlatformNameIsKey(){
				    return false;
				}
				public Integer sourcePlatformNameLength(){
				    return 150;
				}
				public Integer sourcePlatformNamePrecision(){
				    return 0;
				}
				public String sourcePlatformNameDefault(){
				
					return null;
				
				}
				public String sourcePlatformNameComment(){
				
				    return "";
				
				}
				public String sourcePlatformNamePattern(){
				
					return "";
				
				}
				public String sourcePlatformNameOriginalDbColumnName(){
				
					return "sourcePlatformName";
				
				}

				
			    public String sourceProgress;

				public String getSourceProgress () {
					return this.sourceProgress;
				}

				public Boolean sourceProgressIsNullable(){
				    return true;
				}
				public Boolean sourceProgressIsKey(){
				    return false;
				}
				public Integer sourceProgressLength(){
				    return 150;
				}
				public Integer sourceProgressPrecision(){
				    return 0;
				}
				public String sourceProgressDefault(){
				
					return null;
				
				}
				public String sourceProgressComment(){
				
				    return "";
				
				}
				public String sourceProgressPattern(){
				
					return "";
				
				}
				public String sourceProgressOriginalDbColumnName(){
				
					return "sourceProgress";
				
				}

				
			    public String sourceRoundName;

				public String getSourceRoundName () {
					return this.sourceRoundName;
				}

				public Boolean sourceRoundNameIsNullable(){
				    return true;
				}
				public Boolean sourceRoundNameIsKey(){
				    return false;
				}
				public Integer sourceRoundNameLength(){
				    return 150;
				}
				public Integer sourceRoundNamePrecision(){
				    return 0;
				}
				public String sourceRoundNameDefault(){
				
					return null;
				
				}
				public String sourceRoundNameComment(){
				
				    return "";
				
				}
				public String sourceRoundNamePattern(){
				
					return "";
				
				}
				public String sourceRoundNameOriginalDbColumnName(){
				
					return "sourceRoundName";
				
				}

				
			    public Double sourceSequence;

				public Double getSourceSequence () {
					return this.sourceSequence;
				}

				public Boolean sourceSequenceIsNullable(){
				    return true;
				}
				public Boolean sourceSequenceIsKey(){
				    return false;
				}
				public Integer sourceSequenceLength(){
				    return 22;
				}
				public Integer sourceSequencePrecision(){
				    return 0;
				}
				public String sourceSequenceDefault(){
				
					return null;
				
				}
				public String sourceSequenceComment(){
				
				    return "";
				
				}
				public String sourceSequencePattern(){
				
					return "";
				
				}
				public String sourceSequenceOriginalDbColumnName(){
				
					return "sourceSequence";
				
				}

				
			    public Double sourceServiceTime;

				public Double getSourceServiceTime () {
					return this.sourceServiceTime;
				}

				public Boolean sourceServiceTimeIsNullable(){
				    return true;
				}
				public Boolean sourceServiceTimeIsKey(){
				    return false;
				}
				public Integer sourceServiceTimeLength(){
				    return 22;
				}
				public Integer sourceServiceTimePrecision(){
				    return 0;
				}
				public String sourceServiceTimeDefault(){
				
					return null;
				
				}
				public String sourceServiceTimeComment(){
				
				    return "";
				
				}
				public String sourceServiceTimePattern(){
				
					return "";
				
				}
				public String sourceServiceTimeOriginalDbColumnName(){
				
					return "sourceServiceTime";
				
				}

				
			    public String sourceTrackingId;

				public String getSourceTrackingId () {
					return this.sourceTrackingId;
				}

				public Boolean sourceTrackingIdIsNullable(){
				    return true;
				}
				public Boolean sourceTrackingIdIsKey(){
				    return false;
				}
				public Integer sourceTrackingIdLength(){
				    return 150;
				}
				public Integer sourceTrackingIdPrecision(){
				    return 0;
				}
				public String sourceTrackingIdDefault(){
				
					return null;
				
				}
				public String sourceTrackingIdComment(){
				
				    return "";
				
				}
				public String sourceTrackingIdPattern(){
				
					return "";
				
				}
				public String sourceTrackingIdOriginalDbColumnName(){
				
					return "sourceTrackingId";
				
				}

				
			    public String sourceHub;

				public String getSourceHub () {
					return this.sourceHub;
				}

				public Boolean sourceHubIsNullable(){
				    return true;
				}
				public Boolean sourceHubIsKey(){
				    return false;
				}
				public Integer sourceHubLength(){
				    return 150;
				}
				public Integer sourceHubPrecision(){
				    return 0;
				}
				public String sourceHubDefault(){
				
					return null;
				
				}
				public String sourceHubComment(){
				
				    return "";
				
				}
				public String sourceHubPattern(){
				
					return "";
				
				}
				public String sourceHubOriginalDbColumnName(){
				
					return "sourceHub";
				
				}

				
			    public String sourceHubName;

				public String getSourceHubName () {
					return this.sourceHubName;
				}

				public Boolean sourceHubNameIsNullable(){
				    return true;
				}
				public Boolean sourceHubNameIsKey(){
				    return false;
				}
				public Integer sourceHubNameLength(){
				    return 150;
				}
				public Integer sourceHubNamePrecision(){
				    return 0;
				}
				public String sourceHubNameDefault(){
				
					return null;
				
				}
				public String sourceHubNameComment(){
				
				    return "";
				
				}
				public String sourceHubNamePattern(){
				
					return "";
				
				}
				public String sourceHubNameOriginalDbColumnName(){
				
					return "sourceHubName";
				
				}

				
			    public String sourceTargetFlux;

				public String getSourceTargetFlux () {
					return this.sourceTargetFlux;
				}

				public Boolean sourceTargetFluxIsNullable(){
				    return true;
				}
				public Boolean sourceTargetFluxIsKey(){
				    return false;
				}
				public Integer sourceTargetFluxLength(){
				    return 150;
				}
				public Integer sourceTargetFluxPrecision(){
				    return 0;
				}
				public String sourceTargetFluxDefault(){
				
					return null;
				
				}
				public String sourceTargetFluxComment(){
				
				    return "";
				
				}
				public String sourceTargetFluxPattern(){
				
					return "";
				
				}
				public String sourceTargetFluxOriginalDbColumnName(){
				
					return "sourceTargetFlux";
				
				}

				
			    public String sourceZone;

				public String getSourceZone () {
					return this.sourceZone;
				}

				public Boolean sourceZoneIsNullable(){
				    return true;
				}
				public Boolean sourceZoneIsKey(){
				    return false;
				}
				public Integer sourceZoneLength(){
				    return 150;
				}
				public Integer sourceZonePrecision(){
				    return 0;
				}
				public String sourceZoneDefault(){
				
					return null;
				
				}
				public String sourceZoneComment(){
				
				    return "";
				
				}
				public String sourceZonePattern(){
				
					return "";
				
				}
				public String sourceZoneOriginalDbColumnName(){
				
					return "sourceZone";
				
				}

				
			    public String sourceOrder;

				public String getSourceOrder () {
					return this.sourceOrder;
				}

				public Boolean sourceOrderIsNullable(){
				    return true;
				}
				public Boolean sourceOrderIsKey(){
				    return false;
				}
				public Integer sourceOrderLength(){
				    return 150;
				}
				public Integer sourceOrderPrecision(){
				    return 0;
				}
				public String sourceOrderDefault(){
				
					return null;
				
				}
				public String sourceOrderComment(){
				
				    return "";
				
				}
				public String sourceOrderPattern(){
				
					return "";
				
				}
				public String sourceOrderOriginalDbColumnName(){
				
					return "sourceOrder";
				
				}

				
			    public String sourceArriveTime;

				public String getSourceArriveTime () {
					return this.sourceArriveTime;
				}

				public Boolean sourceArriveTimeIsNullable(){
				    return true;
				}
				public Boolean sourceArriveTimeIsKey(){
				    return false;
				}
				public Integer sourceArriveTimeLength(){
				    return 150;
				}
				public Integer sourceArriveTimePrecision(){
				    return 0;
				}
				public String sourceArriveTimeDefault(){
				
					return null;
				
				}
				public String sourceArriveTimeComment(){
				
				    return "";
				
				}
				public String sourceArriveTimePattern(){
				
					return "";
				
				}
				public String sourceArriveTimeOriginalDbColumnName(){
				
					return "sourceArriveTime";
				
				}

				
			    public String sourceAssociated;

				public String getSourceAssociated () {
					return this.sourceAssociated;
				}

				public Boolean sourceAssociatedIsNullable(){
				    return true;
				}
				public Boolean sourceAssociatedIsKey(){
				    return false;
				}
				public Integer sourceAssociatedLength(){
				    return 150;
				}
				public Integer sourceAssociatedPrecision(){
				    return 0;
				}
				public String sourceAssociatedDefault(){
				
					return null;
				
				}
				public String sourceAssociatedComment(){
				
				    return "";
				
				}
				public String sourceAssociatedPattern(){
				
					return "";
				
				}
				public String sourceAssociatedOriginalDbColumnName(){
				
					return "sourceAssociated";
				
				}

				
			    public String sourceAssociatedName;

				public String getSourceAssociatedName () {
					return this.sourceAssociatedName;
				}

				public Boolean sourceAssociatedNameIsNullable(){
				    return true;
				}
				public Boolean sourceAssociatedNameIsKey(){
				    return false;
				}
				public Integer sourceAssociatedNameLength(){
				    return 150;
				}
				public Integer sourceAssociatedNamePrecision(){
				    return 0;
				}
				public String sourceAssociatedNameDefault(){
				
					return null;
				
				}
				public String sourceAssociatedNameComment(){
				
				    return "";
				
				}
				public String sourceAssociatedNamePattern(){
				
					return "";
				
				}
				public String sourceAssociatedNameOriginalDbColumnName(){
				
					return "sourceAssociatedName";
				
				}

				
			    public String driver_id;

				public String getDriver_id () {
					return this.driver_id;
				}

				public Boolean driver_idIsNullable(){
				    return true;
				}
				public Boolean driver_idIsKey(){
				    return false;
				}
				public Integer driver_idLength(){
				    return 150;
				}
				public Integer driver_idPrecision(){
				    return 0;
				}
				public String driver_idDefault(){
				
					return null;
				
				}
				public String driver_idComment(){
				
				    return "";
				
				}
				public String driver_idPattern(){
				
					return "";
				
				}
				public String driver_idOriginalDbColumnName(){
				
					return "driver_id";
				
				}

				
			    public String driverFirstName;

				public String getDriverFirstName () {
					return this.driverFirstName;
				}

				public Boolean driverFirstNameIsNullable(){
				    return true;
				}
				public Boolean driverFirstNameIsKey(){
				    return false;
				}
				public Integer driverFirstNameLength(){
				    return 150;
				}
				public Integer driverFirstNamePrecision(){
				    return 0;
				}
				public String driverFirstNameDefault(){
				
					return null;
				
				}
				public String driverFirstNameComment(){
				
				    return "";
				
				}
				public String driverFirstNamePattern(){
				
					return "";
				
				}
				public String driverFirstNameOriginalDbColumnName(){
				
					return "driverFirstName";
				
				}

				
			    public String driverLastName;

				public String getDriverLastName () {
					return this.driverLastName;
				}

				public Boolean driverLastNameIsNullable(){
				    return true;
				}
				public Boolean driverLastNameIsKey(){
				    return false;
				}
				public Integer driverLastNameLength(){
				    return 150;
				}
				public Integer driverLastNamePrecision(){
				    return 0;
				}
				public String driverLastNameDefault(){
				
					return null;
				
				}
				public String driverLastNameComment(){
				
				    return "";
				
				}
				public String driverLastNamePattern(){
				
					return "";
				
				}
				public String driverLastNameOriginalDbColumnName(){
				
					return "driverLastName";
				
				}

				
			    public String driverExternalId;

				public String getDriverExternalId () {
					return this.driverExternalId;
				}

				public Boolean driverExternalIdIsNullable(){
				    return true;
				}
				public Boolean driverExternalIdIsKey(){
				    return false;
				}
				public Integer driverExternalIdLength(){
				    return 150;
				}
				public Integer driverExternalIdPrecision(){
				    return 0;
				}
				public String driverExternalIdDefault(){
				
					return null;
				
				}
				public String driverExternalIdComment(){
				
				    return "";
				
				}
				public String driverExternalIdPattern(){
				
					return "";
				
				}
				public String driverExternalIdOriginalDbColumnName(){
				
					return "driverExternalId";
				
				}

				
			    public String driverId;

				public String getDriverId () {
					return this.driverId;
				}

				public Boolean driverIdIsNullable(){
				    return true;
				}
				public Boolean driverIdIsKey(){
				    return false;
				}
				public Integer driverIdLength(){
				    return 150;
				}
				public Integer driverIdPrecision(){
				    return 0;
				}
				public String driverIdDefault(){
				
					return null;
				
				}
				public String driverIdComment(){
				
				    return "";
				
				}
				public String driverIdPattern(){
				
					return "";
				
				}
				public String driverIdOriginalDbColumnName(){
				
					return "driverId";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 150;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				
			    public String sourceRoundColor;

				public String getSourceRoundColor () {
					return this.sourceRoundColor;
				}

				public Boolean sourceRoundColorIsNullable(){
				    return true;
				}
				public Boolean sourceRoundColorIsKey(){
				    return false;
				}
				public Integer sourceRoundColorLength(){
				    return 150;
				}
				public Integer sourceRoundColorPrecision(){
				    return 0;
				}
				public String sourceRoundColorDefault(){
				
					return null;
				
				}
				public String sourceRoundColorComment(){
				
				    return "";
				
				}
				public String sourceRoundColorPattern(){
				
					return "";
				
				}
				public String sourceRoundColorOriginalDbColumnName(){
				
					return "sourceRoundColor";
				
				}

				
			    public String sourceCompletedBy;

				public String getSourceCompletedBy () {
					return this.sourceCompletedBy;
				}

				public Boolean sourceCompletedByIsNullable(){
				    return true;
				}
				public Boolean sourceCompletedByIsKey(){
				    return false;
				}
				public Integer sourceCompletedByLength(){
				    return 150;
				}
				public Integer sourceCompletedByPrecision(){
				    return 0;
				}
				public String sourceCompletedByDefault(){
				
					return null;
				
				}
				public String sourceCompletedByComment(){
				
				    return "";
				
				}
				public String sourceCompletedByPattern(){
				
					return "";
				
				}
				public String sourceCompletedByOriginalDbColumnName(){
				
					return "sourceCompletedBy";
				
				}

				
			    public String sourceImagePath;

				public String getSourceImagePath () {
					return this.sourceImagePath;
				}

				public Boolean sourceImagePathIsNullable(){
				    return true;
				}
				public Boolean sourceImagePathIsKey(){
				    return false;
				}
				public Integer sourceImagePathLength(){
				    return 150;
				}
				public Integer sourceImagePathPrecision(){
				    return 0;
				}
				public String sourceImagePathDefault(){
				
					return null;
				
				}
				public String sourceImagePathComment(){
				
				    return "";
				
				}
				public String sourceImagePathPattern(){
				
					return "";
				
				}
				public String sourceImagePathOriginalDbColumnName(){
				
					return "sourceImagePath";
				
				}

				
			    public Boolean sourceHasRejectedProducts;

				public Boolean getSourceHasRejectedProducts () {
					return this.sourceHasRejectedProducts;
				}

				public Boolean sourceHasRejectedProductsIsNullable(){
				    return true;
				}
				public Boolean sourceHasRejectedProductsIsKey(){
				    return false;
				}
				public Integer sourceHasRejectedProductsLength(){
				    return 5;
				}
				public Integer sourceHasRejectedProductsPrecision(){
				    return 0;
				}
				public String sourceHasRejectedProductsDefault(){
				
					return null;
				
				}
				public String sourceHasRejectedProductsComment(){
				
				    return "";
				
				}
				public String sourceHasRejectedProductsPattern(){
				
					return "";
				
				}
				public String sourceHasRejectedProductsOriginalDbColumnName(){
				
					return "sourceHasRejectedProducts";
				
				}

				
			    public String source_Id;

				public String getSource_Id () {
					return this.source_Id;
				}

				public Boolean source_IdIsNullable(){
				    return true;
				}
				public Boolean source_IdIsKey(){
				    return false;
				}
				public Integer source_IdLength(){
				    return 150;
				}
				public Integer source_IdPrecision(){
				    return 0;
				}
				public String source_IdDefault(){
				
					return null;
				
				}
				public String source_IdComment(){
				
				    return "";
				
				}
				public String source_IdPattern(){
				
					return "";
				
				}
				public String source_IdOriginalDbColumnName(){
				
					return "source_Id";
				
				}

				
			    public String metadataVehicule;

				public String getMetadataVehicule () {
					return this.metadataVehicule;
				}

				public Boolean metadataVehiculeIsNullable(){
				    return true;
				}
				public Boolean metadataVehiculeIsKey(){
				    return false;
				}
				public Integer metadataVehiculeLength(){
				    return null;
				}
				public Integer metadataVehiculePrecision(){
				    return null;
				}
				public String metadataVehiculeDefault(){
				
					return null;
				
				}
				public String metadataVehiculeComment(){
				
				    return "";
				
				}
				public String metadataVehiculePattern(){
				
					return "";
				
				}
				public String metadataVehiculeOriginalDbColumnName(){
				
					return "metadataVehicule";
				
				}

				
			    public String metadataFACTURATION;

				public String getMetadataFACTURATION () {
					return this.metadataFACTURATION;
				}

				public Boolean metadataFACTURATIONIsNullable(){
				    return true;
				}
				public Boolean metadataFACTURATIONIsKey(){
				    return false;
				}
				public Integer metadataFACTURATIONLength(){
				    return null;
				}
				public Integer metadataFACTURATIONPrecision(){
				    return null;
				}
				public String metadataFACTURATIONDefault(){
				
					return null;
				
				}
				public String metadataFACTURATIONComment(){
				
				    return "";
				
				}
				public String metadataFACTURATIONPattern(){
				
					return "";
				
				}
				public String metadataFACTURATIONOriginalDbColumnName(){
				
					return "metadataFACTURATION";
				
				}

				
			    public String metadataRouteGrenoble;

				public String getMetadataRouteGrenoble () {
					return this.metadataRouteGrenoble;
				}

				public Boolean metadataRouteGrenobleIsNullable(){
				    return true;
				}
				public Boolean metadataRouteGrenobleIsKey(){
				    return false;
				}
				public Integer metadataRouteGrenobleLength(){
				    return null;
				}
				public Integer metadataRouteGrenoblePrecision(){
				    return null;
				}
				public String metadataRouteGrenobleDefault(){
				
					return null;
				
				}
				public String metadataRouteGrenobleComment(){
				
				    return "";
				
				}
				public String metadataRouteGrenoblePattern(){
				
					return "";
				
				}
				public String metadataRouteGrenobleOriginalDbColumnName(){
				
					return "metadataRouteGrenoble";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return null;
				}
				public Integer is_deletedPrecision(){
				    return null;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String delay;

				public String getDelay () {
					return this.delay;
				}

				public Boolean delayIsNullable(){
				    return true;
				}
				public Boolean delayIsKey(){
				    return false;
				}
				public Integer delayLength(){
				    return null;
				}
				public Integer delayPrecision(){
				    return null;
				}
				public String delayDefault(){
				
					return null;
				
				}
				public String delayComment(){
				
				    return "";
				
				}
				public String delayPattern(){
				
					return "";
				
				}
				public String delayOriginalDbColumnName(){
				
					return "delay";
				
				}

				
			    public String failedReason;

				public String getFailedReason () {
					return this.failedReason;
				}

				public Boolean failedReasonIsNullable(){
				    return true;
				}
				public Boolean failedReasonIsKey(){
				    return false;
				}
				public Integer failedReasonLength(){
				    return null;
				}
				public Integer failedReasonPrecision(){
				    return null;
				}
				public String failedReasonDefault(){
				
					return null;
				
				}
				public String failedReasonComment(){
				
				    return "";
				
				}
				public String failedReasonPattern(){
				
					return "";
				
				}
				public String failedReasonOriginalDbColumnName(){
				
					return "failedReason";
				
				}

				
			    public String failedReasonCustom;

				public String getFailedReasonCustom () {
					return this.failedReasonCustom;
				}

				public Boolean failedReasonCustomIsNullable(){
				    return true;
				}
				public Boolean failedReasonCustomIsKey(){
				    return false;
				}
				public Integer failedReasonCustomLength(){
				    return null;
				}
				public Integer failedReasonCustomPrecision(){
				    return null;
				}
				public String failedReasonCustomDefault(){
				
					return null;
				
				}
				public String failedReasonCustomComment(){
				
				    return "";
				
				}
				public String failedReasonCustomPattern(){
				
					return "";
				
				}
				public String failedReasonCustomOriginalDbColumnName(){
				
					return "failedReasonCustom";
				
				}

				
			    public String isExpress;

				public String getIsExpress () {
					return this.isExpress;
				}

				public Boolean isExpressIsNullable(){
				    return true;
				}
				public Boolean isExpressIsKey(){
				    return false;
				}
				public Integer isExpressLength(){
				    return null;
				}
				public Integer isExpressPrecision(){
				    return null;
				}
				public String isExpressDefault(){
				
					return null;
				
				}
				public String isExpressComment(){
				
				    return "";
				
				}
				public String isExpressPattern(){
				
					return "";
				
				}
				public String isExpressOriginalDbColumnName(){
				
					return "isExpress";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.sourceId == null) ? 0 : this.sourceId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final task_dbStruct other = (task_dbStruct) obj;
		
						if (this.sourceId == null) {
							if (other.sourceId != null)
								return false;
						
						} else if (!this.sourceId.equals(other.sourceId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(task_dbStruct other) {

		other.sourceId = this.sourceId;
	            other.sourceLocationType = this.sourceLocationType;
	            other.sourceLocationGeometry = this.sourceLocationGeometry;
	            other.sourceAddressLines = this.sourceAddressLines;
	            other.sourceGeocodeScore = this.sourceGeocodeScore;
	            other.sourceCleanScore = this.sourceCleanScore;
	            other.sourceStreet = this.sourceStreet;
	            other.sourceCity = this.sourceCity;
	            other.sourceZip = this.sourceZip;
	            other.sourceCountry = this.sourceCountry;
	            other.sourceAddress = this.sourceAddress;
	            other.locationType = this.locationType;
	            other.locationGeometry = this.locationGeometry;
	            other.locationAddressLines = this.locationAddressLines;
	            other.locationGeocodeScore = this.locationGeocodeScore;
	            other.locationCleanScore = this.locationCleanScore;
	            other.locationStreet = this.locationStreet;
	            other.locationAddress = this.locationAddress;
	            other.locationZip = this.locationZip;
	            other.locationCity = this.locationCity;
	            other.locationCountry = this.locationCountry;
	            other.locationOrigin = this.locationOrigin;
	            other.contactBuildingInfo = this.contactBuildingInfo;
	            other.contactPerson = this.contactPerson;
	            other.contactPhone = this.contactPhone;
	            other.contactEmail = this.contactEmail;
	            other.timeWindowStart = this.timeWindowStart;
	            other.timeWindowStop = this.timeWindowStop;
	            other.sourceStatus = this.sourceStatus;
	            other.sourceActivity = this.sourceActivity;
	            other.sourceSkills = this.sourceSkills;
	            other.sourceLabels = this.sourceLabels;
	            other.sourceAttempts = this.sourceAttempts;
	            other.sourceHasBeenPaid = this.sourceHasBeenPaid;
	            other.sourceClosureDate = this.sourceClosureDate;
	            other.sourcePaymentType = this.sourcePaymentType;
	            other.sourceCollectedAmount = this.sourceCollectedAmount;
	            other.metadataCodeArticle = this.metadataCodeArticle;
	            other.metadataTypePrestation = this.metadataTypePrestation;
	            other.sourceIssues = this.sourceIssues;
	            other.sourceWhen = this.sourceWhen;
	            other.sourceUpdated = this.sourceUpdated;
	            other.sourceItems = this.sourceItems;
	            other.sourceProducts = this.sourceProducts;
	            other.sourceAnnouncement = this.sourceAnnouncement;
	            other.sourceDate = this.sourceDate;
	            other.sourceEndpoint = this.sourceEndpoint;
	            other.taskId = this.taskId;
	            other.sourceType = this.sourceType;
	            other.sourceBy = this.sourceBy;
	            other.sourceCategory = this.sourceCategory;
	            other.sourceClient = this.sourceClient;
	            other.createdBy_id = this.createdBy_id;
	            other.createdByFirstName = this.createdByFirstName;
	            other.createdByLastName = this.createdByLastName;
	            other.createdByExternalId = this.createdByExternalId;
	            other.createdById = this.createdById;
	            other.dimensionsWeight = this.dimensionsWeight;
	            other.dimensionsVolume = this.dimensionsVolume;
	            other.sourceFlux = this.sourceFlux;
	            other.sourceInstructions = this.sourceInstructions;
	            other.sourcePlatform = this.sourcePlatform;
	            other.sourcePlatformName = this.sourcePlatformName;
	            other.sourceProgress = this.sourceProgress;
	            other.sourceRoundName = this.sourceRoundName;
	            other.sourceSequence = this.sourceSequence;
	            other.sourceServiceTime = this.sourceServiceTime;
	            other.sourceTrackingId = this.sourceTrackingId;
	            other.sourceHub = this.sourceHub;
	            other.sourceHubName = this.sourceHubName;
	            other.sourceTargetFlux = this.sourceTargetFlux;
	            other.sourceZone = this.sourceZone;
	            other.sourceOrder = this.sourceOrder;
	            other.sourceArriveTime = this.sourceArriveTime;
	            other.sourceAssociated = this.sourceAssociated;
	            other.sourceAssociatedName = this.sourceAssociatedName;
	            other.driver_id = this.driver_id;
	            other.driverFirstName = this.driverFirstName;
	            other.driverLastName = this.driverLastName;
	            other.driverExternalId = this.driverExternalId;
	            other.driverId = this.driverId;
	            other.sourceRound = this.sourceRound;
	            other.sourceRoundColor = this.sourceRoundColor;
	            other.sourceCompletedBy = this.sourceCompletedBy;
	            other.sourceImagePath = this.sourceImagePath;
	            other.sourceHasRejectedProducts = this.sourceHasRejectedProducts;
	            other.source_Id = this.source_Id;
	            other.metadataVehicule = this.metadataVehicule;
	            other.metadataFACTURATION = this.metadataFACTURATION;
	            other.metadataRouteGrenoble = this.metadataRouteGrenoble;
	            other.is_deleted = this.is_deleted;
	            other.delay = this.delay;
	            other.failedReason = this.failedReason;
	            other.failedReasonCustom = this.failedReasonCustom;
	            other.isExpress = this.isExpress;
	            
	}

	public void copyKeysDataTo(task_dbStruct other) {

		other.sourceId = this.sourceId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceLocationType = readString(dis);
					
					this.sourceLocationGeometry = readString(dis);
					
					this.sourceAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceGeocodeScore = null;
           				} else {
           			    	this.sourceGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCleanScore = null;
           				} else {
           			    	this.sourceCleanScore = dis.readDouble();
           				}
					
					this.sourceStreet = readString(dis);
					
					this.sourceCity = readString(dis);
					
						this.sourceZip = readInteger(dis);
					
					this.sourceCountry = readString(dis);
					
					this.sourceAddress = readString(dis);
					
					this.locationType = readString(dis);
					
					this.locationGeometry = readString(dis);
					
					this.locationAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationGeocodeScore = null;
           				} else {
           			    	this.locationGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationCleanScore = null;
           				} else {
           			    	this.locationCleanScore = dis.readDouble();
           				}
					
					this.locationStreet = readString(dis);
					
					this.locationAddress = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.locationCity = readString(dis);
					
					this.locationCountry = readString(dis);
					
					this.locationOrigin = readString(dis);
					
					this.contactBuildingInfo = readString(dis);
					
					this.contactPerson = readString(dis);
					
					this.contactPhone = readString(dis);
					
					this.contactEmail = readString(dis);
					
					this.timeWindowStart = readString(dis);
					
					this.timeWindowStop = readString(dis);
					
					this.sourceStatus = readString(dis);
					
					this.sourceActivity = readString(dis);
					
					this.sourceSkills = readString(dis);
					
					this.sourceLabels = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceAttempts = null;
           				} else {
           			    	this.sourceAttempts = dis.readDouble();
           				}
					
					this.sourceHasBeenPaid = readString(dis);
					
					this.sourceClosureDate = readString(dis);
					
					this.sourcePaymentType = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCollectedAmount = null;
           				} else {
           			    	this.sourceCollectedAmount = dis.readDouble();
           				}
					
						this.metadataCodeArticle = (Object) dis.readObject();
					
					this.metadataTypePrestation = readString(dis);
					
					this.sourceIssues = readString(dis);
					
					this.sourceWhen = readString(dis);
					
					this.sourceUpdated = readString(dis);
					
					this.sourceItems = readString(dis);
					
					this.sourceProducts = readString(dis);
					
					this.sourceAnnouncement = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.sourceEndpoint = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceBy = readString(dis);
					
					this.sourceCategory = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.createdBy_id = readString(dis);
					
					this.createdByFirstName = readString(dis);
					
					this.createdByLastName = readString(dis);
					
					this.createdByExternalId = readString(dis);
					
					this.createdById = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsWeight = null;
           				} else {
           			    	this.dimensionsWeight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsVolume = null;
           				} else {
           			    	this.dimensionsVolume = dis.readDouble();
           				}
					
					this.sourceFlux = readString(dis);
					
					this.sourceInstructions = readString(dis);
					
					this.sourcePlatform = readString(dis);
					
					this.sourcePlatformName = readString(dis);
					
					this.sourceProgress = readString(dis);
					
					this.sourceRoundName = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceSequence = null;
           				} else {
           			    	this.sourceSequence = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceServiceTime = null;
           				} else {
           			    	this.sourceServiceTime = dis.readDouble();
           				}
					
					this.sourceTrackingId = readString(dis);
					
					this.sourceHub = readString(dis);
					
					this.sourceHubName = readString(dis);
					
					this.sourceTargetFlux = readString(dis);
					
					this.sourceZone = readString(dis);
					
					this.sourceOrder = readString(dis);
					
					this.sourceArriveTime = readString(dis);
					
					this.sourceAssociated = readString(dis);
					
					this.sourceAssociatedName = readString(dis);
					
					this.driver_id = readString(dis);
					
					this.driverFirstName = readString(dis);
					
					this.driverLastName = readString(dis);
					
					this.driverExternalId = readString(dis);
					
					this.driverId = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.sourceRoundColor = readString(dis);
					
					this.sourceCompletedBy = readString(dis);
					
					this.sourceImagePath = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceHasRejectedProducts = null;
           				} else {
           			    	this.sourceHasRejectedProducts = dis.readBoolean();
           				}
					
					this.source_Id = readString(dis);
					
					this.metadataVehicule = readString(dis);
					
					this.metadataFACTURATION = readString(dis);
					
					this.metadataRouteGrenoble = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.delay = readString(dis);
					
					this.failedReason = readString(dis);
					
					this.failedReasonCustom = readString(dis);
					
					this.isExpress = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceLocationType = readString(dis);
					
					this.sourceLocationGeometry = readString(dis);
					
					this.sourceAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceGeocodeScore = null;
           				} else {
           			    	this.sourceGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCleanScore = null;
           				} else {
           			    	this.sourceCleanScore = dis.readDouble();
           				}
					
					this.sourceStreet = readString(dis);
					
					this.sourceCity = readString(dis);
					
						this.sourceZip = readInteger(dis);
					
					this.sourceCountry = readString(dis);
					
					this.sourceAddress = readString(dis);
					
					this.locationType = readString(dis);
					
					this.locationGeometry = readString(dis);
					
					this.locationAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationGeocodeScore = null;
           				} else {
           			    	this.locationGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationCleanScore = null;
           				} else {
           			    	this.locationCleanScore = dis.readDouble();
           				}
					
					this.locationStreet = readString(dis);
					
					this.locationAddress = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.locationCity = readString(dis);
					
					this.locationCountry = readString(dis);
					
					this.locationOrigin = readString(dis);
					
					this.contactBuildingInfo = readString(dis);
					
					this.contactPerson = readString(dis);
					
					this.contactPhone = readString(dis);
					
					this.contactEmail = readString(dis);
					
					this.timeWindowStart = readString(dis);
					
					this.timeWindowStop = readString(dis);
					
					this.sourceStatus = readString(dis);
					
					this.sourceActivity = readString(dis);
					
					this.sourceSkills = readString(dis);
					
					this.sourceLabels = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceAttempts = null;
           				} else {
           			    	this.sourceAttempts = dis.readDouble();
           				}
					
					this.sourceHasBeenPaid = readString(dis);
					
					this.sourceClosureDate = readString(dis);
					
					this.sourcePaymentType = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCollectedAmount = null;
           				} else {
           			    	this.sourceCollectedAmount = dis.readDouble();
           				}
					
						this.metadataCodeArticle = (Object) dis.readObject();
					
					this.metadataTypePrestation = readString(dis);
					
					this.sourceIssues = readString(dis);
					
					this.sourceWhen = readString(dis);
					
					this.sourceUpdated = readString(dis);
					
					this.sourceItems = readString(dis);
					
					this.sourceProducts = readString(dis);
					
					this.sourceAnnouncement = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.sourceEndpoint = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceBy = readString(dis);
					
					this.sourceCategory = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.createdBy_id = readString(dis);
					
					this.createdByFirstName = readString(dis);
					
					this.createdByLastName = readString(dis);
					
					this.createdByExternalId = readString(dis);
					
					this.createdById = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsWeight = null;
           				} else {
           			    	this.dimensionsWeight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsVolume = null;
           				} else {
           			    	this.dimensionsVolume = dis.readDouble();
           				}
					
					this.sourceFlux = readString(dis);
					
					this.sourceInstructions = readString(dis);
					
					this.sourcePlatform = readString(dis);
					
					this.sourcePlatformName = readString(dis);
					
					this.sourceProgress = readString(dis);
					
					this.sourceRoundName = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceSequence = null;
           				} else {
           			    	this.sourceSequence = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceServiceTime = null;
           				} else {
           			    	this.sourceServiceTime = dis.readDouble();
           				}
					
					this.sourceTrackingId = readString(dis);
					
					this.sourceHub = readString(dis);
					
					this.sourceHubName = readString(dis);
					
					this.sourceTargetFlux = readString(dis);
					
					this.sourceZone = readString(dis);
					
					this.sourceOrder = readString(dis);
					
					this.sourceArriveTime = readString(dis);
					
					this.sourceAssociated = readString(dis);
					
					this.sourceAssociatedName = readString(dis);
					
					this.driver_id = readString(dis);
					
					this.driverFirstName = readString(dis);
					
					this.driverLastName = readString(dis);
					
					this.driverExternalId = readString(dis);
					
					this.driverId = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.sourceRoundColor = readString(dis);
					
					this.sourceCompletedBy = readString(dis);
					
					this.sourceImagePath = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceHasRejectedProducts = null;
           				} else {
           			    	this.sourceHasRejectedProducts = dis.readBoolean();
           				}
					
					this.source_Id = readString(dis);
					
					this.metadataVehicule = readString(dis);
					
					this.metadataFACTURATION = readString(dis);
					
					this.metadataRouteGrenoble = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.delay = readString(dis);
					
					this.failedReason = readString(dis);
					
					this.failedReasonCustom = readString(dis);
					
					this.isExpress = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceLocationType,dos);
					
					// String
				
						writeString(this.sourceLocationGeometry,dos);
					
					// String
				
						writeString(this.sourceAddressLines,dos);
					
					// Double
				
						if(this.sourceGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceGeocodeScore);
		            	}
					
					// Double
				
						if(this.sourceCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCleanScore);
		            	}
					
					// String
				
						writeString(this.sourceStreet,dos);
					
					// String
				
						writeString(this.sourceCity,dos);
					
					// Integer
				
						writeInteger(this.sourceZip,dos);
					
					// String
				
						writeString(this.sourceCountry,dos);
					
					// String
				
						writeString(this.sourceAddress,dos);
					
					// String
				
						writeString(this.locationType,dos);
					
					// String
				
						writeString(this.locationGeometry,dos);
					
					// String
				
						writeString(this.locationAddressLines,dos);
					
					// Double
				
						if(this.locationGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationGeocodeScore);
		            	}
					
					// Double
				
						if(this.locationCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationCleanScore);
		            	}
					
					// String
				
						writeString(this.locationStreet,dos);
					
					// String
				
						writeString(this.locationAddress,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.locationCity,dos);
					
					// String
				
						writeString(this.locationCountry,dos);
					
					// String
				
						writeString(this.locationOrigin,dos);
					
					// String
				
						writeString(this.contactBuildingInfo,dos);
					
					// String
				
						writeString(this.contactPerson,dos);
					
					// String
				
						writeString(this.contactPhone,dos);
					
					// String
				
						writeString(this.contactEmail,dos);
					
					// String
				
						writeString(this.timeWindowStart,dos);
					
					// String
				
						writeString(this.timeWindowStop,dos);
					
					// String
				
						writeString(this.sourceStatus,dos);
					
					// String
				
						writeString(this.sourceActivity,dos);
					
					// String
				
						writeString(this.sourceSkills,dos);
					
					// String
				
						writeString(this.sourceLabels,dos);
					
					// Double
				
						if(this.sourceAttempts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceAttempts);
		            	}
					
					// String
				
						writeString(this.sourceHasBeenPaid,dos);
					
					// String
				
						writeString(this.sourceClosureDate,dos);
					
					// String
				
						writeString(this.sourcePaymentType,dos);
					
					// Double
				
						if(this.sourceCollectedAmount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCollectedAmount);
		            	}
					
					// Object
				
       			    	dos.writeObject(this.metadataCodeArticle);
					
					// String
				
						writeString(this.metadataTypePrestation,dos);
					
					// String
				
						writeString(this.sourceIssues,dos);
					
					// String
				
						writeString(this.sourceWhen,dos);
					
					// String
				
						writeString(this.sourceUpdated,dos);
					
					// String
				
						writeString(this.sourceItems,dos);
					
					// String
				
						writeString(this.sourceProducts,dos);
					
					// String
				
						writeString(this.sourceAnnouncement,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.sourceEndpoint,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceBy,dos);
					
					// String
				
						writeString(this.sourceCategory,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.createdBy_id,dos);
					
					// String
				
						writeString(this.createdByFirstName,dos);
					
					// String
				
						writeString(this.createdByLastName,dos);
					
					// String
				
						writeString(this.createdByExternalId,dos);
					
					// String
				
						writeString(this.createdById,dos);
					
					// Double
				
						if(this.dimensionsWeight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsWeight);
		            	}
					
					// Double
				
						if(this.dimensionsVolume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsVolume);
		            	}
					
					// String
				
						writeString(this.sourceFlux,dos);
					
					// String
				
						writeString(this.sourceInstructions,dos);
					
					// String
				
						writeString(this.sourcePlatform,dos);
					
					// String
				
						writeString(this.sourcePlatformName,dos);
					
					// String
				
						writeString(this.sourceProgress,dos);
					
					// String
				
						writeString(this.sourceRoundName,dos);
					
					// Double
				
						if(this.sourceSequence == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceSequence);
		            	}
					
					// Double
				
						if(this.sourceServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceServiceTime);
		            	}
					
					// String
				
						writeString(this.sourceTrackingId,dos);
					
					// String
				
						writeString(this.sourceHub,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.sourceTargetFlux,dos);
					
					// String
				
						writeString(this.sourceZone,dos);
					
					// String
				
						writeString(this.sourceOrder,dos);
					
					// String
				
						writeString(this.sourceArriveTime,dos);
					
					// String
				
						writeString(this.sourceAssociated,dos);
					
					// String
				
						writeString(this.sourceAssociatedName,dos);
					
					// String
				
						writeString(this.driver_id,dos);
					
					// String
				
						writeString(this.driverFirstName,dos);
					
					// String
				
						writeString(this.driverLastName,dos);
					
					// String
				
						writeString(this.driverExternalId,dos);
					
					// String
				
						writeString(this.driverId,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.sourceRoundColor,dos);
					
					// String
				
						writeString(this.sourceCompletedBy,dos);
					
					// String
				
						writeString(this.sourceImagePath,dos);
					
					// Boolean
				
						if(this.sourceHasRejectedProducts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.sourceHasRejectedProducts);
		            	}
					
					// String
				
						writeString(this.source_Id,dos);
					
					// String
				
						writeString(this.metadataVehicule,dos);
					
					// String
				
						writeString(this.metadataFACTURATION,dos);
					
					// String
				
						writeString(this.metadataRouteGrenoble,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// String
				
						writeString(this.delay,dos);
					
					// String
				
						writeString(this.failedReason,dos);
					
					// String
				
						writeString(this.failedReasonCustom,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceLocationType,dos);
					
					// String
				
						writeString(this.sourceLocationGeometry,dos);
					
					// String
				
						writeString(this.sourceAddressLines,dos);
					
					// Double
				
						if(this.sourceGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceGeocodeScore);
		            	}
					
					// Double
				
						if(this.sourceCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCleanScore);
		            	}
					
					// String
				
						writeString(this.sourceStreet,dos);
					
					// String
				
						writeString(this.sourceCity,dos);
					
					// Integer
				
						writeInteger(this.sourceZip,dos);
					
					// String
				
						writeString(this.sourceCountry,dos);
					
					// String
				
						writeString(this.sourceAddress,dos);
					
					// String
				
						writeString(this.locationType,dos);
					
					// String
				
						writeString(this.locationGeometry,dos);
					
					// String
				
						writeString(this.locationAddressLines,dos);
					
					// Double
				
						if(this.locationGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationGeocodeScore);
		            	}
					
					// Double
				
						if(this.locationCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationCleanScore);
		            	}
					
					// String
				
						writeString(this.locationStreet,dos);
					
					// String
				
						writeString(this.locationAddress,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.locationCity,dos);
					
					// String
				
						writeString(this.locationCountry,dos);
					
					// String
				
						writeString(this.locationOrigin,dos);
					
					// String
				
						writeString(this.contactBuildingInfo,dos);
					
					// String
				
						writeString(this.contactPerson,dos);
					
					// String
				
						writeString(this.contactPhone,dos);
					
					// String
				
						writeString(this.contactEmail,dos);
					
					// String
				
						writeString(this.timeWindowStart,dos);
					
					// String
				
						writeString(this.timeWindowStop,dos);
					
					// String
				
						writeString(this.sourceStatus,dos);
					
					// String
				
						writeString(this.sourceActivity,dos);
					
					// String
				
						writeString(this.sourceSkills,dos);
					
					// String
				
						writeString(this.sourceLabels,dos);
					
					// Double
				
						if(this.sourceAttempts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceAttempts);
		            	}
					
					// String
				
						writeString(this.sourceHasBeenPaid,dos);
					
					// String
				
						writeString(this.sourceClosureDate,dos);
					
					// String
				
						writeString(this.sourcePaymentType,dos);
					
					// Double
				
						if(this.sourceCollectedAmount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCollectedAmount);
		            	}
					
					// Object
				
						dos.clearInstanceCache();
						dos.writeObject(this.metadataCodeArticle);
					
					// String
				
						writeString(this.metadataTypePrestation,dos);
					
					// String
				
						writeString(this.sourceIssues,dos);
					
					// String
				
						writeString(this.sourceWhen,dos);
					
					// String
				
						writeString(this.sourceUpdated,dos);
					
					// String
				
						writeString(this.sourceItems,dos);
					
					// String
				
						writeString(this.sourceProducts,dos);
					
					// String
				
						writeString(this.sourceAnnouncement,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.sourceEndpoint,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceBy,dos);
					
					// String
				
						writeString(this.sourceCategory,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.createdBy_id,dos);
					
					// String
				
						writeString(this.createdByFirstName,dos);
					
					// String
				
						writeString(this.createdByLastName,dos);
					
					// String
				
						writeString(this.createdByExternalId,dos);
					
					// String
				
						writeString(this.createdById,dos);
					
					// Double
				
						if(this.dimensionsWeight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsWeight);
		            	}
					
					// Double
				
						if(this.dimensionsVolume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsVolume);
		            	}
					
					// String
				
						writeString(this.sourceFlux,dos);
					
					// String
				
						writeString(this.sourceInstructions,dos);
					
					// String
				
						writeString(this.sourcePlatform,dos);
					
					// String
				
						writeString(this.sourcePlatformName,dos);
					
					// String
				
						writeString(this.sourceProgress,dos);
					
					// String
				
						writeString(this.sourceRoundName,dos);
					
					// Double
				
						if(this.sourceSequence == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceSequence);
		            	}
					
					// Double
				
						if(this.sourceServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceServiceTime);
		            	}
					
					// String
				
						writeString(this.sourceTrackingId,dos);
					
					// String
				
						writeString(this.sourceHub,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.sourceTargetFlux,dos);
					
					// String
				
						writeString(this.sourceZone,dos);
					
					// String
				
						writeString(this.sourceOrder,dos);
					
					// String
				
						writeString(this.sourceArriveTime,dos);
					
					// String
				
						writeString(this.sourceAssociated,dos);
					
					// String
				
						writeString(this.sourceAssociatedName,dos);
					
					// String
				
						writeString(this.driver_id,dos);
					
					// String
				
						writeString(this.driverFirstName,dos);
					
					// String
				
						writeString(this.driverLastName,dos);
					
					// String
				
						writeString(this.driverExternalId,dos);
					
					// String
				
						writeString(this.driverId,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.sourceRoundColor,dos);
					
					// String
				
						writeString(this.sourceCompletedBy,dos);
					
					// String
				
						writeString(this.sourceImagePath,dos);
					
					// Boolean
				
						if(this.sourceHasRejectedProducts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.sourceHasRejectedProducts);
		            	}
					
					// String
				
						writeString(this.source_Id,dos);
					
					// String
				
						writeString(this.metadataVehicule,dos);
					
					// String
				
						writeString(this.metadataFACTURATION,dos);
					
					// String
				
						writeString(this.metadataRouteGrenoble,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// String
				
						writeString(this.delay,dos);
					
					// String
				
						writeString(this.failedReason,dos);
					
					// String
				
						writeString(this.failedReasonCustom,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",sourceLocationType="+sourceLocationType);
		sb.append(",sourceLocationGeometry="+sourceLocationGeometry);
		sb.append(",sourceAddressLines="+sourceAddressLines);
		sb.append(",sourceGeocodeScore="+String.valueOf(sourceGeocodeScore));
		sb.append(",sourceCleanScore="+String.valueOf(sourceCleanScore));
		sb.append(",sourceStreet="+sourceStreet);
		sb.append(",sourceCity="+sourceCity);
		sb.append(",sourceZip="+String.valueOf(sourceZip));
		sb.append(",sourceCountry="+sourceCountry);
		sb.append(",sourceAddress="+sourceAddress);
		sb.append(",locationType="+locationType);
		sb.append(",locationGeometry="+locationGeometry);
		sb.append(",locationAddressLines="+locationAddressLines);
		sb.append(",locationGeocodeScore="+String.valueOf(locationGeocodeScore));
		sb.append(",locationCleanScore="+String.valueOf(locationCleanScore));
		sb.append(",locationStreet="+locationStreet);
		sb.append(",locationAddress="+locationAddress);
		sb.append(",locationZip="+String.valueOf(locationZip));
		sb.append(",locationCity="+locationCity);
		sb.append(",locationCountry="+locationCountry);
		sb.append(",locationOrigin="+locationOrigin);
		sb.append(",contactBuildingInfo="+contactBuildingInfo);
		sb.append(",contactPerson="+contactPerson);
		sb.append(",contactPhone="+contactPhone);
		sb.append(",contactEmail="+contactEmail);
		sb.append(",timeWindowStart="+timeWindowStart);
		sb.append(",timeWindowStop="+timeWindowStop);
		sb.append(",sourceStatus="+sourceStatus);
		sb.append(",sourceActivity="+sourceActivity);
		sb.append(",sourceSkills="+sourceSkills);
		sb.append(",sourceLabels="+sourceLabels);
		sb.append(",sourceAttempts="+String.valueOf(sourceAttempts));
		sb.append(",sourceHasBeenPaid="+sourceHasBeenPaid);
		sb.append(",sourceClosureDate="+sourceClosureDate);
		sb.append(",sourcePaymentType="+sourcePaymentType);
		sb.append(",sourceCollectedAmount="+String.valueOf(sourceCollectedAmount));
		sb.append(",metadataCodeArticle="+String.valueOf(metadataCodeArticle));
		sb.append(",metadataTypePrestation="+metadataTypePrestation);
		sb.append(",sourceIssues="+sourceIssues);
		sb.append(",sourceWhen="+sourceWhen);
		sb.append(",sourceUpdated="+sourceUpdated);
		sb.append(",sourceItems="+sourceItems);
		sb.append(",sourceProducts="+sourceProducts);
		sb.append(",sourceAnnouncement="+sourceAnnouncement);
		sb.append(",sourceDate="+sourceDate);
		sb.append(",sourceEndpoint="+sourceEndpoint);
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceBy="+sourceBy);
		sb.append(",sourceCategory="+sourceCategory);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",createdBy_id="+createdBy_id);
		sb.append(",createdByFirstName="+createdByFirstName);
		sb.append(",createdByLastName="+createdByLastName);
		sb.append(",createdByExternalId="+createdByExternalId);
		sb.append(",createdById="+createdById);
		sb.append(",dimensionsWeight="+String.valueOf(dimensionsWeight));
		sb.append(",dimensionsVolume="+String.valueOf(dimensionsVolume));
		sb.append(",sourceFlux="+sourceFlux);
		sb.append(",sourceInstructions="+sourceInstructions);
		sb.append(",sourcePlatform="+sourcePlatform);
		sb.append(",sourcePlatformName="+sourcePlatformName);
		sb.append(",sourceProgress="+sourceProgress);
		sb.append(",sourceRoundName="+sourceRoundName);
		sb.append(",sourceSequence="+String.valueOf(sourceSequence));
		sb.append(",sourceServiceTime="+String.valueOf(sourceServiceTime));
		sb.append(",sourceTrackingId="+sourceTrackingId);
		sb.append(",sourceHub="+sourceHub);
		sb.append(",sourceHubName="+sourceHubName);
		sb.append(",sourceTargetFlux="+sourceTargetFlux);
		sb.append(",sourceZone="+sourceZone);
		sb.append(",sourceOrder="+sourceOrder);
		sb.append(",sourceArriveTime="+sourceArriveTime);
		sb.append(",sourceAssociated="+sourceAssociated);
		sb.append(",sourceAssociatedName="+sourceAssociatedName);
		sb.append(",driver_id="+driver_id);
		sb.append(",driverFirstName="+driverFirstName);
		sb.append(",driverLastName="+driverLastName);
		sb.append(",driverExternalId="+driverExternalId);
		sb.append(",driverId="+driverId);
		sb.append(",sourceRound="+sourceRound);
		sb.append(",sourceRoundColor="+sourceRoundColor);
		sb.append(",sourceCompletedBy="+sourceCompletedBy);
		sb.append(",sourceImagePath="+sourceImagePath);
		sb.append(",sourceHasRejectedProducts="+String.valueOf(sourceHasRejectedProducts));
		sb.append(",source_Id="+source_Id);
		sb.append(",metadataVehicule="+metadataVehicule);
		sb.append(",metadataFACTURATION="+metadataFACTURATION);
		sb.append(",metadataRouteGrenoble="+metadataRouteGrenoble);
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",delay="+delay);
		sb.append(",failedReason="+failedReason);
		sb.append(",failedReasonCustom="+failedReasonCustom);
		sb.append(",isExpress="+isExpress);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLocationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLocationType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLocationGeometry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLocationGeometry);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAddressLines == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAddressLines);
            			}
            		
        			sb.append("|");
        		
        				if(sourceGeocodeScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceGeocodeScore);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCleanScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCleanScore);
            			}
            		
        			sb.append("|");
        		
        				if(sourceStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceStreet);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCity);
            			}
            		
        			sb.append("|");
        		
        				if(sourceZip == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceZip);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCountry);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAddress);
            			}
            		
        			sb.append("|");
        		
        				if(locationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationType);
            			}
            		
        			sb.append("|");
        		
        				if(locationGeometry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationGeometry);
            			}
            		
        			sb.append("|");
        		
        				if(locationAddressLines == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationAddressLines);
            			}
            		
        			sb.append("|");
        		
        				if(locationGeocodeScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationGeocodeScore);
            			}
            		
        			sb.append("|");
        		
        				if(locationCleanScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCleanScore);
            			}
            		
        			sb.append("|");
        		
        				if(locationStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationStreet);
            			}
            		
        			sb.append("|");
        		
        				if(locationAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationAddress);
            			}
            		
        			sb.append("|");
        		
        				if(locationZip == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationZip);
            			}
            		
        			sb.append("|");
        		
        				if(locationCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCity);
            			}
            		
        			sb.append("|");
        		
        				if(locationCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCountry);
            			}
            		
        			sb.append("|");
        		
        				if(locationOrigin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationOrigin);
            			}
            		
        			sb.append("|");
        		
        				if(contactBuildingInfo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactBuildingInfo);
            			}
            		
        			sb.append("|");
        		
        				if(contactPerson == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactPerson);
            			}
            		
        			sb.append("|");
        		
        				if(contactPhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactPhone);
            			}
            		
        			sb.append("|");
        		
        				if(contactEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactEmail);
            			}
            		
        			sb.append("|");
        		
        				if(timeWindowStart == null){
        					sb.append("<null>");
        				}else{
            				sb.append(timeWindowStart);
            			}
            		
        			sb.append("|");
        		
        				if(timeWindowStop == null){
        					sb.append("<null>");
        				}else{
            				sb.append(timeWindowStop);
            			}
            		
        			sb.append("|");
        		
        				if(sourceStatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceStatus);
            			}
            		
        			sb.append("|");
        		
        				if(sourceActivity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceActivity);
            			}
            		
        			sb.append("|");
        		
        				if(sourceSkills == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceSkills);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLabels == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLabels);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAttempts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAttempts);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHasBeenPaid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHasBeenPaid);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClosureDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClosureDate);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePaymentType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePaymentType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCollectedAmount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCollectedAmount);
            			}
            		
        			sb.append("|");
        		
        				if(metadataCodeArticle == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataCodeArticle);
            			}
            		
        			sb.append("|");
        		
        				if(metadataTypePrestation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataTypePrestation);
            			}
            		
        			sb.append("|");
        		
        				if(sourceIssues == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceIssues);
            			}
            		
        			sb.append("|");
        		
        				if(sourceWhen == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceWhen);
            			}
            		
        			sb.append("|");
        		
        				if(sourceUpdated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceUpdated);
            			}
            		
        			sb.append("|");
        		
        				if(sourceItems == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceItems);
            			}
            		
        			sb.append("|");
        		
        				if(sourceProducts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceProducts);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAnnouncement == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAnnouncement);
            			}
            		
        			sb.append("|");
        		
        				if(sourceDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceDate);
            			}
            		
        			sb.append("|");
        		
        				if(sourceEndpoint == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceEndpoint);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceBy);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCategory == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCategory);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(createdBy_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdBy_id);
            			}
            		
        			sb.append("|");
        		
        				if(createdByFirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByFirstName);
            			}
            		
        			sb.append("|");
        		
        				if(createdByLastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByLastName);
            			}
            		
        			sb.append("|");
        		
        				if(createdByExternalId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByExternalId);
            			}
            		
        			sb.append("|");
        		
        				if(createdById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdById);
            			}
            		
        			sb.append("|");
        		
        				if(dimensionsWeight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dimensionsWeight);
            			}
            		
        			sb.append("|");
        		
        				if(dimensionsVolume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dimensionsVolume);
            			}
            		
        			sb.append("|");
        		
        				if(sourceFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceFlux);
            			}
            		
        			sb.append("|");
        		
        				if(sourceInstructions == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceInstructions);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePlatform == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePlatform);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePlatformName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePlatformName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceProgress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceProgress);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRoundName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceSequence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceSequence);
            			}
            		
        			sb.append("|");
        		
        				if(sourceServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(sourceTrackingId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceTrackingId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHub == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHub);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHubName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHubName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceTargetFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceTargetFlux);
            			}
            		
        			sb.append("|");
        		
        				if(sourceZone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceZone);
            			}
            		
        			sb.append("|");
        		
        				if(sourceOrder == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceOrder);
            			}
            		
        			sb.append("|");
        		
        				if(sourceArriveTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceArriveTime);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAssociated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAssociated);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAssociatedName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAssociatedName);
            			}
            		
        			sb.append("|");
        		
        				if(driver_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driver_id);
            			}
            		
        			sb.append("|");
        		
        				if(driverFirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverFirstName);
            			}
            		
        			sb.append("|");
        		
        				if(driverLastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverLastName);
            			}
            		
        			sb.append("|");
        		
        				if(driverExternalId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverExternalId);
            			}
            		
        			sb.append("|");
        		
        				if(driverId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRoundColor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRoundColor);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCompletedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCompletedBy);
            			}
            		
        			sb.append("|");
        		
        				if(sourceImagePath == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceImagePath);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHasRejectedProducts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHasRejectedProducts);
            			}
            		
        			sb.append("|");
        		
        				if(source_Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_Id);
            			}
            		
        			sb.append("|");
        		
        				if(metadataVehicule == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataVehicule);
            			}
            		
        			sb.append("|");
        		
        				if(metadataFACTURATION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataFACTURATION);
            			}
            		
        			sb.append("|");
        		
        				if(metadataRouteGrenoble == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataRouteGrenoble);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(delay == null){
        					sb.append("<null>");
        				}else{
            				sb.append(delay);
            			}
            		
        			sb.append("|");
        		
        				if(failedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(failedReason);
            			}
            		
        			sb.append("|");
        		
        				if(failedReasonCustom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(failedReasonCustom);
            			}
            		
        			sb.append("|");
        		
        				if(isExpress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isExpress);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(task_dbStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.sourceId, other.sourceId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public String sourceId;

				public String getSourceId () {
					return this.sourceId;
				}

				public Boolean sourceIdIsNullable(){
				    return true;
				}
				public Boolean sourceIdIsKey(){
				    return false;
				}
				public Integer sourceIdLength(){
				    return 24;
				}
				public Integer sourceIdPrecision(){
				    return 0;
				}
				public String sourceIdDefault(){
				
					return null;
				
				}
				public String sourceIdComment(){
				
				    return "";
				
				}
				public String sourceIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceIdOriginalDbColumnName(){
				
					return "sourceId";
				
				}

				
			    public String sourceLocationType;

				public String getSourceLocationType () {
					return this.sourceLocationType;
				}

				public Boolean sourceLocationTypeIsNullable(){
				    return true;
				}
				public Boolean sourceLocationTypeIsKey(){
				    return false;
				}
				public Integer sourceLocationTypeLength(){
				    return 5;
				}
				public Integer sourceLocationTypePrecision(){
				    return 0;
				}
				public String sourceLocationTypeDefault(){
				
					return null;
				
				}
				public String sourceLocationTypeComment(){
				
				    return "";
				
				}
				public String sourceLocationTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceLocationTypeOriginalDbColumnName(){
				
					return "sourceLocationType";
				
				}

				
			    public String sourceLocationGeometry;

				public String getSourceLocationGeometry () {
					return this.sourceLocationGeometry;
				}

				public Boolean sourceLocationGeometryIsNullable(){
				    return true;
				}
				public Boolean sourceLocationGeometryIsKey(){
				    return false;
				}
				public Integer sourceLocationGeometryLength(){
				    return 2;
				}
				public Integer sourceLocationGeometryPrecision(){
				    return 0;
				}
				public String sourceLocationGeometryDefault(){
				
					return null;
				
				}
				public String sourceLocationGeometryComment(){
				
				    return "";
				
				}
				public String sourceLocationGeometryPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceLocationGeometryOriginalDbColumnName(){
				
					return "sourceLocationGeometry";
				
				}

				
			    public String sourceAddressLines;

				public String getSourceAddressLines () {
					return this.sourceAddressLines;
				}

				public Boolean sourceAddressLinesIsNullable(){
				    return true;
				}
				public Boolean sourceAddressLinesIsKey(){
				    return false;
				}
				public Integer sourceAddressLinesLength(){
				    return 2;
				}
				public Integer sourceAddressLinesPrecision(){
				    return 0;
				}
				public String sourceAddressLinesDefault(){
				
					return null;
				
				}
				public String sourceAddressLinesComment(){
				
				    return "";
				
				}
				public String sourceAddressLinesPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAddressLinesOriginalDbColumnName(){
				
					return "sourceAddressLines";
				
				}

				
			    public Double sourceGeocodeScore;

				public Double getSourceGeocodeScore () {
					return this.sourceGeocodeScore;
				}

				public Boolean sourceGeocodeScoreIsNullable(){
				    return true;
				}
				public Boolean sourceGeocodeScoreIsKey(){
				    return false;
				}
				public Integer sourceGeocodeScoreLength(){
				    return null;
				}
				public Integer sourceGeocodeScorePrecision(){
				    return 0;
				}
				public String sourceGeocodeScoreDefault(){
				
					return null;
				
				}
				public String sourceGeocodeScoreComment(){
				
				    return "";
				
				}
				public String sourceGeocodeScorePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceGeocodeScoreOriginalDbColumnName(){
				
					return "sourceGeocodeScore";
				
				}

				
			    public Double sourceCleanScore;

				public Double getSourceCleanScore () {
					return this.sourceCleanScore;
				}

				public Boolean sourceCleanScoreIsNullable(){
				    return true;
				}
				public Boolean sourceCleanScoreIsKey(){
				    return false;
				}
				public Integer sourceCleanScoreLength(){
				    return null;
				}
				public Integer sourceCleanScorePrecision(){
				    return 0;
				}
				public String sourceCleanScoreDefault(){
				
					return null;
				
				}
				public String sourceCleanScoreComment(){
				
				    return "";
				
				}
				public String sourceCleanScorePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCleanScoreOriginalDbColumnName(){
				
					return "sourceCleanScore";
				
				}

				
			    public String sourceStreet;

				public String getSourceStreet () {
					return this.sourceStreet;
				}

				public Boolean sourceStreetIsNullable(){
				    return true;
				}
				public Boolean sourceStreetIsKey(){
				    return false;
				}
				public Integer sourceStreetLength(){
				    return 54;
				}
				public Integer sourceStreetPrecision(){
				    return 0;
				}
				public String sourceStreetDefault(){
				
					return null;
				
				}
				public String sourceStreetComment(){
				
				    return "";
				
				}
				public String sourceStreetPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceStreetOriginalDbColumnName(){
				
					return "sourceStreet";
				
				}

				
			    public String sourceCity;

				public String getSourceCity () {
					return this.sourceCity;
				}

				public Boolean sourceCityIsNullable(){
				    return true;
				}
				public Boolean sourceCityIsKey(){
				    return false;
				}
				public Integer sourceCityLength(){
				    return 6;
				}
				public Integer sourceCityPrecision(){
				    return 0;
				}
				public String sourceCityDefault(){
				
					return null;
				
				}
				public String sourceCityComment(){
				
				    return "";
				
				}
				public String sourceCityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCityOriginalDbColumnName(){
				
					return "sourceCity";
				
				}

				
			    public Integer sourceZip;

				public Integer getSourceZip () {
					return this.sourceZip;
				}

				public Boolean sourceZipIsNullable(){
				    return true;
				}
				public Boolean sourceZipIsKey(){
				    return false;
				}
				public Integer sourceZipLength(){
				    return 5;
				}
				public Integer sourceZipPrecision(){
				    return 0;
				}
				public String sourceZipDefault(){
				
					return null;
				
				}
				public String sourceZipComment(){
				
				    return "";
				
				}
				public String sourceZipPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceZipOriginalDbColumnName(){
				
					return "sourceZip";
				
				}

				
			    public String sourceCountry;

				public String getSourceCountry () {
					return this.sourceCountry;
				}

				public Boolean sourceCountryIsNullable(){
				    return true;
				}
				public Boolean sourceCountryIsKey(){
				    return false;
				}
				public Integer sourceCountryLength(){
				    return 2;
				}
				public Integer sourceCountryPrecision(){
				    return 0;
				}
				public String sourceCountryDefault(){
				
					return null;
				
				}
				public String sourceCountryComment(){
				
				    return "";
				
				}
				public String sourceCountryPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCountryOriginalDbColumnName(){
				
					return "sourceCountry";
				
				}

				
			    public String sourceAddress;

				public String getSourceAddress () {
					return this.sourceAddress;
				}

				public Boolean sourceAddressIsNullable(){
				    return true;
				}
				public Boolean sourceAddressIsKey(){
				    return false;
				}
				public Integer sourceAddressLength(){
				    return 69;
				}
				public Integer sourceAddressPrecision(){
				    return 0;
				}
				public String sourceAddressDefault(){
				
					return null;
				
				}
				public String sourceAddressComment(){
				
				    return "";
				
				}
				public String sourceAddressPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAddressOriginalDbColumnName(){
				
					return "sourceAddress";
				
				}

				
			    public String locationType;

				public String getLocationType () {
					return this.locationType;
				}

				public Boolean locationTypeIsNullable(){
				    return true;
				}
				public Boolean locationTypeIsKey(){
				    return false;
				}
				public Integer locationTypeLength(){
				    return 5;
				}
				public Integer locationTypePrecision(){
				    return 0;
				}
				public String locationTypeDefault(){
				
					return null;
				
				}
				public String locationTypeComment(){
				
				    return "";
				
				}
				public String locationTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationTypeOriginalDbColumnName(){
				
					return "locationType";
				
				}

				
			    public String locationGeometry;

				public String getLocationGeometry () {
					return this.locationGeometry;
				}

				public Boolean locationGeometryIsNullable(){
				    return true;
				}
				public Boolean locationGeometryIsKey(){
				    return false;
				}
				public Integer locationGeometryLength(){
				    return 31;
				}
				public Integer locationGeometryPrecision(){
				    return 0;
				}
				public String locationGeometryDefault(){
				
					return null;
				
				}
				public String locationGeometryComment(){
				
				    return "";
				
				}
				public String locationGeometryPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationGeometryOriginalDbColumnName(){
				
					return "locationGeometry";
				
				}

				
			    public String locationAddressLines;

				public String getLocationAddressLines () {
					return this.locationAddressLines;
				}

				public Boolean locationAddressLinesIsNullable(){
				    return true;
				}
				public Boolean locationAddressLinesIsKey(){
				    return false;
				}
				public Integer locationAddressLinesLength(){
				    return 101;
				}
				public Integer locationAddressLinesPrecision(){
				    return 0;
				}
				public String locationAddressLinesDefault(){
				
					return null;
				
				}
				public String locationAddressLinesComment(){
				
				    return "";
				
				}
				public String locationAddressLinesPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationAddressLinesOriginalDbColumnName(){
				
					return "locationAddressLines";
				
				}

				
			    public Double locationGeocodeScore;

				public Double getLocationGeocodeScore () {
					return this.locationGeocodeScore;
				}

				public Boolean locationGeocodeScoreIsNullable(){
				    return true;
				}
				public Boolean locationGeocodeScoreIsKey(){
				    return false;
				}
				public Integer locationGeocodeScoreLength(){
				    return null;
				}
				public Integer locationGeocodeScorePrecision(){
				    return 0;
				}
				public String locationGeocodeScoreDefault(){
				
					return null;
				
				}
				public String locationGeocodeScoreComment(){
				
				    return "";
				
				}
				public String locationGeocodeScorePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationGeocodeScoreOriginalDbColumnName(){
				
					return "locationGeocodeScore";
				
				}

				
			    public Double locationCleanScore;

				public Double getLocationCleanScore () {
					return this.locationCleanScore;
				}

				public Boolean locationCleanScoreIsNullable(){
				    return true;
				}
				public Boolean locationCleanScoreIsKey(){
				    return false;
				}
				public Integer locationCleanScoreLength(){
				    return null;
				}
				public Integer locationCleanScorePrecision(){
				    return 0;
				}
				public String locationCleanScoreDefault(){
				
					return null;
				
				}
				public String locationCleanScoreComment(){
				
				    return "";
				
				}
				public String locationCleanScorePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationCleanScoreOriginalDbColumnName(){
				
					return "locationCleanScore";
				
				}

				
			    public String locationStreet;

				public String getLocationStreet () {
					return this.locationStreet;
				}

				public Boolean locationStreetIsNullable(){
				    return true;
				}
				public Boolean locationStreetIsKey(){
				    return false;
				}
				public Integer locationStreetLength(){
				    return 54;
				}
				public Integer locationStreetPrecision(){
				    return 0;
				}
				public String locationStreetDefault(){
				
					return null;
				
				}
				public String locationStreetComment(){
				
				    return "";
				
				}
				public String locationStreetPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationStreetOriginalDbColumnName(){
				
					return "locationStreet";
				
				}

				
			    public String locationAddress;

				public String getLocationAddress () {
					return this.locationAddress;
				}

				public Boolean locationAddressIsNullable(){
				    return true;
				}
				public Boolean locationAddressIsKey(){
				    return false;
				}
				public Integer locationAddressLength(){
				    return 89;
				}
				public Integer locationAddressPrecision(){
				    return 0;
				}
				public String locationAddressDefault(){
				
					return null;
				
				}
				public String locationAddressComment(){
				
				    return "";
				
				}
				public String locationAddressPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationAddressOriginalDbColumnName(){
				
					return "locationAddress";
				
				}

				
			    public Integer locationZip;

				public Integer getLocationZip () {
					return this.locationZip;
				}

				public Boolean locationZipIsNullable(){
				    return true;
				}
				public Boolean locationZipIsKey(){
				    return false;
				}
				public Integer locationZipLength(){
				    return 5;
				}
				public Integer locationZipPrecision(){
				    return 0;
				}
				public String locationZipDefault(){
				
					return null;
				
				}
				public String locationZipComment(){
				
				    return "";
				
				}
				public String locationZipPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationZipOriginalDbColumnName(){
				
					return "locationZip";
				
				}

				
			    public String locationCity;

				public String getLocationCity () {
					return this.locationCity;
				}

				public Boolean locationCityIsNullable(){
				    return true;
				}
				public Boolean locationCityIsKey(){
				    return false;
				}
				public Integer locationCityLength(){
				    return 6;
				}
				public Integer locationCityPrecision(){
				    return 0;
				}
				public String locationCityDefault(){
				
					return null;
				
				}
				public String locationCityComment(){
				
				    return "";
				
				}
				public String locationCityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationCityOriginalDbColumnName(){
				
					return "locationCity";
				
				}

				
			    public String locationCountry;

				public String getLocationCountry () {
					return this.locationCountry;
				}

				public Boolean locationCountryIsNullable(){
				    return true;
				}
				public Boolean locationCountryIsKey(){
				    return false;
				}
				public Integer locationCountryLength(){
				    return 2;
				}
				public Integer locationCountryPrecision(){
				    return 0;
				}
				public String locationCountryDefault(){
				
					return null;
				
				}
				public String locationCountryComment(){
				
				    return "";
				
				}
				public String locationCountryPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationCountryOriginalDbColumnName(){
				
					return "locationCountry";
				
				}

				
			    public String locationOrigin;

				public String getLocationOrigin () {
					return this.locationOrigin;
				}

				public Boolean locationOriginIsNullable(){
				    return true;
				}
				public Boolean locationOriginIsKey(){
				    return false;
				}
				public Integer locationOriginLength(){
				    return 12;
				}
				public Integer locationOriginPrecision(){
				    return 0;
				}
				public String locationOriginDefault(){
				
					return null;
				
				}
				public String locationOriginComment(){
				
				    return "";
				
				}
				public String locationOriginPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String locationOriginOriginalDbColumnName(){
				
					return "locationOrigin";
				
				}

				
			    public String contactBuildingInfo;

				public String getContactBuildingInfo () {
					return this.contactBuildingInfo;
				}

				public Boolean contactBuildingInfoIsNullable(){
				    return true;
				}
				public Boolean contactBuildingInfoIsKey(){
				    return false;
				}
				public Integer contactBuildingInfoLength(){
				    return 21;
				}
				public Integer contactBuildingInfoPrecision(){
				    return 0;
				}
				public String contactBuildingInfoDefault(){
				
					return null;
				
				}
				public String contactBuildingInfoComment(){
				
				    return "";
				
				}
				public String contactBuildingInfoPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String contactBuildingInfoOriginalDbColumnName(){
				
					return "contactBuildingInfo";
				
				}

				
			    public String contactPerson;

				public String getContactPerson () {
					return this.contactPerson;
				}

				public Boolean contactPersonIsNullable(){
				    return true;
				}
				public Boolean contactPersonIsKey(){
				    return false;
				}
				public Integer contactPersonLength(){
				    return 26;
				}
				public Integer contactPersonPrecision(){
				    return 0;
				}
				public String contactPersonDefault(){
				
					return null;
				
				}
				public String contactPersonComment(){
				
				    return "";
				
				}
				public String contactPersonPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String contactPersonOriginalDbColumnName(){
				
					return "contactPerson";
				
				}

				
			    public String contactPhone;

				public String getContactPhone () {
					return this.contactPhone;
				}

				public Boolean contactPhoneIsNullable(){
				    return true;
				}
				public Boolean contactPhoneIsKey(){
				    return false;
				}
				public Integer contactPhoneLength(){
				    return 0;
				}
				public Integer contactPhonePrecision(){
				    return 0;
				}
				public String contactPhoneDefault(){
				
					return null;
				
				}
				public String contactPhoneComment(){
				
				    return "";
				
				}
				public String contactPhonePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String contactPhoneOriginalDbColumnName(){
				
					return "contactPhone";
				
				}

				
			    public String contactEmail;

				public String getContactEmail () {
					return this.contactEmail;
				}

				public Boolean contactEmailIsNullable(){
				    return true;
				}
				public Boolean contactEmailIsKey(){
				    return false;
				}
				public Integer contactEmailLength(){
				    return 0;
				}
				public Integer contactEmailPrecision(){
				    return 0;
				}
				public String contactEmailDefault(){
				
					return null;
				
				}
				public String contactEmailComment(){
				
				    return "";
				
				}
				public String contactEmailPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String contactEmailOriginalDbColumnName(){
				
					return "contactEmail";
				
				}

				
			    public String timeWindowStart;

				public String getTimeWindowStart () {
					return this.timeWindowStart;
				}

				public Boolean timeWindowStartIsNullable(){
				    return true;
				}
				public Boolean timeWindowStartIsKey(){
				    return false;
				}
				public Integer timeWindowStartLength(){
				    return null;
				}
				public Integer timeWindowStartPrecision(){
				    return 0;
				}
				public String timeWindowStartDefault(){
				
					return null;
				
				}
				public String timeWindowStartComment(){
				
				    return "";
				
				}
				public String timeWindowStartPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String timeWindowStartOriginalDbColumnName(){
				
					return "timeWindowStart";
				
				}

				
			    public String timeWindowStop;

				public String getTimeWindowStop () {
					return this.timeWindowStop;
				}

				public Boolean timeWindowStopIsNullable(){
				    return true;
				}
				public Boolean timeWindowStopIsKey(){
				    return false;
				}
				public Integer timeWindowStopLength(){
				    return null;
				}
				public Integer timeWindowStopPrecision(){
				    return 0;
				}
				public String timeWindowStopDefault(){
				
					return null;
				
				}
				public String timeWindowStopComment(){
				
				    return "";
				
				}
				public String timeWindowStopPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String timeWindowStopOriginalDbColumnName(){
				
					return "timeWindowStop";
				
				}

				
			    public String sourceStatus;

				public String getSourceStatus () {
					return this.sourceStatus;
				}

				public Boolean sourceStatusIsNullable(){
				    return true;
				}
				public Boolean sourceStatusIsKey(){
				    return false;
				}
				public Integer sourceStatusLength(){
				    return 9;
				}
				public Integer sourceStatusPrecision(){
				    return 0;
				}
				public String sourceStatusDefault(){
				
					return null;
				
				}
				public String sourceStatusComment(){
				
				    return "";
				
				}
				public String sourceStatusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceStatusOriginalDbColumnName(){
				
					return "sourceStatus";
				
				}

				
			    public String sourceActivity;

				public String getSourceActivity () {
					return this.sourceActivity;
				}

				public Boolean sourceActivityIsNullable(){
				    return true;
				}
				public Boolean sourceActivityIsKey(){
				    return false;
				}
				public Integer sourceActivityLength(){
				    return 7;
				}
				public Integer sourceActivityPrecision(){
				    return 0;
				}
				public String sourceActivityDefault(){
				
					return null;
				
				}
				public String sourceActivityComment(){
				
				    return "";
				
				}
				public String sourceActivityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceActivityOriginalDbColumnName(){
				
					return "sourceActivity";
				
				}

				
			    public String sourceSkills;

				public String getSourceSkills () {
					return this.sourceSkills;
				}

				public Boolean sourceSkillsIsNullable(){
				    return true;
				}
				public Boolean sourceSkillsIsKey(){
				    return false;
				}
				public Integer sourceSkillsLength(){
				    return 2;
				}
				public Integer sourceSkillsPrecision(){
				    return 0;
				}
				public String sourceSkillsDefault(){
				
					return null;
				
				}
				public String sourceSkillsComment(){
				
				    return "";
				
				}
				public String sourceSkillsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceSkillsOriginalDbColumnName(){
				
					return "sourceSkills";
				
				}

				
			    public String sourceLabels;

				public String getSourceLabels () {
					return this.sourceLabels;
				}

				public Boolean sourceLabelsIsNullable(){
				    return true;
				}
				public Boolean sourceLabelsIsKey(){
				    return false;
				}
				public Integer sourceLabelsLength(){
				    return 9;
				}
				public Integer sourceLabelsPrecision(){
				    return 0;
				}
				public String sourceLabelsDefault(){
				
					return null;
				
				}
				public String sourceLabelsComment(){
				
				    return "";
				
				}
				public String sourceLabelsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceLabelsOriginalDbColumnName(){
				
					return "sourceLabels";
				
				}

				
			    public Double sourceAttempts;

				public Double getSourceAttempts () {
					return this.sourceAttempts;
				}

				public Boolean sourceAttemptsIsNullable(){
				    return true;
				}
				public Boolean sourceAttemptsIsKey(){
				    return false;
				}
				public Integer sourceAttemptsLength(){
				    return null;
				}
				public Integer sourceAttemptsPrecision(){
				    return 0;
				}
				public String sourceAttemptsDefault(){
				
					return null;
				
				}
				public String sourceAttemptsComment(){
				
				    return "";
				
				}
				public String sourceAttemptsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAttemptsOriginalDbColumnName(){
				
					return "sourceAttempts";
				
				}

				
			    public String sourceHasBeenPaid;

				public String getSourceHasBeenPaid () {
					return this.sourceHasBeenPaid;
				}

				public Boolean sourceHasBeenPaidIsNullable(){
				    return true;
				}
				public Boolean sourceHasBeenPaidIsKey(){
				    return false;
				}
				public Integer sourceHasBeenPaidLength(){
				    return 0;
				}
				public Integer sourceHasBeenPaidPrecision(){
				    return 0;
				}
				public String sourceHasBeenPaidDefault(){
				
					return null;
				
				}
				public String sourceHasBeenPaidComment(){
				
				    return "";
				
				}
				public String sourceHasBeenPaidPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceHasBeenPaidOriginalDbColumnName(){
				
					return "sourceHasBeenPaid";
				
				}

				
			    public String sourceClosureDate;

				public String getSourceClosureDate () {
					return this.sourceClosureDate;
				}

				public Boolean sourceClosureDateIsNullable(){
				    return true;
				}
				public Boolean sourceClosureDateIsKey(){
				    return false;
				}
				public Integer sourceClosureDateLength(){
				    return null;
				}
				public Integer sourceClosureDatePrecision(){
				    return 0;
				}
				public String sourceClosureDateDefault(){
				
					return null;
				
				}
				public String sourceClosureDateComment(){
				
				    return "";
				
				}
				public String sourceClosureDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceClosureDateOriginalDbColumnName(){
				
					return "sourceClosureDate";
				
				}

				
			    public String sourcePaymentType;

				public String getSourcePaymentType () {
					return this.sourcePaymentType;
				}

				public Boolean sourcePaymentTypeIsNullable(){
				    return true;
				}
				public Boolean sourcePaymentTypeIsKey(){
				    return false;
				}
				public Integer sourcePaymentTypeLength(){
				    return 0;
				}
				public Integer sourcePaymentTypePrecision(){
				    return 0;
				}
				public String sourcePaymentTypeDefault(){
				
					return null;
				
				}
				public String sourcePaymentTypeComment(){
				
				    return "";
				
				}
				public String sourcePaymentTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourcePaymentTypeOriginalDbColumnName(){
				
					return "sourcePaymentType";
				
				}

				
			    public Double sourceCollectedAmount;

				public Double getSourceCollectedAmount () {
					return this.sourceCollectedAmount;
				}

				public Boolean sourceCollectedAmountIsNullable(){
				    return true;
				}
				public Boolean sourceCollectedAmountIsKey(){
				    return false;
				}
				public Integer sourceCollectedAmountLength(){
				    return null;
				}
				public Integer sourceCollectedAmountPrecision(){
				    return 0;
				}
				public String sourceCollectedAmountDefault(){
				
					return null;
				
				}
				public String sourceCollectedAmountComment(){
				
				    return "";
				
				}
				public String sourceCollectedAmountPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCollectedAmountOriginalDbColumnName(){
				
					return "sourceCollectedAmount";
				
				}

				
			    public String metadataTypePrestation;

				public String getMetadataTypePrestation () {
					return this.metadataTypePrestation;
				}

				public Boolean metadataTypePrestationIsNullable(){
				    return true;
				}
				public Boolean metadataTypePrestationIsKey(){
				    return false;
				}
				public Integer metadataTypePrestationLength(){
				    return null;
				}
				public Integer metadataTypePrestationPrecision(){
				    return null;
				}
				public String metadataTypePrestationDefault(){
				
					return null;
				
				}
				public String metadataTypePrestationComment(){
				
				    return "";
				
				}
				public String metadataTypePrestationPattern(){
				
					return "";
				
				}
				public String metadataTypePrestationOriginalDbColumnName(){
				
					return "metadataTypePrestation";
				
				}

				
			    public String metadataCodeArticle;

				public String getMetadataCodeArticle () {
					return this.metadataCodeArticle;
				}

				public Boolean metadataCodeArticleIsNullable(){
				    return true;
				}
				public Boolean metadataCodeArticleIsKey(){
				    return false;
				}
				public Integer metadataCodeArticleLength(){
				    return 4;
				}
				public Integer metadataCodeArticlePrecision(){
				    return 0;
				}
				public String metadataCodeArticleDefault(){
				
					return null;
				
				}
				public String metadataCodeArticleComment(){
				
				    return "";
				
				}
				public String metadataCodeArticlePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String metadataCodeArticleOriginalDbColumnName(){
				
					return "metadataCodeArticle";
				
				}

				
			    public String sourceIssues;

				public String getSourceIssues () {
					return this.sourceIssues;
				}

				public Boolean sourceIssuesIsNullable(){
				    return true;
				}
				public Boolean sourceIssuesIsKey(){
				    return false;
				}
				public Integer sourceIssuesLength(){
				    return 2;
				}
				public Integer sourceIssuesPrecision(){
				    return 0;
				}
				public String sourceIssuesDefault(){
				
					return null;
				
				}
				public String sourceIssuesComment(){
				
				    return "";
				
				}
				public String sourceIssuesPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceIssuesOriginalDbColumnName(){
				
					return "sourceIssues";
				
				}

				
			    public String sourceWhen;

				public String getSourceWhen () {
					return this.sourceWhen;
				}

				public Boolean sourceWhenIsNullable(){
				    return true;
				}
				public Boolean sourceWhenIsKey(){
				    return false;
				}
				public Integer sourceWhenLength(){
				    return null;
				}
				public Integer sourceWhenPrecision(){
				    return 0;
				}
				public String sourceWhenDefault(){
				
					return null;
				
				}
				public String sourceWhenComment(){
				
				    return "";
				
				}
				public String sourceWhenPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceWhenOriginalDbColumnName(){
				
					return "sourceWhen";
				
				}

				
			    public String sourceUpdated;

				public String getSourceUpdated () {
					return this.sourceUpdated;
				}

				public Boolean sourceUpdatedIsNullable(){
				    return true;
				}
				public Boolean sourceUpdatedIsKey(){
				    return false;
				}
				public Integer sourceUpdatedLength(){
				    return null;
				}
				public Integer sourceUpdatedPrecision(){
				    return 0;
				}
				public String sourceUpdatedDefault(){
				
					return null;
				
				}
				public String sourceUpdatedComment(){
				
				    return "";
				
				}
				public String sourceUpdatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceUpdatedOriginalDbColumnName(){
				
					return "sourceUpdated";
				
				}

				
			    public String sourceItems;

				public String getSourceItems () {
					return this.sourceItems;
				}

				public Boolean sourceItemsIsNullable(){
				    return true;
				}
				public Boolean sourceItemsIsKey(){
				    return false;
				}
				public Integer sourceItemsLength(){
				    return 778;
				}
				public Integer sourceItemsPrecision(){
				    return 0;
				}
				public String sourceItemsDefault(){
				
					return null;
				
				}
				public String sourceItemsComment(){
				
				    return "";
				
				}
				public String sourceItemsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceItemsOriginalDbColumnName(){
				
					return "sourceItems";
				
				}

				
			    public String sourceProducts;

				public String getSourceProducts () {
					return this.sourceProducts;
				}

				public Boolean sourceProductsIsNullable(){
				    return true;
				}
				public Boolean sourceProductsIsKey(){
				    return false;
				}
				public Integer sourceProductsLength(){
				    return 2;
				}
				public Integer sourceProductsPrecision(){
				    return 0;
				}
				public String sourceProductsDefault(){
				
					return null;
				
				}
				public String sourceProductsComment(){
				
				    return "";
				
				}
				public String sourceProductsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceProductsOriginalDbColumnName(){
				
					return "sourceProducts";
				
				}

				
			    public String sourceAnnouncement;

				public String getSourceAnnouncement () {
					return this.sourceAnnouncement;
				}

				public Boolean sourceAnnouncementIsNullable(){
				    return true;
				}
				public Boolean sourceAnnouncementIsKey(){
				    return false;
				}
				public Integer sourceAnnouncementLength(){
				    return 24;
				}
				public Integer sourceAnnouncementPrecision(){
				    return 0;
				}
				public String sourceAnnouncementDefault(){
				
					return null;
				
				}
				public String sourceAnnouncementComment(){
				
				    return "";
				
				}
				public String sourceAnnouncementPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAnnouncementOriginalDbColumnName(){
				
					return "sourceAnnouncement";
				
				}

				
			    public String sourceDate;

				public String getSourceDate () {
					return this.sourceDate;
				}

				public Boolean sourceDateIsNullable(){
				    return true;
				}
				public Boolean sourceDateIsKey(){
				    return false;
				}
				public Integer sourceDateLength(){
				    return null;
				}
				public Integer sourceDatePrecision(){
				    return 0;
				}
				public String sourceDateDefault(){
				
					return null;
				
				}
				public String sourceDateComment(){
				
				    return "";
				
				}
				public String sourceDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceDateOriginalDbColumnName(){
				
					return "sourceDate";
				
				}

				
			    public String sourceEndpoint;

				public String getSourceEndpoint () {
					return this.sourceEndpoint;
				}

				public Boolean sourceEndpointIsNullable(){
				    return true;
				}
				public Boolean sourceEndpointIsKey(){
				    return false;
				}
				public Integer sourceEndpointLength(){
				    return 24;
				}
				public Integer sourceEndpointPrecision(){
				    return 0;
				}
				public String sourceEndpointDefault(){
				
					return null;
				
				}
				public String sourceEndpointComment(){
				
				    return "";
				
				}
				public String sourceEndpointPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceEndpointOriginalDbColumnName(){
				
					return "sourceEndpoint";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return 8;
				}
				public Integer taskIdPrecision(){
				    return 0;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public String sourceType;

				public String getSourceType () {
					return this.sourceType;
				}

				public Boolean sourceTypeIsNullable(){
				    return true;
				}
				public Boolean sourceTypeIsKey(){
				    return false;
				}
				public Integer sourceTypeLength(){
				    return 8;
				}
				public Integer sourceTypePrecision(){
				    return 0;
				}
				public String sourceTypeDefault(){
				
					return null;
				
				}
				public String sourceTypeComment(){
				
				    return "";
				
				}
				public String sourceTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceTypeOriginalDbColumnName(){
				
					return "sourceType";
				
				}

				
			    public String sourceBy;

				public String getSourceBy () {
					return this.sourceBy;
				}

				public Boolean sourceByIsNullable(){
				    return true;
				}
				public Boolean sourceByIsKey(){
				    return false;
				}
				public Integer sourceByLength(){
				    return 24;
				}
				public Integer sourceByPrecision(){
				    return 0;
				}
				public String sourceByDefault(){
				
					return null;
				
				}
				public String sourceByComment(){
				
				    return "";
				
				}
				public String sourceByPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceByOriginalDbColumnName(){
				
					return "sourceBy";
				
				}

				
			    public String sourceCategory;

				public String getSourceCategory () {
					return this.sourceCategory;
				}

				public Boolean sourceCategoryIsNullable(){
				    return true;
				}
				public Boolean sourceCategoryIsKey(){
				    return false;
				}
				public Integer sourceCategoryLength(){
				    return 3;
				}
				public Integer sourceCategoryPrecision(){
				    return 0;
				}
				public String sourceCategoryDefault(){
				
					return null;
				
				}
				public String sourceCategoryComment(){
				
				    return "";
				
				}
				public String sourceCategoryPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCategoryOriginalDbColumnName(){
				
					return "sourceCategory";
				
				}

				
			    public String sourceClient;

				public String getSourceClient () {
					return this.sourceClient;
				}

				public Boolean sourceClientIsNullable(){
				    return true;
				}
				public Boolean sourceClientIsKey(){
				    return false;
				}
				public Integer sourceClientLength(){
				    return 11;
				}
				public Integer sourceClientPrecision(){
				    return 0;
				}
				public String sourceClientDefault(){
				
					return null;
				
				}
				public String sourceClientComment(){
				
				    return "";
				
				}
				public String sourceClientPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceClientOriginalDbColumnName(){
				
					return "sourceClient";
				
				}

				
			    public String createdBy_id;

				public String getCreatedBy_id () {
					return this.createdBy_id;
				}

				public Boolean createdBy_idIsNullable(){
				    return true;
				}
				public Boolean createdBy_idIsKey(){
				    return false;
				}
				public Integer createdBy_idLength(){
				    return 24;
				}
				public Integer createdBy_idPrecision(){
				    return 0;
				}
				public String createdBy_idDefault(){
				
					return null;
				
				}
				public String createdBy_idComment(){
				
				    return "";
				
				}
				public String createdBy_idPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createdBy_idOriginalDbColumnName(){
				
					return "createdBy_id";
				
				}

				
			    public String createdByFirstName;

				public String getCreatedByFirstName () {
					return this.createdByFirstName;
				}

				public Boolean createdByFirstNameIsNullable(){
				    return true;
				}
				public Boolean createdByFirstNameIsKey(){
				    return false;
				}
				public Integer createdByFirstNameLength(){
				    return 8;
				}
				public Integer createdByFirstNamePrecision(){
				    return 0;
				}
				public String createdByFirstNameDefault(){
				
					return null;
				
				}
				public String createdByFirstNameComment(){
				
				    return "";
				
				}
				public String createdByFirstNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createdByFirstNameOriginalDbColumnName(){
				
					return "createdByFirstName";
				
				}

				
			    public String createdByLastName;

				public String getCreatedByLastName () {
					return this.createdByLastName;
				}

				public Boolean createdByLastNameIsNullable(){
				    return true;
				}
				public Boolean createdByLastNameIsKey(){
				    return false;
				}
				public Integer createdByLastNameLength(){
				    return 15;
				}
				public Integer createdByLastNamePrecision(){
				    return 0;
				}
				public String createdByLastNameDefault(){
				
					return null;
				
				}
				public String createdByLastNameComment(){
				
				    return "";
				
				}
				public String createdByLastNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createdByLastNameOriginalDbColumnName(){
				
					return "createdByLastName";
				
				}

				
			    public String createdByExternalId;

				public String getCreatedByExternalId () {
					return this.createdByExternalId;
				}

				public Boolean createdByExternalIdIsNullable(){
				    return true;
				}
				public Boolean createdByExternalIdIsKey(){
				    return false;
				}
				public Integer createdByExternalIdLength(){
				    return 16;
				}
				public Integer createdByExternalIdPrecision(){
				    return 0;
				}
				public String createdByExternalIdDefault(){
				
					return null;
				
				}
				public String createdByExternalIdComment(){
				
				    return "";
				
				}
				public String createdByExternalIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createdByExternalIdOriginalDbColumnName(){
				
					return "createdByExternalId";
				
				}

				
			    public String createdById;

				public String getCreatedById () {
					return this.createdById;
				}

				public Boolean createdByIdIsNullable(){
				    return true;
				}
				public Boolean createdByIdIsKey(){
				    return false;
				}
				public Integer createdByIdLength(){
				    return 24;
				}
				public Integer createdByIdPrecision(){
				    return 0;
				}
				public String createdByIdDefault(){
				
					return null;
				
				}
				public String createdByIdComment(){
				
				    return "";
				
				}
				public String createdByIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createdByIdOriginalDbColumnName(){
				
					return "createdById";
				
				}

				
			    public Double dimensionsWeight;

				public Double getDimensionsWeight () {
					return this.dimensionsWeight;
				}

				public Boolean dimensionsWeightIsNullable(){
				    return true;
				}
				public Boolean dimensionsWeightIsKey(){
				    return false;
				}
				public Integer dimensionsWeightLength(){
				    return null;
				}
				public Integer dimensionsWeightPrecision(){
				    return 0;
				}
				public String dimensionsWeightDefault(){
				
					return null;
				
				}
				public String dimensionsWeightComment(){
				
				    return "";
				
				}
				public String dimensionsWeightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String dimensionsWeightOriginalDbColumnName(){
				
					return "dimensionsWeight";
				
				}

				
			    public Double dimensionsVolume;

				public Double getDimensionsVolume () {
					return this.dimensionsVolume;
				}

				public Boolean dimensionsVolumeIsNullable(){
				    return true;
				}
				public Boolean dimensionsVolumeIsKey(){
				    return false;
				}
				public Integer dimensionsVolumeLength(){
				    return null;
				}
				public Integer dimensionsVolumePrecision(){
				    return 3;
				}
				public String dimensionsVolumeDefault(){
				
					return null;
				
				}
				public String dimensionsVolumeComment(){
				
				    return "";
				
				}
				public String dimensionsVolumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String dimensionsVolumeOriginalDbColumnName(){
				
					return "dimensionsVolume";
				
				}

				
			    public String sourceFlux;

				public String getSourceFlux () {
					return this.sourceFlux;
				}

				public Boolean sourceFluxIsNullable(){
				    return true;
				}
				public Boolean sourceFluxIsKey(){
				    return false;
				}
				public Integer sourceFluxLength(){
				    return 24;
				}
				public Integer sourceFluxPrecision(){
				    return 0;
				}
				public String sourceFluxDefault(){
				
					return null;
				
				}
				public String sourceFluxComment(){
				
				    return "";
				
				}
				public String sourceFluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceFluxOriginalDbColumnName(){
				
					return "sourceFlux";
				
				}

				
			    public String sourceInstructions;

				public String getSourceInstructions () {
					return this.sourceInstructions;
				}

				public Boolean sourceInstructionsIsNullable(){
				    return true;
				}
				public Boolean sourceInstructionsIsKey(){
				    return false;
				}
				public Integer sourceInstructionsLength(){
				    return 0;
				}
				public Integer sourceInstructionsPrecision(){
				    return 0;
				}
				public String sourceInstructionsDefault(){
				
					return null;
				
				}
				public String sourceInstructionsComment(){
				
				    return "";
				
				}
				public String sourceInstructionsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceInstructionsOriginalDbColumnName(){
				
					return "sourceInstructions";
				
				}

				
			    public String sourcePlatform;

				public String getSourcePlatform () {
					return this.sourcePlatform;
				}

				public Boolean sourcePlatformIsNullable(){
				    return true;
				}
				public Boolean sourcePlatformIsKey(){
				    return false;
				}
				public Integer sourcePlatformLength(){
				    return 24;
				}
				public Integer sourcePlatformPrecision(){
				    return 0;
				}
				public String sourcePlatformDefault(){
				
					return null;
				
				}
				public String sourcePlatformComment(){
				
				    return "";
				
				}
				public String sourcePlatformPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourcePlatformOriginalDbColumnName(){
				
					return "sourcePlatform";
				
				}

				
			    public String sourcePlatformName;

				public String getSourcePlatformName () {
					return this.sourcePlatformName;
				}

				public Boolean sourcePlatformNameIsNullable(){
				    return true;
				}
				public Boolean sourcePlatformNameIsKey(){
				    return false;
				}
				public Integer sourcePlatformNameLength(){
				    return 10;
				}
				public Integer sourcePlatformNamePrecision(){
				    return 0;
				}
				public String sourcePlatformNameDefault(){
				
					return null;
				
				}
				public String sourcePlatformNameComment(){
				
				    return "";
				
				}
				public String sourcePlatformNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourcePlatformNameOriginalDbColumnName(){
				
					return "sourcePlatformName";
				
				}

				
			    public String sourceProgress;

				public String getSourceProgress () {
					return this.sourceProgress;
				}

				public Boolean sourceProgressIsNullable(){
				    return true;
				}
				public Boolean sourceProgressIsKey(){
				    return false;
				}
				public Integer sourceProgressLength(){
				    return 9;
				}
				public Integer sourceProgressPrecision(){
				    return 0;
				}
				public String sourceProgressDefault(){
				
					return null;
				
				}
				public String sourceProgressComment(){
				
				    return "";
				
				}
				public String sourceProgressPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceProgressOriginalDbColumnName(){
				
					return "sourceProgress";
				
				}

				
			    public String sourceRoundName;

				public String getSourceRoundName () {
					return this.sourceRoundName;
				}

				public Boolean sourceRoundNameIsNullable(){
				    return true;
				}
				public Boolean sourceRoundNameIsKey(){
				    return false;
				}
				public Integer sourceRoundNameLength(){
				    return 3;
				}
				public Integer sourceRoundNamePrecision(){
				    return 0;
				}
				public String sourceRoundNameDefault(){
				
					return null;
				
				}
				public String sourceRoundNameComment(){
				
				    return "";
				
				}
				public String sourceRoundNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceRoundNameOriginalDbColumnName(){
				
					return "sourceRoundName";
				
				}

				
			    public Double sourceSequence;

				public Double getSourceSequence () {
					return this.sourceSequence;
				}

				public Boolean sourceSequenceIsNullable(){
				    return true;
				}
				public Boolean sourceSequenceIsKey(){
				    return false;
				}
				public Integer sourceSequenceLength(){
				    return null;
				}
				public Integer sourceSequencePrecision(){
				    return 0;
				}
				public String sourceSequenceDefault(){
				
					return null;
				
				}
				public String sourceSequenceComment(){
				
				    return "";
				
				}
				public String sourceSequencePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceSequenceOriginalDbColumnName(){
				
					return "sourceSequence";
				
				}

				
			    public Double sourceServiceTime;

				public Double getSourceServiceTime () {
					return this.sourceServiceTime;
				}

				public Boolean sourceServiceTimeIsNullable(){
				    return true;
				}
				public Boolean sourceServiceTimeIsKey(){
				    return false;
				}
				public Integer sourceServiceTimeLength(){
				    return null;
				}
				public Integer sourceServiceTimePrecision(){
				    return 0;
				}
				public String sourceServiceTimeDefault(){
				
					return null;
				
				}
				public String sourceServiceTimeComment(){
				
				    return "";
				
				}
				public String sourceServiceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceServiceTimeOriginalDbColumnName(){
				
					return "sourceServiceTime";
				
				}

				
			    public String sourceTrackingId;

				public String getSourceTrackingId () {
					return this.sourceTrackingId;
				}

				public Boolean sourceTrackingIdIsNullable(){
				    return true;
				}
				public Boolean sourceTrackingIdIsKey(){
				    return false;
				}
				public Integer sourceTrackingIdLength(){
				    return 35;
				}
				public Integer sourceTrackingIdPrecision(){
				    return 0;
				}
				public String sourceTrackingIdDefault(){
				
					return null;
				
				}
				public String sourceTrackingIdComment(){
				
				    return "";
				
				}
				public String sourceTrackingIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceTrackingIdOriginalDbColumnName(){
				
					return "sourceTrackingId";
				
				}

				
			    public String sourceHub;

				public String getSourceHub () {
					return this.sourceHub;
				}

				public Boolean sourceHubIsNullable(){
				    return true;
				}
				public Boolean sourceHubIsKey(){
				    return false;
				}
				public Integer sourceHubLength(){
				    return 24;
				}
				public Integer sourceHubPrecision(){
				    return 0;
				}
				public String sourceHubDefault(){
				
					return null;
				
				}
				public String sourceHubComment(){
				
				    return "";
				
				}
				public String sourceHubPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceHubOriginalDbColumnName(){
				
					return "sourceHub";
				
				}

				
			    public String sourceHubName;

				public String getSourceHubName () {
					return this.sourceHubName;
				}

				public Boolean sourceHubNameIsNullable(){
				    return true;
				}
				public Boolean sourceHubNameIsKey(){
				    return false;
				}
				public Integer sourceHubNameLength(){
				    return 20;
				}
				public Integer sourceHubNamePrecision(){
				    return 0;
				}
				public String sourceHubNameDefault(){
				
					return null;
				
				}
				public String sourceHubNameComment(){
				
				    return "";
				
				}
				public String sourceHubNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceHubNameOriginalDbColumnName(){
				
					return "sourceHubName";
				
				}

				
			    public String sourceTargetFlux;

				public String getSourceTargetFlux () {
					return this.sourceTargetFlux;
				}

				public Boolean sourceTargetFluxIsNullable(){
				    return true;
				}
				public Boolean sourceTargetFluxIsKey(){
				    return false;
				}
				public Integer sourceTargetFluxLength(){
				    return 61;
				}
				public Integer sourceTargetFluxPrecision(){
				    return 0;
				}
				public String sourceTargetFluxDefault(){
				
					return null;
				
				}
				public String sourceTargetFluxComment(){
				
				    return "";
				
				}
				public String sourceTargetFluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceTargetFluxOriginalDbColumnName(){
				
					return "sourceTargetFlux";
				
				}

				
			    public String sourceZone;

				public String getSourceZone () {
					return this.sourceZone;
				}

				public Boolean sourceZoneIsNullable(){
				    return true;
				}
				public Boolean sourceZoneIsKey(){
				    return false;
				}
				public Integer sourceZoneLength(){
				    return 6;
				}
				public Integer sourceZonePrecision(){
				    return 0;
				}
				public String sourceZoneDefault(){
				
					return null;
				
				}
				public String sourceZoneComment(){
				
				    return "";
				
				}
				public String sourceZonePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceZoneOriginalDbColumnName(){
				
					return "sourceZone";
				
				}

				
			    public String sourceOrder;

				public String getSourceOrder () {
					return this.sourceOrder;
				}

				public Boolean sourceOrderIsNullable(){
				    return true;
				}
				public Boolean sourceOrderIsKey(){
				    return false;
				}
				public Integer sourceOrderLength(){
				    return 24;
				}
				public Integer sourceOrderPrecision(){
				    return 0;
				}
				public String sourceOrderDefault(){
				
					return null;
				
				}
				public String sourceOrderComment(){
				
				    return "";
				
				}
				public String sourceOrderPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceOrderOriginalDbColumnName(){
				
					return "sourceOrder";
				
				}

				
			    public String sourceArriveTime;

				public String getSourceArriveTime () {
					return this.sourceArriveTime;
				}

				public Boolean sourceArriveTimeIsNullable(){
				    return true;
				}
				public Boolean sourceArriveTimeIsKey(){
				    return false;
				}
				public Integer sourceArriveTimeLength(){
				    return null;
				}
				public Integer sourceArriveTimePrecision(){
				    return 0;
				}
				public String sourceArriveTimeDefault(){
				
					return null;
				
				}
				public String sourceArriveTimeComment(){
				
				    return "";
				
				}
				public String sourceArriveTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceArriveTimeOriginalDbColumnName(){
				
					return "sourceArriveTime";
				
				}

				
			    public String sourceAssociated;

				public String getSourceAssociated () {
					return this.sourceAssociated;
				}

				public Boolean sourceAssociatedIsNullable(){
				    return true;
				}
				public Boolean sourceAssociatedIsKey(){
				    return false;
				}
				public Integer sourceAssociatedLength(){
				    return 0;
				}
				public Integer sourceAssociatedPrecision(){
				    return 0;
				}
				public String sourceAssociatedDefault(){
				
					return null;
				
				}
				public String sourceAssociatedComment(){
				
				    return "";
				
				}
				public String sourceAssociatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAssociatedOriginalDbColumnName(){
				
					return "sourceAssociated";
				
				}

				
			    public String sourceAssociatedName;

				public String getSourceAssociatedName () {
					return this.sourceAssociatedName;
				}

				public Boolean sourceAssociatedNameIsNullable(){
				    return true;
				}
				public Boolean sourceAssociatedNameIsKey(){
				    return false;
				}
				public Integer sourceAssociatedNameLength(){
				    return 0;
				}
				public Integer sourceAssociatedNamePrecision(){
				    return 0;
				}
				public String sourceAssociatedNameDefault(){
				
					return null;
				
				}
				public String sourceAssociatedNameComment(){
				
				    return "";
				
				}
				public String sourceAssociatedNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceAssociatedNameOriginalDbColumnName(){
				
					return "sourceAssociatedName";
				
				}

				
			    public String driver_id;

				public String getDriver_id () {
					return this.driver_id;
				}

				public Boolean driver_idIsNullable(){
				    return true;
				}
				public Boolean driver_idIsKey(){
				    return false;
				}
				public Integer driver_idLength(){
				    return 24;
				}
				public Integer driver_idPrecision(){
				    return 0;
				}
				public String driver_idDefault(){
				
					return null;
				
				}
				public String driver_idComment(){
				
				    return "";
				
				}
				public String driver_idPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driver_idOriginalDbColumnName(){
				
					return "driver_id";
				
				}

				
			    public String driverFirstName;

				public String getDriverFirstName () {
					return this.driverFirstName;
				}

				public Boolean driverFirstNameIsNullable(){
				    return true;
				}
				public Boolean driverFirstNameIsKey(){
				    return false;
				}
				public Integer driverFirstNameLength(){
				    return 9;
				}
				public Integer driverFirstNamePrecision(){
				    return 0;
				}
				public String driverFirstNameDefault(){
				
					return null;
				
				}
				public String driverFirstNameComment(){
				
				    return "";
				
				}
				public String driverFirstNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverFirstNameOriginalDbColumnName(){
				
					return "driverFirstName";
				
				}

				
			    public String driverLastName;

				public String getDriverLastName () {
					return this.driverLastName;
				}

				public Boolean driverLastNameIsNullable(){
				    return true;
				}
				public Boolean driverLastNameIsKey(){
				    return false;
				}
				public Integer driverLastNameLength(){
				    return 6;
				}
				public Integer driverLastNamePrecision(){
				    return 0;
				}
				public String driverLastNameDefault(){
				
					return null;
				
				}
				public String driverLastNameComment(){
				
				    return "";
				
				}
				public String driverLastNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverLastNameOriginalDbColumnName(){
				
					return "driverLastName";
				
				}

				
			    public String driverExternalId;

				public String getDriverExternalId () {
					return this.driverExternalId;
				}

				public Boolean driverExternalIdIsNullable(){
				    return true;
				}
				public Boolean driverExternalIdIsKey(){
				    return false;
				}
				public Integer driverExternalIdLength(){
				    return 27;
				}
				public Integer driverExternalIdPrecision(){
				    return 0;
				}
				public String driverExternalIdDefault(){
				
					return null;
				
				}
				public String driverExternalIdComment(){
				
				    return "";
				
				}
				public String driverExternalIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverExternalIdOriginalDbColumnName(){
				
					return "driverExternalId";
				
				}

				
			    public String driverId;

				public String getDriverId () {
					return this.driverId;
				}

				public Boolean driverIdIsNullable(){
				    return true;
				}
				public Boolean driverIdIsKey(){
				    return false;
				}
				public Integer driverIdLength(){
				    return 24;
				}
				public Integer driverIdPrecision(){
				    return 0;
				}
				public String driverIdDefault(){
				
					return null;
				
				}
				public String driverIdComment(){
				
				    return "";
				
				}
				public String driverIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverIdOriginalDbColumnName(){
				
					return "driverId";
				
				}

				
			    public String sourceRound;

				public String getSourceRound () {
					return this.sourceRound;
				}

				public Boolean sourceRoundIsNullable(){
				    return true;
				}
				public Boolean sourceRoundIsKey(){
				    return false;
				}
				public Integer sourceRoundLength(){
				    return 24;
				}
				public Integer sourceRoundPrecision(){
				    return 0;
				}
				public String sourceRoundDefault(){
				
					return null;
				
				}
				public String sourceRoundComment(){
				
				    return "";
				
				}
				public String sourceRoundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceRoundOriginalDbColumnName(){
				
					return "sourceRound";
				
				}

				
			    public String sourceRoundColor;

				public String getSourceRoundColor () {
					return this.sourceRoundColor;
				}

				public Boolean sourceRoundColorIsNullable(){
				    return true;
				}
				public Boolean sourceRoundColorIsKey(){
				    return false;
				}
				public Integer sourceRoundColorLength(){
				    return 7;
				}
				public Integer sourceRoundColorPrecision(){
				    return 0;
				}
				public String sourceRoundColorDefault(){
				
					return null;
				
				}
				public String sourceRoundColorComment(){
				
				    return "";
				
				}
				public String sourceRoundColorPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceRoundColorOriginalDbColumnName(){
				
					return "sourceRoundColor";
				
				}

				
			    public String sourceCompletedBy;

				public String getSourceCompletedBy () {
					return this.sourceCompletedBy;
				}

				public Boolean sourceCompletedByIsNullable(){
				    return true;
				}
				public Boolean sourceCompletedByIsKey(){
				    return false;
				}
				public Integer sourceCompletedByLength(){
				    return 3;
				}
				public Integer sourceCompletedByPrecision(){
				    return 0;
				}
				public String sourceCompletedByDefault(){
				
					return null;
				
				}
				public String sourceCompletedByComment(){
				
				    return "";
				
				}
				public String sourceCompletedByPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceCompletedByOriginalDbColumnName(){
				
					return "sourceCompletedBy";
				
				}

				
			    public String sourceImagePath;

				public String getSourceImagePath () {
					return this.sourceImagePath;
				}

				public Boolean sourceImagePathIsNullable(){
				    return true;
				}
				public Boolean sourceImagePathIsKey(){
				    return false;
				}
				public Integer sourceImagePathLength(){
				    return 72;
				}
				public Integer sourceImagePathPrecision(){
				    return 0;
				}
				public String sourceImagePathDefault(){
				
					return null;
				
				}
				public String sourceImagePathComment(){
				
				    return "";
				
				}
				public String sourceImagePathPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceImagePathOriginalDbColumnName(){
				
					return "sourceImagePath";
				
				}

				
			    public Boolean sourceHasRejectedProducts;

				public Boolean getSourceHasRejectedProducts () {
					return this.sourceHasRejectedProducts;
				}

				public Boolean sourceHasRejectedProductsIsNullable(){
				    return true;
				}
				public Boolean sourceHasRejectedProductsIsKey(){
				    return false;
				}
				public Integer sourceHasRejectedProductsLength(){
				    return 5;
				}
				public Integer sourceHasRejectedProductsPrecision(){
				    return 0;
				}
				public String sourceHasRejectedProductsDefault(){
				
					return null;
				
				}
				public String sourceHasRejectedProductsComment(){
				
				    return "";
				
				}
				public String sourceHasRejectedProductsPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String sourceHasRejectedProductsOriginalDbColumnName(){
				
					return "sourceHasRejectedProducts";
				
				}

				
			    public String source_Id;

				public String getSource_Id () {
					return this.source_Id;
				}

				public Boolean source_IdIsNullable(){
				    return true;
				}
				public Boolean source_IdIsKey(){
				    return false;
				}
				public Integer source_IdLength(){
				    return 24;
				}
				public Integer source_IdPrecision(){
				    return 0;
				}
				public String source_IdDefault(){
				
					return null;
				
				}
				public String source_IdComment(){
				
				    return "";
				
				}
				public String source_IdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String source_IdOriginalDbColumnName(){
				
					return "source_Id";
				
				}

				
			    public String metadataVehicule;

				public String getMetadataVehicule () {
					return this.metadataVehicule;
				}

				public Boolean metadataVehiculeIsNullable(){
				    return true;
				}
				public Boolean metadataVehiculeIsKey(){
				    return false;
				}
				public Integer metadataVehiculeLength(){
				    return null;
				}
				public Integer metadataVehiculePrecision(){
				    return null;
				}
				public String metadataVehiculeDefault(){
				
					return null;
				
				}
				public String metadataVehiculeComment(){
				
				    return "";
				
				}
				public String metadataVehiculePattern(){
				
					return "";
				
				}
				public String metadataVehiculeOriginalDbColumnName(){
				
					return "metadataVehicule";
				
				}

				
			    public String metadataFACTURATION;

				public String getMetadataFACTURATION () {
					return this.metadataFACTURATION;
				}

				public Boolean metadataFACTURATIONIsNullable(){
				    return true;
				}
				public Boolean metadataFACTURATIONIsKey(){
				    return false;
				}
				public Integer metadataFACTURATIONLength(){
				    return null;
				}
				public Integer metadataFACTURATIONPrecision(){
				    return null;
				}
				public String metadataFACTURATIONDefault(){
				
					return null;
				
				}
				public String metadataFACTURATIONComment(){
				
				    return "";
				
				}
				public String metadataFACTURATIONPattern(){
				
					return "";
				
				}
				public String metadataFACTURATIONOriginalDbColumnName(){
				
					return "metadataFACTURATION";
				
				}

				
			    public String metadataRouteGrenoble;

				public String getMetadataRouteGrenoble () {
					return this.metadataRouteGrenoble;
				}

				public Boolean metadataRouteGrenobleIsNullable(){
				    return true;
				}
				public Boolean metadataRouteGrenobleIsKey(){
				    return false;
				}
				public Integer metadataRouteGrenobleLength(){
				    return null;
				}
				public Integer metadataRouteGrenoblePrecision(){
				    return null;
				}
				public String metadataRouteGrenobleDefault(){
				
					return null;
				
				}
				public String metadataRouteGrenobleComment(){
				
				    return "";
				
				}
				public String metadataRouteGrenoblePattern(){
				
					return "";
				
				}
				public String metadataRouteGrenobleOriginalDbColumnName(){
				
					return "metadataRouteGrenoble";
				
				}

				
			    public String delay;

				public String getDelay () {
					return this.delay;
				}

				public Boolean delayIsNullable(){
				    return true;
				}
				public Boolean delayIsKey(){
				    return false;
				}
				public Integer delayLength(){
				    return null;
				}
				public Integer delayPrecision(){
				    return null;
				}
				public String delayDefault(){
				
					return null;
				
				}
				public String delayComment(){
				
				    return "";
				
				}
				public String delayPattern(){
				
					return "";
				
				}
				public String delayOriginalDbColumnName(){
				
					return "delay";
				
				}

				
			    public String failedReason;

				public String getFailedReason () {
					return this.failedReason;
				}

				public Boolean failedReasonIsNullable(){
				    return true;
				}
				public Boolean failedReasonIsKey(){
				    return false;
				}
				public Integer failedReasonLength(){
				    return null;
				}
				public Integer failedReasonPrecision(){
				    return null;
				}
				public String failedReasonDefault(){
				
					return null;
				
				}
				public String failedReasonComment(){
				
				    return "";
				
				}
				public String failedReasonPattern(){
				
					return "";
				
				}
				public String failedReasonOriginalDbColumnName(){
				
					return "failedReason";
				
				}

				
			    public String failedReasonCustom;

				public String getFailedReasonCustom () {
					return this.failedReasonCustom;
				}

				public Boolean failedReasonCustomIsNullable(){
				    return true;
				}
				public Boolean failedReasonCustomIsKey(){
				    return false;
				}
				public Integer failedReasonCustomLength(){
				    return null;
				}
				public Integer failedReasonCustomPrecision(){
				    return null;
				}
				public String failedReasonCustomDefault(){
				
					return null;
				
				}
				public String failedReasonCustomComment(){
				
				    return "";
				
				}
				public String failedReasonCustomPattern(){
				
					return "";
				
				}
				public String failedReasonCustomOriginalDbColumnName(){
				
					return "failedReasonCustom";
				
				}

				
			    public String isExpress;

				public String getIsExpress () {
					return this.isExpress;
				}

				public Boolean isExpressIsNullable(){
				    return true;
				}
				public Boolean isExpressIsKey(){
				    return false;
				}
				public Integer isExpressLength(){
				    return null;
				}
				public Integer isExpressPrecision(){
				    return null;
				}
				public String isExpressDefault(){
				
					return null;
				
				}
				public String isExpressComment(){
				
				    return "";
				
				}
				public String isExpressPattern(){
				
					return "";
				
				}
				public String isExpressOriginalDbColumnName(){
				
					return "isExpress";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceLocationType = readString(dis);
					
					this.sourceLocationGeometry = readString(dis);
					
					this.sourceAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceGeocodeScore = null;
           				} else {
           			    	this.sourceGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCleanScore = null;
           				} else {
           			    	this.sourceCleanScore = dis.readDouble();
           				}
					
					this.sourceStreet = readString(dis);
					
					this.sourceCity = readString(dis);
					
						this.sourceZip = readInteger(dis);
					
					this.sourceCountry = readString(dis);
					
					this.sourceAddress = readString(dis);
					
					this.locationType = readString(dis);
					
					this.locationGeometry = readString(dis);
					
					this.locationAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationGeocodeScore = null;
           				} else {
           			    	this.locationGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationCleanScore = null;
           				} else {
           			    	this.locationCleanScore = dis.readDouble();
           				}
					
					this.locationStreet = readString(dis);
					
					this.locationAddress = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.locationCity = readString(dis);
					
					this.locationCountry = readString(dis);
					
					this.locationOrigin = readString(dis);
					
					this.contactBuildingInfo = readString(dis);
					
					this.contactPerson = readString(dis);
					
					this.contactPhone = readString(dis);
					
					this.contactEmail = readString(dis);
					
					this.timeWindowStart = readString(dis);
					
					this.timeWindowStop = readString(dis);
					
					this.sourceStatus = readString(dis);
					
					this.sourceActivity = readString(dis);
					
					this.sourceSkills = readString(dis);
					
					this.sourceLabels = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceAttempts = null;
           				} else {
           			    	this.sourceAttempts = dis.readDouble();
           				}
					
					this.sourceHasBeenPaid = readString(dis);
					
					this.sourceClosureDate = readString(dis);
					
					this.sourcePaymentType = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCollectedAmount = null;
           				} else {
           			    	this.sourceCollectedAmount = dis.readDouble();
           				}
					
					this.metadataTypePrestation = readString(dis);
					
					this.metadataCodeArticle = readString(dis);
					
					this.sourceIssues = readString(dis);
					
					this.sourceWhen = readString(dis);
					
					this.sourceUpdated = readString(dis);
					
					this.sourceItems = readString(dis);
					
					this.sourceProducts = readString(dis);
					
					this.sourceAnnouncement = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.sourceEndpoint = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceBy = readString(dis);
					
					this.sourceCategory = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.createdBy_id = readString(dis);
					
					this.createdByFirstName = readString(dis);
					
					this.createdByLastName = readString(dis);
					
					this.createdByExternalId = readString(dis);
					
					this.createdById = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsWeight = null;
           				} else {
           			    	this.dimensionsWeight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsVolume = null;
           				} else {
           			    	this.dimensionsVolume = dis.readDouble();
           				}
					
					this.sourceFlux = readString(dis);
					
					this.sourceInstructions = readString(dis);
					
					this.sourcePlatform = readString(dis);
					
					this.sourcePlatformName = readString(dis);
					
					this.sourceProgress = readString(dis);
					
					this.sourceRoundName = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceSequence = null;
           				} else {
           			    	this.sourceSequence = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceServiceTime = null;
           				} else {
           			    	this.sourceServiceTime = dis.readDouble();
           				}
					
					this.sourceTrackingId = readString(dis);
					
					this.sourceHub = readString(dis);
					
					this.sourceHubName = readString(dis);
					
					this.sourceTargetFlux = readString(dis);
					
					this.sourceZone = readString(dis);
					
					this.sourceOrder = readString(dis);
					
					this.sourceArriveTime = readString(dis);
					
					this.sourceAssociated = readString(dis);
					
					this.sourceAssociatedName = readString(dis);
					
					this.driver_id = readString(dis);
					
					this.driverFirstName = readString(dis);
					
					this.driverLastName = readString(dis);
					
					this.driverExternalId = readString(dis);
					
					this.driverId = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.sourceRoundColor = readString(dis);
					
					this.sourceCompletedBy = readString(dis);
					
					this.sourceImagePath = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceHasRejectedProducts = null;
           				} else {
           			    	this.sourceHasRejectedProducts = dis.readBoolean();
           				}
					
					this.source_Id = readString(dis);
					
					this.metadataVehicule = readString(dis);
					
					this.metadataFACTURATION = readString(dis);
					
					this.metadataRouteGrenoble = readString(dis);
					
					this.delay = readString(dis);
					
					this.failedReason = readString(dis);
					
					this.failedReasonCustom = readString(dis);
					
					this.isExpress = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.sourceId = readString(dis);
					
					this.sourceLocationType = readString(dis);
					
					this.sourceLocationGeometry = readString(dis);
					
					this.sourceAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceGeocodeScore = null;
           				} else {
           			    	this.sourceGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCleanScore = null;
           				} else {
           			    	this.sourceCleanScore = dis.readDouble();
           				}
					
					this.sourceStreet = readString(dis);
					
					this.sourceCity = readString(dis);
					
						this.sourceZip = readInteger(dis);
					
					this.sourceCountry = readString(dis);
					
					this.sourceAddress = readString(dis);
					
					this.locationType = readString(dis);
					
					this.locationGeometry = readString(dis);
					
					this.locationAddressLines = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationGeocodeScore = null;
           				} else {
           			    	this.locationGeocodeScore = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.locationCleanScore = null;
           				} else {
           			    	this.locationCleanScore = dis.readDouble();
           				}
					
					this.locationStreet = readString(dis);
					
					this.locationAddress = readString(dis);
					
						this.locationZip = readInteger(dis);
					
					this.locationCity = readString(dis);
					
					this.locationCountry = readString(dis);
					
					this.locationOrigin = readString(dis);
					
					this.contactBuildingInfo = readString(dis);
					
					this.contactPerson = readString(dis);
					
					this.contactPhone = readString(dis);
					
					this.contactEmail = readString(dis);
					
					this.timeWindowStart = readString(dis);
					
					this.timeWindowStop = readString(dis);
					
					this.sourceStatus = readString(dis);
					
					this.sourceActivity = readString(dis);
					
					this.sourceSkills = readString(dis);
					
					this.sourceLabels = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceAttempts = null;
           				} else {
           			    	this.sourceAttempts = dis.readDouble();
           				}
					
					this.sourceHasBeenPaid = readString(dis);
					
					this.sourceClosureDate = readString(dis);
					
					this.sourcePaymentType = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceCollectedAmount = null;
           				} else {
           			    	this.sourceCollectedAmount = dis.readDouble();
           				}
					
					this.metadataTypePrestation = readString(dis);
					
					this.metadataCodeArticle = readString(dis);
					
					this.sourceIssues = readString(dis);
					
					this.sourceWhen = readString(dis);
					
					this.sourceUpdated = readString(dis);
					
					this.sourceItems = readString(dis);
					
					this.sourceProducts = readString(dis);
					
					this.sourceAnnouncement = readString(dis);
					
					this.sourceDate = readString(dis);
					
					this.sourceEndpoint = readString(dis);
					
					this.taskId = readString(dis);
					
					this.sourceType = readString(dis);
					
					this.sourceBy = readString(dis);
					
					this.sourceCategory = readString(dis);
					
					this.sourceClient = readString(dis);
					
					this.createdBy_id = readString(dis);
					
					this.createdByFirstName = readString(dis);
					
					this.createdByLastName = readString(dis);
					
					this.createdByExternalId = readString(dis);
					
					this.createdById = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsWeight = null;
           				} else {
           			    	this.dimensionsWeight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.dimensionsVolume = null;
           				} else {
           			    	this.dimensionsVolume = dis.readDouble();
           				}
					
					this.sourceFlux = readString(dis);
					
					this.sourceInstructions = readString(dis);
					
					this.sourcePlatform = readString(dis);
					
					this.sourcePlatformName = readString(dis);
					
					this.sourceProgress = readString(dis);
					
					this.sourceRoundName = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceSequence = null;
           				} else {
           			    	this.sourceSequence = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceServiceTime = null;
           				} else {
           			    	this.sourceServiceTime = dis.readDouble();
           				}
					
					this.sourceTrackingId = readString(dis);
					
					this.sourceHub = readString(dis);
					
					this.sourceHubName = readString(dis);
					
					this.sourceTargetFlux = readString(dis);
					
					this.sourceZone = readString(dis);
					
					this.sourceOrder = readString(dis);
					
					this.sourceArriveTime = readString(dis);
					
					this.sourceAssociated = readString(dis);
					
					this.sourceAssociatedName = readString(dis);
					
					this.driver_id = readString(dis);
					
					this.driverFirstName = readString(dis);
					
					this.driverLastName = readString(dis);
					
					this.driverExternalId = readString(dis);
					
					this.driverId = readString(dis);
					
					this.sourceRound = readString(dis);
					
					this.sourceRoundColor = readString(dis);
					
					this.sourceCompletedBy = readString(dis);
					
					this.sourceImagePath = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sourceHasRejectedProducts = null;
           				} else {
           			    	this.sourceHasRejectedProducts = dis.readBoolean();
           				}
					
					this.source_Id = readString(dis);
					
					this.metadataVehicule = readString(dis);
					
					this.metadataFACTURATION = readString(dis);
					
					this.metadataRouteGrenoble = readString(dis);
					
					this.delay = readString(dis);
					
					this.failedReason = readString(dis);
					
					this.failedReasonCustom = readString(dis);
					
					this.isExpress = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceLocationType,dos);
					
					// String
				
						writeString(this.sourceLocationGeometry,dos);
					
					// String
				
						writeString(this.sourceAddressLines,dos);
					
					// Double
				
						if(this.sourceGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceGeocodeScore);
		            	}
					
					// Double
				
						if(this.sourceCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCleanScore);
		            	}
					
					// String
				
						writeString(this.sourceStreet,dos);
					
					// String
				
						writeString(this.sourceCity,dos);
					
					// Integer
				
						writeInteger(this.sourceZip,dos);
					
					// String
				
						writeString(this.sourceCountry,dos);
					
					// String
				
						writeString(this.sourceAddress,dos);
					
					// String
				
						writeString(this.locationType,dos);
					
					// String
				
						writeString(this.locationGeometry,dos);
					
					// String
				
						writeString(this.locationAddressLines,dos);
					
					// Double
				
						if(this.locationGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationGeocodeScore);
		            	}
					
					// Double
				
						if(this.locationCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationCleanScore);
		            	}
					
					// String
				
						writeString(this.locationStreet,dos);
					
					// String
				
						writeString(this.locationAddress,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.locationCity,dos);
					
					// String
				
						writeString(this.locationCountry,dos);
					
					// String
				
						writeString(this.locationOrigin,dos);
					
					// String
				
						writeString(this.contactBuildingInfo,dos);
					
					// String
				
						writeString(this.contactPerson,dos);
					
					// String
				
						writeString(this.contactPhone,dos);
					
					// String
				
						writeString(this.contactEmail,dos);
					
					// String
				
						writeString(this.timeWindowStart,dos);
					
					// String
				
						writeString(this.timeWindowStop,dos);
					
					// String
				
						writeString(this.sourceStatus,dos);
					
					// String
				
						writeString(this.sourceActivity,dos);
					
					// String
				
						writeString(this.sourceSkills,dos);
					
					// String
				
						writeString(this.sourceLabels,dos);
					
					// Double
				
						if(this.sourceAttempts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceAttempts);
		            	}
					
					// String
				
						writeString(this.sourceHasBeenPaid,dos);
					
					// String
				
						writeString(this.sourceClosureDate,dos);
					
					// String
				
						writeString(this.sourcePaymentType,dos);
					
					// Double
				
						if(this.sourceCollectedAmount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCollectedAmount);
		            	}
					
					// String
				
						writeString(this.metadataTypePrestation,dos);
					
					// String
				
						writeString(this.metadataCodeArticle,dos);
					
					// String
				
						writeString(this.sourceIssues,dos);
					
					// String
				
						writeString(this.sourceWhen,dos);
					
					// String
				
						writeString(this.sourceUpdated,dos);
					
					// String
				
						writeString(this.sourceItems,dos);
					
					// String
				
						writeString(this.sourceProducts,dos);
					
					// String
				
						writeString(this.sourceAnnouncement,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.sourceEndpoint,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceBy,dos);
					
					// String
				
						writeString(this.sourceCategory,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.createdBy_id,dos);
					
					// String
				
						writeString(this.createdByFirstName,dos);
					
					// String
				
						writeString(this.createdByLastName,dos);
					
					// String
				
						writeString(this.createdByExternalId,dos);
					
					// String
				
						writeString(this.createdById,dos);
					
					// Double
				
						if(this.dimensionsWeight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsWeight);
		            	}
					
					// Double
				
						if(this.dimensionsVolume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsVolume);
		            	}
					
					// String
				
						writeString(this.sourceFlux,dos);
					
					// String
				
						writeString(this.sourceInstructions,dos);
					
					// String
				
						writeString(this.sourcePlatform,dos);
					
					// String
				
						writeString(this.sourcePlatformName,dos);
					
					// String
				
						writeString(this.sourceProgress,dos);
					
					// String
				
						writeString(this.sourceRoundName,dos);
					
					// Double
				
						if(this.sourceSequence == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceSequence);
		            	}
					
					// Double
				
						if(this.sourceServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceServiceTime);
		            	}
					
					// String
				
						writeString(this.sourceTrackingId,dos);
					
					// String
				
						writeString(this.sourceHub,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.sourceTargetFlux,dos);
					
					// String
				
						writeString(this.sourceZone,dos);
					
					// String
				
						writeString(this.sourceOrder,dos);
					
					// String
				
						writeString(this.sourceArriveTime,dos);
					
					// String
				
						writeString(this.sourceAssociated,dos);
					
					// String
				
						writeString(this.sourceAssociatedName,dos);
					
					// String
				
						writeString(this.driver_id,dos);
					
					// String
				
						writeString(this.driverFirstName,dos);
					
					// String
				
						writeString(this.driverLastName,dos);
					
					// String
				
						writeString(this.driverExternalId,dos);
					
					// String
				
						writeString(this.driverId,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.sourceRoundColor,dos);
					
					// String
				
						writeString(this.sourceCompletedBy,dos);
					
					// String
				
						writeString(this.sourceImagePath,dos);
					
					// Boolean
				
						if(this.sourceHasRejectedProducts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.sourceHasRejectedProducts);
		            	}
					
					// String
				
						writeString(this.source_Id,dos);
					
					// String
				
						writeString(this.metadataVehicule,dos);
					
					// String
				
						writeString(this.metadataFACTURATION,dos);
					
					// String
				
						writeString(this.metadataRouteGrenoble,dos);
					
					// String
				
						writeString(this.delay,dos);
					
					// String
				
						writeString(this.failedReason,dos);
					
					// String
				
						writeString(this.failedReasonCustom,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.sourceId,dos);
					
					// String
				
						writeString(this.sourceLocationType,dos);
					
					// String
				
						writeString(this.sourceLocationGeometry,dos);
					
					// String
				
						writeString(this.sourceAddressLines,dos);
					
					// Double
				
						if(this.sourceGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceGeocodeScore);
		            	}
					
					// Double
				
						if(this.sourceCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCleanScore);
		            	}
					
					// String
				
						writeString(this.sourceStreet,dos);
					
					// String
				
						writeString(this.sourceCity,dos);
					
					// Integer
				
						writeInteger(this.sourceZip,dos);
					
					// String
				
						writeString(this.sourceCountry,dos);
					
					// String
				
						writeString(this.sourceAddress,dos);
					
					// String
				
						writeString(this.locationType,dos);
					
					// String
				
						writeString(this.locationGeometry,dos);
					
					// String
				
						writeString(this.locationAddressLines,dos);
					
					// Double
				
						if(this.locationGeocodeScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationGeocodeScore);
		            	}
					
					// Double
				
						if(this.locationCleanScore == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.locationCleanScore);
		            	}
					
					// String
				
						writeString(this.locationStreet,dos);
					
					// String
				
						writeString(this.locationAddress,dos);
					
					// Integer
				
						writeInteger(this.locationZip,dos);
					
					// String
				
						writeString(this.locationCity,dos);
					
					// String
				
						writeString(this.locationCountry,dos);
					
					// String
				
						writeString(this.locationOrigin,dos);
					
					// String
				
						writeString(this.contactBuildingInfo,dos);
					
					// String
				
						writeString(this.contactPerson,dos);
					
					// String
				
						writeString(this.contactPhone,dos);
					
					// String
				
						writeString(this.contactEmail,dos);
					
					// String
				
						writeString(this.timeWindowStart,dos);
					
					// String
				
						writeString(this.timeWindowStop,dos);
					
					// String
				
						writeString(this.sourceStatus,dos);
					
					// String
				
						writeString(this.sourceActivity,dos);
					
					// String
				
						writeString(this.sourceSkills,dos);
					
					// String
				
						writeString(this.sourceLabels,dos);
					
					// Double
				
						if(this.sourceAttempts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceAttempts);
		            	}
					
					// String
				
						writeString(this.sourceHasBeenPaid,dos);
					
					// String
				
						writeString(this.sourceClosureDate,dos);
					
					// String
				
						writeString(this.sourcePaymentType,dos);
					
					// Double
				
						if(this.sourceCollectedAmount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceCollectedAmount);
		            	}
					
					// String
				
						writeString(this.metadataTypePrestation,dos);
					
					// String
				
						writeString(this.metadataCodeArticle,dos);
					
					// String
				
						writeString(this.sourceIssues,dos);
					
					// String
				
						writeString(this.sourceWhen,dos);
					
					// String
				
						writeString(this.sourceUpdated,dos);
					
					// String
				
						writeString(this.sourceItems,dos);
					
					// String
				
						writeString(this.sourceProducts,dos);
					
					// String
				
						writeString(this.sourceAnnouncement,dos);
					
					// String
				
						writeString(this.sourceDate,dos);
					
					// String
				
						writeString(this.sourceEndpoint,dos);
					
					// String
				
						writeString(this.taskId,dos);
					
					// String
				
						writeString(this.sourceType,dos);
					
					// String
				
						writeString(this.sourceBy,dos);
					
					// String
				
						writeString(this.sourceCategory,dos);
					
					// String
				
						writeString(this.sourceClient,dos);
					
					// String
				
						writeString(this.createdBy_id,dos);
					
					// String
				
						writeString(this.createdByFirstName,dos);
					
					// String
				
						writeString(this.createdByLastName,dos);
					
					// String
				
						writeString(this.createdByExternalId,dos);
					
					// String
				
						writeString(this.createdById,dos);
					
					// Double
				
						if(this.dimensionsWeight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsWeight);
		            	}
					
					// Double
				
						if(this.dimensionsVolume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.dimensionsVolume);
		            	}
					
					// String
				
						writeString(this.sourceFlux,dos);
					
					// String
				
						writeString(this.sourceInstructions,dos);
					
					// String
				
						writeString(this.sourcePlatform,dos);
					
					// String
				
						writeString(this.sourcePlatformName,dos);
					
					// String
				
						writeString(this.sourceProgress,dos);
					
					// String
				
						writeString(this.sourceRoundName,dos);
					
					// Double
				
						if(this.sourceSequence == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceSequence);
		            	}
					
					// Double
				
						if(this.sourceServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sourceServiceTime);
		            	}
					
					// String
				
						writeString(this.sourceTrackingId,dos);
					
					// String
				
						writeString(this.sourceHub,dos);
					
					// String
				
						writeString(this.sourceHubName,dos);
					
					// String
				
						writeString(this.sourceTargetFlux,dos);
					
					// String
				
						writeString(this.sourceZone,dos);
					
					// String
				
						writeString(this.sourceOrder,dos);
					
					// String
				
						writeString(this.sourceArriveTime,dos);
					
					// String
				
						writeString(this.sourceAssociated,dos);
					
					// String
				
						writeString(this.sourceAssociatedName,dos);
					
					// String
				
						writeString(this.driver_id,dos);
					
					// String
				
						writeString(this.driverFirstName,dos);
					
					// String
				
						writeString(this.driverLastName,dos);
					
					// String
				
						writeString(this.driverExternalId,dos);
					
					// String
				
						writeString(this.driverId,dos);
					
					// String
				
						writeString(this.sourceRound,dos);
					
					// String
				
						writeString(this.sourceRoundColor,dos);
					
					// String
				
						writeString(this.sourceCompletedBy,dos);
					
					// String
				
						writeString(this.sourceImagePath,dos);
					
					// Boolean
				
						if(this.sourceHasRejectedProducts == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.sourceHasRejectedProducts);
		            	}
					
					// String
				
						writeString(this.source_Id,dos);
					
					// String
				
						writeString(this.metadataVehicule,dos);
					
					// String
				
						writeString(this.metadataFACTURATION,dos);
					
					// String
				
						writeString(this.metadataRouteGrenoble,dos);
					
					// String
				
						writeString(this.delay,dos);
					
					// String
				
						writeString(this.failedReason,dos);
					
					// String
				
						writeString(this.failedReasonCustom,dos);
					
					// String
				
						writeString(this.isExpress,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("sourceId="+sourceId);
		sb.append(",sourceLocationType="+sourceLocationType);
		sb.append(",sourceLocationGeometry="+sourceLocationGeometry);
		sb.append(",sourceAddressLines="+sourceAddressLines);
		sb.append(",sourceGeocodeScore="+String.valueOf(sourceGeocodeScore));
		sb.append(",sourceCleanScore="+String.valueOf(sourceCleanScore));
		sb.append(",sourceStreet="+sourceStreet);
		sb.append(",sourceCity="+sourceCity);
		sb.append(",sourceZip="+String.valueOf(sourceZip));
		sb.append(",sourceCountry="+sourceCountry);
		sb.append(",sourceAddress="+sourceAddress);
		sb.append(",locationType="+locationType);
		sb.append(",locationGeometry="+locationGeometry);
		sb.append(",locationAddressLines="+locationAddressLines);
		sb.append(",locationGeocodeScore="+String.valueOf(locationGeocodeScore));
		sb.append(",locationCleanScore="+String.valueOf(locationCleanScore));
		sb.append(",locationStreet="+locationStreet);
		sb.append(",locationAddress="+locationAddress);
		sb.append(",locationZip="+String.valueOf(locationZip));
		sb.append(",locationCity="+locationCity);
		sb.append(",locationCountry="+locationCountry);
		sb.append(",locationOrigin="+locationOrigin);
		sb.append(",contactBuildingInfo="+contactBuildingInfo);
		sb.append(",contactPerson="+contactPerson);
		sb.append(",contactPhone="+contactPhone);
		sb.append(",contactEmail="+contactEmail);
		sb.append(",timeWindowStart="+timeWindowStart);
		sb.append(",timeWindowStop="+timeWindowStop);
		sb.append(",sourceStatus="+sourceStatus);
		sb.append(",sourceActivity="+sourceActivity);
		sb.append(",sourceSkills="+sourceSkills);
		sb.append(",sourceLabels="+sourceLabels);
		sb.append(",sourceAttempts="+String.valueOf(sourceAttempts));
		sb.append(",sourceHasBeenPaid="+sourceHasBeenPaid);
		sb.append(",sourceClosureDate="+sourceClosureDate);
		sb.append(",sourcePaymentType="+sourcePaymentType);
		sb.append(",sourceCollectedAmount="+String.valueOf(sourceCollectedAmount));
		sb.append(",metadataTypePrestation="+metadataTypePrestation);
		sb.append(",metadataCodeArticle="+metadataCodeArticle);
		sb.append(",sourceIssues="+sourceIssues);
		sb.append(",sourceWhen="+sourceWhen);
		sb.append(",sourceUpdated="+sourceUpdated);
		sb.append(",sourceItems="+sourceItems);
		sb.append(",sourceProducts="+sourceProducts);
		sb.append(",sourceAnnouncement="+sourceAnnouncement);
		sb.append(",sourceDate="+sourceDate);
		sb.append(",sourceEndpoint="+sourceEndpoint);
		sb.append(",taskId="+taskId);
		sb.append(",sourceType="+sourceType);
		sb.append(",sourceBy="+sourceBy);
		sb.append(",sourceCategory="+sourceCategory);
		sb.append(",sourceClient="+sourceClient);
		sb.append(",createdBy_id="+createdBy_id);
		sb.append(",createdByFirstName="+createdByFirstName);
		sb.append(",createdByLastName="+createdByLastName);
		sb.append(",createdByExternalId="+createdByExternalId);
		sb.append(",createdById="+createdById);
		sb.append(",dimensionsWeight="+String.valueOf(dimensionsWeight));
		sb.append(",dimensionsVolume="+String.valueOf(dimensionsVolume));
		sb.append(",sourceFlux="+sourceFlux);
		sb.append(",sourceInstructions="+sourceInstructions);
		sb.append(",sourcePlatform="+sourcePlatform);
		sb.append(",sourcePlatformName="+sourcePlatformName);
		sb.append(",sourceProgress="+sourceProgress);
		sb.append(",sourceRoundName="+sourceRoundName);
		sb.append(",sourceSequence="+String.valueOf(sourceSequence));
		sb.append(",sourceServiceTime="+String.valueOf(sourceServiceTime));
		sb.append(",sourceTrackingId="+sourceTrackingId);
		sb.append(",sourceHub="+sourceHub);
		sb.append(",sourceHubName="+sourceHubName);
		sb.append(",sourceTargetFlux="+sourceTargetFlux);
		sb.append(",sourceZone="+sourceZone);
		sb.append(",sourceOrder="+sourceOrder);
		sb.append(",sourceArriveTime="+sourceArriveTime);
		sb.append(",sourceAssociated="+sourceAssociated);
		sb.append(",sourceAssociatedName="+sourceAssociatedName);
		sb.append(",driver_id="+driver_id);
		sb.append(",driverFirstName="+driverFirstName);
		sb.append(",driverLastName="+driverLastName);
		sb.append(",driverExternalId="+driverExternalId);
		sb.append(",driverId="+driverId);
		sb.append(",sourceRound="+sourceRound);
		sb.append(",sourceRoundColor="+sourceRoundColor);
		sb.append(",sourceCompletedBy="+sourceCompletedBy);
		sb.append(",sourceImagePath="+sourceImagePath);
		sb.append(",sourceHasRejectedProducts="+String.valueOf(sourceHasRejectedProducts));
		sb.append(",source_Id="+source_Id);
		sb.append(",metadataVehicule="+metadataVehicule);
		sb.append(",metadataFACTURATION="+metadataFACTURATION);
		sb.append(",metadataRouteGrenoble="+metadataRouteGrenoble);
		sb.append(",delay="+delay);
		sb.append(",failedReason="+failedReason);
		sb.append(",failedReasonCustom="+failedReasonCustom);
		sb.append(",isExpress="+isExpress);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(sourceId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLocationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLocationType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLocationGeometry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLocationGeometry);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAddressLines == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAddressLines);
            			}
            		
        			sb.append("|");
        		
        				if(sourceGeocodeScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceGeocodeScore);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCleanScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCleanScore);
            			}
            		
        			sb.append("|");
        		
        				if(sourceStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceStreet);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCity);
            			}
            		
        			sb.append("|");
        		
        				if(sourceZip == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceZip);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCountry);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAddress);
            			}
            		
        			sb.append("|");
        		
        				if(locationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationType);
            			}
            		
        			sb.append("|");
        		
        				if(locationGeometry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationGeometry);
            			}
            		
        			sb.append("|");
        		
        				if(locationAddressLines == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationAddressLines);
            			}
            		
        			sb.append("|");
        		
        				if(locationGeocodeScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationGeocodeScore);
            			}
            		
        			sb.append("|");
        		
        				if(locationCleanScore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCleanScore);
            			}
            		
        			sb.append("|");
        		
        				if(locationStreet == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationStreet);
            			}
            		
        			sb.append("|");
        		
        				if(locationAddress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationAddress);
            			}
            		
        			sb.append("|");
        		
        				if(locationZip == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationZip);
            			}
            		
        			sb.append("|");
        		
        				if(locationCity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCity);
            			}
            		
        			sb.append("|");
        		
        				if(locationCountry == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationCountry);
            			}
            		
        			sb.append("|");
        		
        				if(locationOrigin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationOrigin);
            			}
            		
        			sb.append("|");
        		
        				if(contactBuildingInfo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactBuildingInfo);
            			}
            		
        			sb.append("|");
        		
        				if(contactPerson == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactPerson);
            			}
            		
        			sb.append("|");
        		
        				if(contactPhone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactPhone);
            			}
            		
        			sb.append("|");
        		
        				if(contactEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(contactEmail);
            			}
            		
        			sb.append("|");
        		
        				if(timeWindowStart == null){
        					sb.append("<null>");
        				}else{
            				sb.append(timeWindowStart);
            			}
            		
        			sb.append("|");
        		
        				if(timeWindowStop == null){
        					sb.append("<null>");
        				}else{
            				sb.append(timeWindowStop);
            			}
            		
        			sb.append("|");
        		
        				if(sourceStatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceStatus);
            			}
            		
        			sb.append("|");
        		
        				if(sourceActivity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceActivity);
            			}
            		
        			sb.append("|");
        		
        				if(sourceSkills == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceSkills);
            			}
            		
        			sb.append("|");
        		
        				if(sourceLabels == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceLabels);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAttempts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAttempts);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHasBeenPaid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHasBeenPaid);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClosureDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClosureDate);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePaymentType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePaymentType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCollectedAmount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCollectedAmount);
            			}
            		
        			sb.append("|");
        		
        				if(metadataTypePrestation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataTypePrestation);
            			}
            		
        			sb.append("|");
        		
        				if(metadataCodeArticle == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataCodeArticle);
            			}
            		
        			sb.append("|");
        		
        				if(sourceIssues == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceIssues);
            			}
            		
        			sb.append("|");
        		
        				if(sourceWhen == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceWhen);
            			}
            		
        			sb.append("|");
        		
        				if(sourceUpdated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceUpdated);
            			}
            		
        			sb.append("|");
        		
        				if(sourceItems == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceItems);
            			}
            		
        			sb.append("|");
        		
        				if(sourceProducts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceProducts);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAnnouncement == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAnnouncement);
            			}
            		
        			sb.append("|");
        		
        				if(sourceDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceDate);
            			}
            		
        			sb.append("|");
        		
        				if(sourceEndpoint == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceEndpoint);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceType);
            			}
            		
        			sb.append("|");
        		
        				if(sourceBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceBy);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCategory == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCategory);
            			}
            		
        			sb.append("|");
        		
        				if(sourceClient == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceClient);
            			}
            		
        			sb.append("|");
        		
        				if(createdBy_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdBy_id);
            			}
            		
        			sb.append("|");
        		
        				if(createdByFirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByFirstName);
            			}
            		
        			sb.append("|");
        		
        				if(createdByLastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByLastName);
            			}
            		
        			sb.append("|");
        		
        				if(createdByExternalId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdByExternalId);
            			}
            		
        			sb.append("|");
        		
        				if(createdById == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createdById);
            			}
            		
        			sb.append("|");
        		
        				if(dimensionsWeight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dimensionsWeight);
            			}
            		
        			sb.append("|");
        		
        				if(dimensionsVolume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dimensionsVolume);
            			}
            		
        			sb.append("|");
        		
        				if(sourceFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceFlux);
            			}
            		
        			sb.append("|");
        		
        				if(sourceInstructions == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceInstructions);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePlatform == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePlatform);
            			}
            		
        			sb.append("|");
        		
        				if(sourcePlatformName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourcePlatformName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceProgress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceProgress);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRoundName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceSequence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceSequence);
            			}
            		
        			sb.append("|");
        		
        				if(sourceServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(sourceTrackingId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceTrackingId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHub == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHub);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHubName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHubName);
            			}
            		
        			sb.append("|");
        		
        				if(sourceTargetFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceTargetFlux);
            			}
            		
        			sb.append("|");
        		
        				if(sourceZone == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceZone);
            			}
            		
        			sb.append("|");
        		
        				if(sourceOrder == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceOrder);
            			}
            		
        			sb.append("|");
        		
        				if(sourceArriveTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceArriveTime);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAssociated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAssociated);
            			}
            		
        			sb.append("|");
        		
        				if(sourceAssociatedName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceAssociatedName);
            			}
            		
        			sb.append("|");
        		
        				if(driver_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driver_id);
            			}
            		
        			sb.append("|");
        		
        				if(driverFirstName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverFirstName);
            			}
            		
        			sb.append("|");
        		
        				if(driverLastName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverLastName);
            			}
            		
        			sb.append("|");
        		
        				if(driverExternalId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverExternalId);
            			}
            		
        			sb.append("|");
        		
        				if(driverId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driverId);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRound == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRound);
            			}
            		
        			sb.append("|");
        		
        				if(sourceRoundColor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceRoundColor);
            			}
            		
        			sb.append("|");
        		
        				if(sourceCompletedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceCompletedBy);
            			}
            		
        			sb.append("|");
        		
        				if(sourceImagePath == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceImagePath);
            			}
            		
        			sb.append("|");
        		
        				if(sourceHasRejectedProducts == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sourceHasRejectedProducts);
            			}
            		
        			sb.append("|");
        		
        				if(source_Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_Id);
            			}
            		
        			sb.append("|");
        		
        				if(metadataVehicule == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataVehicule);
            			}
            		
        			sb.append("|");
        		
        				if(metadataFACTURATION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataFACTURATION);
            			}
            		
        			sb.append("|");
        		
        				if(metadataRouteGrenoble == null){
        					sb.append("<null>");
        				}else{
            				sb.append(metadataRouteGrenoble);
            			}
            		
        			sb.append("|");
        		
        				if(delay == null){
        					sb.append("<null>");
        				}else{
            				sb.append(delay);
            			}
            		
        			sb.append("|");
        		
        				if(failedReason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(failedReason);
            			}
            		
        			sb.append("|");
        		
        				if(failedReasonCustom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(failedReasonCustom);
            			}
            		
        			sb.append("|");
        		
        				if(isExpress == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isExpress);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public String Task;

				public String getTask () {
					return this.Task;
				}

				public Boolean TaskIsNullable(){
				    return true;
				}
				public Boolean TaskIsKey(){
				    return false;
				}
				public Integer TaskLength(){
				    return 10000;
				}
				public Integer TaskPrecision(){
				    return 0;
				}
				public String TaskDefault(){
				
					return null;
				
				}
				public String TaskComment(){
				
				    return "";
				
				}
				public String TaskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TaskOriginalDbColumnName(){
				
					return "Task";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Task="+Task);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Task);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public String Task;

				public String getTask () {
					return this.Task;
				}

				public Boolean TaskIsNullable(){
				    return true;
				}
				public Boolean TaskIsKey(){
				    return false;
				}
				public Integer TaskLength(){
				    return 10000;
				}
				public Integer TaskPrecision(){
				    return 0;
				}
				public String TaskDefault(){
				
					return null;
				
				}
				public String TaskComment(){
				
				    return "";
				
				}
				public String TaskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TaskOriginalDbColumnName(){
				
					return "Task";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Task="+Task);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Task);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public String Task;

				public String getTask () {
					return this.Task;
				}

				public Boolean TaskIsNullable(){
				    return true;
				}
				public Boolean TaskIsKey(){
				    return false;
				}
				public Integer TaskLength(){
				    return 10000;
				}
				public Integer TaskPrecision(){
				    return 0;
				}
				public String TaskDefault(){
				
					return null;
				
				}
				public String TaskComment(){
				
				    return "";
				
				}
				public String TaskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String TaskOriginalDbColumnName(){
				
					return "Task";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Task = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Task,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Task="+Task);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Task);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public int statusCode;

				public int getStatusCode () {
					return this.statusCode;
				}

				public Boolean statusCodeIsNullable(){
				    return false;
				}
				public Boolean statusCodeIsKey(){
				    return false;
				}
				public Integer statusCodeLength(){
				    return null;
				}
				public Integer statusCodePrecision(){
				    return null;
				}
				public String statusCodeDefault(){
				
					return null;
				
				}
				public String statusCodeComment(){
				
				    return "";
				
				}
				public String statusCodePattern(){
				
					return "";
				
				}
				public String statusCodeOriginalDbColumnName(){
				
					return "statusCode";
				
				}

				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return 0;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				
			    public String string;

				public String getString () {
					return this.string;
				}

				public Boolean stringIsNullable(){
				    return false;
				}
				public Boolean stringIsKey(){
				    return false;
				}
				public Integer stringLength(){
				    return 4048;
				}
				public Integer stringPrecision(){
				    return null;
				}
				public String stringDefault(){
				
					return null;
				
				}
				public String stringComment(){
				
				    return "";
				
				}
				public String stringPattern(){
				
					return "";
				
				}
				public String stringOriginalDbColumnName(){
				
					return "string";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
			        this.statusCode = dis.readInt();
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
			        this.statusCode = dis.readInt();
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.statusCode);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.statusCode);
					
					// Document
				
						dos.clearInstanceCache();
						dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(statusCode);
        			
        			sb.append("|");
        		
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        				if(string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[0];

	
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}

				public Boolean statusCodeIsNullable(){
				    return true;
				}
				public Boolean statusCodeIsKey(){
				    return false;
				}
				public Integer statusCodeLength(){
				    return null;
				}
				public Integer statusCodePrecision(){
				    return null;
				}
				public String statusCodeDefault(){
				
					return null;
				
				}
				public String statusCodeComment(){
				
				    return "";
				
				}
				public String statusCodePattern(){
				
					return "";
				
				}
				public String statusCodeOriginalDbColumnName(){
				
					return "statusCode";
				
				}

				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return 0;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				
			    public String string;

				public String getString () {
					return this.string;
				}

				public Boolean stringIsNullable(){
				    return true;
				}
				public Boolean stringIsKey(){
				    return false;
				}
				public Integer stringLength(){
				    return 4048;
				}
				public Integer stringPrecision(){
				    return null;
				}
				public String stringDefault(){
				
					return null;
				
				}
				public String stringComment(){
				
				    return "";
				
				}
				public String stringPattern(){
				
					return "";
				
				}
				public String stringOriginalDbColumnName(){
				
					return "string";
				
				}

				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_TASKS_IMPORT) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
						dos.clearInstanceCache();
						dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(statusCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statusCode);
            			}
            		
        			sb.append("|");
        		
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        				if(string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tLoop_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLoop_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tLoop_1");
		org.slf4j.MDC.put("_subJobPid", "D1wrrQ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
row1Struct row1 = new row1Struct();
row2Struct row2 = new row2Struct();
row3Struct row3 = new row3Struct();
row8Struct row8 = new row8Struct();
task_dbStruct task_db = new task_dbStruct();
row4Struct row4 = new row4Struct();
row7Struct row7 = new row7Struct();
out2Struct out2 = new out2Struct();
out2Struct row9 = out2;



	
	/**
	 * [tLoop_1 begin ] start
	 */

				
			int NB_ITERATE_tJava_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tLoop_1", false);
		start_Hash.put("tLoop_1", System.currentTimeMillis());
		
	
	currentComponent="tLoop_1";
	
	
		int tos_count_tLoop_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLoop_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLoop_1 = new StringBuilder();
                    log4jParamters_tLoop_1.append("Parameters:");
                            log4jParamters_tLoop_1.append("FORLOOP" + " = " + "false");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("WHILELOOP" + " = " + "true");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("DECLARATION" + " = " + "int i = 0 ;");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("CONDITION" + " = " + "((Integer)globalMap.get(\"numberOfElementsInPage\"))  == 50");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("ITERATION" + " = " + "i++;");
                        log4jParamters_tLoop_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + (log4jParamters_tLoop_1) );
                    } 
                } 
            new BytesLimit65535_tLoop_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLoop_1", "tLoop_1", "tLoop");
				talendJobLogProcess(globalMap);
			}
			

int current_iteration_tLoop_1 = 0;

int i = 0 ;;
	
		log.info("tLoop_1 - Start to loop using a while loop. Initial declaration: '" + "int i = 0 ;" + "'. Condition: '" + "((Integer)globalMap.get(\"numberOfElementsInPage\"))  == 50" + "'.");
	
while(((Integer)globalMap.get("numberOfElementsInPage"))  == 50){
	
		log.debug("tLoop_1 - Current iteration value: " + current_iteration_tLoop_1);
	
current_iteration_tLoop_1++;
globalMap.put("tLoop_1_CURRENT_ITERATION",current_iteration_tLoop_1);


 



/**
 * [tLoop_1 begin ] stop
 */
	
	/**
	 * [tLoop_1 main ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 


	tos_count_tLoop_1++;

/**
 * [tLoop_1 main ] stop
 */
	
	/**
	 * [tLoop_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 process_data_begin ] stop
 */
	NB_ITERATE_tJava_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("out2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("task_db", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tJava_1);
					//Thread.sleep(1000);
				}				
			







	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"task_db");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"urbantz_task\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"urbantz_task\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
         if (updateKeyCount_tDBOutput_1 == 95 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "urbantz_task";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "urbantz_task" + "` (`sourceId`,`sourceLocationType`,`sourceLocationGeometry`,`sourceAddressLines`,`sourceGeocodeScore`,`sourceCleanScore`,`sourceStreet`,`sourceCity`,`sourceZip`,`sourceCountry`,`sourceAddress`,`locationType`,`locationGeometry`,`locationAddressLines`,`locationGeocodeScore`,`locationCleanScore`,`locationStreet`,`locationAddress`,`locationZip`,`locationCity`,`locationCountry`,`locationOrigin`,`contactBuildingInfo`,`contactPerson`,`contactPhone`,`contactEmail`,`timeWindowStart`,`timeWindowStop`,`sourceStatus`,`sourceActivity`,`sourceSkills`,`sourceLabels`,`sourceAttempts`,`sourceHasBeenPaid`,`sourceClosureDate`,`sourcePaymentType`,`sourceCollectedAmount`,`metadataCodeArticle`,`metadataTypePrestation`,`sourceIssues`,`sourceWhen`,`sourceUpdated`,`sourceItems`,`sourceProducts`,`sourceAnnouncement`,`sourceDate`,`sourceEndpoint`,`taskId`,`sourceType`,`sourceBy`,`sourceCategory`,`sourceClient`,`createdBy_id`,`createdByFirstName`,`createdByLastName`,`createdByExternalId`,`createdById`,`dimensionsWeight`,`dimensionsVolume`,`sourceFlux`,`sourceInstructions`,`sourcePlatform`,`sourcePlatformName`,`sourceProgress`,`sourceRoundName`,`sourceSequence`,`sourceServiceTime`,`sourceTrackingId`,`sourceHub`,`sourceHubName`,`sourceTargetFlux`,`sourceZone`,`sourceOrder`,`sourceArriveTime`,`sourceAssociated`,`sourceAssociatedName`,`driver_id`,`driverFirstName`,`driverLastName`,`driverExternalId`,`driverId`,`sourceRound`,`sourceRoundColor`,`sourceCompletedBy`,`sourceImagePath`,`sourceHasRejectedProducts`,`source_Id`,`metadataVehicule`,`metadataFACTURATION`,`metadataRouteGrenoble`,`is_deleted`,`delay`,`failedReason`,`failedReasonCustom`,`isExpress`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `sourceLocationType` = ?,`sourceLocationGeometry` = ?,`sourceAddressLines` = ?,`sourceGeocodeScore` = ?,`sourceCleanScore` = ?,`sourceStreet` = ?,`sourceCity` = ?,`sourceZip` = ?,`sourceCountry` = ?,`sourceAddress` = ?,`locationType` = ?,`locationGeometry` = ?,`locationAddressLines` = ?,`locationGeocodeScore` = ?,`locationCleanScore` = ?,`locationStreet` = ?,`locationAddress` = ?,`locationZip` = ?,`locationCity` = ?,`locationCountry` = ?,`locationOrigin` = ?,`contactBuildingInfo` = ?,`contactPerson` = ?,`contactPhone` = ?,`contactEmail` = ?,`timeWindowStart` = ?,`timeWindowStop` = ?,`sourceStatus` = ?,`sourceActivity` = ?,`sourceSkills` = ?,`sourceLabels` = ?,`sourceAttempts` = ?,`sourceHasBeenPaid` = ?,`sourceClosureDate` = ?,`sourcePaymentType` = ?,`sourceCollectedAmount` = ?,`metadataCodeArticle` = ?,`metadataTypePrestation` = ?,`sourceIssues` = ?,`sourceWhen` = ?,`sourceUpdated` = ?,`sourceItems` = ?,`sourceProducts` = ?,`sourceAnnouncement` = ?,`sourceDate` = ?,`sourceEndpoint` = ?,`taskId` = ?,`sourceType` = ?,`sourceBy` = ?,`sourceCategory` = ?,`sourceClient` = ?,`createdBy_id` = ?,`createdByFirstName` = ?,`createdByLastName` = ?,`createdByExternalId` = ?,`createdById` = ?,`dimensionsWeight` = ?,`dimensionsVolume` = ?,`sourceFlux` = ?,`sourceInstructions` = ?,`sourcePlatform` = ?,`sourcePlatformName` = ?,`sourceProgress` = ?,`sourceRoundName` = ?,`sourceSequence` = ?,`sourceServiceTime` = ?,`sourceTrackingId` = ?,`sourceHub` = ?,`sourceHubName` = ?,`sourceTargetFlux` = ?,`sourceZone` = ?,`sourceOrder` = ?,`sourceArriveTime` = ?,`sourceAssociated` = ?,`sourceAssociatedName` = ?,`driver_id` = ?,`driverFirstName` = ?,`driverLastName` = ?,`driverExternalId` = ?,`driverId` = ?,`sourceRound` = ?,`sourceRoundColor` = ?,`sourceCompletedBy` = ?,`sourceImagePath` = ?,`sourceHasRejectedProducts` = ?,`source_Id` = ?,`metadataVehicule` = ?,`metadataFACTURATION` = ?,`metadataRouteGrenoble` = ?,`is_deleted` = ?,`delay` = ?,`failedReason` = ?,`failedReasonCustom` = ?,`isExpress` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_3 = new StringBuilder();
                    log4jParamters_tMap_3.append("Parameters:");
                            log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_3.append(" | ");
                            log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + (log4jParamters_tMap_3) );
                    } 
                } 
            new BytesLimit65535_tMap_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row8_tMap_3 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_task_db_tMap_3 = 0;
				
task_dbStruct task_db_tmp = new task_dbStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_4", false);
		start_Hash.put("tExtractJSONFields_4", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tExtractJSONFields_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_4 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_4.append("Parameters:");
                            log4jParamters_tExtractJSONFields_4.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSONFIELD" + " = " + "Task");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSON_LOOP_QUERY" + " = " + "\"$\"");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"_id\"")+", SCHEMA_COLUMN="+("sourceId")+"}, {QUERY="+("\"source.location.type\"")+", SCHEMA_COLUMN="+("sourceLocationType")+"}, {QUERY="+("\"source.location.geometry[*]\"")+", SCHEMA_COLUMN="+("sourceLocationGeometry")+"}, {QUERY="+("\"source.addressLines[*]\"")+", SCHEMA_COLUMN="+("sourceAddressLines")+"}, {QUERY="+("\"source.geocodeScore\"")+", SCHEMA_COLUMN="+("sourceGeocodeScore")+"}, {QUERY="+("\"source.cleanScore\"")+", SCHEMA_COLUMN="+("sourceCleanScore")+"}, {QUERY="+("\"source.street\"")+", SCHEMA_COLUMN="+("sourceStreet")+"}, {QUERY="+("\"source.city\"")+", SCHEMA_COLUMN="+("sourceCity")+"}, {QUERY="+("\"source.zip\"")+", SCHEMA_COLUMN="+("sourceZip")+"}, {QUERY="+("\"source.country\"")+", SCHEMA_COLUMN="+("sourceCountry")+"}, {QUERY="+("\"source.address\"")+", SCHEMA_COLUMN="+("sourceAddress")+"}, {QUERY="+("\"location.location.type\"")+", SCHEMA_COLUMN="+("locationType")+"}, {QUERY="+("\"location.location.geometry[*]\"")+", SCHEMA_COLUMN="+("locationGeometry")+"}, {QUERY="+("\"location.addressLines[*]\"")+", SCHEMA_COLUMN="+("locationAddressLines")+"}, {QUERY="+("\"location.geocodeScore\"")+", SCHEMA_COLUMN="+("locationGeocodeScore")+"}, {QUERY="+("\"location.cleanScore\"")+", SCHEMA_COLUMN="+("locationCleanScore")+"}, {QUERY="+("\"location.street\"")+", SCHEMA_COLUMN="+("locationStreet")+"}, {QUERY="+("\"location.address\"")+", SCHEMA_COLUMN="+("locationAddress")+"}, {QUERY="+("\"location.zip\"")+", SCHEMA_COLUMN="+("locationZip")+"}, {QUERY="+("\"location.city\"")+", SCHEMA_COLUMN="+("locationCity")+"}, {QUERY="+("\"location.country\"")+", SCHEMA_COLUMN="+("locationCountry")+"}, {QUERY="+("\"location.origin\"")+", SCHEMA_COLUMN="+("locationOrigin")+"}, {QUERY="+("\"contact.buildingInfo\"")+", SCHEMA_COLUMN="+("contactBuildingInfo")+"}, {QUERY="+("\"contact.person\"")+", SCHEMA_COLUMN="+("contactPerson")+"}, {QUERY="+("\"contact.phone\"")+", SCHEMA_COLUMN="+("contactPhone")+"}, {QUERY="+("\"contact.email\"")+", SCHEMA_COLUMN="+("contactEmail")+"}, {QUERY="+("\"timeWindow.start\"")+", SCHEMA_COLUMN="+("timeWindowStart")+"}, {QUERY="+("\"timeWindow.stop\"")+", SCHEMA_COLUMN="+("timeWindowStop")+"}, {QUERY="+("\"status\"")+", SCHEMA_COLUMN="+("sourceStatus")+"}, {QUERY="+("\"activity\"")+", SCHEMA_COLUMN="+("sourceActivity")+"}, {QUERY="+("\"skills[*]\"")+", SCHEMA_COLUMN="+("sourceSkills")+"}, {QUERY="+("\"labels[*]\"")+", SCHEMA_COLUMN="+("sourceLabels")+"}, {QUERY="+("\"attempts\"")+", SCHEMA_COLUMN="+("sourceAttempts")+"}, {QUERY="+("\"hasBeenPaid\"")+", SCHEMA_COLUMN="+("sourceHasBeenPaid")+"}, {QUERY="+("\"closureDate\"")+", SCHEMA_COLUMN="+("sourceClosureDate")+"}, {QUERY="+("\"paymentType\"")+", SCHEMA_COLUMN="+("sourcePaymentType")+"}, {QUERY="+("\"collectedAmount\"")+", SCHEMA_COLUMN="+("sourceCollectedAmount")+"}, {QUERY="+("\"metadata.TypePrestation\"")+", SCHEMA_COLUMN="+("metadataTypePrestation")+"}, {QUERY="+("\"metadata.CodeArticle\"")+", SCHEMA_COLUMN="+("metadataCodeArticle")+"}, {QUERY="+("\"issues[*]\"")+", SCHEMA_COLUMN="+("sourceIssues")+"}, {QUERY="+("\"when\"")+", SCHEMA_COLUMN="+("sourceWhen")+"}, {QUERY="+("\"updated\"")+", SCHEMA_COLUMN="+("sourceUpdated")+"}, {QUERY="+("\"activity\"")+", SCHEMA_COLUMN="+("sourceItems")+"}, {QUERY="+("\"products[*]\"")+", SCHEMA_COLUMN="+("sourceProducts")+"}, {QUERY="+("\"announcement\"")+", SCHEMA_COLUMN="+("sourceAnnouncement")+"}, {QUERY="+("\"date\"")+", SCHEMA_COLUMN="+("sourceDate")+"}, {QUERY="+("\"endpoint\"")+", SCHEMA_COLUMN="+("sourceEndpoint")+"}, {QUERY="+("\"taskId\"")+", SCHEMA_COLUMN="+("taskId")+"}, {QUERY="+("\"type\"")+", SCHEMA_COLUMN="+("sourceType")+"}, {QUERY="+("\"by\"")+", SCHEMA_COLUMN="+("sourceBy")+"}, {QUERY="+("\"category\"")+", SCHEMA_COLUMN="+("sourceCategory")+"}, {QUERY="+("\"client\"")+", SCHEMA_COLUMN="+("sourceClient")+"}, {QUERY="+("\"createdBy._id\"")+", SCHEMA_COLUMN="+("createdBy_id")+"}, {QUERY="+("\"createdBy.firstName\"")+", SCHEMA_COLUMN="+("createdByFirstName")+"}, {QUERY="+("\"createdBy.lastName\"")+", SCHEMA_COLUMN="+("createdByLastName")+"}, {QUERY="+("\"createdBy.externalId\"")+", SCHEMA_COLUMN="+("createdByExternalId")+"}, {QUERY="+("\"createdBy.id\"")+", SCHEMA_COLUMN="+("createdById")+"}, {QUERY="+("\"dimensions.weight\"")+", SCHEMA_COLUMN="+("dimensionsWeight")+"}, {QUERY="+("\"dimensions.volume\"")+", SCHEMA_COLUMN="+("dimensionsVolume")+"}, {QUERY="+("\"flux\"")+", SCHEMA_COLUMN="+("sourceFlux")+"}, {QUERY="+("\"instructions\"")+", SCHEMA_COLUMN="+("sourceInstructions")+"}, {QUERY="+("\"platform\"")+", SCHEMA_COLUMN="+("sourcePlatform")+"}, {QUERY="+("\"platformName\"")+", SCHEMA_COLUMN="+("sourcePlatformName")+"}, {QUERY="+("\"progress\"")+", SCHEMA_COLUMN="+("sourceProgress")+"}, {QUERY="+("\"roundName\"")+", SCHEMA_COLUMN="+("sourceRoundName")+"}, {QUERY="+("\"sequence\"")+", SCHEMA_COLUMN="+("sourceSequence")+"}, {QUERY="+("\"serviceTime\"")+", SCHEMA_COLUMN="+("sourceServiceTime")+"}, {QUERY="+("\"trackingId\"")+", SCHEMA_COLUMN="+("sourceTrackingId")+"}, {QUERY="+("\"hub\"")+", SCHEMA_COLUMN="+("sourceHub")+"}, {QUERY="+("\"hubName\"")+", SCHEMA_COLUMN="+("sourceHubName")+"}, {QUERY="+("\"targetFlux\"")+", SCHEMA_COLUMN="+("sourceTargetFlux")+"}, {QUERY="+("\"zone\"")+", SCHEMA_COLUMN="+("sourceZone")+"}, {QUERY="+("\"order\"")+", SCHEMA_COLUMN="+("sourceOrder")+"}, {QUERY="+("\"arriveTime\"")+", SCHEMA_COLUMN="+("sourceArriveTime")+"}, {QUERY="+("\"associated\"")+", SCHEMA_COLUMN="+("sourceAssociated")+"}, {QUERY="+("\"associatedName\"")+", SCHEMA_COLUMN="+("sourceAssociatedName")+"}, {QUERY="+("\"driver._id\"")+", SCHEMA_COLUMN="+("driver_id")+"}, {QUERY="+("\"driver.firstName\"")+", SCHEMA_COLUMN="+("driverFirstName")+"}, {QUERY="+("\"driver.lastName\"")+", SCHEMA_COLUMN="+("driverLastName")+"}, {QUERY="+("\"driver.externalId\"")+", SCHEMA_COLUMN="+("driverExternalId")+"}, {QUERY="+("\"driver.id\"")+", SCHEMA_COLUMN="+("driverId")+"}, {QUERY="+("\"round\"")+", SCHEMA_COLUMN="+("sourceRound")+"}, {QUERY="+("\"roundColor\"")+", SCHEMA_COLUMN="+("sourceRoundColor")+"}, {QUERY="+("\"completedBy\"")+", SCHEMA_COLUMN="+("sourceCompletedBy")+"}, {QUERY="+("\"imagePath\"")+", SCHEMA_COLUMN="+("sourceImagePath")+"}, {QUERY="+("\"hasRejectedProducts\"")+", SCHEMA_COLUMN="+("sourceHasRejectedProducts")+"}, {QUERY="+("\"id\"")+", SCHEMA_COLUMN="+("source_Id")+"}, {QUERY="+("\"metadata.Vehicule\"")+", SCHEMA_COLUMN="+("metadataVehicule")+"}, {QUERY="+("\"metadata.FACTURATION\"")+", SCHEMA_COLUMN="+("metadataFACTURATION")+"}, {QUERY="+("\"metadata.RouteGrenoble\"")+", SCHEMA_COLUMN="+("metadataRouteGrenoble")+"}, {QUERY="+("\"delay.time\"")+", SCHEMA_COLUMN="+("delay")+"}, {QUERY="+("\"execution.failedReason.reason\"")+", SCHEMA_COLUMN="+("failedReason")+"}, {QUERY="+("\"execution.failedReason.custom\"")+", SCHEMA_COLUMN="+("failedReasonCustom")+"}, {QUERY="+("\"metadata.Express\"")+", SCHEMA_COLUMN="+("isExpress")+"}]");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + (log4jParamters_tExtractJSONFields_4) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_4", "Extract_Task_Fields", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_4 = 0;
String jsonStr_tExtractJSONFields_4 = "";

	

class JsonPathCache_tExtractJSONFields_4 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_4 jsonPathCache_tExtractJSONFields_4 = new JsonPathCache_tExtractJSONFields_4();

 



/**
 * [tExtractJSONFields_4 begin ] stop
 */







	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"urbantz_item\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"urbantz_item\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_2 = 2;
         if (updateKeyCount_tDBOutput_2 == 16 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

String tableName_tDBOutput_2 = "urbantz_item";
boolean whetherReject_tDBOutput_2 = false;

java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
long date_tDBOutput_2;

java.sql.Connection conn_tDBOutput_2 = null;
		conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );

		int count_tDBOutput_2=0;
		
				
			
				String insertIgnore_tDBOutput_2 = "INSERT IGNORE INTO `" + "urbantz_item" + "` (`itemId`,`confirmed`,`pictures___`,`status`,`quantity`,`labels`,`skills`,`lastOfflineUpdatedAt`,`name`,`type`,`barcode`,`barcodeEncoding`,`weight`,`volume`,`taskId`,`reference`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `confirmed` = ?,`pictures___` = ?,`status` = ?,`quantity` = ?,`labels` = ?,`skills` = ?,`lastOfflineUpdatedAt` = ?,`name` = ?,`type` = ?,`barcode` = ?,`barcodeEncoding` = ?,`weight` = ?,`volume` = ?,`reference` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insertIgnore_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
				


 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out2");
			
		int tos_count_tLogRow_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_2", "tLogRow_2", "tDummyRow");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_2 = new StringBuilder();
                    log4jParamters_tMap_2.append("Parameters:");
                            log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
                    } 
                } 
            new BytesLimit65535_tMap_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row7_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out2_tMap_2 = 0;
				
out2Struct out2_tmp = new out2Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_3", false);
		start_Hash.put("tExtractJSONFields_3", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tExtractJSONFields_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_3 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_3.append("Parameters:");
                            log4jParamters_tExtractJSONFields_3.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSONFIELD" + " = " + "Task");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSON_LOOP_QUERY" + " = " + "\"$.items[*]\"");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"_id\"")+", SCHEMA_COLUMN="+("itemId")+"}, {QUERY="+("\"damaged.confirmed\"")+", SCHEMA_COLUMN="+("confirmed")+"}, {QUERY="+("\"damaged.pictures[*]\"")+", SCHEMA_COLUMN="+("pictures___")+"}, {QUERY="+("\"status\"")+", SCHEMA_COLUMN="+("status")+"}, {QUERY="+("\"quantity\"")+", SCHEMA_COLUMN="+("quantity")+"}, {QUERY="+("\"labels[*]\"")+", SCHEMA_COLUMN="+("labels")+"}, {QUERY="+("\"skills[*]\"")+", SCHEMA_COLUMN="+("skills")+"}, {QUERY="+("\"lastOfflineUpdatedAt\"")+", SCHEMA_COLUMN="+("lastOfflineUpdatedAt")+"}, {QUERY="+("\"name\"")+", SCHEMA_COLUMN="+("name")+"}, {QUERY="+("\"type\"")+", SCHEMA_COLUMN="+("type")+"}, {QUERY="+("\"barcode\"")+", SCHEMA_COLUMN="+("barcode")+"}, {QUERY="+("\"barcodeEncoding\"")+", SCHEMA_COLUMN="+("barcodeEncoding")+"}, {QUERY="+("\"dimensions.weight\"")+", SCHEMA_COLUMN="+("weight")+"}, {QUERY="+("\"dimensions.volume\"")+", SCHEMA_COLUMN="+("volume")+"}, {QUERY="+("\"$._id\"")+", SCHEMA_COLUMN="+("taskId")+"}, {QUERY="+("\"reference\"")+", SCHEMA_COLUMN="+("reference")+"}]");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + (log4jParamters_tExtractJSONFields_3) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_3", "Extract_Item_Fields_From_Task", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_3 = 0;
String jsonStr_tExtractJSONFields_3 = "";

	

class JsonPathCache_tExtractJSONFields_3 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_3 jsonPathCache_tExtractJSONFields_3 = new JsonPathCache_tExtractJSONFields_3();

 



/**
 * [tExtractJSONFields_3 begin ] stop
 */



	
	/**
	 * [tReplicate_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tReplicate_1", false);
		start_Hash.put("tReplicate_1", System.currentTimeMillis());
		
	
	currentComponent="tReplicate_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tReplicate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tReplicate_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tReplicate_1 = new StringBuilder();
                    log4jParamters_tReplicate_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + (log4jParamters_tReplicate_1) );
                    } 
                } 
            new BytesLimit65535_tReplicate_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tReplicate_1", "tReplicate_1", "tReplicate");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tReplicate_1 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tExtractJSONFields_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_1 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_1.append("Parameters:");
                            log4jParamters_tExtractJSONFields_1.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSONFIELD" + " = " + "string");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_LOOP_QUERY" + " = " + "\"$[*]\"");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"@\"")+", SCHEMA_COLUMN="+("Task")+"}]");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + (log4jParamters_tExtractJSONFields_1) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_1", "Extract_Task_From_List", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tRESTClient_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tRESTClient_1", false);
		start_Hash.put("tRESTClient_1", System.currentTimeMillis());
		
	
	currentComponent="tRESTClient_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tRESTClient_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tRESTClient_1", "tRESTClient_1", "tRESTClient");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tRESTClient_1 begin ] stop
 */



	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";
	
	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_1", "tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_begin ] stop
 */

	
	/**
	 * [tRESTClient_1 main ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tJava_1","tJava_1","tJava","tRESTClient_1","tRESTClient_1","tRESTClient"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		
	row1 = null;

// expected response body
Object responseDoc_tRESTClient_1 = null;

try {
	// request body
	org.dom4j.Document requestDoc_tRESTClient_1 = null;
	String requestString_tRESTClient_1 = null;
			if (null != row5.body) {
				requestDoc_tRESTClient_1 = row5.body.getDocument();
			}
			requestString_tRESTClient_1 = row5.string;

	Object requestBody_tRESTClient_1 = requestDoc_tRESTClient_1 != null ? requestDoc_tRESTClient_1 : requestString_tRESTClient_1;

	

    //resposne class name
	Class<?> responseClass_tRESTClient_1
		= String.class;

	// create web client instance
	org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean factoryBean_tRESTClient_1 =
			new org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean();

	boolean inOSGi = routines.system.BundleUtils.inOSGi();

	final java.util.List<org.apache.cxf.feature.Feature> features_tRESTClient_1 =
			new java.util.ArrayList<org.apache.cxf.feature.Feature>();

	String url = null;
	
		url = "https://api.urbantz.com/v2/task";
		// {baseUri}tRESTClient
		factoryBean_tRESTClient_1.setServiceName(new javax.xml.namespace.QName(url, "tRESTClient"));
		factoryBean_tRESTClient_1.setAddress(url);
	

	

    boolean log_messages_tRESTClient_1 = Boolean.valueOf(false);
	if (log_messages_tRESTClient_1) {
		org.apache.cxf.ext.logging.LoggingFeature loggingFeature = new  org.apache.cxf.ext.logging.LoggingFeature();
		loggingFeature.addSensitiveProtocolHeaderNames(new java.util.HashSet<>(java.util.Arrays.asList(org.apache.cxf.helpers.HttpHeaderHelper.AUTHORIZATION)));
		loggingFeature.addSensitiveElementNames(new java.util.HashSet<>(java.util.Arrays.asList("password")));
		features_tRESTClient_1.add(loggingFeature);
	}

	

	factoryBean_tRESTClient_1.setFeatures(features_tRESTClient_1);


	java.util.List<Object> providers_tRESTClient_1 = new java.util.ArrayList<Object>();
	providers_tRESTClient_1.add(new org.apache.cxf.jaxrs.provider.dom4j.DOM4JProvider() {
		// workaround for https://jira.talendforge.org/browse/TESB-7276
		public org.dom4j.Document readFrom(Class<org.dom4j.Document> cls,
											java.lang.reflect.Type type,
											java.lang.annotation.Annotation[] anns,
											javax.ws.rs.core.MediaType mt,
											javax.ws.rs.core.MultivaluedMap<String, String> headers,
											java.io.InputStream is)
				throws IOException, javax.ws.rs.WebApplicationException {
			String contentLength = headers.getFirst("Content-Length");
			if (!org.apache.cxf.common.util.StringUtils.isEmpty(contentLength)
					&& Integer.valueOf(contentLength) <= 0) {
				try {
					return org.dom4j.DocumentHelper.parseText("<root/>");
				} catch (org.dom4j.DocumentException e_tRESTClient_1) {
					e_tRESTClient_1.printStackTrace();
				}
				return null;
			}
			return super.readFrom(cls, type, anns, mt, headers, is);
		}
	});
	org.apache.cxf.jaxrs.provider.json.JSONProvider jsonProvider_tRESTClient_1 =
			new org.apache.cxf.jaxrs.provider.json.JSONProvider();
		jsonProvider_tRESTClient_1.setIgnoreNamespaces(true);
		jsonProvider_tRESTClient_1.setAttributesToElements(true);
	
	
	
		jsonProvider_tRESTClient_1.setSupportUnwrapped(true);
		jsonProvider_tRESTClient_1.setWrapperName("root");
	
	
		jsonProvider_tRESTClient_1.setDropRootElement(false);
		jsonProvider_tRESTClient_1.setConvertTypesToStrings(false);
	providers_tRESTClient_1.add(jsonProvider_tRESTClient_1);
	factoryBean_tRESTClient_1.setProviders(providers_tRESTClient_1);
	factoryBean_tRESTClient_1.setTransportId("http://cxf.apache.org/transports/http");

	boolean use_auth_tRESTClient_1 = false;

	

	org.apache.cxf.jaxrs.client.WebClient webClient_tRESTClient_1 = null;
	
		webClient_tRESTClient_1 = factoryBean_tRESTClient_1.createWebClient();
		// set request path
		webClient_tRESTClient_1.path("");
	

	// set connection properties
	org.apache.cxf.jaxrs.client.ClientConfiguration clientConfig_tRESTClient_1 = org.apache.cxf.jaxrs.client.WebClient.getConfig(webClient_tRESTClient_1);
	org.apache.cxf.transport.http.auth.HttpAuthSupplier httpAuthSupplerHttpConduit = null;
	org.apache.cxf.transport.http.HTTPConduit conduit_tRESTClient_1 = null;

	
		conduit_tRESTClient_1 = clientConfig_tRESTClient_1.getHttpConduit();
	
	
    if (clientConfig_tRESTClient_1.getEndpoint() != null) {
		org.apache.cxf.service.model.EndpointInfo endpointInfo_tRESTClient_1 = clientConfig_tRESTClient_1.getEndpoint().getEndpointInfo();
		if(endpointInfo_tRESTClient_1 != null) {
			endpointInfo_tRESTClient_1.setProperty("enable.webclient.operation.reporting", true);
		}
    }

	

	

	if (!inOSGi) {
		conduit_tRESTClient_1.getClient().setReceiveTimeout((long)(60 * 1000L));
		conduit_tRESTClient_1.getClient().setConnectionTimeout((long)(30 * 1000L));
	}
	
	
	
		

	

	

	
		// set Accept-Type
		webClient_tRESTClient_1.accept("application/json");
	

	
		// set optional query and header properties if any
	
		webClient_tRESTClient_1.header("x-api-key", "0OCDfeE0zXfOjWYnV9rBaXepnJFnoPJngNLGSaGhhBCpCU6U");
	
	if (use_auth_tRESTClient_1 && "OAUTH2_BEARER".equals("BASIC")) {
		// set oAuth2 bearer token
		org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier authSupplier = new org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier();
		authSupplier.setAccessToken((String) "");
		conduit_tRESTClient_1.setAuthSupplier(authSupplier);
	}

	

	// if FORM request then capture query parameters into Form, otherwise set them as queries
	
		
		
			webClient_tRESTClient_1.query("pageSize" ,50);
		
			webClient_tRESTClient_1.query("page" ,i);
		
			webClient_tRESTClient_1.query("date" ,((String)globalMap.get("day_to_retrieve")));
		
	


	try {
		// start send request
		
			responseDoc_tRESTClient_1 = webClient_tRESTClient_1.get();
			javax.ws.rs.core.Response responseObjBase_tRESTClient_1 = (javax.ws.rs.core.Response)responseDoc_tRESTClient_1;
            int status_tRESTClient_1 = responseObjBase_tRESTClient_1.getStatus();
            if (status_tRESTClient_1 != 304 && status_tRESTClient_1 >= 300 && responseClass_tRESTClient_1 != javax.ws.rs.core.Response.class) {
                throw org.apache.cxf.jaxrs.utils.ExceptionUtils.toWebApplicationException((javax.ws.rs.core.Response)responseObjBase_tRESTClient_1);
            }
            if (status_tRESTClient_1 != 204 && responseObjBase_tRESTClient_1.getEntity() != null) {
				responseDoc_tRESTClient_1 = responseObjBase_tRESTClient_1.readEntity(responseClass_tRESTClient_1);
			}
		


		int webClientResponseStatus_tRESTClient_1 = webClient_tRESTClient_1.getResponse().getStatus();
		if (webClientResponseStatus_tRESTClient_1 >= 300) {
			throw new javax.ws.rs.WebApplicationException(webClient_tRESTClient_1.getResponse());
		}

		
			if (row1 == null) {
				row1 = new row1Struct();
			}

			row1.statusCode = webClientResponseStatus_tRESTClient_1;
			row1.string = "";
			
				
				{
					Object responseObj_tRESTClient_1 = responseDoc_tRESTClient_1;
				
				if(responseObj_tRESTClient_1 != null){
					if (responseClass_tRESTClient_1 == String.class && responseObj_tRESTClient_1 instanceof String) {
							row1.string = (String) responseObj_tRESTClient_1;
					} else {
						routines.system.Document responseTalendDoc_tRESTClient_1 = null;
						if (null != responseObj_tRESTClient_1) {
							responseTalendDoc_tRESTClient_1 = new routines.system.Document();
							if (responseObj_tRESTClient_1 instanceof org.dom4j.Document) {
								responseTalendDoc_tRESTClient_1.setDocument((org.dom4j.Document) responseObj_tRESTClient_1);
							}
						}
						row1.body = responseTalendDoc_tRESTClient_1;
					}
				}
			}
			

			java.util.Map<String, javax.ws.rs.core.NewCookie> cookies_tRESTClient_1 = new java.util.HashMap<String, javax.ws.rs.core.NewCookie>();

			if (webClient_tRESTClient_1.getResponse() != null && webClient_tRESTClient_1.getResponse().getCookies() != null ) { 
				cookies_tRESTClient_1.putAll(webClient_tRESTClient_1.getResponse().getCookies());
			}

			


			globalMap.put("tRESTClient_1_HEADERS", webClient_tRESTClient_1.getResponse().getHeaders());
			globalMap.put("tRESTClient_1_COOKIES", cookies_tRESTClient_1);
			
		

	} catch (javax.ws.rs.WebApplicationException ex_tRESTClient_1) {
	    globalMap.put("tRESTClient_1_ERROR_MESSAGE",ex_tRESTClient_1.getMessage());
		
			throw ex_tRESTClient_1;
		
	}

} catch(Exception e_tRESTClient_1) {
    globalMap.put("tRESTClient_1_ERROR_MESSAGE",e_tRESTClient_1.getMessage());
	
		new TalendException(e_tRESTClient_1, currentComponent, globalMap).printStackTrace();
	
}


 


	tos_count_tRESTClient_1++;

/**
 * [tRESTClient_1 main ] stop
 */
	
	/**
	 * [tRESTClient_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tRESTClient_1","tRESTClient_1","tRESTClient","tExtractJSONFields_1","Extract_Task_From_List","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

            if(row1.string!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row1.string.toString();
   
row2 = null;

	

String loopPath_tExtractJSONFields_1 = "$[*]";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
		log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row2 = null;
	row2 = new row2Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "@";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_1.startsWith("$")){
		            if(root_tExtractJSONFields_1 == null){
		                root_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(root_tExtractJSONFields_1);
		        }else{
		            value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		        }
				row2.Task = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row2.Task = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
			log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row2 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
	log.debug("tExtractJSONFields_1 - Extracting the record " + nb_line_tExtractJSONFields_1 + ".");
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tReplicate_1 main ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tExtractJSONFields_1","Extract_Task_From_List","tExtractJSONFields","tReplicate_1","tReplicate_1","tReplicate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		


	row3 = new row3Struct();
						
	row3.Task = row2.Task;			
	row4 = new row4Struct();
						
	row4.Task = row2.Task;			


 


	tos_count_tReplicate_1++;

/**
 * [tReplicate_1 main ] stop
 */
	
	/**
	 * [tReplicate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_4 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_4","Extract_Task_Fields","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

            if(row3.Task!=null){// C_01
                jsonStr_tExtractJSONFields_4 = row3.Task.toString();
   
row8 = null;

	

String loopPath_tExtractJSONFields_4 = "$";
java.util.List<Object> resultset_tExtractJSONFields_4 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_4 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_4 = null;
try {
	document_tExtractJSONFields_4 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_4);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(loopPath_tExtractJSONFields_4);
	Object result_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(compiledLoopPath_tExtractJSONFields_4,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_4 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_4 = (net.minidev.json.JSONArray) result_tExtractJSONFields_4;
	} else {
		resultset_tExtractJSONFields_4.add(result_tExtractJSONFields_4);
	}
	
	isStructError_tExtractJSONFields_4 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",ex_tExtractJSONFields_4.getMessage());
		log.error("tExtractJSONFields_4 - " + ex_tExtractJSONFields_4.getMessage());
		System.err.println(ex_tExtractJSONFields_4.getMessage());
}

String jsonPath_tExtractJSONFields_4 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_4 = null;

Object value_tExtractJSONFields_4 = null;

Object root_tExtractJSONFields_4 = null;
for(int i_tExtractJSONFields_4=0; isStructError_tExtractJSONFields_4 || (i_tExtractJSONFields_4 < resultset_tExtractJSONFields_4.size());i_tExtractJSONFields_4++){
	if(!isStructError_tExtractJSONFields_4){
		Object row_tExtractJSONFields_4 = resultset_tExtractJSONFields_4.get(i_tExtractJSONFields_4);
            row8 = null;
	row8 = new row8Struct();
	nb_line_tExtractJSONFields_4++;
	try {
		jsonPath_tExtractJSONFields_4 = "_id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.location.type";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceLocationType = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceLocationType = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.location.geometry[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceLocationGeometry = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceLocationGeometry = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.addressLines[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceAddressLines = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAddressLines = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.geocodeScore";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceGeocodeScore = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceGeocodeScore = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceGeocodeScore = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.cleanScore";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceCleanScore = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceCleanScore = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCleanScore = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.street";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceStreet = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceStreet = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.city";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceCity = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCity = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.zip";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceZip = ParserUtils.parseTo_Integer(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceZip = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceZip = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.country";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceCountry = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCountry = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "source.address";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceAddress = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAddress = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.location.type";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationType = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationType = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.location.geometry[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationGeometry = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationGeometry = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.addressLines[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationAddressLines = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationAddressLines = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.geocodeScore";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.locationGeocodeScore = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.locationGeocodeScore = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationGeocodeScore = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.cleanScore";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.locationCleanScore = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.locationCleanScore = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationCleanScore = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.street";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationStreet = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationStreet = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.address";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationAddress = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationAddress = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.zip";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.locationZip = ParserUtils.parseTo_Integer(value_tExtractJSONFields_4.toString());
				} else {
					row8.locationZip = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationZip = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.city";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationCity = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationCity = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.country";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationCountry = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationCountry = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "location.origin";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.locationOrigin = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.locationOrigin = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "contact.buildingInfo";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.contactBuildingInfo = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.contactBuildingInfo = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "contact.person";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.contactPerson = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.contactPerson = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "contact.phone";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.contactPhone = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.contactPhone = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "contact.email";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.contactEmail = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.contactEmail = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "timeWindow.start";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.timeWindowStart = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.timeWindowStart = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "timeWindow.stop";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.timeWindowStop = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.timeWindowStop = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "status";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceStatus = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceStatus = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "activity";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceActivity = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceActivity = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "skills[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceSkills = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceSkills = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "labels[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceLabels = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceLabels = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "attempts";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceAttempts = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceAttempts = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAttempts = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "hasBeenPaid";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceHasBeenPaid = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceHasBeenPaid = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "closureDate";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceClosureDate = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceClosureDate = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "paymentType";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourcePaymentType = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourcePaymentType = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "collectedAmount";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceCollectedAmount = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceCollectedAmount = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCollectedAmount = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.TypePrestation";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.metadataTypePrestation = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.metadataTypePrestation = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.CodeArticle";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.metadataCodeArticle = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.metadataCodeArticle = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "issues[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceIssues = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceIssues = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "when";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceWhen = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceWhen = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "updated";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceUpdated = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceUpdated = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "activity";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceItems = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceItems = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "products[*]";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceProducts = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceProducts = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "announcement";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceAnnouncement = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAnnouncement = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "date";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceDate = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceDate = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "endpoint";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceEndpoint = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceEndpoint = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "taskId";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.taskId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.taskId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "type";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceType = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceType = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "by";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceBy = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceBy = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "category";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceCategory = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCategory = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "client";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceClient = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceClient = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "createdBy._id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.createdBy_id = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.createdBy_id = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "createdBy.firstName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.createdByFirstName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.createdByFirstName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "createdBy.lastName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.createdByLastName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.createdByLastName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "createdBy.externalId";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.createdByExternalId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.createdByExternalId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "createdBy.id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.createdById = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.createdById = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "dimensions.weight";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.dimensionsWeight = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.dimensionsWeight = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.dimensionsWeight = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "dimensions.volume";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.dimensionsVolume = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.dimensionsVolume = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.dimensionsVolume = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "flux";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceFlux = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceFlux = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "instructions";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceInstructions = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceInstructions = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "platform";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourcePlatform = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourcePlatform = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "platformName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourcePlatformName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourcePlatformName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "progress";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceProgress = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceProgress = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "roundName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceRoundName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceRoundName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "sequence";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceSequence = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceSequence = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceSequence = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "serviceTime";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceServiceTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceServiceTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceServiceTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "trackingId";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceTrackingId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceTrackingId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "hub";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceHub = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceHub = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "hubName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceHubName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceHubName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "targetFlux";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceTargetFlux = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceTargetFlux = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "zone";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceZone = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceZone = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "order";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceOrder = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceOrder = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "arriveTime";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceArriveTime = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceArriveTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "associated";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceAssociated = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAssociated = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "associatedName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceAssociatedName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceAssociatedName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "driver._id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.driver_id = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.driver_id = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "driver.firstName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.driverFirstName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.driverFirstName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "driver.lastName";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.driverLastName = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.driverLastName = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "driver.externalId";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.driverExternalId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.driverExternalId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "driver.id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.driverId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.driverId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "round";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceRound = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceRound = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "roundColor";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceRoundColor = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceRoundColor = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "completedBy";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceCompletedBy = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceCompletedBy = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "imagePath";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.sourceImagePath = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceImagePath = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "hasRejectedProducts";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row8.sourceHasRejectedProducts = ParserUtils.parseTo_Boolean(value_tExtractJSONFields_4.toString());
				} else {
					row8.sourceHasRejectedProducts = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.sourceHasRejectedProducts = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.source_Id = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.source_Id = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.Vehicule";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.metadataVehicule = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.metadataVehicule = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.FACTURATION";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.metadataFACTURATION = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.metadataFACTURATION = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.RouteGrenoble";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.metadataRouteGrenoble = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.metadataRouteGrenoble = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "delay.time";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.delay = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.delay = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "execution.failedReason.reason";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.failedReason = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.failedReason = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "execution.failedReason.custom";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.failedReasonCustom = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.failedReasonCustom = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "metadata.Express";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row8.isExpress = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row8.isExpress = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",ex_tExtractJSONFields_4.getMessage());
			log.error("tExtractJSONFields_4 - " + ex_tExtractJSONFields_4.getMessage());
		    System.err.println(ex_tExtractJSONFields_4.getMessage());
		    row8 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_4 = false;
	
	log.debug("tExtractJSONFields_4 - Extracting the record " + nb_line_tExtractJSONFields_4 + ".");
//}


 


	tos_count_tExtractJSONFields_4++;

/**
 * [tExtractJSONFields_4 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		

 



/**
 * [tExtractJSONFields_4 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tExtractJSONFields_4","Extract_Task_Fields","tExtractJSONFields","tMap_3","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_3 = false;
		boolean mainRowRejected_tMap_3 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

task_db = null;


// # Output table : 'task_db'
count_task_db_tMap_3++;

task_db_tmp.sourceId = row8.sourceId;
task_db_tmp.sourceLocationType = row8.sourceLocationType;
task_db_tmp.sourceLocationGeometry = row8.sourceLocationGeometry;
task_db_tmp.sourceAddressLines = row8.sourceAddressLines;
task_db_tmp.sourceGeocodeScore = row8.sourceGeocodeScore;
task_db_tmp.sourceCleanScore = row8.sourceCleanScore;
task_db_tmp.sourceStreet = row8.sourceStreet;
task_db_tmp.sourceCity = row8.sourceCity;
task_db_tmp.sourceZip = row8.sourceZip;
task_db_tmp.sourceCountry = row8.sourceCountry;
task_db_tmp.sourceAddress = row8.sourceAddress;
task_db_tmp.locationType = row8.locationType;
task_db_tmp.locationGeometry = row8.locationGeometry;
task_db_tmp.locationAddressLines = row8.locationAddressLines;
task_db_tmp.locationGeocodeScore = row8.locationGeocodeScore;
task_db_tmp.locationCleanScore = row8.locationCleanScore;
task_db_tmp.locationStreet = row8.locationStreet;
task_db_tmp.locationAddress = row8.locationAddress;
task_db_tmp.locationZip = row8.locationZip;
task_db_tmp.locationCity = row8.locationCity;
task_db_tmp.locationCountry = row8.locationCountry;
task_db_tmp.locationOrigin = row8.locationOrigin;
task_db_tmp.contactBuildingInfo = row8.contactBuildingInfo;
task_db_tmp.contactPerson = row8.contactPerson;
task_db_tmp.contactPhone = row8.contactPhone;
task_db_tmp.contactEmail = row8.contactEmail;
task_db_tmp.timeWindowStart = row8.timeWindowStart;
task_db_tmp.timeWindowStop = row8.timeWindowStop;
task_db_tmp.sourceStatus = row8.sourceStatus;
task_db_tmp.sourceActivity = row8.sourceActivity;
task_db_tmp.sourceSkills = row8.sourceSkills;
task_db_tmp.sourceLabels = row8.sourceLabels;
task_db_tmp.sourceAttempts = row8.sourceAttempts;
task_db_tmp.sourceHasBeenPaid = row8.sourceHasBeenPaid;
task_db_tmp.sourceClosureDate = row8.sourceClosureDate;
task_db_tmp.sourcePaymentType = row8.sourcePaymentType;
task_db_tmp.sourceCollectedAmount = row8.sourceCollectedAmount;
task_db_tmp.metadataCodeArticle = row8.metadataCodeArticle ;
task_db_tmp.metadataTypePrestation = row8.metadataTypePrestation ;
task_db_tmp.sourceIssues = null;
task_db_tmp.sourceWhen = row8.sourceWhen;
task_db_tmp.sourceUpdated = row8.sourceUpdated;
task_db_tmp.sourceItems = row8.sourceItems;
task_db_tmp.sourceProducts = row8.sourceProducts;
task_db_tmp.sourceAnnouncement = row8.sourceAnnouncement;
task_db_tmp.sourceDate = ((String)globalMap.get("day_to_retrieve"));
task_db_tmp.sourceEndpoint = row8.sourceEndpoint;
task_db_tmp.taskId = row8.taskId;
task_db_tmp.sourceType = row8.sourceType;
task_db_tmp.sourceBy = row8.sourceBy;
task_db_tmp.sourceCategory = row8.sourceCategory;
task_db_tmp.sourceClient = row8.sourceClient;
task_db_tmp.createdBy_id = row8.createdBy_id;
task_db_tmp.createdByFirstName = row8.createdByFirstName;
task_db_tmp.createdByLastName = row8.createdByLastName;
task_db_tmp.createdByExternalId = row8.createdByExternalId;
task_db_tmp.createdById = row8.createdById;
task_db_tmp.dimensionsWeight = row8.dimensionsWeight;
task_db_tmp.dimensionsVolume = row8.dimensionsVolume;
task_db_tmp.sourceFlux = row8.sourceFlux;
task_db_tmp.sourceInstructions = row8.sourceInstructions;
task_db_tmp.sourcePlatform = row8.sourcePlatform;
task_db_tmp.sourcePlatformName = row8.sourcePlatformName;
task_db_tmp.sourceProgress = row8.sourceProgress;
task_db_tmp.sourceRoundName = row8.sourceRoundName;
task_db_tmp.sourceSequence = row8.sourceSequence;
task_db_tmp.sourceServiceTime = row8.sourceServiceTime;
task_db_tmp.sourceTrackingId = row8.sourceTrackingId;
task_db_tmp.sourceHub = row8.sourceHub;
task_db_tmp.sourceHubName = row8.sourceHubName;
task_db_tmp.sourceTargetFlux = row8.sourceTargetFlux;
task_db_tmp.sourceZone = row8.sourceZone;
task_db_tmp.sourceOrder = row8.sourceOrder;
task_db_tmp.sourceArriveTime = row8.sourceArriveTime;
task_db_tmp.sourceAssociated = row8.sourceAssociated;
task_db_tmp.sourceAssociatedName = row8.sourceAssociatedName;
task_db_tmp.driver_id = row8.driver_id;
task_db_tmp.driverFirstName = row8.driverFirstName;
task_db_tmp.driverLastName = row8.driverLastName;
task_db_tmp.driverExternalId = row8.driverExternalId;
task_db_tmp.driverId = row8.driverId;
task_db_tmp.sourceRound = row8.sourceRound;
task_db_tmp.sourceRoundColor = row8.sourceRoundColor;
task_db_tmp.sourceCompletedBy = row8.sourceCompletedBy;
task_db_tmp.sourceImagePath = row8.sourceImagePath;
task_db_tmp.sourceHasRejectedProducts = row8.sourceHasRejectedProducts;
task_db_tmp.source_Id = row8.source_Id;
task_db_tmp.metadataVehicule = row8.metadataVehicule ;
task_db_tmp.metadataFACTURATION = row8.metadataFACTURATION ;
task_db_tmp.metadataRouteGrenoble = row8.metadataRouteGrenoble ;
task_db_tmp.is_deleted = 0;
task_db_tmp.delay = row8.delay ;
task_db_tmp.failedReason = row8.failedReason ;
task_db_tmp.failedReasonCustom = row8.failedReasonCustom ;
task_db_tmp.isExpress = row8.isExpress != null && "true".equals(row8.isExpress.toLowerCase()) ? "true" : null ;
task_db = task_db_tmp;
log.debug("tMap_3 - Outputting the record " + count_task_db_tMap_3 + " of the output table 'task_db'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "task_db"
if(task_db != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"task_db","tMap_3","tMap_1","tMap","tDBOutput_1","\"urbantz_task\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("task_db - " + (task_db==null? "": task_db.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    if(task_db.sourceId == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, task_db.sourceId);
}

                    if(task_db.sourceLocationType == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, task_db.sourceLocationType);
}

                    if(task_db.sourceLocationGeometry == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, task_db.sourceLocationGeometry);
}

                    if(task_db.sourceAddressLines == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, task_db.sourceAddressLines);
}

                    if(task_db.sourceGeocodeScore == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(5, task_db.sourceGeocodeScore);
}

                    if(task_db.sourceCleanScore == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(6, task_db.sourceCleanScore);
}

                    if(task_db.sourceStreet == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, task_db.sourceStreet);
}

                    if(task_db.sourceCity == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, task_db.sourceCity);
}

                    if(task_db.sourceZip == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(9, task_db.sourceZip);
}

                    if(task_db.sourceCountry == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, task_db.sourceCountry);
}

                    if(task_db.sourceAddress == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, task_db.sourceAddress);
}

                    if(task_db.locationType == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, task_db.locationType);
}

                    if(task_db.locationGeometry == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, task_db.locationGeometry);
}

                    if(task_db.locationAddressLines == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(14, task_db.locationAddressLines);
}

                    if(task_db.locationGeocodeScore == null) {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(15, task_db.locationGeocodeScore);
}

                    if(task_db.locationCleanScore == null) {
pstmt_tDBOutput_1.setNull(16, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(16, task_db.locationCleanScore);
}

                    if(task_db.locationStreet == null) {
pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(17, task_db.locationStreet);
}

                    if(task_db.locationAddress == null) {
pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(18, task_db.locationAddress);
}

                    if(task_db.locationZip == null) {
pstmt_tDBOutput_1.setNull(19, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(19, task_db.locationZip);
}

                    if(task_db.locationCity == null) {
pstmt_tDBOutput_1.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(20, task_db.locationCity);
}

                    if(task_db.locationCountry == null) {
pstmt_tDBOutput_1.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(21, task_db.locationCountry);
}

                    if(task_db.locationOrigin == null) {
pstmt_tDBOutput_1.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(22, task_db.locationOrigin);
}

                    if(task_db.contactBuildingInfo == null) {
pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(23, task_db.contactBuildingInfo);
}

                    if(task_db.contactPerson == null) {
pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(24, task_db.contactPerson);
}

                    if(task_db.contactPhone == null) {
pstmt_tDBOutput_1.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(25, task_db.contactPhone);
}

                    if(task_db.contactEmail == null) {
pstmt_tDBOutput_1.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(26, task_db.contactEmail);
}

                    if(task_db.timeWindowStart == null) {
pstmt_tDBOutput_1.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(27, task_db.timeWindowStart);
}

                    if(task_db.timeWindowStop == null) {
pstmt_tDBOutput_1.setNull(28, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(28, task_db.timeWindowStop);
}

                    if(task_db.sourceStatus == null) {
pstmt_tDBOutput_1.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(29, task_db.sourceStatus);
}

                    if(task_db.sourceActivity == null) {
pstmt_tDBOutput_1.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(30, task_db.sourceActivity);
}

                    if(task_db.sourceSkills == null) {
pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(31, task_db.sourceSkills);
}

                    if(task_db.sourceLabels == null) {
pstmt_tDBOutput_1.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(32, task_db.sourceLabels);
}

                    if(task_db.sourceAttempts == null) {
pstmt_tDBOutput_1.setNull(33, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(33, task_db.sourceAttempts);
}

                    if(task_db.sourceHasBeenPaid == null) {
pstmt_tDBOutput_1.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(34, task_db.sourceHasBeenPaid);
}

                    if(task_db.sourceClosureDate == null) {
pstmt_tDBOutput_1.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(35, task_db.sourceClosureDate);
}

                    if(task_db.sourcePaymentType == null) {
pstmt_tDBOutput_1.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(36, task_db.sourcePaymentType);
}

                    if(task_db.sourceCollectedAmount == null) {
pstmt_tDBOutput_1.setNull(37, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(37, task_db.sourceCollectedAmount);
}

                    if(task_db.metadataCodeArticle == null) {
pstmt_tDBOutput_1.setNull(38, java.sql.Types.OTHER);
} else {pstmt_tDBOutput_1.setObject(38, task_db.metadataCodeArticle);
}

                    if(task_db.metadataTypePrestation == null) {
pstmt_tDBOutput_1.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(39, task_db.metadataTypePrestation);
}

                    if(task_db.sourceIssues == null) {
pstmt_tDBOutput_1.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(40, task_db.sourceIssues);
}

                    if(task_db.sourceWhen == null) {
pstmt_tDBOutput_1.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(41, task_db.sourceWhen);
}

                    if(task_db.sourceUpdated == null) {
pstmt_tDBOutput_1.setNull(42, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(42, task_db.sourceUpdated);
}

                    if(task_db.sourceItems == null) {
pstmt_tDBOutput_1.setNull(43, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(43, task_db.sourceItems);
}

                    if(task_db.sourceProducts == null) {
pstmt_tDBOutput_1.setNull(44, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(44, task_db.sourceProducts);
}

                    if(task_db.sourceAnnouncement == null) {
pstmt_tDBOutput_1.setNull(45, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(45, task_db.sourceAnnouncement);
}

                    if(task_db.sourceDate == null) {
pstmt_tDBOutput_1.setNull(46, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(46, task_db.sourceDate);
}

                    if(task_db.sourceEndpoint == null) {
pstmt_tDBOutput_1.setNull(47, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(47, task_db.sourceEndpoint);
}

                    if(task_db.taskId == null) {
pstmt_tDBOutput_1.setNull(48, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(48, task_db.taskId);
}

                    if(task_db.sourceType == null) {
pstmt_tDBOutput_1.setNull(49, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(49, task_db.sourceType);
}

                    if(task_db.sourceBy == null) {
pstmt_tDBOutput_1.setNull(50, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(50, task_db.sourceBy);
}

                    if(task_db.sourceCategory == null) {
pstmt_tDBOutput_1.setNull(51, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(51, task_db.sourceCategory);
}

                    if(task_db.sourceClient == null) {
pstmt_tDBOutput_1.setNull(52, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(52, task_db.sourceClient);
}

                    if(task_db.createdBy_id == null) {
pstmt_tDBOutput_1.setNull(53, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(53, task_db.createdBy_id);
}

                    if(task_db.createdByFirstName == null) {
pstmt_tDBOutput_1.setNull(54, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(54, task_db.createdByFirstName);
}

                    if(task_db.createdByLastName == null) {
pstmt_tDBOutput_1.setNull(55, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(55, task_db.createdByLastName);
}

                    if(task_db.createdByExternalId == null) {
pstmt_tDBOutput_1.setNull(56, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(56, task_db.createdByExternalId);
}

                    if(task_db.createdById == null) {
pstmt_tDBOutput_1.setNull(57, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(57, task_db.createdById);
}

                    if(task_db.dimensionsWeight == null) {
pstmt_tDBOutput_1.setNull(58, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(58, task_db.dimensionsWeight);
}

                    if(task_db.dimensionsVolume == null) {
pstmt_tDBOutput_1.setNull(59, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(59, task_db.dimensionsVolume);
}

                    if(task_db.sourceFlux == null) {
pstmt_tDBOutput_1.setNull(60, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(60, task_db.sourceFlux);
}

                    if(task_db.sourceInstructions == null) {
pstmt_tDBOutput_1.setNull(61, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(61, task_db.sourceInstructions);
}

                    if(task_db.sourcePlatform == null) {
pstmt_tDBOutput_1.setNull(62, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(62, task_db.sourcePlatform);
}

                    if(task_db.sourcePlatformName == null) {
pstmt_tDBOutput_1.setNull(63, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(63, task_db.sourcePlatformName);
}

                    if(task_db.sourceProgress == null) {
pstmt_tDBOutput_1.setNull(64, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(64, task_db.sourceProgress);
}

                    if(task_db.sourceRoundName == null) {
pstmt_tDBOutput_1.setNull(65, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(65, task_db.sourceRoundName);
}

                    if(task_db.sourceSequence == null) {
pstmt_tDBOutput_1.setNull(66, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(66, task_db.sourceSequence);
}

                    if(task_db.sourceServiceTime == null) {
pstmt_tDBOutput_1.setNull(67, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(67, task_db.sourceServiceTime);
}

                    if(task_db.sourceTrackingId == null) {
pstmt_tDBOutput_1.setNull(68, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(68, task_db.sourceTrackingId);
}

                    if(task_db.sourceHub == null) {
pstmt_tDBOutput_1.setNull(69, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(69, task_db.sourceHub);
}

                    if(task_db.sourceHubName == null) {
pstmt_tDBOutput_1.setNull(70, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(70, task_db.sourceHubName);
}

                    if(task_db.sourceTargetFlux == null) {
pstmt_tDBOutput_1.setNull(71, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(71, task_db.sourceTargetFlux);
}

                    if(task_db.sourceZone == null) {
pstmt_tDBOutput_1.setNull(72, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(72, task_db.sourceZone);
}

                    if(task_db.sourceOrder == null) {
pstmt_tDBOutput_1.setNull(73, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(73, task_db.sourceOrder);
}

                    if(task_db.sourceArriveTime == null) {
pstmt_tDBOutput_1.setNull(74, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(74, task_db.sourceArriveTime);
}

                    if(task_db.sourceAssociated == null) {
pstmt_tDBOutput_1.setNull(75, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(75, task_db.sourceAssociated);
}

                    if(task_db.sourceAssociatedName == null) {
pstmt_tDBOutput_1.setNull(76, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(76, task_db.sourceAssociatedName);
}

                    if(task_db.driver_id == null) {
pstmt_tDBOutput_1.setNull(77, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(77, task_db.driver_id);
}

                    if(task_db.driverFirstName == null) {
pstmt_tDBOutput_1.setNull(78, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(78, task_db.driverFirstName);
}

                    if(task_db.driverLastName == null) {
pstmt_tDBOutput_1.setNull(79, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(79, task_db.driverLastName);
}

                    if(task_db.driverExternalId == null) {
pstmt_tDBOutput_1.setNull(80, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(80, task_db.driverExternalId);
}

                    if(task_db.driverId == null) {
pstmt_tDBOutput_1.setNull(81, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(81, task_db.driverId);
}

                    if(task_db.sourceRound == null) {
pstmt_tDBOutput_1.setNull(82, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(82, task_db.sourceRound);
}

                    if(task_db.sourceRoundColor == null) {
pstmt_tDBOutput_1.setNull(83, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(83, task_db.sourceRoundColor);
}

                    if(task_db.sourceCompletedBy == null) {
pstmt_tDBOutput_1.setNull(84, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(84, task_db.sourceCompletedBy);
}

                    if(task_db.sourceImagePath == null) {
pstmt_tDBOutput_1.setNull(85, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(85, task_db.sourceImagePath);
}

                    if(task_db.sourceHasRejectedProducts == null) {
pstmt_tDBOutput_1.setNull(86, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_1.setBoolean(86, task_db.sourceHasRejectedProducts);
}

                    if(task_db.source_Id == null) {
pstmt_tDBOutput_1.setNull(87, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(87, task_db.source_Id);
}

                    if(task_db.metadataVehicule == null) {
pstmt_tDBOutput_1.setNull(88, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(88, task_db.metadataVehicule);
}

                    if(task_db.metadataFACTURATION == null) {
pstmt_tDBOutput_1.setNull(89, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(89, task_db.metadataFACTURATION);
}

                    if(task_db.metadataRouteGrenoble == null) {
pstmt_tDBOutput_1.setNull(90, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(90, task_db.metadataRouteGrenoble);
}

                    if(task_db.is_deleted == null) {
pstmt_tDBOutput_1.setNull(91, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(91, task_db.is_deleted);
}

                    if(task_db.delay == null) {
pstmt_tDBOutput_1.setNull(92, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(92, task_db.delay);
}

                    if(task_db.failedReason == null) {
pstmt_tDBOutput_1.setNull(93, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(93, task_db.failedReason);
}

                    if(task_db.failedReasonCustom == null) {
pstmt_tDBOutput_1.setNull(94, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(94, task_db.failedReasonCustom);
}

                    if(task_db.isExpress == null) {
pstmt_tDBOutput_1.setNull(95, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(95, task_db.isExpress);
}

                    if(task_db.sourceLocationType == null) {
pstmt_tDBOutput_1.setNull(96 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(96 + count_tDBOutput_1, task_db.sourceLocationType);
}

                    if(task_db.sourceLocationGeometry == null) {
pstmt_tDBOutput_1.setNull(97 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(97 + count_tDBOutput_1, task_db.sourceLocationGeometry);
}

                    if(task_db.sourceAddressLines == null) {
pstmt_tDBOutput_1.setNull(98 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(98 + count_tDBOutput_1, task_db.sourceAddressLines);
}

                    if(task_db.sourceGeocodeScore == null) {
pstmt_tDBOutput_1.setNull(99 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(99 + count_tDBOutput_1, task_db.sourceGeocodeScore);
}

                    if(task_db.sourceCleanScore == null) {
pstmt_tDBOutput_1.setNull(100 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(100 + count_tDBOutput_1, task_db.sourceCleanScore);
}

                    if(task_db.sourceStreet == null) {
pstmt_tDBOutput_1.setNull(101 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(101 + count_tDBOutput_1, task_db.sourceStreet);
}

                    if(task_db.sourceCity == null) {
pstmt_tDBOutput_1.setNull(102 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(102 + count_tDBOutput_1, task_db.sourceCity);
}

                    if(task_db.sourceZip == null) {
pstmt_tDBOutput_1.setNull(103 + count_tDBOutput_1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(103 + count_tDBOutput_1, task_db.sourceZip);
}

                    if(task_db.sourceCountry == null) {
pstmt_tDBOutput_1.setNull(104 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(104 + count_tDBOutput_1, task_db.sourceCountry);
}

                    if(task_db.sourceAddress == null) {
pstmt_tDBOutput_1.setNull(105 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(105 + count_tDBOutput_1, task_db.sourceAddress);
}

                    if(task_db.locationType == null) {
pstmt_tDBOutput_1.setNull(106 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(106 + count_tDBOutput_1, task_db.locationType);
}

                    if(task_db.locationGeometry == null) {
pstmt_tDBOutput_1.setNull(107 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(107 + count_tDBOutput_1, task_db.locationGeometry);
}

                    if(task_db.locationAddressLines == null) {
pstmt_tDBOutput_1.setNull(108 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(108 + count_tDBOutput_1, task_db.locationAddressLines);
}

                    if(task_db.locationGeocodeScore == null) {
pstmt_tDBOutput_1.setNull(109 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(109 + count_tDBOutput_1, task_db.locationGeocodeScore);
}

                    if(task_db.locationCleanScore == null) {
pstmt_tDBOutput_1.setNull(110 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(110 + count_tDBOutput_1, task_db.locationCleanScore);
}

                    if(task_db.locationStreet == null) {
pstmt_tDBOutput_1.setNull(111 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(111 + count_tDBOutput_1, task_db.locationStreet);
}

                    if(task_db.locationAddress == null) {
pstmt_tDBOutput_1.setNull(112 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(112 + count_tDBOutput_1, task_db.locationAddress);
}

                    if(task_db.locationZip == null) {
pstmt_tDBOutput_1.setNull(113 + count_tDBOutput_1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(113 + count_tDBOutput_1, task_db.locationZip);
}

                    if(task_db.locationCity == null) {
pstmt_tDBOutput_1.setNull(114 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(114 + count_tDBOutput_1, task_db.locationCity);
}

                    if(task_db.locationCountry == null) {
pstmt_tDBOutput_1.setNull(115 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(115 + count_tDBOutput_1, task_db.locationCountry);
}

                    if(task_db.locationOrigin == null) {
pstmt_tDBOutput_1.setNull(116 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(116 + count_tDBOutput_1, task_db.locationOrigin);
}

                    if(task_db.contactBuildingInfo == null) {
pstmt_tDBOutput_1.setNull(117 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(117 + count_tDBOutput_1, task_db.contactBuildingInfo);
}

                    if(task_db.contactPerson == null) {
pstmt_tDBOutput_1.setNull(118 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(118 + count_tDBOutput_1, task_db.contactPerson);
}

                    if(task_db.contactPhone == null) {
pstmt_tDBOutput_1.setNull(119 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(119 + count_tDBOutput_1, task_db.contactPhone);
}

                    if(task_db.contactEmail == null) {
pstmt_tDBOutput_1.setNull(120 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(120 + count_tDBOutput_1, task_db.contactEmail);
}

                    if(task_db.timeWindowStart == null) {
pstmt_tDBOutput_1.setNull(121 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(121 + count_tDBOutput_1, task_db.timeWindowStart);
}

                    if(task_db.timeWindowStop == null) {
pstmt_tDBOutput_1.setNull(122 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(122 + count_tDBOutput_1, task_db.timeWindowStop);
}

                    if(task_db.sourceStatus == null) {
pstmt_tDBOutput_1.setNull(123 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(123 + count_tDBOutput_1, task_db.sourceStatus);
}

                    if(task_db.sourceActivity == null) {
pstmt_tDBOutput_1.setNull(124 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(124 + count_tDBOutput_1, task_db.sourceActivity);
}

                    if(task_db.sourceSkills == null) {
pstmt_tDBOutput_1.setNull(125 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(125 + count_tDBOutput_1, task_db.sourceSkills);
}

                    if(task_db.sourceLabels == null) {
pstmt_tDBOutput_1.setNull(126 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(126 + count_tDBOutput_1, task_db.sourceLabels);
}

                    if(task_db.sourceAttempts == null) {
pstmt_tDBOutput_1.setNull(127 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(127 + count_tDBOutput_1, task_db.sourceAttempts);
}

                    if(task_db.sourceHasBeenPaid == null) {
pstmt_tDBOutput_1.setNull(128 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(128 + count_tDBOutput_1, task_db.sourceHasBeenPaid);
}

                    if(task_db.sourceClosureDate == null) {
pstmt_tDBOutput_1.setNull(129 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(129 + count_tDBOutput_1, task_db.sourceClosureDate);
}

                    if(task_db.sourcePaymentType == null) {
pstmt_tDBOutput_1.setNull(130 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(130 + count_tDBOutput_1, task_db.sourcePaymentType);
}

                    if(task_db.sourceCollectedAmount == null) {
pstmt_tDBOutput_1.setNull(131 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(131 + count_tDBOutput_1, task_db.sourceCollectedAmount);
}

                    if(task_db.metadataCodeArticle == null) {
pstmt_tDBOutput_1.setNull(132 + count_tDBOutput_1, java.sql.Types.OTHER);
} else {pstmt_tDBOutput_1.setObject(132 + count_tDBOutput_1, task_db.metadataCodeArticle);
}

                    if(task_db.metadataTypePrestation == null) {
pstmt_tDBOutput_1.setNull(133 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(133 + count_tDBOutput_1, task_db.metadataTypePrestation);
}

                    if(task_db.sourceIssues == null) {
pstmt_tDBOutput_1.setNull(134 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(134 + count_tDBOutput_1, task_db.sourceIssues);
}

                    if(task_db.sourceWhen == null) {
pstmt_tDBOutput_1.setNull(135 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(135 + count_tDBOutput_1, task_db.sourceWhen);
}

                    if(task_db.sourceUpdated == null) {
pstmt_tDBOutput_1.setNull(136 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(136 + count_tDBOutput_1, task_db.sourceUpdated);
}

                    if(task_db.sourceItems == null) {
pstmt_tDBOutput_1.setNull(137 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(137 + count_tDBOutput_1, task_db.sourceItems);
}

                    if(task_db.sourceProducts == null) {
pstmt_tDBOutput_1.setNull(138 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(138 + count_tDBOutput_1, task_db.sourceProducts);
}

                    if(task_db.sourceAnnouncement == null) {
pstmt_tDBOutput_1.setNull(139 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(139 + count_tDBOutput_1, task_db.sourceAnnouncement);
}

                    if(task_db.sourceDate == null) {
pstmt_tDBOutput_1.setNull(140 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(140 + count_tDBOutput_1, task_db.sourceDate);
}

                    if(task_db.sourceEndpoint == null) {
pstmt_tDBOutput_1.setNull(141 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(141 + count_tDBOutput_1, task_db.sourceEndpoint);
}

                    if(task_db.taskId == null) {
pstmt_tDBOutput_1.setNull(142 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(142 + count_tDBOutput_1, task_db.taskId);
}

                    if(task_db.sourceType == null) {
pstmt_tDBOutput_1.setNull(143 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(143 + count_tDBOutput_1, task_db.sourceType);
}

                    if(task_db.sourceBy == null) {
pstmt_tDBOutput_1.setNull(144 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(144 + count_tDBOutput_1, task_db.sourceBy);
}

                    if(task_db.sourceCategory == null) {
pstmt_tDBOutput_1.setNull(145 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(145 + count_tDBOutput_1, task_db.sourceCategory);
}

                    if(task_db.sourceClient == null) {
pstmt_tDBOutput_1.setNull(146 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(146 + count_tDBOutput_1, task_db.sourceClient);
}

                    if(task_db.createdBy_id == null) {
pstmt_tDBOutput_1.setNull(147 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(147 + count_tDBOutput_1, task_db.createdBy_id);
}

                    if(task_db.createdByFirstName == null) {
pstmt_tDBOutput_1.setNull(148 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(148 + count_tDBOutput_1, task_db.createdByFirstName);
}

                    if(task_db.createdByLastName == null) {
pstmt_tDBOutput_1.setNull(149 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(149 + count_tDBOutput_1, task_db.createdByLastName);
}

                    if(task_db.createdByExternalId == null) {
pstmt_tDBOutput_1.setNull(150 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(150 + count_tDBOutput_1, task_db.createdByExternalId);
}

                    if(task_db.createdById == null) {
pstmt_tDBOutput_1.setNull(151 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(151 + count_tDBOutput_1, task_db.createdById);
}

                    if(task_db.dimensionsWeight == null) {
pstmt_tDBOutput_1.setNull(152 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(152 + count_tDBOutput_1, task_db.dimensionsWeight);
}

                    if(task_db.dimensionsVolume == null) {
pstmt_tDBOutput_1.setNull(153 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(153 + count_tDBOutput_1, task_db.dimensionsVolume);
}

                    if(task_db.sourceFlux == null) {
pstmt_tDBOutput_1.setNull(154 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(154 + count_tDBOutput_1, task_db.sourceFlux);
}

                    if(task_db.sourceInstructions == null) {
pstmt_tDBOutput_1.setNull(155 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(155 + count_tDBOutput_1, task_db.sourceInstructions);
}

                    if(task_db.sourcePlatform == null) {
pstmt_tDBOutput_1.setNull(156 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(156 + count_tDBOutput_1, task_db.sourcePlatform);
}

                    if(task_db.sourcePlatformName == null) {
pstmt_tDBOutput_1.setNull(157 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(157 + count_tDBOutput_1, task_db.sourcePlatformName);
}

                    if(task_db.sourceProgress == null) {
pstmt_tDBOutput_1.setNull(158 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(158 + count_tDBOutput_1, task_db.sourceProgress);
}

                    if(task_db.sourceRoundName == null) {
pstmt_tDBOutput_1.setNull(159 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(159 + count_tDBOutput_1, task_db.sourceRoundName);
}

                    if(task_db.sourceSequence == null) {
pstmt_tDBOutput_1.setNull(160 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(160 + count_tDBOutput_1, task_db.sourceSequence);
}

                    if(task_db.sourceServiceTime == null) {
pstmt_tDBOutput_1.setNull(161 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(161 + count_tDBOutput_1, task_db.sourceServiceTime);
}

                    if(task_db.sourceTrackingId == null) {
pstmt_tDBOutput_1.setNull(162 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(162 + count_tDBOutput_1, task_db.sourceTrackingId);
}

                    if(task_db.sourceHub == null) {
pstmt_tDBOutput_1.setNull(163 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(163 + count_tDBOutput_1, task_db.sourceHub);
}

                    if(task_db.sourceHubName == null) {
pstmt_tDBOutput_1.setNull(164 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(164 + count_tDBOutput_1, task_db.sourceHubName);
}

                    if(task_db.sourceTargetFlux == null) {
pstmt_tDBOutput_1.setNull(165 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(165 + count_tDBOutput_1, task_db.sourceTargetFlux);
}

                    if(task_db.sourceZone == null) {
pstmt_tDBOutput_1.setNull(166 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(166 + count_tDBOutput_1, task_db.sourceZone);
}

                    if(task_db.sourceOrder == null) {
pstmt_tDBOutput_1.setNull(167 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(167 + count_tDBOutput_1, task_db.sourceOrder);
}

                    if(task_db.sourceArriveTime == null) {
pstmt_tDBOutput_1.setNull(168 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(168 + count_tDBOutput_1, task_db.sourceArriveTime);
}

                    if(task_db.sourceAssociated == null) {
pstmt_tDBOutput_1.setNull(169 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(169 + count_tDBOutput_1, task_db.sourceAssociated);
}

                    if(task_db.sourceAssociatedName == null) {
pstmt_tDBOutput_1.setNull(170 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(170 + count_tDBOutput_1, task_db.sourceAssociatedName);
}

                    if(task_db.driver_id == null) {
pstmt_tDBOutput_1.setNull(171 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(171 + count_tDBOutput_1, task_db.driver_id);
}

                    if(task_db.driverFirstName == null) {
pstmt_tDBOutput_1.setNull(172 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(172 + count_tDBOutput_1, task_db.driverFirstName);
}

                    if(task_db.driverLastName == null) {
pstmt_tDBOutput_1.setNull(173 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(173 + count_tDBOutput_1, task_db.driverLastName);
}

                    if(task_db.driverExternalId == null) {
pstmt_tDBOutput_1.setNull(174 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(174 + count_tDBOutput_1, task_db.driverExternalId);
}

                    if(task_db.driverId == null) {
pstmt_tDBOutput_1.setNull(175 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(175 + count_tDBOutput_1, task_db.driverId);
}

                    if(task_db.sourceRound == null) {
pstmt_tDBOutput_1.setNull(176 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(176 + count_tDBOutput_1, task_db.sourceRound);
}

                    if(task_db.sourceRoundColor == null) {
pstmt_tDBOutput_1.setNull(177 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(177 + count_tDBOutput_1, task_db.sourceRoundColor);
}

                    if(task_db.sourceCompletedBy == null) {
pstmt_tDBOutput_1.setNull(178 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(178 + count_tDBOutput_1, task_db.sourceCompletedBy);
}

                    if(task_db.sourceImagePath == null) {
pstmt_tDBOutput_1.setNull(179 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(179 + count_tDBOutput_1, task_db.sourceImagePath);
}

                    if(task_db.sourceHasRejectedProducts == null) {
pstmt_tDBOutput_1.setNull(180 + count_tDBOutput_1, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_1.setBoolean(180 + count_tDBOutput_1, task_db.sourceHasRejectedProducts);
}

                    if(task_db.source_Id == null) {
pstmt_tDBOutput_1.setNull(181 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(181 + count_tDBOutput_1, task_db.source_Id);
}

                    if(task_db.metadataVehicule == null) {
pstmt_tDBOutput_1.setNull(182 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(182 + count_tDBOutput_1, task_db.metadataVehicule);
}

                    if(task_db.metadataFACTURATION == null) {
pstmt_tDBOutput_1.setNull(183 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(183 + count_tDBOutput_1, task_db.metadataFACTURATION);
}

                    if(task_db.metadataRouteGrenoble == null) {
pstmt_tDBOutput_1.setNull(184 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(184 + count_tDBOutput_1, task_db.metadataRouteGrenoble);
}

                    if(task_db.is_deleted == null) {
pstmt_tDBOutput_1.setNull(185 + count_tDBOutput_1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(185 + count_tDBOutput_1, task_db.is_deleted);
}

                    if(task_db.delay == null) {
pstmt_tDBOutput_1.setNull(186 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(186 + count_tDBOutput_1, task_db.delay);
}

                    if(task_db.failedReason == null) {
pstmt_tDBOutput_1.setNull(187 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(187 + count_tDBOutput_1, task_db.failedReason);
}

                    if(task_db.failedReasonCustom == null) {
pstmt_tDBOutput_1.setNull(188 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(188 + count_tDBOutput_1, task_db.failedReasonCustom);
}

                    if(task_db.isExpress == null) {
pstmt_tDBOutput_1.setNull(189 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(189 + count_tDBOutput_1, task_db.isExpress);
}

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "task_db"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 process_data_end ] stop
 */

} // End of branch "row8"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		

 



/**
 * [tExtractJSONFields_4 process_data_end ] stop
 */




	
	/**
	 * [tExtractJSONFields_3 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_3","Extract_Item_Fields_From_Task","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

            if(row4.Task!=null){// C_01
                jsonStr_tExtractJSONFields_3 = row4.Task.toString();
   
row7 = null;

	

String loopPath_tExtractJSONFields_3 = "$.items[*]";
java.util.List<Object> resultset_tExtractJSONFields_3 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_3 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_3 = null;
try {
	document_tExtractJSONFields_3 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_3);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(loopPath_tExtractJSONFields_3);
	Object result_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(compiledLoopPath_tExtractJSONFields_3,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_3 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_3 = (net.minidev.json.JSONArray) result_tExtractJSONFields_3;
	} else {
		resultset_tExtractJSONFields_3.add(result_tExtractJSONFields_3);
	}
	
	isStructError_tExtractJSONFields_3 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",ex_tExtractJSONFields_3.getMessage());
		log.error("tExtractJSONFields_3 - " + ex_tExtractJSONFields_3.getMessage());
		System.err.println(ex_tExtractJSONFields_3.getMessage());
}

String jsonPath_tExtractJSONFields_3 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_3 = null;

Object value_tExtractJSONFields_3 = null;

Object root_tExtractJSONFields_3 = null;
for(int i_tExtractJSONFields_3=0; isStructError_tExtractJSONFields_3 || (i_tExtractJSONFields_3 < resultset_tExtractJSONFields_3.size());i_tExtractJSONFields_3++){
	if(!isStructError_tExtractJSONFields_3){
		Object row_tExtractJSONFields_3 = resultset_tExtractJSONFields_3.get(i_tExtractJSONFields_3);
            row7 = null;
	row7 = new row7Struct();
	nb_line_tExtractJSONFields_3++;
	try {
		jsonPath_tExtractJSONFields_3 = "_id";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.itemId = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.itemId = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "damaged.confirmed";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row7.confirmed = ParserUtils.parseTo_Boolean(value_tExtractJSONFields_3.toString());
				} else {
					row7.confirmed = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.confirmed = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "damaged.pictures[*]";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.pictures___ = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.pictures___ = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "status";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.status = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.status = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "quantity";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row7.quantity = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row7.quantity = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.quantity = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "labels[*]";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.labels = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.labels = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "skills[*]";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.skills = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.skills = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "lastOfflineUpdatedAt";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.lastOfflineUpdatedAt = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.lastOfflineUpdatedAt = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "name";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.name = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.name = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "type";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.type = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.type = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "barcode";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.barcode = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.barcode = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "barcodeEncoding";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.barcodeEncoding = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.barcodeEncoding = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "dimensions.weight";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row7.weight = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row7.weight = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.weight = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "dimensions.volume";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row7.volume = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row7.volume = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.volume = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "$._id";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.taskId = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.taskId = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "reference";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row7.reference = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row7.reference = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",ex_tExtractJSONFields_3.getMessage());
			log.error("tExtractJSONFields_3 - " + ex_tExtractJSONFields_3.getMessage());
		    System.err.println(ex_tExtractJSONFields_3.getMessage());
		    row7 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_3 = false;
	
	log.debug("tExtractJSONFields_3 - Extracting the record " + nb_line_tExtractJSONFields_3 + ".");
//}


 


	tos_count_tExtractJSONFields_3++;

/**
 * [tExtractJSONFields_3 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		

 



/**
 * [tExtractJSONFields_3 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tExtractJSONFields_3","Extract_Item_Fields_From_Task","tExtractJSONFields","tMap_2","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_2 = false;
		boolean mainRowRejected_tMap_2 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

out2 = null;


// # Output table : 'out2'
count_out2_tMap_2++;

out2_tmp.itemId = row7.itemId ;
out2_tmp.confirmed = row7.confirmed ;
out2_tmp.pictures___ = row7.pictures___ ;
out2_tmp.status = row7.status ;
out2_tmp.quantity = row7.quantity ;
out2_tmp.labels = row7.labels ;
out2_tmp.skills = row7.skills ;
out2_tmp.lastOfflineUpdatedAt = row7.lastOfflineUpdatedAt ;
out2_tmp.name = row7.name ;
out2_tmp.type = row7.type ;
out2_tmp.barcode = row7.barcode ;
out2_tmp.barcodeEncoding = row7.barcodeEncoding ;
out2_tmp.weight = row7.weight ;
out2_tmp.volume = row7.volume ;
out2_tmp.taskId = row7.taskId ;
out2_tmp.reference = row7.reference ;
out2 = out2_tmp;
log.debug("tMap_2 - Outputting the record " + count_out2_tMap_2 + " of the output table 'out2'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "out2"
if(out2 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"out2","tMap_2","tMap_1","tMap","tLogRow_2","tLogRow_2","tDummyRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("out2 - " + (out2==null? "": out2.toLogString()));
    			}
    		

 
     row9 = out2;


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tLogRow_2","tLogRow_2","tDummyRow","tDBOutput_2","\"urbantz_item\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    if(row9.itemId == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, row9.itemId);
}

                    if(row9.confirmed == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_2.setBoolean(2, row9.confirmed);
}

                    if(row9.pictures___ == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row9.pictures___);
}

                    if(row9.status == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, row9.status);
}

                    if(row9.quantity == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(5, row9.quantity);
}

                    if(row9.labels == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, row9.labels);
}

                    if(row9.skills == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, row9.skills);
}

                    if(row9.lastOfflineUpdatedAt == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(8, row9.lastOfflineUpdatedAt);
}

                    if(row9.name == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, row9.name);
}

                    if(row9.type == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10, row9.type);
}

                    if(row9.barcode == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, row9.barcode);
}

                    if(row9.barcodeEncoding == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, row9.barcodeEncoding);
}

                    if(row9.weight == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(13, row9.weight);
}

                    if(row9.volume == null) {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(14, row9.volume);
}

                    if(row9.taskId == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(15, row9.taskId);
}

                    if(row9.reference == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(16, row9.reference);
}

                    if(row9.confirmed == null) {
pstmt_tDBOutput_2.setNull(17 + count_tDBOutput_2, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_2.setBoolean(17 + count_tDBOutput_2, row9.confirmed);
}

                    if(row9.pictures___ == null) {
pstmt_tDBOutput_2.setNull(18 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(18 + count_tDBOutput_2, row9.pictures___);
}

                    if(row9.status == null) {
pstmt_tDBOutput_2.setNull(19 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(19 + count_tDBOutput_2, row9.status);
}

                    if(row9.quantity == null) {
pstmt_tDBOutput_2.setNull(20 + count_tDBOutput_2, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(20 + count_tDBOutput_2, row9.quantity);
}

                    if(row9.labels == null) {
pstmt_tDBOutput_2.setNull(21 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(21 + count_tDBOutput_2, row9.labels);
}

                    if(row9.skills == null) {
pstmt_tDBOutput_2.setNull(22 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(22 + count_tDBOutput_2, row9.skills);
}

                    if(row9.lastOfflineUpdatedAt == null) {
pstmt_tDBOutput_2.setNull(23 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(23 + count_tDBOutput_2, row9.lastOfflineUpdatedAt);
}

                    if(row9.name == null) {
pstmt_tDBOutput_2.setNull(24 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(24 + count_tDBOutput_2, row9.name);
}

                    if(row9.type == null) {
pstmt_tDBOutput_2.setNull(25 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(25 + count_tDBOutput_2, row9.type);
}

                    if(row9.barcode == null) {
pstmt_tDBOutput_2.setNull(26 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(26 + count_tDBOutput_2, row9.barcode);
}

                    if(row9.barcodeEncoding == null) {
pstmt_tDBOutput_2.setNull(27 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(27 + count_tDBOutput_2, row9.barcodeEncoding);
}

                    if(row9.weight == null) {
pstmt_tDBOutput_2.setNull(28 + count_tDBOutput_2, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(28 + count_tDBOutput_2, row9.weight);
}

                    if(row9.volume == null) {
pstmt_tDBOutput_2.setNull(29 + count_tDBOutput_2, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(29 + count_tDBOutput_2, row9.volume);
}

                    if(row9.reference == null) {
pstmt_tDBOutput_2.setNull(30 + count_tDBOutput_2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(30 + count_tDBOutput_2, row9.reference);
}

            int count_on_duplicate_key_tDBOutput_2 = 0;
            try {
                int processedCount_tDBOutput_2 = pstmt_tDBOutput_2.executeUpdate();
                count_on_duplicate_key_tDBOutput_2 += processedCount_tDBOutput_2;
                rowsToCommitCount_tDBOutput_2 += processedCount_tDBOutput_2;
                nb_line_tDBOutput_2++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_2_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_2 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_2 == 1) {
                insertedCount_tDBOutput_2 += count_on_duplicate_key_tDBOutput_2;
            } else {
                insertedCount_tDBOutput_2 += 1;
                updatedCount_tDBOutput_2 += count_on_duplicate_key_tDBOutput_2 - 1;
            }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "out2"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row7"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		

 



/**
 * [tExtractJSONFields_3 process_data_end ] stop
 */



	
	/**
	 * [tReplicate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_end ] stop
 */

} // End of branch "row2"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tRESTClient_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 process_data_end ] stop
 */



	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */

	
	/**
	 * [tRESTClient_1 end ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	


if (globalMap.get("tRESTClient_1_NB_LINE") == null) {
	globalMap.put("tRESTClient_1_NB_LINE", 1);
}

// [tRESTCliend_end]
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tJava_1","tJava_1","tJava","tRESTClient_1","tRESTClient_1","tRESTClient","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tRESTClient_1", true);
end_Hash.put("tRESTClient_1", System.currentTimeMillis());




/**
 * [tRESTClient_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);
	log.debug("tExtractJSONFields_1 - Extracted records count: " + nb_line_tExtractJSONFields_1 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tRESTClient_1","tRESTClient_1","tRESTClient","tExtractJSONFields_1","Extract_Task_From_List","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());




/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tReplicate_1 end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tExtractJSONFields_1","Extract_Task_From_List","tExtractJSONFields","tReplicate_1","tReplicate_1","tReplicate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Done.") );

ok_Hash.put("tReplicate_1", true);
end_Hash.put("tReplicate_1", System.currentTimeMillis());

   			if (1==1) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				tJava_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tReplicate_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_4 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		
   globalMap.put("tExtractJSONFields_4_NB_LINE", nb_line_tExtractJSONFields_4);
	log.debug("tExtractJSONFields_4 - Extracted records count: " + nb_line_tExtractJSONFields_4 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_4","Extract_Task_Fields","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_4", true);
end_Hash.put("tExtractJSONFields_4", System.currentTimeMillis());




/**
 * [tExtractJSONFields_4 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'task_db': " + count_task_db_tMap_3 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tExtractJSONFields_4","Extract_Task_Fields","tExtractJSONFields","tMap_3","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Done.") );

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"task_db",2,0,
			 			"tMap_3","tMap_1","tMap","tDBOutput_1","\"urbantz_task\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */










	
	/**
	 * [tExtractJSONFields_3 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		
   globalMap.put("tExtractJSONFields_3_NB_LINE", nb_line_tExtractJSONFields_3);
	log.debug("tExtractJSONFields_3 - Extracted records count: " + nb_line_tExtractJSONFields_3 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_3","Extract_Item_Fields_From_Task","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_3", true);
end_Hash.put("tExtractJSONFields_3", System.currentTimeMillis());




/**
 * [tExtractJSONFields_3 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'out2': " + count_out2_tMap_2 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tExtractJSONFields_3","Extract_Item_Fields_From_Task","tExtractJSONFields","tMap_2","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out2",2,0,
			 			"tMap_2","tMap_1","tMap","tLogRow_2","tLogRow_2","tDummyRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		



		

		if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_2", true);
	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tLogRow_2","tLogRow_2","tDummyRow","tDBOutput_2","\"urbantz_item\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */





















						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tJava_1);
						}				
					




	
	/**
	 * [tLoop_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 process_data_end ] stop
 */
	
	/**
	 * [tLoop_1 end ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	




i++;;


}


 
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + ("Done.") );

ok_Hash.put("tLoop_1", true);
end_Hash.put("tLoop_1", System.currentTimeMillis());




/**
 * [tLoop_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLoop_1 finally ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 finally ] stop
 */

	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 finally ] stop
 */

	
	/**
	 * [tRESTClient_1 finally ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Task_From_List";
		

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tReplicate_1 finally ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_4 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Task_Fields";
		

 



/**
 * [tExtractJSONFields_4 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";
	
	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_task\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */










	
	/**
	 * [tExtractJSONFields_3 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Item_Fields_From_Task";
		

 



/**
 * [tExtractJSONFields_3 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"urbantz_item\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */
























				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLoop_1_SUBPROCESS_STATE", 1);
	}
	


public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_2");
		org.slf4j.MDC.put("_subJobPid", "pXmFGJ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";
	
	
		int tos_count_tJava_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_2", "tJava_2", "tJava");
				talendJobLogProcess(globalMap);
			}
			



globalMap.put("numberOfElementsInPage", ((Integer)globalMap.get("tExtractJSONFields_1_NB_LINE")));
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "9RKAT3_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tWarn_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "XPoh8N_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "zIHEpY_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ECOLOTRANS_URBANTZ_TASKS_IMPORT ECOLOTRANS_URBANTZ_TASKS_IMPORTClass = new ECOLOTRANS_URBANTZ_TASKS_IMPORT();

        int exitCode = ECOLOTRANS_URBANTZ_TASKS_IMPORTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_TASKS_IMPORT' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ECOLOTRANS_URBANTZ_TASKS_IMPORT' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_6dAgwJiwEeyH_6mQlKsMew");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-03-05T16:44:22.270556400Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ECOLOTRANS_URBANTZ_TASKS_IMPORT.class.getClassLoader().getResourceAsStream("atelier_facturation/ecolotrans_urbantz_tasks_import_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ECOLOTRANS_URBANTZ_TASKS_IMPORT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Billing_Comptabilite_File", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_File") == null) {
                            context.Billing_Comptabilite_File = null;
                        } else {
                            context.Billing_Comptabilite_File=(String) context.getProperty("Billing_Comptabilite_File");
                        }
                        context.setContextType("Billing_Comptabilite_Folder", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_Folder") == null) {
                            context.Billing_Comptabilite_Folder = null;
                        } else {
                            context.Billing_Comptabilite_Folder=(String) context.getProperty("Billing_Comptabilite_Folder");
                        }
                        context.setContextType("Billing_Distant_Rep", "id_String");
                        if(context.getStringValue("Billing_Distant_Rep") == null) {
                            context.Billing_Distant_Rep = null;
                        } else {
                            context.Billing_Distant_Rep=(String) context.getProperty("Billing_Distant_Rep");
                        }
                        context.setContextType("Billing_File_Masque", "id_String");
                        if(context.getStringValue("Billing_File_Masque") == null) {
                            context.Billing_File_Masque = null;
                        } else {
                            context.Billing_File_Masque=(String) context.getProperty("Billing_File_Masque");
                        }
                        context.setContextType("Billing_Local_Rep", "id_String");
                        if(context.getStringValue("Billing_Local_Rep") == null) {
                            context.Billing_Local_Rep = null;
                        } else {
                            context.Billing_Local_Rep=(String) context.getProperty("Billing_Local_Rep");
                        }
                        context.setContextType("Billing_Name", "id_String");
                        if(context.getStringValue("Billing_Name") == null) {
                            context.Billing_Name = null;
                        } else {
                            context.Billing_Name=(String) context.getProperty("Billing_Name");
                        }
                        context.setContextType("Billing_Start_Number", "id_Integer");
                        if(context.getStringValue("Billing_Start_Number") == null) {
                            context.Billing_Start_Number = null;
                        } else {
                            try{
                                context.Billing_Start_Number=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Billing_Start_Number"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_Start_Number", e.getMessage()));
                                context.Billing_Start_Number=null;
                            }
                        }
                        context.setContextType("Billing_TVA_default_value", "id_Float");
                        if(context.getStringValue("Billing_TVA_default_value") == null) {
                            context.Billing_TVA_default_value = null;
                        } else {
                            try{
                                context.Billing_TVA_default_value=routines.system.ParserUtils.parseTo_Float (context.getProperty("Billing_TVA_default_value"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_TVA_default_value", e.getMessage()));
                                context.Billing_TVA_default_value=null;
                            }
                        }
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("FTP_DistantRep", "id_Directory");
                        if(context.getStringValue("FTP_DistantRep") == null) {
                            context.FTP_DistantRep = null;
                        } else {
                            context.FTP_DistantRep=(String) context.getProperty("FTP_DistantRep");
                        }
                        context.setContextType("FTP_FileMasque", "id_String");
                        if(context.getStringValue("FTP_FileMasque") == null) {
                            context.FTP_FileMasque = null;
                        } else {
                            context.FTP_FileMasque=(String) context.getProperty("FTP_FileMasque");
                        }
                        context.setContextType("FTP_Hote", "id_String");
                        if(context.getStringValue("FTP_Hote") == null) {
                            context.FTP_Hote = null;
                        } else {
                            context.FTP_Hote=(String) context.getProperty("FTP_Hote");
                        }
                        context.setContextType("FTP_Password", "id_Password");
                        if(context.getStringValue("FTP_Password") == null) {
                            context.FTP_Password = null;
                        } else {
                            String pwd_FTP_Password_value = context.getProperty("FTP_Password");
                            context.FTP_Password = null;
                            if(pwd_FTP_Password_value!=null) {
                                if(context_param.containsKey("FTP_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.FTP_Password = pwd_FTP_Password_value;
                                } else if (!pwd_FTP_Password_value.isEmpty()) {
                                    try {
                                        context.FTP_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_FTP_Password_value);
                                        context.put("FTP_Password",context.FTP_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("FTP_Port", "id_Integer");
                        if(context.getStringValue("FTP_Port") == null) {
                            context.FTP_Port = null;
                        } else {
                            try{
                                context.FTP_Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("FTP_Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "FTP_Port", e.getMessage()));
                                context.FTP_Port=null;
                            }
                        }
                        context.setContextType("FTP_User", "id_String");
                        if(context.getStringValue("FTP_User") == null) {
                            context.FTP_User = null;
                        } else {
                            context.FTP_User=(String) context.getProperty("FTP_User");
                        }
                        context.setContextType("keyStore_file_name", "id_String");
                        if(context.getStringValue("keyStore_file_name") == null) {
                            context.keyStore_file_name = null;
                        } else {
                            context.keyStore_file_name=(String) context.getProperty("keyStore_file_name");
                        }
                        context.setContextType("KeyStore_Repo", "id_String");
                        if(context.getStringValue("KeyStore_Repo") == null) {
                            context.KeyStore_Repo = null;
                        } else {
                            context.KeyStore_Repo=(String) context.getProperty("KeyStore_Repo");
                        }
                        context.setContextType("mail_password", "id_Password");
                        if(context.getStringValue("mail_password") == null) {
                            context.mail_password = null;
                        } else {
                            String pwd_mail_password_value = context.getProperty("mail_password");
                            context.mail_password = null;
                            if(pwd_mail_password_value!=null) {
                                if(context_param.containsKey("mail_password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.mail_password = pwd_mail_password_value;
                                } else if (!pwd_mail_password_value.isEmpty()) {
                                    try {
                                        context.mail_password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_mail_password_value);
                                        context.put("mail_password",context.mail_password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("send_mail_from", "id_String");
                        if(context.getStringValue("send_mail_from") == null) {
                            context.send_mail_from = null;
                        } else {
                            context.send_mail_from=(String) context.getProperty("send_mail_from");
                        }
                        context.setContextType("send_mail_to", "id_String");
                        if(context.getStringValue("send_mail_to") == null) {
                            context.send_mail_to = null;
                        } else {
                            context.send_mail_to=(String) context.getProperty("send_mail_to");
                        }
                        context.setContextType("send_to_second_mail", "id_String");
                        if(context.getStringValue("send_to_second_mail") == null) {
                            context.send_to_second_mail = null;
                        } else {
                            context.send_to_second_mail=(String) context.getProperty("send_to_second_mail");
                        }
                        context.setContextType("send_to_third_mail", "id_String");
                        if(context.getStringValue("send_to_third_mail") == null) {
                            context.send_to_third_mail = null;
                        } else {
                            context.send_to_third_mail=(String) context.getProperty("send_to_third_mail");
                        }
                        context.setContextType("Clients_Masque", "id_String");
                        if(context.getStringValue("Clients_Masque") == null) {
                            context.Clients_Masque = null;
                        } else {
                            context.Clients_Masque=(String) context.getProperty("Clients_Masque");
                        }
                        context.setContextType("Code_client_masque", "id_String");
                        if(context.getStringValue("Code_client_masque") == null) {
                            context.Code_client_masque = null;
                        } else {
                            context.Code_client_masque=(String) context.getProperty("Code_client_masque");
                        }
                        context.setContextType("Command_Logistic_Invalid_Date", "id_String");
                        if(context.getStringValue("Command_Logistic_Invalid_Date") == null) {
                            context.Command_Logistic_Invalid_Date = null;
                        } else {
                            context.Command_Logistic_Invalid_Date=(String) context.getProperty("Command_Logistic_Invalid_Date");
                        }
                        context.setContextType("Command_Logistic_Masque", "id_String");
                        if(context.getStringValue("Command_Logistic_Masque") == null) {
                            context.Command_Logistic_Masque = null;
                        } else {
                            context.Command_Logistic_Masque=(String) context.getProperty("Command_Logistic_Masque");
                        }
                        context.setContextType("Command_Transport_Masque", "id_String");
                        if(context.getStringValue("Command_Transport_Masque") == null) {
                            context.Command_Transport_Masque = null;
                        } else {
                            context.Command_Transport_Masque=(String) context.getProperty("Command_Transport_Masque");
                        }
                        context.setContextType("Command_Transport_Masque_Express", "id_String");
                        if(context.getStringValue("Command_Transport_Masque_Express") == null) {
                            context.Command_Transport_Masque_Express = null;
                        } else {
                            context.Command_Transport_Masque_Express=(String) context.getProperty("Command_Transport_Masque_Express");
                        }
                        context.setContextType("Holiday_Days_Masque", "id_String");
                        if(context.getStringValue("Holiday_Days_Masque") == null) {
                            context.Holiday_Days_Masque = null;
                        } else {
                            context.Holiday_Days_Masque=(String) context.getProperty("Holiday_Days_Masque");
                        }
                        context.setContextType("Livraisons_Exception", "id_String");
                        if(context.getStringValue("Livraisons_Exception") == null) {
                            context.Livraisons_Exception = null;
                        } else {
                            context.Livraisons_Exception=(String) context.getProperty("Livraisons_Exception");
                        }
                        context.setContextType("Livraisons_Masque", "id_String");
                        if(context.getStringValue("Livraisons_Masque") == null) {
                            context.Livraisons_Masque = null;
                        } else {
                            context.Livraisons_Masque=(String) context.getProperty("Livraisons_Masque");
                        }
                        context.setContextType("Livraisons_Ok", "id_String");
                        if(context.getStringValue("Livraisons_Ok") == null) {
                            context.Livraisons_Ok = null;
                        } else {
                            context.Livraisons_Ok=(String) context.getProperty("Livraisons_Ok");
                        }
                        context.setContextType("Tarification_Logistic_Masque", "id_String");
                        if(context.getStringValue("Tarification_Logistic_Masque") == null) {
                            context.Tarification_Logistic_Masque = null;
                        } else {
                            context.Tarification_Logistic_Masque=(String) context.getProperty("Tarification_Logistic_Masque");
                        }
                        context.setContextType("Tarification_Transport_Masque", "id_String");
                        if(context.getStringValue("Tarification_Transport_Masque") == null) {
                            context.Tarification_Transport_Masque = null;
                        } else {
                            context.Tarification_Transport_Masque=(String) context.getProperty("Tarification_Transport_Masque");
                        }
                        context.setContextType("Tournee_Masque", "id_String");
                        if(context.getStringValue("Tournee_Masque") == null) {
                            context.Tournee_Masque = null;
                        } else {
                            context.Tournee_Masque=(String) context.getProperty("Tournee_Masque");
                        }
                        context.setContextType("TVA_Exceptions", "id_String");
                        if(context.getStringValue("TVA_Exceptions") == null) {
                            context.TVA_Exceptions = null;
                        } else {
                            context.TVA_Exceptions=(String) context.getProperty("TVA_Exceptions");
                        }
                        context.setContextType("Backup", "id_String");
                        if(context.getStringValue("Backup") == null) {
                            context.Backup = null;
                        } else {
                            context.Backup=(String) context.getProperty("Backup");
                        }
                        context.setContextType("Server_Clean", "id_String");
                        if(context.getStringValue("Server_Clean") == null) {
                            context.Server_Clean = null;
                        } else {
                            context.Server_Clean=(String) context.getProperty("Server_Clean");
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Server_Out", "id_String");
                        if(context.getStringValue("Server_Out") == null) {
                            context.Server_Out = null;
                        } else {
                            context.Server_Out=(String) context.getProperty("Server_Out");
                        }
                        context.setContextType("Cleaning_Reject_Logistic_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Logistic_price_is_zero") == null) {
                            context.Cleaning_Reject_Logistic_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Logistic_price_is_zero=(String) context.getProperty("Cleaning_Reject_Logistic_price_is_zero");
                        }
                        context.setContextType("Cleaning_Reject_Rep", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Rep") == null) {
                            context.Cleaning_Reject_Rep = null;
                        } else {
                            context.Cleaning_Reject_Rep=(String) context.getProperty("Cleaning_Reject_Rep");
                        }
                        context.setContextType("Cleaning_Reject_Transport_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Transport_price_is_zero") == null) {
                            context.Cleaning_Reject_Transport_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Transport_price_is_zero=(String) context.getProperty("Cleaning_Reject_Transport_price_is_zero");
                        }
                        context.setContextType("Cleaning_Transport_no_PostalCode", "id_String");
                        if(context.getStringValue("Cleaning_Transport_no_PostalCode") == null) {
                            context.Cleaning_Transport_no_PostalCode = null;
                        } else {
                            context.Cleaning_Transport_no_PostalCode=(String) context.getProperty("Cleaning_Transport_no_PostalCode");
                        }
                        context.setContextType("Csv_File_Masque", "id_String");
                        if(context.getStringValue("Csv_File_Masque") == null) {
                            context.Csv_File_Masque = null;
                        } else {
                            context.Csv_File_Masque=(String) context.getProperty("Csv_File_Masque");
                        }
                        context.setContextType("Diagnostic_Reject_Command_Error", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Command_Error") == null) {
                            context.Diagnostic_Reject_Command_Error = null;
                        } else {
                            context.Diagnostic_Reject_Command_Error=(String) context.getProperty("Diagnostic_Reject_Command_Error");
                        }
                        context.setContextType("Diagnostic_Reject_Day_Not_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Day_Not_Ok") == null) {
                            context.Diagnostic_Reject_Day_Not_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Day_Not_Ok=(String) context.getProperty("Diagnostic_Reject_Day_Not_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Postal_Code_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Postal_Code_Ok") == null) {
                            context.Diagnostic_Reject_Postal_Code_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Postal_Code_Ok=(String) context.getProperty("Diagnostic_Reject_Postal_Code_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Rep", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Rep") == null) {
                            context.Diagnostic_Reject_Rep = null;
                        } else {
                            context.Diagnostic_Reject_Rep=(String) context.getProperty("Diagnostic_Reject_Rep");
                        }
                        context.setContextType("Excel_File_Masque", "id_String");
                        if(context.getStringValue("Excel_File_Masque") == null) {
                            context.Excel_File_Masque = null;
                        } else {
                            context.Excel_File_Masque=(String) context.getProperty("Excel_File_Masque");
                        }
                        context.setContextType("Migration_Billing_Not_Ok", "id_String");
                        if(context.getStringValue("Migration_Billing_Not_Ok") == null) {
                            context.Migration_Billing_Not_Ok = null;
                        } else {
                            context.Migration_Billing_Not_Ok=(String) context.getProperty("Migration_Billing_Not_Ok");
                        }
                        context.setContextType("Reject_Client_File", "id_String");
                        if(context.getStringValue("Reject_Client_File") == null) {
                            context.Reject_Client_File = null;
                        } else {
                            context.Reject_Client_File=(String) context.getProperty("Reject_Client_File");
                        }
                        context.setContextType("Reject_Client_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Client_Local_Rep") == null) {
                            context.Reject_Client_Local_Rep = null;
                        } else {
                            context.Reject_Client_Local_Rep=(String) context.getProperty("Reject_Client_Local_Rep");
                        }
                        context.setContextType("Reject_Command_Logisitc_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Logisitc_Code_Client") == null) {
                            context.Reject_Command_Logisitc_Code_Client = null;
                        } else {
                            context.Reject_Command_Logisitc_Code_Client=(String) context.getProperty("Reject_Command_Logisitc_Code_Client");
                        }
                        context.setContextType("Reject_Command_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Transport_Code_Client") == null) {
                            context.Reject_Command_Transport_Code_Client = null;
                        } else {
                            context.Reject_Command_Transport_Code_Client=(String) context.getProperty("Reject_Command_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Distant_Rep", "id_String");
                        if(context.getStringValue("Reject_Distant_Rep") == null) {
                            context.Reject_Distant_Rep = null;
                        } else {
                            context.Reject_Distant_Rep=(String) context.getProperty("Reject_Distant_Rep");
                        }
                        context.setContextType("Reject_Duplicated_Client_File", "id_String");
                        if(context.getStringValue("Reject_Duplicated_Client_File") == null) {
                            context.Reject_Duplicated_Client_File = null;
                        } else {
                            context.Reject_Duplicated_Client_File=(String) context.getProperty("Reject_Duplicated_Client_File");
                        }
                        context.setContextType("Reject_Migration_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Migration_Local_Rep") == null) {
                            context.Reject_Migration_Local_Rep = null;
                        } else {
                            context.Reject_Migration_Local_Rep=(String) context.getProperty("Reject_Migration_Local_Rep");
                        }
                        context.setContextType("Reject_Not_Complet_Client", "id_String");
                        if(context.getStringValue("Reject_Not_Complet_Client") == null) {
                            context.Reject_Not_Complet_Client = null;
                        } else {
                            context.Reject_Not_Complet_Client=(String) context.getProperty("Reject_Not_Complet_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Local_Rep") == null) {
                            context.Reject_Service_Detail_Local_Rep = null;
                        } else {
                            context.Reject_Service_Detail_Local_Rep=(String) context.getProperty("Reject_Service_Detail_Local_Rep");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_DB") == null) {
                            context.Reject_Service_Detail_Logistic_DB = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_DB=(String) context.getProperty("Reject_Service_Detail_Logistic_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Logistic_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Logistic_Unknown_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_DB") == null) {
                            context.Reject_Service_Detail_Transport_DB = null;
                        } else {
                            context.Reject_Service_Detail_Transport_DB=(String) context.getProperty("Reject_Service_Detail_Transport_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Transport_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Transport_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Transport_Unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Tarification_Local_Rep") == null) {
                            context.Reject_Tarification_Local_Rep = null;
                        } else {
                            context.Reject_Tarification_Local_Rep=(String) context.getProperty("Reject_Tarification_Local_Rep");
                        }
                        context.setContextType("Reject_Tarification_Logistic_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_Code_Client") == null) {
                            context.Reject_Tarification_Logistic_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_Code_Client=(String) context.getProperty("Reject_Tarification_Logistic_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_DB") == null) {
                            context.Reject_Tarification_Logistic_DB = null;
                        } else {
                            context.Reject_Tarification_Logistic_DB=(String) context.getProperty("Reject_Tarification_Logistic_DB");
                        }
                        context.setContextType("Reject_Tarification_Logistic_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_unknown_Client") == null) {
                            context.Reject_Tarification_Logistic_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_unknown_Client=(String) context.getProperty("Reject_Tarification_Logistic_unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_Code_Client") == null) {
                            context.Reject_Tarification_Transport_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_Code_Client=(String) context.getProperty("Reject_Tarification_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_DB") == null) {
                            context.Reject_Tarification_Transport_DB = null;
                        } else {
                            context.Reject_Tarification_Transport_DB=(String) context.getProperty("Reject_Tarification_Transport_DB");
                        }
                        context.setContextType("Reject_Tarification_Transport_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_unknown_Client") == null) {
                            context.Reject_Tarification_Transport_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_unknown_Client=(String) context.getProperty("Reject_Tarification_Transport_unknown_Client");
                        }
                        context.setContextType("code_client_length", "id_Integer");
                        if(context.getStringValue("code_client_length") == null) {
                            context.code_client_length = null;
                        } else {
                            try{
                                context.code_client_length=routines.system.ParserUtils.parseTo_Integer (context.getProperty("code_client_length"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "code_client_length", e.getMessage()));
                                context.code_client_length=null;
                            }
                        }
                        context.setContextType("code_client_regex", "id_String");
                        if(context.getStringValue("code_client_regex") == null) {
                            context.code_client_regex = null;
                        } else {
                            context.code_client_regex=(String) context.getProperty("code_client_regex");
                        }
                        context.setContextType("Livraison_directory", "id_String");
                        if(context.getStringValue("Livraison_directory") == null) {
                            context.Livraison_directory = null;
                        } else {
                            context.Livraison_directory=(String) context.getProperty("Livraison_directory");
                        }
                        context.setContextType("Round_directory", "id_String");
                        if(context.getStringValue("Round_directory") == null) {
                            context.Round_directory = null;
                        } else {
                            context.Round_directory=(String) context.getProperty("Round_directory");
                        }
                        context.setContextType("Round_file_name", "id_String");
                        if(context.getStringValue("Round_file_name") == null) {
                            context.Round_file_name = null;
                        } else {
                            context.Round_file_name=(String) context.getProperty("Round_file_name");
                        }
                        context.setContextType("Round_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Minus_Days") == null) {
                            context.Round_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Minus_Days", e.getMessage()));
                                context.Round_Minus_Days=null;
                            }
                        }
                        context.setContextType("start_date", "id_String");
                        if(context.getStringValue("start_date") == null) {
                            context.start_date = null;
                        } else {
                            context.start_date=(String) context.getProperty("start_date");
                        }
                        context.setContextType("Urbantz_directory", "id_String");
                        if(context.getStringValue("Urbantz_directory") == null) {
                            context.Urbantz_directory = null;
                        } else {
                            context.Urbantz_directory=(String) context.getProperty("Urbantz_directory");
                        }
                        context.setContextType("urbantz_extraction_date", "id_String");
                        if(context.getStringValue("urbantz_extraction_date") == null) {
                            context.urbantz_extraction_date = null;
                        } else {
                            context.urbantz_extraction_date=(String) context.getProperty("urbantz_extraction_date");
                        }
                        context.setContextType("Max_Extarction_Hour_HH", "id_Integer");
                        if(context.getStringValue("Max_Extarction_Hour_HH") == null) {
                            context.Max_Extarction_Hour_HH = null;
                        } else {
                            try{
                                context.Max_Extarction_Hour_HH=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Max_Extarction_Hour_HH"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Max_Extarction_Hour_HH", e.getMessage()));
                                context.Max_Extarction_Hour_HH=null;
                            }
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Billing_Comptabilite_File")) {
                context.Billing_Comptabilite_File = (String) parentContextMap.get("Billing_Comptabilite_File");
            }if (parentContextMap.containsKey("Billing_Comptabilite_Folder")) {
                context.Billing_Comptabilite_Folder = (String) parentContextMap.get("Billing_Comptabilite_Folder");
            }if (parentContextMap.containsKey("Billing_Distant_Rep")) {
                context.Billing_Distant_Rep = (String) parentContextMap.get("Billing_Distant_Rep");
            }if (parentContextMap.containsKey("Billing_File_Masque")) {
                context.Billing_File_Masque = (String) parentContextMap.get("Billing_File_Masque");
            }if (parentContextMap.containsKey("Billing_Local_Rep")) {
                context.Billing_Local_Rep = (String) parentContextMap.get("Billing_Local_Rep");
            }if (parentContextMap.containsKey("Billing_Name")) {
                context.Billing_Name = (String) parentContextMap.get("Billing_Name");
            }if (parentContextMap.containsKey("Billing_Start_Number")) {
                context.Billing_Start_Number = (Integer) parentContextMap.get("Billing_Start_Number");
            }if (parentContextMap.containsKey("Billing_TVA_default_value")) {
                context.Billing_TVA_default_value = (Float) parentContextMap.get("Billing_TVA_default_value");
            }if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("FTP_DistantRep")) {
                context.FTP_DistantRep = (String) parentContextMap.get("FTP_DistantRep");
            }if (parentContextMap.containsKey("FTP_FileMasque")) {
                context.FTP_FileMasque = (String) parentContextMap.get("FTP_FileMasque");
            }if (parentContextMap.containsKey("FTP_Hote")) {
                context.FTP_Hote = (String) parentContextMap.get("FTP_Hote");
            }if (parentContextMap.containsKey("FTP_Password")) {
                context.FTP_Password = (java.lang.String) parentContextMap.get("FTP_Password");
            }if (parentContextMap.containsKey("FTP_Port")) {
                context.FTP_Port = (Integer) parentContextMap.get("FTP_Port");
            }if (parentContextMap.containsKey("FTP_User")) {
                context.FTP_User = (String) parentContextMap.get("FTP_User");
            }if (parentContextMap.containsKey("keyStore_file_name")) {
                context.keyStore_file_name = (String) parentContextMap.get("keyStore_file_name");
            }if (parentContextMap.containsKey("KeyStore_Repo")) {
                context.KeyStore_Repo = (String) parentContextMap.get("KeyStore_Repo");
            }if (parentContextMap.containsKey("mail_password")) {
                context.mail_password = (java.lang.String) parentContextMap.get("mail_password");
            }if (parentContextMap.containsKey("send_mail_from")) {
                context.send_mail_from = (String) parentContextMap.get("send_mail_from");
            }if (parentContextMap.containsKey("send_mail_to")) {
                context.send_mail_to = (String) parentContextMap.get("send_mail_to");
            }if (parentContextMap.containsKey("send_to_second_mail")) {
                context.send_to_second_mail = (String) parentContextMap.get("send_to_second_mail");
            }if (parentContextMap.containsKey("send_to_third_mail")) {
                context.send_to_third_mail = (String) parentContextMap.get("send_to_third_mail");
            }if (parentContextMap.containsKey("Clients_Masque")) {
                context.Clients_Masque = (String) parentContextMap.get("Clients_Masque");
            }if (parentContextMap.containsKey("Code_client_masque")) {
                context.Code_client_masque = (String) parentContextMap.get("Code_client_masque");
            }if (parentContextMap.containsKey("Command_Logistic_Invalid_Date")) {
                context.Command_Logistic_Invalid_Date = (String) parentContextMap.get("Command_Logistic_Invalid_Date");
            }if (parentContextMap.containsKey("Command_Logistic_Masque")) {
                context.Command_Logistic_Masque = (String) parentContextMap.get("Command_Logistic_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque")) {
                context.Command_Transport_Masque = (String) parentContextMap.get("Command_Transport_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque_Express")) {
                context.Command_Transport_Masque_Express = (String) parentContextMap.get("Command_Transport_Masque_Express");
            }if (parentContextMap.containsKey("Holiday_Days_Masque")) {
                context.Holiday_Days_Masque = (String) parentContextMap.get("Holiday_Days_Masque");
            }if (parentContextMap.containsKey("Livraisons_Exception")) {
                context.Livraisons_Exception = (String) parentContextMap.get("Livraisons_Exception");
            }if (parentContextMap.containsKey("Livraisons_Masque")) {
                context.Livraisons_Masque = (String) parentContextMap.get("Livraisons_Masque");
            }if (parentContextMap.containsKey("Livraisons_Ok")) {
                context.Livraisons_Ok = (String) parentContextMap.get("Livraisons_Ok");
            }if (parentContextMap.containsKey("Tarification_Logistic_Masque")) {
                context.Tarification_Logistic_Masque = (String) parentContextMap.get("Tarification_Logistic_Masque");
            }if (parentContextMap.containsKey("Tarification_Transport_Masque")) {
                context.Tarification_Transport_Masque = (String) parentContextMap.get("Tarification_Transport_Masque");
            }if (parentContextMap.containsKey("Tournee_Masque")) {
                context.Tournee_Masque = (String) parentContextMap.get("Tournee_Masque");
            }if (parentContextMap.containsKey("TVA_Exceptions")) {
                context.TVA_Exceptions = (String) parentContextMap.get("TVA_Exceptions");
            }if (parentContextMap.containsKey("Backup")) {
                context.Backup = (String) parentContextMap.get("Backup");
            }if (parentContextMap.containsKey("Server_Clean")) {
                context.Server_Clean = (String) parentContextMap.get("Server_Clean");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Server_Out")) {
                context.Server_Out = (String) parentContextMap.get("Server_Out");
            }if (parentContextMap.containsKey("Cleaning_Reject_Logistic_price_is_zero")) {
                context.Cleaning_Reject_Logistic_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Logistic_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Reject_Rep")) {
                context.Cleaning_Reject_Rep = (String) parentContextMap.get("Cleaning_Reject_Rep");
            }if (parentContextMap.containsKey("Cleaning_Reject_Transport_price_is_zero")) {
                context.Cleaning_Reject_Transport_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Transport_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Transport_no_PostalCode")) {
                context.Cleaning_Transport_no_PostalCode = (String) parentContextMap.get("Cleaning_Transport_no_PostalCode");
            }if (parentContextMap.containsKey("Csv_File_Masque")) {
                context.Csv_File_Masque = (String) parentContextMap.get("Csv_File_Masque");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Command_Error")) {
                context.Diagnostic_Reject_Command_Error = (String) parentContextMap.get("Diagnostic_Reject_Command_Error");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Day_Not_Ok")) {
                context.Diagnostic_Reject_Day_Not_Ok = (String) parentContextMap.get("Diagnostic_Reject_Day_Not_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Postal_Code_Ok")) {
                context.Diagnostic_Reject_Postal_Code_Ok = (String) parentContextMap.get("Diagnostic_Reject_Postal_Code_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Rep")) {
                context.Diagnostic_Reject_Rep = (String) parentContextMap.get("Diagnostic_Reject_Rep");
            }if (parentContextMap.containsKey("Excel_File_Masque")) {
                context.Excel_File_Masque = (String) parentContextMap.get("Excel_File_Masque");
            }if (parentContextMap.containsKey("Migration_Billing_Not_Ok")) {
                context.Migration_Billing_Not_Ok = (String) parentContextMap.get("Migration_Billing_Not_Ok");
            }if (parentContextMap.containsKey("Reject_Client_File")) {
                context.Reject_Client_File = (String) parentContextMap.get("Reject_Client_File");
            }if (parentContextMap.containsKey("Reject_Client_Local_Rep")) {
                context.Reject_Client_Local_Rep = (String) parentContextMap.get("Reject_Client_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Command_Logisitc_Code_Client")) {
                context.Reject_Command_Logisitc_Code_Client = (String) parentContextMap.get("Reject_Command_Logisitc_Code_Client");
            }if (parentContextMap.containsKey("Reject_Command_Transport_Code_Client")) {
                context.Reject_Command_Transport_Code_Client = (String) parentContextMap.get("Reject_Command_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Distant_Rep")) {
                context.Reject_Distant_Rep = (String) parentContextMap.get("Reject_Distant_Rep");
            }if (parentContextMap.containsKey("Reject_Duplicated_Client_File")) {
                context.Reject_Duplicated_Client_File = (String) parentContextMap.get("Reject_Duplicated_Client_File");
            }if (parentContextMap.containsKey("Reject_Migration_Local_Rep")) {
                context.Reject_Migration_Local_Rep = (String) parentContextMap.get("Reject_Migration_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Not_Complet_Client")) {
                context.Reject_Not_Complet_Client = (String) parentContextMap.get("Reject_Not_Complet_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Local_Rep")) {
                context.Reject_Service_Detail_Local_Rep = (String) parentContextMap.get("Reject_Service_Detail_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_DB")) {
                context.Reject_Service_Detail_Logistic_DB = (String) parentContextMap.get("Reject_Service_Detail_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_Unknown_Client")) {
                context.Reject_Service_Detail_Logistic_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Logistic_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_DB")) {
                context.Reject_Service_Detail_Transport_DB = (String) parentContextMap.get("Reject_Service_Detail_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_Unknown_Client")) {
                context.Reject_Service_Detail_Transport_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Transport_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Local_Rep")) {
                context.Reject_Tarification_Local_Rep = (String) parentContextMap.get("Reject_Tarification_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_Code_Client")) {
                context.Reject_Tarification_Logistic_Code_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_DB")) {
                context.Reject_Tarification_Logistic_DB = (String) parentContextMap.get("Reject_Tarification_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_unknown_Client")) {
                context.Reject_Tarification_Logistic_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_Code_Client")) {
                context.Reject_Tarification_Transport_Code_Client = (String) parentContextMap.get("Reject_Tarification_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_DB")) {
                context.Reject_Tarification_Transport_DB = (String) parentContextMap.get("Reject_Tarification_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_unknown_Client")) {
                context.Reject_Tarification_Transport_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Transport_unknown_Client");
            }if (parentContextMap.containsKey("code_client_length")) {
                context.code_client_length = (Integer) parentContextMap.get("code_client_length");
            }if (parentContextMap.containsKey("code_client_regex")) {
                context.code_client_regex = (String) parentContextMap.get("code_client_regex");
            }if (parentContextMap.containsKey("Livraison_directory")) {
                context.Livraison_directory = (String) parentContextMap.get("Livraison_directory");
            }if (parentContextMap.containsKey("Round_directory")) {
                context.Round_directory = (String) parentContextMap.get("Round_directory");
            }if (parentContextMap.containsKey("Round_file_name")) {
                context.Round_file_name = (String) parentContextMap.get("Round_file_name");
            }if (parentContextMap.containsKey("Round_Minus_Days")) {
                context.Round_Minus_Days = (Integer) parentContextMap.get("Round_Minus_Days");
            }if (parentContextMap.containsKey("start_date")) {
                context.start_date = (String) parentContextMap.get("start_date");
            }if (parentContextMap.containsKey("Urbantz_directory")) {
                context.Urbantz_directory = (String) parentContextMap.get("Urbantz_directory");
            }if (parentContextMap.containsKey("urbantz_extraction_date")) {
                context.urbantz_extraction_date = (String) parentContextMap.get("urbantz_extraction_date");
            }if (parentContextMap.containsKey("Max_Extarction_Hour_HH")) {
                context.Max_Extarction_Hour_HH = (Integer) parentContextMap.get("Max_Extarction_Hour_HH");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("FTP_Password");
			parametersToEncrypt.add("mail_password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ECOLOTRANS_URBANTZ_TASKS_IMPORT' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs


this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ECOLOTRANS_URBANTZ_TASKS_IMPORT");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_TASKS_IMPORT' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     845836 characters generated by Talend Cloud Data Integration 
 *     on the 5 mars 2024 à 17:44:22 WAT
 ************************************************************************************************/
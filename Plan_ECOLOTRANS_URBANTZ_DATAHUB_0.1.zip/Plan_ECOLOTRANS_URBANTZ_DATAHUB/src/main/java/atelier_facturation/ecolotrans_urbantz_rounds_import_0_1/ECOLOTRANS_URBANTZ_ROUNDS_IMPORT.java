
package atelier_facturation.ecolotrans_urbantz_rounds_import_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: ECOLOTRANS_URBANTZ_ROUNDS_IMPORT Purpose: Transfer rounds from api to database<br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ECOLOTRANS_URBANTZ_ROUNDS_IMPORT implements TalendJob {
	static {System.setProperty("TalendJob.log", "ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(Round_directory != null){
				
					this.setProperty("Round_directory", Round_directory.toString());
				
			}
			
			if(Round_file_name != null){
				
					this.setProperty("Round_file_name", Round_file_name.toString());
				
			}
			
			if(Round_Minus_Days != null){
				
					this.setProperty("Round_Minus_Days", Round_Minus_Days.toString());
				
			}
			
			if(start_date != null){
				
					this.setProperty("start_date", start_date.toString());
				
			}
			
			if(Max_Extarction_Hour_HH != null){
				
					this.setProperty("Max_Extarction_Hour_HH", Max_Extarction_Hour_HH.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String Round_directory;
public String getRound_directory(){
	return this.Round_directory;
}
public String Round_file_name;
public String getRound_file_name(){
	return this.Round_file_name;
}
public Integer Round_Minus_Days;
public Integer getRound_Minus_Days(){
	return this.Round_Minus_Days;
}
public String start_date;
public String getStart_date(){
	return this.start_date;
}
public Integer Max_Extarction_Hour_HH;
public Integer getMax_Extarction_Hour_HH(){
	return this.Max_Extarction_Hour_HH;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ECOLOTRANS_URBANTZ_ROUNDS_IMPORT";
	private final String projectName = "ATELIER_FACTURATION";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_f6JAsJidEeyH_6mQlKsMew", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLoop_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLoop_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRESTClient_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tReplicate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLoop_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLoop_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLoop_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "jIdnGN_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tWarn_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "GpsOUF_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "voHbu0_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.Hote");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.Client_DataBase");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.User");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&useSSL=false&serverTimezone=Europe/Paris";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + context.Hote + ":" + context.Port + "/" + context.Client_DataBase + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = context.User;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.DB_Password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1",context.Client_DataBase);
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tSetGlobalVar_3Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tSetGlobalVar_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_3");
		org.slf4j.MDC.put("_subJobPid", "3H9Ro6_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";
	
	
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_3.append("Parameters:");
                            log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(new Date(),+3,\"dd\"))")+", KEY="+("\"end_date_plus_one\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(new Date(),-1,\"dd\"))")+", KEY="+("\"start_date\"")+"}]");
                        log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_3", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

globalMap.put("end_date_plus_one", TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(new Date(),+3,"dd")));
globalMap.put("start_date", TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(new Date(),-1,"dd")));

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tLoop_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";
	
	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 1);
	}
	


public void tLoop_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLoop_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tLoop_2");
		org.slf4j.MDC.put("_subJobPid", "K5aazi_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tLoop_2 begin ] start
	 */

				
			int NB_ITERATE_tJava_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tLoop_2", false);
		start_Hash.put("tLoop_2", System.currentTimeMillis());
		
	
	currentComponent="tLoop_2";
	
	
		int tos_count_tLoop_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLoop_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLoop_2 = new StringBuilder();
                    log4jParamters_tLoop_2.append("Parameters:");
                            log4jParamters_tLoop_2.append("FORLOOP" + " = " + "false");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("WHILELOOP" + " = " + "true");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("DECLARATION" + " = " + "int i = 0 ;");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("CONDITION" + " = " + "!TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy/MM/dd\", (String)globalMap.get(\"start_date\")),+i,\"dd\")).equals((String)globalMap.get(\"end_date_plus_one\"))");
                        log4jParamters_tLoop_2.append(" | ");
                            log4jParamters_tLoop_2.append("ITERATION" + " = " + "i++;");
                        log4jParamters_tLoop_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + (log4jParamters_tLoop_2) );
                    } 
                } 
            new BytesLimit65535_tLoop_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLoop_2", "tLoop_2", "tLoop");
				talendJobLogProcess(globalMap);
			}
			

int current_iteration_tLoop_2 = 0;

int i = 0 ;;
	
		log.info("tLoop_2 - Start to loop using a while loop. Initial declaration: '" + "int i = 0 ;" + "'. Condition: '" + "!TalendDate.formatDate(\"yyyy/MM/dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy/MM/dd\", (String)globalMap.get(\"start_date\")),+i,\"dd\")).equals((String)globalMap.get(\"end_date_plus_one\"))" + "'.");
	
while(!TalendDate.formatDate("yyyy/MM/dd",TalendDate.addDate(TalendDate.parseDate("yyyy/MM/dd", (String)globalMap.get("start_date")),+i,"dd")).equals((String)globalMap.get("end_date_plus_one"))){
	
		log.debug("tLoop_2 - Current iteration value: " + current_iteration_tLoop_2);
	
current_iteration_tLoop_2++;
globalMap.put("tLoop_2_CURRENT_ITERATION",current_iteration_tLoop_2);


 



/**
 * [tLoop_2 begin ] stop
 */
	
	/**
	 * [tLoop_2 main ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 


	tos_count_tLoop_2++;

/**
 * [tLoop_2 main ] stop
 */
	
	/**
	 * [tLoop_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 process_data_begin ] stop
 */
	NB_ITERATE_tJava_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("copyOfout1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row14", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tJava_3);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";
	
	
		int tos_count_tJava_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_3", "tJava_3", "tJava");
				talendJobLogProcess(globalMap);
			}
			


 System.out.println((Integer)globalMap.get("tLoop_2_CURRENT_ITERATION"));

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_begin ] stop
 */
	
	/**
	 * [tJava_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_end ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tSetGlobalVar_2Process(globalMap);



/**
 * [tJava_3 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tJava_3);
						}				
					




	
	/**
	 * [tLoop_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 process_data_end ] stop
 */
	
	/**
	 * [tLoop_2 end ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	




i++;;


}


 
                if(log.isDebugEnabled())
            log.debug("tLoop_2 - "  + ("Done.") );

ok_Hash.put("tLoop_2", true);
end_Hash.put("tLoop_2", System.currentTimeMillis());




/**
 * [tLoop_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLoop_2 finally ] start
	 */

	

	
	
	currentComponent="tLoop_2";
	
	

 



/**
 * [tLoop_2 finally ] stop
 */

	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLoop_2_SUBPROCESS_STATE", 1);
	}
	


public void tSetGlobalVar_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_2");
		org.slf4j.MDC.put("_subJobPid", "55wnx5_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";
	
	
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_2.append("Parameters:");
                            log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("50")+", KEY="+("\"numberOfElementsInPage\"")+"}, {VALUE="+("TalendDate.formatDate(\"yyyy-MM-dd\",TalendDate.addDate(TalendDate.parseDate(\"yyyy-MM-dd\", (String)globalMap.get(\"start_date\")),+( (Integer)globalMap.get(\"tLoop_2_CURRENT_ITERATION\")-1),\"dd\"))")+", KEY="+("\"day_to_retrieve\"")+"}]");
                        log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_2", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

globalMap.put("numberOfElementsInPage", 50);
globalMap.put("day_to_retrieve", TalendDate.formatDate("yyyy-MM-dd",TalendDate.addDate(TalendDate.parseDate("yyyy-MM-dd", (String)globalMap.get("start_date")),+( (Integer)globalMap.get("tLoop_2_CURRENT_ITERATION")-1),"dd")));

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tLoop_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";
	
	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 24;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}

				public Boolean countIsNullable(){
				    return true;
				}
				public Boolean countIsKey(){
				    return false;
				}
				public Integer countLength(){
				    return 1;
				}
				public Integer countPrecision(){
				    return 0;
				}
				public String countDefault(){
				
					return null;
				
				}
				public String countComment(){
				
				    return "";
				
				}
				public String countPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String countOriginalDbColumnName(){
				
					return "count";
				
				}

				
			    public String senderId;

				public String getSenderId () {
					return this.senderId;
				}

				public Boolean senderIdIsNullable(){
				    return true;
				}
				public Boolean senderIdIsKey(){
				    return false;
				}
				public Integer senderIdLength(){
				    return 24;
				}
				public Integer senderIdPrecision(){
				    return 0;
				}
				public String senderIdDefault(){
				
					return null;
				
				}
				public String senderIdComment(){
				
				    return "";
				
				}
				public String senderIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String senderIdOriginalDbColumnName(){
				
					return "senderId";
				
				}

				
			    public String reference;

				public String getReference () {
					return this.reference;
				}

				public Boolean referenceIsNullable(){
				    return true;
				}
				public Boolean referenceIsKey(){
				    return false;
				}
				public Integer referenceLength(){
				    return 24;
				}
				public Integer referencePrecision(){
				    return 0;
				}
				public String referenceDefault(){
				
					return null;
				
				}
				public String referenceComment(){
				
				    return "";
				
				}
				public String referencePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String referenceOriginalDbColumnName(){
				
					return "reference";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 11;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row11Struct other = (row11Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row11Struct other) {

		other.roundId = this.roundId;
	            other.count = this.count;
	            other.senderId = this.senderId;
	            other.reference = this.reference;
	            other.name = this.name;
	            
	}

	public void copyKeysDataTo(row11Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
						this.count = readInteger(dis);
					
					this.senderId = readString(dis);
					
					this.reference = readString(dis);
					
					this.name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
						this.count = readInteger(dis);
					
					this.senderId = readString(dis);
					
					this.reference = readString(dis);
					
					this.name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// String
				
						writeString(this.senderId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
					// String
				
						writeString(this.name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// String
				
						writeString(this.senderId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
					// String
				
						writeString(this.name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",count="+String.valueOf(count));
		sb.append(",senderId="+senderId);
		sb.append(",reference="+reference);
		sb.append(",name="+name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(senderId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(senderId);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return false;
				}
				public Integer roundIdLength(){
				    return 24;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}

				public Boolean countIsNullable(){
				    return true;
				}
				public Boolean countIsKey(){
				    return false;
				}
				public Integer countLength(){
				    return 1;
				}
				public Integer countPrecision(){
				    return 0;
				}
				public String countDefault(){
				
					return null;
				
				}
				public String countComment(){
				
				    return "";
				
				}
				public String countPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String countOriginalDbColumnName(){
				
					return "count";
				
				}

				
			    public String senderId;

				public String getSenderId () {
					return this.senderId;
				}

				public Boolean senderIdIsNullable(){
				    return true;
				}
				public Boolean senderIdIsKey(){
				    return false;
				}
				public Integer senderIdLength(){
				    return 24;
				}
				public Integer senderIdPrecision(){
				    return 0;
				}
				public String senderIdDefault(){
				
					return null;
				
				}
				public String senderIdComment(){
				
				    return "";
				
				}
				public String senderIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String senderIdOriginalDbColumnName(){
				
					return "senderId";
				
				}

				
			    public String reference;

				public String getReference () {
					return this.reference;
				}

				public Boolean referenceIsNullable(){
				    return true;
				}
				public Boolean referenceIsKey(){
				    return false;
				}
				public Integer referenceLength(){
				    return 24;
				}
				public Integer referencePrecision(){
				    return 0;
				}
				public String referenceDefault(){
				
					return null;
				
				}
				public String referenceComment(){
				
				    return "";
				
				}
				public String referencePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String referenceOriginalDbColumnName(){
				
					return "reference";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return true;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 11;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
						this.count = readInteger(dis);
					
					this.senderId = readString(dis);
					
					this.reference = readString(dis);
					
					this.name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
						this.count = readInteger(dis);
					
					this.senderId = readString(dis);
					
					this.reference = readString(dis);
					
					this.name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// String
				
						writeString(this.senderId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
					// String
				
						writeString(this.name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// String
				
						writeString(this.senderId,dos);
					
					// String
				
						writeString(this.reference,dos);
					
					// String
				
						writeString(this.name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",count="+String.valueOf(count));
		sb.append(",senderId="+senderId);
		sb.append(",reference="+reference);
		sb.append(",name="+name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(senderId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(senderId);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal travelTime;

				public BigDecimal getTravelTime () {
					return this.travelTime;
				}

				public Boolean travelTimeIsNullable(){
				    return true;
				}
				public Boolean travelTimeIsKey(){
				    return false;
				}
				public Integer travelTimeLength(){
				    return 4;
				}
				public Integer travelTimePrecision(){
				    return 0;
				}
				public String travelTimeDefault(){
				
					return null;
				
				}
				public String travelTimeComment(){
				
				    return "";
				
				}
				public String travelTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String travelTimeOriginalDbColumnName(){
				
					return "travelTime";
				
				}

				
			    public BigDecimal serviceTime;

				public BigDecimal getServiceTime () {
					return this.serviceTime;
				}

				public Boolean serviceTimeIsNullable(){
				    return true;
				}
				public Boolean serviceTimeIsKey(){
				    return false;
				}
				public Integer serviceTimeLength(){
				    return 3;
				}
				public Integer serviceTimePrecision(){
				    return 0;
				}
				public String serviceTimeDefault(){
				
					return null;
				
				}
				public String serviceTimeComment(){
				
				    return "";
				
				}
				public String serviceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String serviceTimeOriginalDbColumnName(){
				
					return "serviceTime";
				
				}

				
			    public String stopType;

				public String getStopType () {
					return this.stopType;
				}

				public Boolean stopTypeIsNullable(){
				    return true;
				}
				public Boolean stopTypeIsKey(){
				    return false;
				}
				public Integer stopTypeLength(){
				    return 1;
				}
				public Integer stopTypePrecision(){
				    return 0;
				}
				public String stopTypeDefault(){
				
					return null;
				
				}
				public String stopTypeComment(){
				
				    return "";
				
				}
				public String stopTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String stopTypeOriginalDbColumnName(){
				
					return "stopType";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 8;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String arriveTime;

				public String getArriveTime () {
					return this.arriveTime;
				}

				public Boolean arriveTimeIsNullable(){
				    return true;
				}
				public Boolean arriveTimeIsKey(){
				    return false;
				}
				public Integer arriveTimeLength(){
				    return null;
				}
				public Integer arriveTimePrecision(){
				    return 0;
				}
				public String arriveTimeDefault(){
				
					return null;
				
				}
				public String arriveTimeComment(){
				
				    return "";
				
				}
				public String arriveTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String arriveTimeOriginalDbColumnName(){
				
					return "arriveTime";
				
				}

				
			    public String departTime;

				public String getDepartTime () {
					return this.departTime;
				}

				public Boolean departTimeIsNullable(){
				    return true;
				}
				public Boolean departTimeIsKey(){
				    return false;
				}
				public Integer departTimeLength(){
				    return null;
				}
				public Integer departTimePrecision(){
				    return 0;
				}
				public String departTimeDefault(){
				
					return null;
				
				}
				public String departTimeComment(){
				
				    return "";
				
				}
				public String departTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String departTimeOriginalDbColumnName(){
				
					return "departTime";
				
				}

				
			    public String task;

				public String getTask () {
					return this.task;
				}

				public Boolean taskIsNullable(){
				    return true;
				}
				public Boolean taskIsKey(){
				    return true;
				}
				public Integer taskLength(){
				    return 8;
				}
				public Integer taskPrecision(){
				    return 0;
				}
				public String taskDefault(){
				
					return null;
				
				}
				public String taskComment(){
				
				    return "";
				
				}
				public String taskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskOriginalDbColumnName(){
				
					return "task";
				
				}

				
			    public String round;

				public String getRound () {
					return this.round;
				}

				public Boolean roundIsNullable(){
				    return true;
				}
				public Boolean roundIsKey(){
				    return false;
				}
				public Integer roundLength(){
				    return 24;
				}
				public Integer roundPrecision(){
				    return 0;
				}
				public String roundDefault(){
				
					return null;
				
				}
				public String roundComment(){
				
				    return "";
				
				}
				public String roundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundOriginalDbColumnName(){
				
					return "round";
				
				}

				
			    public Double travelDistance;

				public Double getTravelDistance () {
					return this.travelDistance;
				}

				public Boolean travelDistanceIsNullable(){
				    return true;
				}
				public Boolean travelDistanceIsKey(){
				    return false;
				}
				public Integer travelDistanceLength(){
				    return null;
				}
				public Integer travelDistancePrecision(){
				    return null;
				}
				public String travelDistanceDefault(){
				
					return null;
				
				}
				public String travelDistanceComment(){
				
				    return "";
				
				}
				public String travelDistancePattern(){
				
					return "";
				
				}
				public String travelDistanceOriginalDbColumnName(){
				
					return "travelDistance";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public Integer sequence;

				public Integer getSequence () {
					return this.sequence;
				}

				public Boolean sequenceIsNullable(){
				    return true;
				}
				public Boolean sequenceIsKey(){
				    return false;
				}
				public Integer sequenceLength(){
				    return null;
				}
				public Integer sequencePrecision(){
				    return null;
				}
				public String sequenceDefault(){
				
					return null;
				
				}
				public String sequenceComment(){
				
				    return "";
				
				}
				public String sequencePattern(){
				
					return "";
				
				}
				public String sequenceOriginalDbColumnName(){
				
					return "sequence";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.task == null) ? 0 : this.task.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row14Struct other = (row14Struct) obj;
		
						if (this.task == null) {
							if (other.task != null)
								return false;
						
						} else if (!this.task.equals(other.task))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row14Struct other) {

		other.travelTime = this.travelTime;
	            other.serviceTime = this.serviceTime;
	            other.stopType = this.stopType;
	            other.type = this.type;
	            other.arriveTime = this.arriveTime;
	            other.departTime = this.departTime;
	            other.task = this.task;
	            other.round = this.round;
	            other.travelDistance = this.travelDistance;
	            other.taskId = this.taskId;
	            other.sequence = this.sequence;
	            
	}

	public void copyKeysDataTo(row14Struct other) {

		other.task = this.task;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
					this.stopType = readString(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
					this.stopType = readString(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.travelTime);
					
					// BigDecimal
				
       			    	dos.writeObject(this.serviceTime);
					
					// String
				
						writeString(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.travelTime);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.serviceTime);
					
					// String
				
						writeString(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("travelTime="+String.valueOf(travelTime));
		sb.append(",serviceTime="+String.valueOf(serviceTime));
		sb.append(",stopType="+stopType);
		sb.append(",type="+type);
		sb.append(",arriveTime="+arriveTime);
		sb.append(",departTime="+departTime);
		sb.append(",task="+task);
		sb.append(",round="+round);
		sb.append(",travelDistance="+String.valueOf(travelDistance));
		sb.append(",taskId="+taskId);
		sb.append(",sequence="+String.valueOf(sequence));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(travelTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelTime);
            			}
            		
        			sb.append("|");
        		
        				if(serviceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(serviceTime);
            			}
            		
        			sb.append("|");
        		
        				if(stopType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stopType);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(arriveTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(arriveTime);
            			}
            		
        			sb.append("|");
        		
        				if(departTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(departTime);
            			}
            		
        			sb.append("|");
        		
        				if(task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(task);
            			}
            		
        			sb.append("|");
        		
        				if(round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(round);
            			}
            		
        			sb.append("|");
        		
        				if(travelDistance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelDistance);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sequence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sequence);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.task, other.task);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfout1Struct implements routines.system.IPersistableRow<copyOfout1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal travelTime;

				public BigDecimal getTravelTime () {
					return this.travelTime;
				}

				public Boolean travelTimeIsNullable(){
				    return true;
				}
				public Boolean travelTimeIsKey(){
				    return false;
				}
				public Integer travelTimeLength(){
				    return 4;
				}
				public Integer travelTimePrecision(){
				    return 0;
				}
				public String travelTimeDefault(){
				
					return null;
				
				}
				public String travelTimeComment(){
				
				    return "";
				
				}
				public String travelTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String travelTimeOriginalDbColumnName(){
				
					return "travelTime";
				
				}

				
			    public BigDecimal serviceTime;

				public BigDecimal getServiceTime () {
					return this.serviceTime;
				}

				public Boolean serviceTimeIsNullable(){
				    return true;
				}
				public Boolean serviceTimeIsKey(){
				    return false;
				}
				public Integer serviceTimeLength(){
				    return 3;
				}
				public Integer serviceTimePrecision(){
				    return 0;
				}
				public String serviceTimeDefault(){
				
					return null;
				
				}
				public String serviceTimeComment(){
				
				    return "";
				
				}
				public String serviceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String serviceTimeOriginalDbColumnName(){
				
					return "serviceTime";
				
				}

				
			    public String stopType;

				public String getStopType () {
					return this.stopType;
				}

				public Boolean stopTypeIsNullable(){
				    return true;
				}
				public Boolean stopTypeIsKey(){
				    return false;
				}
				public Integer stopTypeLength(){
				    return 1;
				}
				public Integer stopTypePrecision(){
				    return 0;
				}
				public String stopTypeDefault(){
				
					return null;
				
				}
				public String stopTypeComment(){
				
				    return "";
				
				}
				public String stopTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String stopTypeOriginalDbColumnName(){
				
					return "stopType";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 8;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String arriveTime;

				public String getArriveTime () {
					return this.arriveTime;
				}

				public Boolean arriveTimeIsNullable(){
				    return true;
				}
				public Boolean arriveTimeIsKey(){
				    return false;
				}
				public Integer arriveTimeLength(){
				    return null;
				}
				public Integer arriveTimePrecision(){
				    return 0;
				}
				public String arriveTimeDefault(){
				
					return null;
				
				}
				public String arriveTimeComment(){
				
				    return "";
				
				}
				public String arriveTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String arriveTimeOriginalDbColumnName(){
				
					return "arriveTime";
				
				}

				
			    public String departTime;

				public String getDepartTime () {
					return this.departTime;
				}

				public Boolean departTimeIsNullable(){
				    return true;
				}
				public Boolean departTimeIsKey(){
				    return false;
				}
				public Integer departTimeLength(){
				    return null;
				}
				public Integer departTimePrecision(){
				    return 0;
				}
				public String departTimeDefault(){
				
					return null;
				
				}
				public String departTimeComment(){
				
				    return "";
				
				}
				public String departTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String departTimeOriginalDbColumnName(){
				
					return "departTime";
				
				}

				
			    public String task;

				public String getTask () {
					return this.task;
				}

				public Boolean taskIsNullable(){
				    return true;
				}
				public Boolean taskIsKey(){
				    return true;
				}
				public Integer taskLength(){
				    return 8;
				}
				public Integer taskPrecision(){
				    return 0;
				}
				public String taskDefault(){
				
					return null;
				
				}
				public String taskComment(){
				
				    return "";
				
				}
				public String taskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskOriginalDbColumnName(){
				
					return "task";
				
				}

				
			    public String round;

				public String getRound () {
					return this.round;
				}

				public Boolean roundIsNullable(){
				    return true;
				}
				public Boolean roundIsKey(){
				    return false;
				}
				public Integer roundLength(){
				    return 24;
				}
				public Integer roundPrecision(){
				    return 0;
				}
				public String roundDefault(){
				
					return null;
				
				}
				public String roundComment(){
				
				    return "";
				
				}
				public String roundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundOriginalDbColumnName(){
				
					return "round";
				
				}

				
			    public Double travelDistance;

				public Double getTravelDistance () {
					return this.travelDistance;
				}

				public Boolean travelDistanceIsNullable(){
				    return true;
				}
				public Boolean travelDistanceIsKey(){
				    return false;
				}
				public Integer travelDistanceLength(){
				    return null;
				}
				public Integer travelDistancePrecision(){
				    return null;
				}
				public String travelDistanceDefault(){
				
					return null;
				
				}
				public String travelDistanceComment(){
				
				    return "";
				
				}
				public String travelDistancePattern(){
				
					return "";
				
				}
				public String travelDistanceOriginalDbColumnName(){
				
					return "travelDistance";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public Integer sequence;

				public Integer getSequence () {
					return this.sequence;
				}

				public Boolean sequenceIsNullable(){
				    return true;
				}
				public Boolean sequenceIsKey(){
				    return false;
				}
				public Integer sequenceLength(){
				    return null;
				}
				public Integer sequencePrecision(){
				    return null;
				}
				public String sequenceDefault(){
				
					return null;
				
				}
				public String sequenceComment(){
				
				    return "";
				
				}
				public String sequencePattern(){
				
					return "";
				
				}
				public String sequenceOriginalDbColumnName(){
				
					return "sequence";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.task == null) ? 0 : this.task.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final copyOfout1Struct other = (copyOfout1Struct) obj;
		
						if (this.task == null) {
							if (other.task != null)
								return false;
						
						} else if (!this.task.equals(other.task))
						
							return false;
					

		return true;
    }

	public void copyDataTo(copyOfout1Struct other) {

		other.travelTime = this.travelTime;
	            other.serviceTime = this.serviceTime;
	            other.stopType = this.stopType;
	            other.type = this.type;
	            other.arriveTime = this.arriveTime;
	            other.departTime = this.departTime;
	            other.task = this.task;
	            other.round = this.round;
	            other.travelDistance = this.travelDistance;
	            other.taskId = this.taskId;
	            other.sequence = this.sequence;
	            
	}

	public void copyKeysDataTo(copyOfout1Struct other) {

		other.task = this.task;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
					this.stopType = readString(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
					this.stopType = readString(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.travelTime);
					
					// BigDecimal
				
       			    	dos.writeObject(this.serviceTime);
					
					// String
				
						writeString(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.travelTime);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.serviceTime);
					
					// String
				
						writeString(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("travelTime="+String.valueOf(travelTime));
		sb.append(",serviceTime="+String.valueOf(serviceTime));
		sb.append(",stopType="+stopType);
		sb.append(",type="+type);
		sb.append(",arriveTime="+arriveTime);
		sb.append(",departTime="+departTime);
		sb.append(",task="+task);
		sb.append(",round="+round);
		sb.append(",travelDistance="+String.valueOf(travelDistance));
		sb.append(",taskId="+taskId);
		sb.append(",sequence="+String.valueOf(sequence));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(travelTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelTime);
            			}
            		
        			sb.append("|");
        		
        				if(serviceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(serviceTime);
            			}
            		
        			sb.append("|");
        		
        				if(stopType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stopType);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(arriveTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(arriveTime);
            			}
            		
        			sb.append("|");
        		
        				if(departTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(departTime);
            			}
            		
        			sb.append("|");
        		
        				if(task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(task);
            			}
            		
        			sb.append("|");
        		
        				if(round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(round);
            			}
            		
        			sb.append("|");
        		
        				if(travelDistance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelDistance);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sequence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sequence);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfout1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.task, other.task);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public BigDecimal travelTime;

				public BigDecimal getTravelTime () {
					return this.travelTime;
				}

				public Boolean travelTimeIsNullable(){
				    return true;
				}
				public Boolean travelTimeIsKey(){
				    return false;
				}
				public Integer travelTimeLength(){
				    return null;
				}
				public Integer travelTimePrecision(){
				    return 0;
				}
				public String travelTimeDefault(){
				
					return null;
				
				}
				public String travelTimeComment(){
				
				    return "";
				
				}
				public String travelTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String travelTimeOriginalDbColumnName(){
				
					return "travelTime";
				
				}

				
			    public BigDecimal serviceTime;

				public BigDecimal getServiceTime () {
					return this.serviceTime;
				}

				public Boolean serviceTimeIsNullable(){
				    return true;
				}
				public Boolean serviceTimeIsKey(){
				    return false;
				}
				public Integer serviceTimeLength(){
				    return null;
				}
				public Integer serviceTimePrecision(){
				    return 0;
				}
				public String serviceTimeDefault(){
				
					return null;
				
				}
				public String serviceTimeComment(){
				
				    return "";
				
				}
				public String serviceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String serviceTimeOriginalDbColumnName(){
				
					return "serviceTime";
				
				}

				
			    public Integer stopType;

				public Integer getStopType () {
					return this.stopType;
				}

				public Boolean stopTypeIsNullable(){
				    return true;
				}
				public Boolean stopTypeIsKey(){
				    return false;
				}
				public Integer stopTypeLength(){
				    return 1;
				}
				public Integer stopTypePrecision(){
				    return 0;
				}
				public String stopTypeDefault(){
				
					return null;
				
				}
				public String stopTypeComment(){
				
				    return "";
				
				}
				public String stopTypePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String stopTypeOriginalDbColumnName(){
				
					return "stopType";
				
				}

				
			    public String type;

				public String getType () {
					return this.type;
				}

				public Boolean typeIsNullable(){
				    return true;
				}
				public Boolean typeIsKey(){
				    return false;
				}
				public Integer typeLength(){
				    return 8;
				}
				public Integer typePrecision(){
				    return 0;
				}
				public String typeDefault(){
				
					return null;
				
				}
				public String typeComment(){
				
				    return "";
				
				}
				public String typePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String typeOriginalDbColumnName(){
				
					return "type";
				
				}

				
			    public String arriveTime;

				public String getArriveTime () {
					return this.arriveTime;
				}

				public Boolean arriveTimeIsNullable(){
				    return true;
				}
				public Boolean arriveTimeIsKey(){
				    return false;
				}
				public Integer arriveTimeLength(){
				    return null;
				}
				public Integer arriveTimePrecision(){
				    return 0;
				}
				public String arriveTimeDefault(){
				
					return null;
				
				}
				public String arriveTimeComment(){
				
				    return "";
				
				}
				public String arriveTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String arriveTimeOriginalDbColumnName(){
				
					return "arriveTime";
				
				}

				
			    public String departTime;

				public String getDepartTime () {
					return this.departTime;
				}

				public Boolean departTimeIsNullable(){
				    return true;
				}
				public Boolean departTimeIsKey(){
				    return false;
				}
				public Integer departTimeLength(){
				    return null;
				}
				public Integer departTimePrecision(){
				    return 0;
				}
				public String departTimeDefault(){
				
					return null;
				
				}
				public String departTimeComment(){
				
				    return "";
				
				}
				public String departTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String departTimeOriginalDbColumnName(){
				
					return "departTime";
				
				}

				
			    public String task;

				public String getTask () {
					return this.task;
				}

				public Boolean taskIsNullable(){
				    return true;
				}
				public Boolean taskIsKey(){
				    return false;
				}
				public Integer taskLength(){
				    return 8;
				}
				public Integer taskPrecision(){
				    return 0;
				}
				public String taskDefault(){
				
					return null;
				
				}
				public String taskComment(){
				
				    return "";
				
				}
				public String taskPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String taskOriginalDbColumnName(){
				
					return "task";
				
				}

				
			    public String round;

				public String getRound () {
					return this.round;
				}

				public Boolean roundIsNullable(){
				    return true;
				}
				public Boolean roundIsKey(){
				    return false;
				}
				public Integer roundLength(){
				    return 24;
				}
				public Integer roundPrecision(){
				    return 0;
				}
				public String roundDefault(){
				
					return null;
				
				}
				public String roundComment(){
				
				    return "";
				
				}
				public String roundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundOriginalDbColumnName(){
				
					return "round";
				
				}

				
			    public Double travelDistance;

				public Double getTravelDistance () {
					return this.travelDistance;
				}

				public Boolean travelDistanceIsNullable(){
				    return true;
				}
				public Boolean travelDistanceIsKey(){
				    return false;
				}
				public Integer travelDistanceLength(){
				    return null;
				}
				public Integer travelDistancePrecision(){
				    return null;
				}
				public String travelDistanceDefault(){
				
					return null;
				
				}
				public String travelDistanceComment(){
				
				    return "";
				
				}
				public String travelDistancePattern(){
				
					return "";
				
				}
				public String travelDistanceOriginalDbColumnName(){
				
					return "travelDistance";
				
				}

				
			    public String taskId;

				public String getTaskId () {
					return this.taskId;
				}

				public Boolean taskIdIsNullable(){
				    return true;
				}
				public Boolean taskIdIsKey(){
				    return false;
				}
				public Integer taskIdLength(){
				    return null;
				}
				public Integer taskIdPrecision(){
				    return null;
				}
				public String taskIdDefault(){
				
					return null;
				
				}
				public String taskIdComment(){
				
				    return "";
				
				}
				public String taskIdPattern(){
				
					return "";
				
				}
				public String taskIdOriginalDbColumnName(){
				
					return "taskId";
				
				}

				
			    public Integer sequence;

				public Integer getSequence () {
					return this.sequence;
				}

				public Boolean sequenceIsNullable(){
				    return true;
				}
				public Boolean sequenceIsKey(){
				    return false;
				}
				public Integer sequenceLength(){
				    return null;
				}
				public Integer sequencePrecision(){
				    return null;
				}
				public String sequenceDefault(){
				
					return null;
				
				}
				public String sequenceComment(){
				
				    return "";
				
				}
				public String sequencePattern(){
				
					return "";
				
				}
				public String sequenceOriginalDbColumnName(){
				
					return "sequence";
				
				}

				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
						this.stopType = readInteger(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.travelTime = (BigDecimal) dis.readObject();
					
						this.serviceTime = (BigDecimal) dis.readObject();
					
						this.stopType = readInteger(dis);
					
					this.type = readString(dis);
					
					this.arriveTime = readString(dis);
					
					this.departTime = readString(dis);
					
					this.task = readString(dis);
					
					this.round = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.travelDistance = null;
           				} else {
           			    	this.travelDistance = dis.readDouble();
           				}
					
					this.taskId = readString(dis);
					
						this.sequence = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.travelTime);
					
					// BigDecimal
				
       			    	dos.writeObject(this.serviceTime);
					
					// Integer
				
						writeInteger(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.travelTime);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.serviceTime);
					
					// Integer
				
						writeInteger(this.stopType,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.arriveTime,dos);
					
					// String
				
						writeString(this.departTime,dos);
					
					// String
				
						writeString(this.task,dos);
					
					// String
				
						writeString(this.round,dos);
					
					// Double
				
						if(this.travelDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.travelDistance);
		            	}
					
					// String
				
						writeString(this.taskId,dos);
					
					// Integer
				
						writeInteger(this.sequence,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("travelTime="+String.valueOf(travelTime));
		sb.append(",serviceTime="+String.valueOf(serviceTime));
		sb.append(",stopType="+String.valueOf(stopType));
		sb.append(",type="+type);
		sb.append(",arriveTime="+arriveTime);
		sb.append(",departTime="+departTime);
		sb.append(",task="+task);
		sb.append(",round="+round);
		sb.append(",travelDistance="+String.valueOf(travelDistance));
		sb.append(",taskId="+taskId);
		sb.append(",sequence="+String.valueOf(sequence));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(travelTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelTime);
            			}
            		
        			sb.append("|");
        		
        				if(serviceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(serviceTime);
            			}
            		
        			sb.append("|");
        		
        				if(stopType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stopType);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(arriveTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(arriveTime);
            			}
            		
        			sb.append("|");
        		
        				if(departTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(departTime);
            			}
            		
        			sb.append("|");
        		
        				if(task == null){
        					sb.append("<null>");
        				}else{
            				sb.append(task);
            			}
            		
        			sb.append("|");
        		
        				if(round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(round);
            			}
            		
        			sb.append("|");
        		
        				if(travelDistance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(travelDistance);
            			}
            		
        			sb.append("|");
        		
        				if(taskId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(taskId);
            			}
            		
        			sb.append("|");
        		
        				if(sequence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sequence);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return true;
				}
				public Integer roundIdLength(){
				    return 24;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String roundName;

				public String getRoundName () {
					return this.roundName;
				}

				public Boolean roundNameIsNullable(){
				    return true;
				}
				public Boolean roundNameIsKey(){
				    return false;
				}
				public Integer roundNameLength(){
				    return 3;
				}
				public Integer roundNamePrecision(){
				    return 0;
				}
				public String roundNameDefault(){
				
					return null;
				
				}
				public String roundNameComment(){
				
				    return "";
				
				}
				public String roundNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundNameOriginalDbColumnName(){
				
					return "roundName";
				
				}

				
			    public String realInfoHasPrepared;

				public String getRealInfoHasPrepared () {
					return this.realInfoHasPrepared;
				}

				public Boolean realInfoHasPreparedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasPreparedIsKey(){
				    return false;
				}
				public Integer realInfoHasPreparedLength(){
				    return null;
				}
				public Integer realInfoHasPreparedPrecision(){
				    return 0;
				}
				public String realInfoHasPreparedDefault(){
				
					return null;
				
				}
				public String realInfoHasPreparedComment(){
				
				    return "";
				
				}
				public String realInfoHasPreparedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasPreparedOriginalDbColumnName(){
				
					return "realInfoHasPrepared";
				
				}

				
			    public String realInfoHasStarted;

				public String getRealInfoHasStarted () {
					return this.realInfoHasStarted;
				}

				public Boolean realInfoHasStartedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasStartedIsKey(){
				    return false;
				}
				public Integer realInfoHasStartedLength(){
				    return null;
				}
				public Integer realInfoHasStartedPrecision(){
				    return 0;
				}
				public String realInfoHasStartedDefault(){
				
					return null;
				
				}
				public String realInfoHasStartedComment(){
				
				    return "";
				
				}
				public String realInfoHasStartedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasStartedOriginalDbColumnName(){
				
					return "realInfoHasStarted";
				
				}

				
			    public String realInfoHasFinished;

				public String getRealInfoHasFinished () {
					return this.realInfoHasFinished;
				}

				public Boolean realInfoHasFinishedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasFinishedIsKey(){
				    return false;
				}
				public Integer realInfoHasFinishedLength(){
				    return null;
				}
				public Integer realInfoHasFinishedPrecision(){
				    return 0;
				}
				public String realInfoHasFinishedDefault(){
				
					return null;
				
				}
				public String realInfoHasFinishedComment(){
				
				    return "";
				
				}
				public String realInfoHasFinishedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasFinishedOriginalDbColumnName(){
				
					return "realInfoHasFinished";
				
				}

				
			    public Double realInfoPreparationTime;

				public Double getRealInfoPreparationTime () {
					return this.realInfoPreparationTime;
				}

				public Boolean realInfoPreparationTimeIsNullable(){
				    return true;
				}
				public Boolean realInfoPreparationTimeIsKey(){
				    return false;
				}
				public Integer realInfoPreparationTimeLength(){
				    return null;
				}
				public Integer realInfoPreparationTimePrecision(){
				    return 0;
				}
				public String realInfoPreparationTimeDefault(){
				
					return null;
				
				}
				public String realInfoPreparationTimeComment(){
				
				    return "";
				
				}
				public String realInfoPreparationTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoPreparationTimeOriginalDbColumnName(){
				
					return "realInfoPreparationTime";
				
				}

				
			    public Double realInfoHasLasted;

				public Double getRealInfoHasLasted () {
					return this.realInfoHasLasted;
				}

				public Boolean realInfoHasLastedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasLastedIsKey(){
				    return false;
				}
				public Integer realInfoHasLastedLength(){
				    return null;
				}
				public Integer realInfoHasLastedPrecision(){
				    return 0;
				}
				public String realInfoHasLastedDefault(){
				
					return null;
				
				}
				public String realInfoHasLastedComment(){
				
				    return "";
				
				}
				public String realInfoHasLastedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasLastedOriginalDbColumnName(){
				
					return "realInfoHasLasted";
				
				}

				
			    public String reloads___;

				public String getReloads___ () {
					return this.reloads___;
				}

				public Boolean reloads___IsNullable(){
				    return true;
				}
				public Boolean reloads___IsKey(){
				    return false;
				}
				public Integer reloads___Length(){
				    return 2;
				}
				public Integer reloads___Precision(){
				    return 0;
				}
				public String reloads___Default(){
				
					return null;
				
				}
				public String reloads___Comment(){
				
				    return "";
				
				}
				public String reloads___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String reloads___OriginalDbColumnName(){
				
					return "reloads___";
				
				}

				
			    public String activity;

				public String getActivity () {
					return this.activity;
				}

				public Boolean activityIsNullable(){
				    return true;
				}
				public Boolean activityIsKey(){
				    return false;
				}
				public Integer activityLength(){
				    return 7;
				}
				public Integer activityPrecision(){
				    return 0;
				}
				public String activityDefault(){
				
					return null;
				
				}
				public String activityComment(){
				
				    return "";
				
				}
				public String activityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String activityOriginalDbColumnName(){
				
					return "activity";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 9;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Double orderCount;

				public Double getOrderCount () {
					return this.orderCount;
				}

				public Boolean orderCountIsNullable(){
				    return true;
				}
				public Boolean orderCountIsKey(){
				    return false;
				}
				public Integer orderCountLength(){
				    return null;
				}
				public Integer orderCountPrecision(){
				    return 0;
				}
				public String orderCountDefault(){
				
					return null;
				
				}
				public String orderCountComment(){
				
				    return "";
				
				}
				public String orderCountPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String orderCountOriginalDbColumnName(){
				
					return "orderCount";
				
				}

				
			    public Double totalCost;

				public Double getTotalCost () {
					return this.totalCost;
				}

				public Boolean totalCostIsNullable(){
				    return true;
				}
				public Boolean totalCostIsKey(){
				    return false;
				}
				public Integer totalCostLength(){
				    return null;
				}
				public Integer totalCostPrecision(){
				    return 15;
				}
				public String totalCostDefault(){
				
					return null;
				
				}
				public String totalCostComment(){
				
				    return "";
				
				}
				public String totalCostPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalCostOriginalDbColumnName(){
				
					return "totalCost";
				
				}

				
			    public Double totalTime;

				public Double getTotalTime () {
					return this.totalTime;
				}

				public Boolean totalTimeIsNullable(){
				    return true;
				}
				public Boolean totalTimeIsKey(){
				    return false;
				}
				public Integer totalTimeLength(){
				    return null;
				}
				public Integer totalTimePrecision(){
				    return 0;
				}
				public String totalTimeDefault(){
				
					return null;
				
				}
				public String totalTimeComment(){
				
				    return "";
				
				}
				public String totalTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalTimeOriginalDbColumnName(){
				
					return "totalTime";
				
				}

				
			    public Double totalOrderServiceTime;

				public Double getTotalOrderServiceTime () {
					return this.totalOrderServiceTime;
				}

				public Boolean totalOrderServiceTimeIsNullable(){
				    return true;
				}
				public Boolean totalOrderServiceTimeIsKey(){
				    return false;
				}
				public Integer totalOrderServiceTimeLength(){
				    return null;
				}
				public Integer totalOrderServiceTimePrecision(){
				    return 0;
				}
				public String totalOrderServiceTimeDefault(){
				
					return null;
				
				}
				public String totalOrderServiceTimeComment(){
				
				    return "";
				
				}
				public String totalOrderServiceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalOrderServiceTimeOriginalDbColumnName(){
				
					return "totalOrderServiceTime";
				
				}

				
			    public Double totalBreakServiceTime;

				public Double getTotalBreakServiceTime () {
					return this.totalBreakServiceTime;
				}

				public Boolean totalBreakServiceTimeIsNullable(){
				    return true;
				}
				public Boolean totalBreakServiceTimeIsKey(){
				    return false;
				}
				public Integer totalBreakServiceTimeLength(){
				    return null;
				}
				public Integer totalBreakServiceTimePrecision(){
				    return 0;
				}
				public String totalBreakServiceTimeDefault(){
				
					return null;
				
				}
				public String totalBreakServiceTimeComment(){
				
				    return "";
				
				}
				public String totalBreakServiceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalBreakServiceTimeOriginalDbColumnName(){
				
					return "totalBreakServiceTime";
				
				}

				
			    public Double totalTravelTime;

				public Double getTotalTravelTime () {
					return this.totalTravelTime;
				}

				public Boolean totalTravelTimeIsNullable(){
				    return true;
				}
				public Boolean totalTravelTimeIsKey(){
				    return false;
				}
				public Integer totalTravelTimeLength(){
				    return null;
				}
				public Integer totalTravelTimePrecision(){
				    return 0;
				}
				public String totalTravelTimeDefault(){
				
					return null;
				
				}
				public String totalTravelTimeComment(){
				
				    return "";
				
				}
				public String totalTravelTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalTravelTimeOriginalDbColumnName(){
				
					return "totalTravelTime";
				
				}

				
			    public Double totalDistance;

				public Double getTotalDistance () {
					return this.totalDistance;
				}

				public Boolean totalDistanceIsNullable(){
				    return true;
				}
				public Boolean totalDistanceIsKey(){
				    return false;
				}
				public Integer totalDistanceLength(){
				    return null;
				}
				public Integer totalDistancePrecision(){
				    return 13;
				}
				public String totalDistanceDefault(){
				
					return null;
				
				}
				public String totalDistanceComment(){
				
				    return "";
				
				}
				public String totalDistancePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalDistanceOriginalDbColumnName(){
				
					return "totalDistance";
				
				}

				
			    public String labelsAndSkills___;

				public String getLabelsAndSkills___ () {
					return this.labelsAndSkills___;
				}

				public Boolean labelsAndSkills___IsNullable(){
				    return true;
				}
				public Boolean labelsAndSkills___IsKey(){
				    return false;
				}
				public Integer labelsAndSkills___Length(){
				    return 9;
				}
				public Integer labelsAndSkills___Precision(){
				    return 0;
				}
				public String labelsAndSkills___Default(){
				
					return null;
				
				}
				public String labelsAndSkills___Comment(){
				
				    return "";
				
				}
				public String labelsAndSkills___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String labelsAndSkills___OriginalDbColumnName(){
				
					return "labelsAndSkills___";
				
				}

				
			    public Double totalWaitTime;

				public Double getTotalWaitTime () {
					return this.totalWaitTime;
				}

				public Boolean totalWaitTimeIsNullable(){
				    return true;
				}
				public Boolean totalWaitTimeIsKey(){
				    return false;
				}
				public Integer totalWaitTimeLength(){
				    return null;
				}
				public Integer totalWaitTimePrecision(){
				    return 0;
				}
				public String totalWaitTimeDefault(){
				
					return null;
				
				}
				public String totalWaitTimeComment(){
				
				    return "";
				
				}
				public String totalWaitTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalWaitTimeOriginalDbColumnName(){
				
					return "totalWaitTime";
				
				}

				
			    public Double totalViolationTime;

				public Double getTotalViolationTime () {
					return this.totalViolationTime;
				}

				public Boolean totalViolationTimeIsNullable(){
				    return true;
				}
				public Boolean totalViolationTimeIsKey(){
				    return false;
				}
				public Integer totalViolationTimeLength(){
				    return null;
				}
				public Integer totalViolationTimePrecision(){
				    return 0;
				}
				public String totalViolationTimeDefault(){
				
					return null;
				
				}
				public String totalViolationTimeComment(){
				
				    return "";
				
				}
				public String totalViolationTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalViolationTimeOriginalDbColumnName(){
				
					return "totalViolationTime";
				
				}

				
			    public Boolean validated;

				public Boolean getValidated () {
					return this.validated;
				}

				public Boolean validatedIsNullable(){
				    return true;
				}
				public Boolean validatedIsKey(){
				    return false;
				}
				public Integer validatedLength(){
				    return 4;
				}
				public Integer validatedPrecision(){
				    return 0;
				}
				public String validatedDefault(){
				
					return null;
				
				}
				public String validatedComment(){
				
				    return "";
				
				}
				public String validatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String validatedOriginalDbColumnName(){
				
					return "validated";
				
				}

				
			    public String updated;

				public String getUpdated () {
					return this.updated;
				}

				public Boolean updatedIsNullable(){
				    return true;
				}
				public Boolean updatedIsKey(){
				    return false;
				}
				public Integer updatedLength(){
				    return null;
				}
				public Integer updatedPrecision(){
				    return 0;
				}
				public String updatedDefault(){
				
					return null;
				
				}
				public String updatedComment(){
				
				    return "";
				
				}
				public String updatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updatedOriginalDbColumnName(){
				
					return "updated";
				
				}

				
			    public String immatriculation;

				public String getImmatriculation () {
					return this.immatriculation;
				}

				public Boolean immatriculationIsNullable(){
				    return true;
				}
				public Boolean immatriculationIsKey(){
				    return false;
				}
				public Integer immatriculationLength(){
				    return 9;
				}
				public Integer immatriculationPrecision(){
				    return 0;
				}
				public String immatriculationDefault(){
				
					return null;
				
				}
				public String immatriculationComment(){
				
				    return "";
				
				}
				public String immatriculationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String immatriculationOriginalDbColumnName(){
				
					return "immatriculation";
				
				}

				
			    public String PhotoVehiculeAvant;

				public String getPhotoVehiculeAvant () {
					return this.PhotoVehiculeAvant;
				}

				public Boolean PhotoVehiculeAvantIsNullable(){
				    return true;
				}
				public Boolean PhotoVehiculeAvantIsKey(){
				    return false;
				}
				public Integer PhotoVehiculeAvantLength(){
				    return 40;
				}
				public Integer PhotoVehiculeAvantPrecision(){
				    return 0;
				}
				public String PhotoVehiculeAvantDefault(){
				
					return null;
				
				}
				public String PhotoVehiculeAvantComment(){
				
				    return "";
				
				}
				public String PhotoVehiculeAvantPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotoVehiculeAvantOriginalDbColumnName(){
				
					return "PhotoVehiculeAvant";
				
				}

				
			    public String PhotovehiculeArriere;

				public String getPhotovehiculeArriere () {
					return this.PhotovehiculeArriere;
				}

				public Boolean PhotovehiculeArriereIsNullable(){
				    return true;
				}
				public Boolean PhotovehiculeArriereIsKey(){
				    return false;
				}
				public Integer PhotovehiculeArriereLength(){
				    return 40;
				}
				public Integer PhotovehiculeArrierePrecision(){
				    return 0;
				}
				public String PhotovehiculeArriereDefault(){
				
					return null;
				
				}
				public String PhotovehiculeArriereComment(){
				
				    return "";
				
				}
				public String PhotovehiculeArrierePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotovehiculeArriereOriginalDbColumnName(){
				
					return "PhotovehiculeArriere";
				
				}

				
			    public String photoVehiculedroit;

				public String getPhotoVehiculedroit () {
					return this.photoVehiculedroit;
				}

				public Boolean photoVehiculedroitIsNullable(){
				    return true;
				}
				public Boolean photoVehiculedroitIsKey(){
				    return false;
				}
				public Integer photoVehiculedroitLength(){
				    return 40;
				}
				public Integer photoVehiculedroitPrecision(){
				    return 0;
				}
				public String photoVehiculedroitDefault(){
				
					return null;
				
				}
				public String photoVehiculedroitComment(){
				
				    return "";
				
				}
				public String photoVehiculedroitPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String photoVehiculedroitOriginalDbColumnName(){
				
					return "photoVehiculedroit";
				
				}

				
			    public String PhotoVehicuelGauche;

				public String getPhotoVehicuelGauche () {
					return this.PhotoVehicuelGauche;
				}

				public Boolean PhotoVehicuelGaucheIsNullable(){
				    return true;
				}
				public Boolean PhotoVehicuelGaucheIsKey(){
				    return false;
				}
				public Integer PhotoVehicuelGaucheLength(){
				    return 40;
				}
				public Integer PhotoVehicuelGauchePrecision(){
				    return 0;
				}
				public String PhotoVehicuelGaucheDefault(){
				
					return null;
				
				}
				public String PhotoVehicuelGaucheComment(){
				
				    return "";
				
				}
				public String PhotoVehicuelGauchePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotoVehicuelGaucheOriginalDbColumnName(){
				
					return "PhotoVehicuelGauche";
				
				}

				
			    public Double kmDepart;

				public Double getKmDepart () {
					return this.kmDepart;
				}

				public Boolean kmDepartIsNullable(){
				    return true;
				}
				public Boolean kmDepartIsKey(){
				    return false;
				}
				public Integer kmDepartLength(){
				    return null;
				}
				public Integer kmDepartPrecision(){
				    return 0;
				}
				public String kmDepartDefault(){
				
					return null;
				
				}
				public String kmDepartComment(){
				
				    return "";
				
				}
				public String kmDepartPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String kmDepartOriginalDbColumnName(){
				
					return "kmDepart";
				
				}

				
			    public String startLocation;

				public String getStartLocation () {
					return this.startLocation;
				}

				public Boolean startLocationIsNullable(){
				    return true;
				}
				public Boolean startLocationIsKey(){
				    return false;
				}
				public Integer startLocationLength(){
				    return 3;
				}
				public Integer startLocationPrecision(){
				    return 0;
				}
				public String startLocationDefault(){
				
					return null;
				
				}
				public String startLocationComment(){
				
				    return "";
				
				}
				public String startLocationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String startLocationOriginalDbColumnName(){
				
					return "startLocation";
				
				}

				
			    public String endLocation;

				public String getEndLocation () {
					return this.endLocation;
				}

				public Boolean endLocationIsNullable(){
				    return true;
				}
				public Boolean endLocationIsKey(){
				    return false;
				}
				public Integer endLocationLength(){
				    return 3;
				}
				public Integer endLocationPrecision(){
				    return 0;
				}
				public String endLocationDefault(){
				
					return null;
				
				}
				public String endLocationComment(){
				
				    return "";
				
				}
				public String endLocationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String endLocationOriginalDbColumnName(){
				
					return "endLocation";
				
				}

				
			    public String startTime;

				public String getStartTime () {
					return this.startTime;
				}

				public Boolean startTimeIsNullable(){
				    return true;
				}
				public Boolean startTimeIsKey(){
				    return false;
				}
				public Integer startTimeLength(){
				    return null;
				}
				public Integer startTimePrecision(){
				    return 0;
				}
				public String startTimeDefault(){
				
					return null;
				
				}
				public String startTimeComment(){
				
				    return "";
				
				}
				public String startTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String startTimeOriginalDbColumnName(){
				
					return "startTime";
				
				}

				
			    public String endTime;

				public String getEndTime () {
					return this.endTime;
				}

				public Boolean endTimeIsNullable(){
				    return true;
				}
				public Boolean endTimeIsKey(){
				    return false;
				}
				public Integer endTimeLength(){
				    return null;
				}
				public Integer endTimePrecision(){
				    return 0;
				}
				public String endTimeDefault(){
				
					return null;
				
				}
				public String endTimeComment(){
				
				    return "";
				
				}
				public String endTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String endTimeOriginalDbColumnName(){
				
					return "endTime";
				
				}

				
			    public Double weight;

				public Double getWeight () {
					return this.weight;
				}

				public Boolean weightIsNullable(){
				    return true;
				}
				public Boolean weightIsKey(){
				    return false;
				}
				public Integer weightLength(){
				    return null;
				}
				public Integer weightPrecision(){
				    return 0;
				}
				public String weightDefault(){
				
					return null;
				
				}
				public String weightComment(){
				
				    return "";
				
				}
				public String weightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String weightOriginalDbColumnName(){
				
					return "weight";
				
				}

				
			    public Double volume;

				public Double getVolume () {
					return this.volume;
				}

				public Boolean volumeIsNullable(){
				    return true;
				}
				public Boolean volumeIsKey(){
				    return false;
				}
				public Integer volumeLength(){
				    return null;
				}
				public Integer volumePrecision(){
				    return 2;
				}
				public String volumeDefault(){
				
					return null;
				
				}
				public String volumeComment(){
				
				    return "";
				
				}
				public String volumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String volumeOriginalDbColumnName(){
				
					return "volume";
				
				}

				
			    public String date;

				public String getDate () {
					return this.date;
				}

				public Boolean dateIsNullable(){
				    return true;
				}
				public Boolean dateIsKey(){
				    return false;
				}
				public Integer dateLength(){
				    return null;
				}
				public Integer datePrecision(){
				    return 0;
				}
				public String dateDefault(){
				
					return null;
				
				}
				public String dateComment(){
				
				    return "";
				
				}
				public String datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String dateOriginalDbColumnName(){
				
					return "date";
				
				}

				
			    public String platform;

				public String getPlatform () {
					return this.platform;
				}

				public Boolean platformIsNullable(){
				    return true;
				}
				public Boolean platformIsKey(){
				    return false;
				}
				public Integer platformLength(){
				    return 24;
				}
				public Integer platformPrecision(){
				    return 0;
				}
				public String platformDefault(){
				
					return null;
				
				}
				public String platformComment(){
				
				    return "";
				
				}
				public String platformPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String platformOriginalDbColumnName(){
				
					return "platform";
				
				}

				
			    public String flux;

				public String getFlux () {
					return this.flux;
				}

				public Boolean fluxIsNullable(){
				    return true;
				}
				public Boolean fluxIsKey(){
				    return false;
				}
				public Integer fluxLength(){
				    return 24;
				}
				public Integer fluxPrecision(){
				    return 0;
				}
				public String fluxDefault(){
				
					return null;
				
				}
				public String fluxComment(){
				
				    return "";
				
				}
				public String fluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String fluxOriginalDbColumnName(){
				
					return "flux";
				
				}

				
			    public String targetFlux;

				public String getTargetFlux () {
					return this.targetFlux;
				}

				public Boolean targetFluxIsNullable(){
				    return true;
				}
				public Boolean targetFluxIsKey(){
				    return false;
				}
				public Integer targetFluxLength(){
				    return 61;
				}
				public Integer targetFluxPrecision(){
				    return 0;
				}
				public String targetFluxDefault(){
				
					return null;
				
				}
				public String targetFluxComment(){
				
				    return "";
				
				}
				public String targetFluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String targetFluxOriginalDbColumnName(){
				
					return "targetFlux";
				
				}

				
			    public String picture;

				public String getPicture () {
					return this.picture;
				}

				public Boolean pictureIsNullable(){
				    return true;
				}
				public Boolean pictureIsKey(){
				    return false;
				}
				public Integer pictureLength(){
				    return 89;
				}
				public Integer picturePrecision(){
				    return 0;
				}
				public String pictureDefault(){
				
					return null;
				
				}
				public String pictureComment(){
				
				    return "";
				
				}
				public String picturePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String pictureOriginalDbColumnName(){
				
					return "picture";
				
				}

				
			    public String vehicule;

				public String getVehicule () {
					return this.vehicule;
				}

				public Boolean vehiculeIsNullable(){
				    return true;
				}
				public Boolean vehiculeIsKey(){
				    return false;
				}
				public Integer vehiculeLength(){
				    return 24;
				}
				public Integer vehiculePrecision(){
				    return 0;
				}
				public String vehiculeDefault(){
				
					return null;
				
				}
				public String vehiculeComment(){
				
				    return "";
				
				}
				public String vehiculePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String vehiculeOriginalDbColumnName(){
				
					return "vehicule";
				
				}

				
			    public String driver;

				public String getDriver () {
					return this.driver;
				}

				public Boolean driverIsNullable(){
				    return true;
				}
				public Boolean driverIsKey(){
				    return false;
				}
				public Integer driverLength(){
				    return 24;
				}
				public Integer driverPrecision(){
				    return 0;
				}
				public String driverDefault(){
				
					return null;
				
				}
				public String driverComment(){
				
				    return "";
				
				}
				public String driverPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverOriginalDbColumnName(){
				
					return "driver";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return null;
				}
				public Integer is_deletedPrecision(){
				    return null;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String billingRoundName;

				public String getBillingRoundName () {
					return this.billingRoundName;
				}

				public Boolean billingRoundNameIsNullable(){
				    return true;
				}
				public Boolean billingRoundNameIsKey(){
				    return false;
				}
				public Integer billingRoundNameLength(){
				    return 150;
				}
				public Integer billingRoundNamePrecision(){
				    return null;
				}
				public String billingRoundNameDefault(){
				
					return null;
				
				}
				public String billingRoundNameComment(){
				
				    return "";
				
				}
				public String billingRoundNamePattern(){
				
					return "";
				
				}
				public String billingRoundNameOriginalDbColumnName(){
				
					return "billingRoundName";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.roundId == null) ? 0 : this.roundId.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row10Struct other = (row10Struct) obj;
		
						if (this.roundId == null) {
							if (other.roundId != null)
								return false;
						
						} else if (!this.roundId.equals(other.roundId))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row10Struct other) {

		other.roundId = this.roundId;
	            other.roundName = this.roundName;
	            other.realInfoHasPrepared = this.realInfoHasPrepared;
	            other.realInfoHasStarted = this.realInfoHasStarted;
	            other.realInfoHasFinished = this.realInfoHasFinished;
	            other.realInfoPreparationTime = this.realInfoPreparationTime;
	            other.realInfoHasLasted = this.realInfoHasLasted;
	            other.reloads___ = this.reloads___;
	            other.activity = this.activity;
	            other.status = this.status;
	            other.orderCount = this.orderCount;
	            other.totalCost = this.totalCost;
	            other.totalTime = this.totalTime;
	            other.totalOrderServiceTime = this.totalOrderServiceTime;
	            other.totalBreakServiceTime = this.totalBreakServiceTime;
	            other.totalTravelTime = this.totalTravelTime;
	            other.totalDistance = this.totalDistance;
	            other.labelsAndSkills___ = this.labelsAndSkills___;
	            other.totalWaitTime = this.totalWaitTime;
	            other.totalViolationTime = this.totalViolationTime;
	            other.validated = this.validated;
	            other.updated = this.updated;
	            other.immatriculation = this.immatriculation;
	            other.PhotoVehiculeAvant = this.PhotoVehiculeAvant;
	            other.PhotovehiculeArriere = this.PhotovehiculeArriere;
	            other.photoVehiculedroit = this.photoVehiculedroit;
	            other.PhotoVehicuelGauche = this.PhotoVehicuelGauche;
	            other.kmDepart = this.kmDepart;
	            other.startLocation = this.startLocation;
	            other.endLocation = this.endLocation;
	            other.startTime = this.startTime;
	            other.endTime = this.endTime;
	            other.weight = this.weight;
	            other.volume = this.volume;
	            other.date = this.date;
	            other.platform = this.platform;
	            other.flux = this.flux;
	            other.targetFlux = this.targetFlux;
	            other.picture = this.picture;
	            other.vehicule = this.vehicule;
	            other.driver = this.driver;
	            other.is_deleted = this.is_deleted;
	            other.billingRoundName = this.billingRoundName;
	            
	}

	public void copyKeysDataTo(row10Struct other) {

		other.roundId = this.roundId;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.roundName = readString(dis);
					
					this.realInfoHasPrepared = readString(dis);
					
					this.realInfoHasStarted = readString(dis);
					
					this.realInfoHasFinished = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoPreparationTime = null;
           				} else {
           			    	this.realInfoPreparationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoHasLasted = null;
           				} else {
           			    	this.realInfoHasLasted = dis.readDouble();
           				}
					
					this.reloads___ = readString(dis);
					
					this.activity = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.orderCount = null;
           				} else {
           			    	this.orderCount = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalCost = null;
           				} else {
           			    	this.totalCost = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTime = null;
           				} else {
           			    	this.totalTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalOrderServiceTime = null;
           				} else {
           			    	this.totalOrderServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalBreakServiceTime = null;
           				} else {
           			    	this.totalBreakServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTravelTime = null;
           				} else {
           			    	this.totalTravelTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalDistance = null;
           				} else {
           			    	this.totalDistance = dis.readDouble();
           				}
					
					this.labelsAndSkills___ = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalWaitTime = null;
           				} else {
           			    	this.totalWaitTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalViolationTime = null;
           				} else {
           			    	this.totalViolationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.validated = null;
           				} else {
           			    	this.validated = dis.readBoolean();
           				}
					
					this.updated = readString(dis);
					
					this.immatriculation = readString(dis);
					
					this.PhotoVehiculeAvant = readString(dis);
					
					this.PhotovehiculeArriere = readString(dis);
					
					this.photoVehiculedroit = readString(dis);
					
					this.PhotoVehicuelGauche = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.kmDepart = null;
           				} else {
           			    	this.kmDepart = dis.readDouble();
           				}
					
					this.startLocation = readString(dis);
					
					this.endLocation = readString(dis);
					
					this.startTime = readString(dis);
					
					this.endTime = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.platform = readString(dis);
					
					this.flux = readString(dis);
					
					this.targetFlux = readString(dis);
					
					this.picture = readString(dis);
					
					this.vehicule = readString(dis);
					
					this.driver = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.roundName = readString(dis);
					
					this.realInfoHasPrepared = readString(dis);
					
					this.realInfoHasStarted = readString(dis);
					
					this.realInfoHasFinished = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoPreparationTime = null;
           				} else {
           			    	this.realInfoPreparationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoHasLasted = null;
           				} else {
           			    	this.realInfoHasLasted = dis.readDouble();
           				}
					
					this.reloads___ = readString(dis);
					
					this.activity = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.orderCount = null;
           				} else {
           			    	this.orderCount = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalCost = null;
           				} else {
           			    	this.totalCost = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTime = null;
           				} else {
           			    	this.totalTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalOrderServiceTime = null;
           				} else {
           			    	this.totalOrderServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalBreakServiceTime = null;
           				} else {
           			    	this.totalBreakServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTravelTime = null;
           				} else {
           			    	this.totalTravelTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalDistance = null;
           				} else {
           			    	this.totalDistance = dis.readDouble();
           				}
					
					this.labelsAndSkills___ = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalWaitTime = null;
           				} else {
           			    	this.totalWaitTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalViolationTime = null;
           				} else {
           			    	this.totalViolationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.validated = null;
           				} else {
           			    	this.validated = dis.readBoolean();
           				}
					
					this.updated = readString(dis);
					
					this.immatriculation = readString(dis);
					
					this.PhotoVehiculeAvant = readString(dis);
					
					this.PhotovehiculeArriere = readString(dis);
					
					this.photoVehiculedroit = readString(dis);
					
					this.PhotoVehicuelGauche = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.kmDepart = null;
           				} else {
           			    	this.kmDepart = dis.readDouble();
           				}
					
					this.startLocation = readString(dis);
					
					this.endLocation = readString(dis);
					
					this.startTime = readString(dis);
					
					this.endTime = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.platform = readString(dis);
					
					this.flux = readString(dis);
					
					this.targetFlux = readString(dis);
					
					this.picture = readString(dis);
					
					this.vehicule = readString(dis);
					
					this.driver = readString(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.billingRoundName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// String
				
						writeString(this.realInfoHasPrepared,dos);
					
					// String
				
						writeString(this.realInfoHasStarted,dos);
					
					// String
				
						writeString(this.realInfoHasFinished,dos);
					
					// Double
				
						if(this.realInfoPreparationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoPreparationTime);
		            	}
					
					// Double
				
						if(this.realInfoHasLasted == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoHasLasted);
		            	}
					
					// String
				
						writeString(this.reloads___,dos);
					
					// String
				
						writeString(this.activity,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.orderCount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.orderCount);
		            	}
					
					// Double
				
						if(this.totalCost == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalCost);
		            	}
					
					// Double
				
						if(this.totalTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTime);
		            	}
					
					// Double
				
						if(this.totalOrderServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalOrderServiceTime);
		            	}
					
					// Double
				
						if(this.totalBreakServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalBreakServiceTime);
		            	}
					
					// Double
				
						if(this.totalTravelTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTravelTime);
		            	}
					
					// Double
				
						if(this.totalDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalDistance);
		            	}
					
					// String
				
						writeString(this.labelsAndSkills___,dos);
					
					// Double
				
						if(this.totalWaitTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalWaitTime);
		            	}
					
					// Double
				
						if(this.totalViolationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalViolationTime);
		            	}
					
					// Boolean
				
						if(this.validated == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.validated);
		            	}
					
					// String
				
						writeString(this.updated,dos);
					
					// String
				
						writeString(this.immatriculation,dos);
					
					// String
				
						writeString(this.PhotoVehiculeAvant,dos);
					
					// String
				
						writeString(this.PhotovehiculeArriere,dos);
					
					// String
				
						writeString(this.photoVehiculedroit,dos);
					
					// String
				
						writeString(this.PhotoVehicuelGauche,dos);
					
					// Double
				
						if(this.kmDepart == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.kmDepart);
		            	}
					
					// String
				
						writeString(this.startLocation,dos);
					
					// String
				
						writeString(this.endLocation,dos);
					
					// String
				
						writeString(this.startTime,dos);
					
					// String
				
						writeString(this.endTime,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.platform,dos);
					
					// String
				
						writeString(this.flux,dos);
					
					// String
				
						writeString(this.targetFlux,dos);
					
					// String
				
						writeString(this.picture,dos);
					
					// String
				
						writeString(this.vehicule,dos);
					
					// String
				
						writeString(this.driver,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// String
				
						writeString(this.realInfoHasPrepared,dos);
					
					// String
				
						writeString(this.realInfoHasStarted,dos);
					
					// String
				
						writeString(this.realInfoHasFinished,dos);
					
					// Double
				
						if(this.realInfoPreparationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoPreparationTime);
		            	}
					
					// Double
				
						if(this.realInfoHasLasted == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoHasLasted);
		            	}
					
					// String
				
						writeString(this.reloads___,dos);
					
					// String
				
						writeString(this.activity,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.orderCount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.orderCount);
		            	}
					
					// Double
				
						if(this.totalCost == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalCost);
		            	}
					
					// Double
				
						if(this.totalTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTime);
		            	}
					
					// Double
				
						if(this.totalOrderServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalOrderServiceTime);
		            	}
					
					// Double
				
						if(this.totalBreakServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalBreakServiceTime);
		            	}
					
					// Double
				
						if(this.totalTravelTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTravelTime);
		            	}
					
					// Double
				
						if(this.totalDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalDistance);
		            	}
					
					// String
				
						writeString(this.labelsAndSkills___,dos);
					
					// Double
				
						if(this.totalWaitTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalWaitTime);
		            	}
					
					// Double
				
						if(this.totalViolationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalViolationTime);
		            	}
					
					// Boolean
				
						if(this.validated == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.validated);
		            	}
					
					// String
				
						writeString(this.updated,dos);
					
					// String
				
						writeString(this.immatriculation,dos);
					
					// String
				
						writeString(this.PhotoVehiculeAvant,dos);
					
					// String
				
						writeString(this.PhotovehiculeArriere,dos);
					
					// String
				
						writeString(this.photoVehiculedroit,dos);
					
					// String
				
						writeString(this.PhotoVehicuelGauche,dos);
					
					// Double
				
						if(this.kmDepart == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.kmDepart);
		            	}
					
					// String
				
						writeString(this.startLocation,dos);
					
					// String
				
						writeString(this.endLocation,dos);
					
					// String
				
						writeString(this.startTime,dos);
					
					// String
				
						writeString(this.endTime,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.platform,dos);
					
					// String
				
						writeString(this.flux,dos);
					
					// String
				
						writeString(this.targetFlux,dos);
					
					// String
				
						writeString(this.picture,dos);
					
					// String
				
						writeString(this.vehicule,dos);
					
					// String
				
						writeString(this.driver,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// String
				
						writeString(this.billingRoundName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",roundName="+roundName);
		sb.append(",realInfoHasPrepared="+realInfoHasPrepared);
		sb.append(",realInfoHasStarted="+realInfoHasStarted);
		sb.append(",realInfoHasFinished="+realInfoHasFinished);
		sb.append(",realInfoPreparationTime="+String.valueOf(realInfoPreparationTime));
		sb.append(",realInfoHasLasted="+String.valueOf(realInfoHasLasted));
		sb.append(",reloads___="+reloads___);
		sb.append(",activity="+activity);
		sb.append(",status="+status);
		sb.append(",orderCount="+String.valueOf(orderCount));
		sb.append(",totalCost="+String.valueOf(totalCost));
		sb.append(",totalTime="+String.valueOf(totalTime));
		sb.append(",totalOrderServiceTime="+String.valueOf(totalOrderServiceTime));
		sb.append(",totalBreakServiceTime="+String.valueOf(totalBreakServiceTime));
		sb.append(",totalTravelTime="+String.valueOf(totalTravelTime));
		sb.append(",totalDistance="+String.valueOf(totalDistance));
		sb.append(",labelsAndSkills___="+labelsAndSkills___);
		sb.append(",totalWaitTime="+String.valueOf(totalWaitTime));
		sb.append(",totalViolationTime="+String.valueOf(totalViolationTime));
		sb.append(",validated="+String.valueOf(validated));
		sb.append(",updated="+updated);
		sb.append(",immatriculation="+immatriculation);
		sb.append(",PhotoVehiculeAvant="+PhotoVehiculeAvant);
		sb.append(",PhotovehiculeArriere="+PhotovehiculeArriere);
		sb.append(",photoVehiculedroit="+photoVehiculedroit);
		sb.append(",PhotoVehicuelGauche="+PhotoVehicuelGauche);
		sb.append(",kmDepart="+String.valueOf(kmDepart));
		sb.append(",startLocation="+startLocation);
		sb.append(",endLocation="+endLocation);
		sb.append(",startTime="+startTime);
		sb.append(",endTime="+endTime);
		sb.append(",weight="+String.valueOf(weight));
		sb.append(",volume="+String.valueOf(volume));
		sb.append(",date="+date);
		sb.append(",platform="+platform);
		sb.append(",flux="+flux);
		sb.append(",targetFlux="+targetFlux);
		sb.append(",picture="+picture);
		sb.append(",vehicule="+vehicule);
		sb.append(",driver="+driver);
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",billingRoundName="+billingRoundName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(roundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundName);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasPrepared == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasPrepared);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasStarted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasStarted);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasFinished == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasFinished);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoPreparationTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoPreparationTime);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasLasted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasLasted);
            			}
            		
        			sb.append("|");
        		
        				if(reloads___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reloads___);
            			}
            		
        			sb.append("|");
        		
        				if(activity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(activity);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(orderCount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(orderCount);
            			}
            		
        			sb.append("|");
        		
        				if(totalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalCost);
            			}
            		
        			sb.append("|");
        		
        				if(totalTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalOrderServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalOrderServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalBreakServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalBreakServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalTravelTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalTravelTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalDistance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalDistance);
            			}
            		
        			sb.append("|");
        		
        				if(labelsAndSkills___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(labelsAndSkills___);
            			}
            		
        			sb.append("|");
        		
        				if(totalWaitTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalWaitTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalViolationTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalViolationTime);
            			}
            		
        			sb.append("|");
        		
        				if(validated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(validated);
            			}
            		
        			sb.append("|");
        		
        				if(updated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated);
            			}
            		
        			sb.append("|");
        		
        				if(immatriculation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(immatriculation);
            			}
            		
        			sb.append("|");
        		
        				if(PhotoVehiculeAvant == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoVehiculeAvant);
            			}
            		
        			sb.append("|");
        		
        				if(PhotovehiculeArriere == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotovehiculeArriere);
            			}
            		
        			sb.append("|");
        		
        				if(photoVehiculedroit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(photoVehiculedroit);
            			}
            		
        			sb.append("|");
        		
        				if(PhotoVehicuelGauche == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoVehicuelGauche);
            			}
            		
        			sb.append("|");
        		
        				if(kmDepart == null){
        					sb.append("<null>");
        				}else{
            				sb.append(kmDepart);
            			}
            		
        			sb.append("|");
        		
        				if(startLocation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(startLocation);
            			}
            		
        			sb.append("|");
        		
        				if(endLocation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(endLocation);
            			}
            		
        			sb.append("|");
        		
        				if(startTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(startTime);
            			}
            		
        			sb.append("|");
        		
        				if(endTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(endTime);
            			}
            		
        			sb.append("|");
        		
        				if(weight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weight);
            			}
            		
        			sb.append("|");
        		
        				if(volume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(volume);
            			}
            		
        			sb.append("|");
        		
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(platform == null){
        					sb.append("<null>");
        				}else{
            				sb.append(platform);
            			}
            		
        			sb.append("|");
        		
        				if(flux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flux);
            			}
            		
        			sb.append("|");
        		
        				if(targetFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(targetFlux);
            			}
            		
        			sb.append("|");
        		
        				if(picture == null){
        					sb.append("<null>");
        				}else{
            				sb.append(picture);
            			}
            		
        			sb.append("|");
        		
        				if(vehicule == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vehicule);
            			}
            		
        			sb.append("|");
        		
        				if(driver == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driver);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(billingRoundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billingRoundName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.roundId, other.roundId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String roundId;

				public String getRoundId () {
					return this.roundId;
				}

				public Boolean roundIdIsNullable(){
				    return true;
				}
				public Boolean roundIdIsKey(){
				    return false;
				}
				public Integer roundIdLength(){
				    return 24;
				}
				public Integer roundIdPrecision(){
				    return 0;
				}
				public String roundIdDefault(){
				
					return null;
				
				}
				public String roundIdComment(){
				
				    return "";
				
				}
				public String roundIdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundIdOriginalDbColumnName(){
				
					return "roundId";
				
				}

				
			    public String roundName;

				public String getRoundName () {
					return this.roundName;
				}

				public Boolean roundNameIsNullable(){
				    return true;
				}
				public Boolean roundNameIsKey(){
				    return false;
				}
				public Integer roundNameLength(){
				    return 3;
				}
				public Integer roundNamePrecision(){
				    return 0;
				}
				public String roundNameDefault(){
				
					return null;
				
				}
				public String roundNameComment(){
				
				    return "";
				
				}
				public String roundNamePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String roundNameOriginalDbColumnName(){
				
					return "roundName";
				
				}

				
			    public String realInfoHasPrepared;

				public String getRealInfoHasPrepared () {
					return this.realInfoHasPrepared;
				}

				public Boolean realInfoHasPreparedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasPreparedIsKey(){
				    return false;
				}
				public Integer realInfoHasPreparedLength(){
				    return null;
				}
				public Integer realInfoHasPreparedPrecision(){
				    return 0;
				}
				public String realInfoHasPreparedDefault(){
				
					return null;
				
				}
				public String realInfoHasPreparedComment(){
				
				    return "";
				
				}
				public String realInfoHasPreparedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasPreparedOriginalDbColumnName(){
				
					return "realInfoHasPrepared";
				
				}

				
			    public String realInfoHasStarted;

				public String getRealInfoHasStarted () {
					return this.realInfoHasStarted;
				}

				public Boolean realInfoHasStartedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasStartedIsKey(){
				    return false;
				}
				public Integer realInfoHasStartedLength(){
				    return null;
				}
				public Integer realInfoHasStartedPrecision(){
				    return 0;
				}
				public String realInfoHasStartedDefault(){
				
					return null;
				
				}
				public String realInfoHasStartedComment(){
				
				    return "";
				
				}
				public String realInfoHasStartedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasStartedOriginalDbColumnName(){
				
					return "realInfoHasStarted";
				
				}

				
			    public String realInfoHasFinished;

				public String getRealInfoHasFinished () {
					return this.realInfoHasFinished;
				}

				public Boolean realInfoHasFinishedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasFinishedIsKey(){
				    return false;
				}
				public Integer realInfoHasFinishedLength(){
				    return null;
				}
				public Integer realInfoHasFinishedPrecision(){
				    return 0;
				}
				public String realInfoHasFinishedDefault(){
				
					return null;
				
				}
				public String realInfoHasFinishedComment(){
				
				    return "";
				
				}
				public String realInfoHasFinishedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasFinishedOriginalDbColumnName(){
				
					return "realInfoHasFinished";
				
				}

				
			    public Double realInfoPreparationTime;

				public Double getRealInfoPreparationTime () {
					return this.realInfoPreparationTime;
				}

				public Boolean realInfoPreparationTimeIsNullable(){
				    return true;
				}
				public Boolean realInfoPreparationTimeIsKey(){
				    return false;
				}
				public Integer realInfoPreparationTimeLength(){
				    return null;
				}
				public Integer realInfoPreparationTimePrecision(){
				    return 0;
				}
				public String realInfoPreparationTimeDefault(){
				
					return null;
				
				}
				public String realInfoPreparationTimeComment(){
				
				    return "";
				
				}
				public String realInfoPreparationTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoPreparationTimeOriginalDbColumnName(){
				
					return "realInfoPreparationTime";
				
				}

				
			    public Double realInfoHasLasted;

				public Double getRealInfoHasLasted () {
					return this.realInfoHasLasted;
				}

				public Boolean realInfoHasLastedIsNullable(){
				    return true;
				}
				public Boolean realInfoHasLastedIsKey(){
				    return false;
				}
				public Integer realInfoHasLastedLength(){
				    return null;
				}
				public Integer realInfoHasLastedPrecision(){
				    return 0;
				}
				public String realInfoHasLastedDefault(){
				
					return null;
				
				}
				public String realInfoHasLastedComment(){
				
				    return "";
				
				}
				public String realInfoHasLastedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String realInfoHasLastedOriginalDbColumnName(){
				
					return "realInfoHasLasted";
				
				}

				
			    public String reloads___;

				public String getReloads___ () {
					return this.reloads___;
				}

				public Boolean reloads___IsNullable(){
				    return true;
				}
				public Boolean reloads___IsKey(){
				    return false;
				}
				public Integer reloads___Length(){
				    return 2;
				}
				public Integer reloads___Precision(){
				    return 0;
				}
				public String reloads___Default(){
				
					return null;
				
				}
				public String reloads___Comment(){
				
				    return "";
				
				}
				public String reloads___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String reloads___OriginalDbColumnName(){
				
					return "reloads___";
				
				}

				
			    public String activity;

				public String getActivity () {
					return this.activity;
				}

				public Boolean activityIsNullable(){
				    return true;
				}
				public Boolean activityIsKey(){
				    return false;
				}
				public Integer activityLength(){
				    return 7;
				}
				public Integer activityPrecision(){
				    return 0;
				}
				public String activityDefault(){
				
					return null;
				
				}
				public String activityComment(){
				
				    return "";
				
				}
				public String activityPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String activityOriginalDbColumnName(){
				
					return "activity";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 9;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Double orderCount;

				public Double getOrderCount () {
					return this.orderCount;
				}

				public Boolean orderCountIsNullable(){
				    return true;
				}
				public Boolean orderCountIsKey(){
				    return false;
				}
				public Integer orderCountLength(){
				    return null;
				}
				public Integer orderCountPrecision(){
				    return 0;
				}
				public String orderCountDefault(){
				
					return null;
				
				}
				public String orderCountComment(){
				
				    return "";
				
				}
				public String orderCountPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String orderCountOriginalDbColumnName(){
				
					return "orderCount";
				
				}

				
			    public Double totalCost;

				public Double getTotalCost () {
					return this.totalCost;
				}

				public Boolean totalCostIsNullable(){
				    return true;
				}
				public Boolean totalCostIsKey(){
				    return false;
				}
				public Integer totalCostLength(){
				    return null;
				}
				public Integer totalCostPrecision(){
				    return 15;
				}
				public String totalCostDefault(){
				
					return null;
				
				}
				public String totalCostComment(){
				
				    return "";
				
				}
				public String totalCostPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalCostOriginalDbColumnName(){
				
					return "totalCost";
				
				}

				
			    public Double totalTime;

				public Double getTotalTime () {
					return this.totalTime;
				}

				public Boolean totalTimeIsNullable(){
				    return true;
				}
				public Boolean totalTimeIsKey(){
				    return false;
				}
				public Integer totalTimeLength(){
				    return null;
				}
				public Integer totalTimePrecision(){
				    return 0;
				}
				public String totalTimeDefault(){
				
					return null;
				
				}
				public String totalTimeComment(){
				
				    return "";
				
				}
				public String totalTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalTimeOriginalDbColumnName(){
				
					return "totalTime";
				
				}

				
			    public Double totalOrderServiceTime;

				public Double getTotalOrderServiceTime () {
					return this.totalOrderServiceTime;
				}

				public Boolean totalOrderServiceTimeIsNullable(){
				    return true;
				}
				public Boolean totalOrderServiceTimeIsKey(){
				    return false;
				}
				public Integer totalOrderServiceTimeLength(){
				    return null;
				}
				public Integer totalOrderServiceTimePrecision(){
				    return 0;
				}
				public String totalOrderServiceTimeDefault(){
				
					return null;
				
				}
				public String totalOrderServiceTimeComment(){
				
				    return "";
				
				}
				public String totalOrderServiceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalOrderServiceTimeOriginalDbColumnName(){
				
					return "totalOrderServiceTime";
				
				}

				
			    public Double totalBreakServiceTime;

				public Double getTotalBreakServiceTime () {
					return this.totalBreakServiceTime;
				}

				public Boolean totalBreakServiceTimeIsNullable(){
				    return true;
				}
				public Boolean totalBreakServiceTimeIsKey(){
				    return false;
				}
				public Integer totalBreakServiceTimeLength(){
				    return null;
				}
				public Integer totalBreakServiceTimePrecision(){
				    return 0;
				}
				public String totalBreakServiceTimeDefault(){
				
					return null;
				
				}
				public String totalBreakServiceTimeComment(){
				
				    return "";
				
				}
				public String totalBreakServiceTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalBreakServiceTimeOriginalDbColumnName(){
				
					return "totalBreakServiceTime";
				
				}

				
			    public Double totalTravelTime;

				public Double getTotalTravelTime () {
					return this.totalTravelTime;
				}

				public Boolean totalTravelTimeIsNullable(){
				    return true;
				}
				public Boolean totalTravelTimeIsKey(){
				    return false;
				}
				public Integer totalTravelTimeLength(){
				    return null;
				}
				public Integer totalTravelTimePrecision(){
				    return 0;
				}
				public String totalTravelTimeDefault(){
				
					return null;
				
				}
				public String totalTravelTimeComment(){
				
				    return "";
				
				}
				public String totalTravelTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalTravelTimeOriginalDbColumnName(){
				
					return "totalTravelTime";
				
				}

				
			    public Double totalDistance;

				public Double getTotalDistance () {
					return this.totalDistance;
				}

				public Boolean totalDistanceIsNullable(){
				    return true;
				}
				public Boolean totalDistanceIsKey(){
				    return false;
				}
				public Integer totalDistanceLength(){
				    return null;
				}
				public Integer totalDistancePrecision(){
				    return 13;
				}
				public String totalDistanceDefault(){
				
					return null;
				
				}
				public String totalDistanceComment(){
				
				    return "";
				
				}
				public String totalDistancePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalDistanceOriginalDbColumnName(){
				
					return "totalDistance";
				
				}

				
			    public String labelsAndSkills___;

				public String getLabelsAndSkills___ () {
					return this.labelsAndSkills___;
				}

				public Boolean labelsAndSkills___IsNullable(){
				    return true;
				}
				public Boolean labelsAndSkills___IsKey(){
				    return false;
				}
				public Integer labelsAndSkills___Length(){
				    return 9;
				}
				public Integer labelsAndSkills___Precision(){
				    return 0;
				}
				public String labelsAndSkills___Default(){
				
					return null;
				
				}
				public String labelsAndSkills___Comment(){
				
				    return "";
				
				}
				public String labelsAndSkills___Pattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String labelsAndSkills___OriginalDbColumnName(){
				
					return "labelsAndSkills___";
				
				}

				
			    public Double totalWaitTime;

				public Double getTotalWaitTime () {
					return this.totalWaitTime;
				}

				public Boolean totalWaitTimeIsNullable(){
				    return true;
				}
				public Boolean totalWaitTimeIsKey(){
				    return false;
				}
				public Integer totalWaitTimeLength(){
				    return null;
				}
				public Integer totalWaitTimePrecision(){
				    return 0;
				}
				public String totalWaitTimeDefault(){
				
					return null;
				
				}
				public String totalWaitTimeComment(){
				
				    return "";
				
				}
				public String totalWaitTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalWaitTimeOriginalDbColumnName(){
				
					return "totalWaitTime";
				
				}

				
			    public Double totalViolationTime;

				public Double getTotalViolationTime () {
					return this.totalViolationTime;
				}

				public Boolean totalViolationTimeIsNullable(){
				    return true;
				}
				public Boolean totalViolationTimeIsKey(){
				    return false;
				}
				public Integer totalViolationTimeLength(){
				    return null;
				}
				public Integer totalViolationTimePrecision(){
				    return 0;
				}
				public String totalViolationTimeDefault(){
				
					return null;
				
				}
				public String totalViolationTimeComment(){
				
				    return "";
				
				}
				public String totalViolationTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String totalViolationTimeOriginalDbColumnName(){
				
					return "totalViolationTime";
				
				}

				
			    public Boolean validated;

				public Boolean getValidated () {
					return this.validated;
				}

				public Boolean validatedIsNullable(){
				    return true;
				}
				public Boolean validatedIsKey(){
				    return false;
				}
				public Integer validatedLength(){
				    return 4;
				}
				public Integer validatedPrecision(){
				    return 0;
				}
				public String validatedDefault(){
				
					return null;
				
				}
				public String validatedComment(){
				
				    return "";
				
				}
				public String validatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String validatedOriginalDbColumnName(){
				
					return "validated";
				
				}

				
			    public String updated;

				public String getUpdated () {
					return this.updated;
				}

				public Boolean updatedIsNullable(){
				    return true;
				}
				public Boolean updatedIsKey(){
				    return false;
				}
				public Integer updatedLength(){
				    return null;
				}
				public Integer updatedPrecision(){
				    return 0;
				}
				public String updatedDefault(){
				
					return null;
				
				}
				public String updatedComment(){
				
				    return "";
				
				}
				public String updatedPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updatedOriginalDbColumnName(){
				
					return "updated";
				
				}

				
			    public String immatriculation;

				public String getImmatriculation () {
					return this.immatriculation;
				}

				public Boolean immatriculationIsNullable(){
				    return true;
				}
				public Boolean immatriculationIsKey(){
				    return false;
				}
				public Integer immatriculationLength(){
				    return 9;
				}
				public Integer immatriculationPrecision(){
				    return 0;
				}
				public String immatriculationDefault(){
				
					return null;
				
				}
				public String immatriculationComment(){
				
				    return "";
				
				}
				public String immatriculationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String immatriculationOriginalDbColumnName(){
				
					return "immatriculation";
				
				}

				
			    public String PhotoVehiculeAvant;

				public String getPhotoVehiculeAvant () {
					return this.PhotoVehiculeAvant;
				}

				public Boolean PhotoVehiculeAvantIsNullable(){
				    return true;
				}
				public Boolean PhotoVehiculeAvantIsKey(){
				    return false;
				}
				public Integer PhotoVehiculeAvantLength(){
				    return 40;
				}
				public Integer PhotoVehiculeAvantPrecision(){
				    return 0;
				}
				public String PhotoVehiculeAvantDefault(){
				
					return null;
				
				}
				public String PhotoVehiculeAvantComment(){
				
				    return "";
				
				}
				public String PhotoVehiculeAvantPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotoVehiculeAvantOriginalDbColumnName(){
				
					return "PhotoVehiculeAvant";
				
				}

				
			    public String PhotovehiculeArriere;

				public String getPhotovehiculeArriere () {
					return this.PhotovehiculeArriere;
				}

				public Boolean PhotovehiculeArriereIsNullable(){
				    return true;
				}
				public Boolean PhotovehiculeArriereIsKey(){
				    return false;
				}
				public Integer PhotovehiculeArriereLength(){
				    return 40;
				}
				public Integer PhotovehiculeArrierePrecision(){
				    return 0;
				}
				public String PhotovehiculeArriereDefault(){
				
					return null;
				
				}
				public String PhotovehiculeArriereComment(){
				
				    return "";
				
				}
				public String PhotovehiculeArrierePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotovehiculeArriereOriginalDbColumnName(){
				
					return "PhotovehiculeArriere";
				
				}

				
			    public String photoVehiculedroit;

				public String getPhotoVehiculedroit () {
					return this.photoVehiculedroit;
				}

				public Boolean photoVehiculedroitIsNullable(){
				    return true;
				}
				public Boolean photoVehiculedroitIsKey(){
				    return false;
				}
				public Integer photoVehiculedroitLength(){
				    return 40;
				}
				public Integer photoVehiculedroitPrecision(){
				    return 0;
				}
				public String photoVehiculedroitDefault(){
				
					return null;
				
				}
				public String photoVehiculedroitComment(){
				
				    return "";
				
				}
				public String photoVehiculedroitPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String photoVehiculedroitOriginalDbColumnName(){
				
					return "photoVehiculedroit";
				
				}

				
			    public String PhotoVehicuelGauche;

				public String getPhotoVehicuelGauche () {
					return this.PhotoVehicuelGauche;
				}

				public Boolean PhotoVehicuelGaucheIsNullable(){
				    return true;
				}
				public Boolean PhotoVehicuelGaucheIsKey(){
				    return false;
				}
				public Integer PhotoVehicuelGaucheLength(){
				    return 40;
				}
				public Integer PhotoVehicuelGauchePrecision(){
				    return 0;
				}
				public String PhotoVehicuelGaucheDefault(){
				
					return null;
				
				}
				public String PhotoVehicuelGaucheComment(){
				
				    return "";
				
				}
				public String PhotoVehicuelGauchePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PhotoVehicuelGaucheOriginalDbColumnName(){
				
					return "PhotoVehicuelGauche";
				
				}

				
			    public Double kmDepart;

				public Double getKmDepart () {
					return this.kmDepart;
				}

				public Boolean kmDepartIsNullable(){
				    return true;
				}
				public Boolean kmDepartIsKey(){
				    return false;
				}
				public Integer kmDepartLength(){
				    return null;
				}
				public Integer kmDepartPrecision(){
				    return 0;
				}
				public String kmDepartDefault(){
				
					return null;
				
				}
				public String kmDepartComment(){
				
				    return "";
				
				}
				public String kmDepartPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String kmDepartOriginalDbColumnName(){
				
					return "kmDepart";
				
				}

				
			    public String startLocation;

				public String getStartLocation () {
					return this.startLocation;
				}

				public Boolean startLocationIsNullable(){
				    return true;
				}
				public Boolean startLocationIsKey(){
				    return false;
				}
				public Integer startLocationLength(){
				    return 3;
				}
				public Integer startLocationPrecision(){
				    return 0;
				}
				public String startLocationDefault(){
				
					return null;
				
				}
				public String startLocationComment(){
				
				    return "";
				
				}
				public String startLocationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String startLocationOriginalDbColumnName(){
				
					return "startLocation";
				
				}

				
			    public String endLocation;

				public String getEndLocation () {
					return this.endLocation;
				}

				public Boolean endLocationIsNullable(){
				    return true;
				}
				public Boolean endLocationIsKey(){
				    return false;
				}
				public Integer endLocationLength(){
				    return 3;
				}
				public Integer endLocationPrecision(){
				    return 0;
				}
				public String endLocationDefault(){
				
					return null;
				
				}
				public String endLocationComment(){
				
				    return "";
				
				}
				public String endLocationPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String endLocationOriginalDbColumnName(){
				
					return "endLocation";
				
				}

				
			    public String startTime;

				public String getStartTime () {
					return this.startTime;
				}

				public Boolean startTimeIsNullable(){
				    return true;
				}
				public Boolean startTimeIsKey(){
				    return false;
				}
				public Integer startTimeLength(){
				    return null;
				}
				public Integer startTimePrecision(){
				    return 0;
				}
				public String startTimeDefault(){
				
					return null;
				
				}
				public String startTimeComment(){
				
				    return "";
				
				}
				public String startTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String startTimeOriginalDbColumnName(){
				
					return "startTime";
				
				}

				
			    public String endTime;

				public String getEndTime () {
					return this.endTime;
				}

				public Boolean endTimeIsNullable(){
				    return true;
				}
				public Boolean endTimeIsKey(){
				    return false;
				}
				public Integer endTimeLength(){
				    return null;
				}
				public Integer endTimePrecision(){
				    return 0;
				}
				public String endTimeDefault(){
				
					return null;
				
				}
				public String endTimeComment(){
				
				    return "";
				
				}
				public String endTimePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String endTimeOriginalDbColumnName(){
				
					return "endTime";
				
				}

				
			    public Double weight;

				public Double getWeight () {
					return this.weight;
				}

				public Boolean weightIsNullable(){
				    return true;
				}
				public Boolean weightIsKey(){
				    return false;
				}
				public Integer weightLength(){
				    return null;
				}
				public Integer weightPrecision(){
				    return 0;
				}
				public String weightDefault(){
				
					return null;
				
				}
				public String weightComment(){
				
				    return "";
				
				}
				public String weightPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String weightOriginalDbColumnName(){
				
					return "weight";
				
				}

				
			    public Double volume;

				public Double getVolume () {
					return this.volume;
				}

				public Boolean volumeIsNullable(){
				    return true;
				}
				public Boolean volumeIsKey(){
				    return false;
				}
				public Integer volumeLength(){
				    return null;
				}
				public Integer volumePrecision(){
				    return 2;
				}
				public String volumeDefault(){
				
					return null;
				
				}
				public String volumeComment(){
				
				    return "";
				
				}
				public String volumePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String volumeOriginalDbColumnName(){
				
					return "volume";
				
				}

				
			    public String date;

				public String getDate () {
					return this.date;
				}

				public Boolean dateIsNullable(){
				    return true;
				}
				public Boolean dateIsKey(){
				    return false;
				}
				public Integer dateLength(){
				    return null;
				}
				public Integer datePrecision(){
				    return 0;
				}
				public String dateDefault(){
				
					return null;
				
				}
				public String dateComment(){
				
				    return "";
				
				}
				public String datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String dateOriginalDbColumnName(){
				
					return "date";
				
				}

				
			    public String platform;

				public String getPlatform () {
					return this.platform;
				}

				public Boolean platformIsNullable(){
				    return true;
				}
				public Boolean platformIsKey(){
				    return false;
				}
				public Integer platformLength(){
				    return 24;
				}
				public Integer platformPrecision(){
				    return 0;
				}
				public String platformDefault(){
				
					return null;
				
				}
				public String platformComment(){
				
				    return "";
				
				}
				public String platformPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String platformOriginalDbColumnName(){
				
					return "platform";
				
				}

				
			    public String flux;

				public String getFlux () {
					return this.flux;
				}

				public Boolean fluxIsNullable(){
				    return true;
				}
				public Boolean fluxIsKey(){
				    return false;
				}
				public Integer fluxLength(){
				    return 24;
				}
				public Integer fluxPrecision(){
				    return 0;
				}
				public String fluxDefault(){
				
					return null;
				
				}
				public String fluxComment(){
				
				    return "";
				
				}
				public String fluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String fluxOriginalDbColumnName(){
				
					return "flux";
				
				}

				
			    public String targetFlux;

				public String getTargetFlux () {
					return this.targetFlux;
				}

				public Boolean targetFluxIsNullable(){
				    return true;
				}
				public Boolean targetFluxIsKey(){
				    return false;
				}
				public Integer targetFluxLength(){
				    return 61;
				}
				public Integer targetFluxPrecision(){
				    return 0;
				}
				public String targetFluxDefault(){
				
					return null;
				
				}
				public String targetFluxComment(){
				
				    return "";
				
				}
				public String targetFluxPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String targetFluxOriginalDbColumnName(){
				
					return "targetFlux";
				
				}

				
			    public String picture;

				public String getPicture () {
					return this.picture;
				}

				public Boolean pictureIsNullable(){
				    return true;
				}
				public Boolean pictureIsKey(){
				    return false;
				}
				public Integer pictureLength(){
				    return 89;
				}
				public Integer picturePrecision(){
				    return 0;
				}
				public String pictureDefault(){
				
					return null;
				
				}
				public String pictureComment(){
				
				    return "";
				
				}
				public String picturePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String pictureOriginalDbColumnName(){
				
					return "picture";
				
				}

				
			    public String vehicule;

				public String getVehicule () {
					return this.vehicule;
				}

				public Boolean vehiculeIsNullable(){
				    return true;
				}
				public Boolean vehiculeIsKey(){
				    return false;
				}
				public Integer vehiculeLength(){
				    return 24;
				}
				public Integer vehiculePrecision(){
				    return 0;
				}
				public String vehiculeDefault(){
				
					return null;
				
				}
				public String vehiculeComment(){
				
				    return "";
				
				}
				public String vehiculePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String vehiculeOriginalDbColumnName(){
				
					return "vehicule";
				
				}

				
			    public String driver;

				public String getDriver () {
					return this.driver;
				}

				public Boolean driverIsNullable(){
				    return true;
				}
				public Boolean driverIsKey(){
				    return false;
				}
				public Integer driverLength(){
				    return 24;
				}
				public Integer driverPrecision(){
				    return 0;
				}
				public String driverDefault(){
				
					return null;
				
				}
				public String driverComment(){
				
				    return "";
				
				}
				public String driverPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String driverOriginalDbColumnName(){
				
					return "driver";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.roundName = readString(dis);
					
					this.realInfoHasPrepared = readString(dis);
					
					this.realInfoHasStarted = readString(dis);
					
					this.realInfoHasFinished = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoPreparationTime = null;
           				} else {
           			    	this.realInfoPreparationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoHasLasted = null;
           				} else {
           			    	this.realInfoHasLasted = dis.readDouble();
           				}
					
					this.reloads___ = readString(dis);
					
					this.activity = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.orderCount = null;
           				} else {
           			    	this.orderCount = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalCost = null;
           				} else {
           			    	this.totalCost = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTime = null;
           				} else {
           			    	this.totalTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalOrderServiceTime = null;
           				} else {
           			    	this.totalOrderServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalBreakServiceTime = null;
           				} else {
           			    	this.totalBreakServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTravelTime = null;
           				} else {
           			    	this.totalTravelTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalDistance = null;
           				} else {
           			    	this.totalDistance = dis.readDouble();
           				}
					
					this.labelsAndSkills___ = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalWaitTime = null;
           				} else {
           			    	this.totalWaitTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalViolationTime = null;
           				} else {
           			    	this.totalViolationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.validated = null;
           				} else {
           			    	this.validated = dis.readBoolean();
           				}
					
					this.updated = readString(dis);
					
					this.immatriculation = readString(dis);
					
					this.PhotoVehiculeAvant = readString(dis);
					
					this.PhotovehiculeArriere = readString(dis);
					
					this.photoVehiculedroit = readString(dis);
					
					this.PhotoVehicuelGauche = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.kmDepart = null;
           				} else {
           			    	this.kmDepart = dis.readDouble();
           				}
					
					this.startLocation = readString(dis);
					
					this.endLocation = readString(dis);
					
					this.startTime = readString(dis);
					
					this.endTime = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.platform = readString(dis);
					
					this.flux = readString(dis);
					
					this.targetFlux = readString(dis);
					
					this.picture = readString(dis);
					
					this.vehicule = readString(dis);
					
					this.driver = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.roundId = readString(dis);
					
					this.roundName = readString(dis);
					
					this.realInfoHasPrepared = readString(dis);
					
					this.realInfoHasStarted = readString(dis);
					
					this.realInfoHasFinished = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoPreparationTime = null;
           				} else {
           			    	this.realInfoPreparationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.realInfoHasLasted = null;
           				} else {
           			    	this.realInfoHasLasted = dis.readDouble();
           				}
					
					this.reloads___ = readString(dis);
					
					this.activity = readString(dis);
					
					this.status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.orderCount = null;
           				} else {
           			    	this.orderCount = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalCost = null;
           				} else {
           			    	this.totalCost = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTime = null;
           				} else {
           			    	this.totalTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalOrderServiceTime = null;
           				} else {
           			    	this.totalOrderServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalBreakServiceTime = null;
           				} else {
           			    	this.totalBreakServiceTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalTravelTime = null;
           				} else {
           			    	this.totalTravelTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalDistance = null;
           				} else {
           			    	this.totalDistance = dis.readDouble();
           				}
					
					this.labelsAndSkills___ = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalWaitTime = null;
           				} else {
           			    	this.totalWaitTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.totalViolationTime = null;
           				} else {
           			    	this.totalViolationTime = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.validated = null;
           				} else {
           			    	this.validated = dis.readBoolean();
           				}
					
					this.updated = readString(dis);
					
					this.immatriculation = readString(dis);
					
					this.PhotoVehiculeAvant = readString(dis);
					
					this.PhotovehiculeArriere = readString(dis);
					
					this.photoVehiculedroit = readString(dis);
					
					this.PhotoVehicuelGauche = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.kmDepart = null;
           				} else {
           			    	this.kmDepart = dis.readDouble();
           				}
					
					this.startLocation = readString(dis);
					
					this.endLocation = readString(dis);
					
					this.startTime = readString(dis);
					
					this.endTime = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.weight = null;
           				} else {
           			    	this.weight = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.volume = null;
           				} else {
           			    	this.volume = dis.readDouble();
           				}
					
					this.date = readString(dis);
					
					this.platform = readString(dis);
					
					this.flux = readString(dis);
					
					this.targetFlux = readString(dis);
					
					this.picture = readString(dis);
					
					this.vehicule = readString(dis);
					
					this.driver = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// String
				
						writeString(this.realInfoHasPrepared,dos);
					
					// String
				
						writeString(this.realInfoHasStarted,dos);
					
					// String
				
						writeString(this.realInfoHasFinished,dos);
					
					// Double
				
						if(this.realInfoPreparationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoPreparationTime);
		            	}
					
					// Double
				
						if(this.realInfoHasLasted == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoHasLasted);
		            	}
					
					// String
				
						writeString(this.reloads___,dos);
					
					// String
				
						writeString(this.activity,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.orderCount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.orderCount);
		            	}
					
					// Double
				
						if(this.totalCost == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalCost);
		            	}
					
					// Double
				
						if(this.totalTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTime);
		            	}
					
					// Double
				
						if(this.totalOrderServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalOrderServiceTime);
		            	}
					
					// Double
				
						if(this.totalBreakServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalBreakServiceTime);
		            	}
					
					// Double
				
						if(this.totalTravelTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTravelTime);
		            	}
					
					// Double
				
						if(this.totalDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalDistance);
		            	}
					
					// String
				
						writeString(this.labelsAndSkills___,dos);
					
					// Double
				
						if(this.totalWaitTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalWaitTime);
		            	}
					
					// Double
				
						if(this.totalViolationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalViolationTime);
		            	}
					
					// Boolean
				
						if(this.validated == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.validated);
		            	}
					
					// String
				
						writeString(this.updated,dos);
					
					// String
				
						writeString(this.immatriculation,dos);
					
					// String
				
						writeString(this.PhotoVehiculeAvant,dos);
					
					// String
				
						writeString(this.PhotovehiculeArriere,dos);
					
					// String
				
						writeString(this.photoVehiculedroit,dos);
					
					// String
				
						writeString(this.PhotoVehicuelGauche,dos);
					
					// Double
				
						if(this.kmDepart == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.kmDepart);
		            	}
					
					// String
				
						writeString(this.startLocation,dos);
					
					// String
				
						writeString(this.endLocation,dos);
					
					// String
				
						writeString(this.startTime,dos);
					
					// String
				
						writeString(this.endTime,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.platform,dos);
					
					// String
				
						writeString(this.flux,dos);
					
					// String
				
						writeString(this.targetFlux,dos);
					
					// String
				
						writeString(this.picture,dos);
					
					// String
				
						writeString(this.vehicule,dos);
					
					// String
				
						writeString(this.driver,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.roundId,dos);
					
					// String
				
						writeString(this.roundName,dos);
					
					// String
				
						writeString(this.realInfoHasPrepared,dos);
					
					// String
				
						writeString(this.realInfoHasStarted,dos);
					
					// String
				
						writeString(this.realInfoHasFinished,dos);
					
					// Double
				
						if(this.realInfoPreparationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoPreparationTime);
		            	}
					
					// Double
				
						if(this.realInfoHasLasted == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.realInfoHasLasted);
		            	}
					
					// String
				
						writeString(this.reloads___,dos);
					
					// String
				
						writeString(this.activity,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Double
				
						if(this.orderCount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.orderCount);
		            	}
					
					// Double
				
						if(this.totalCost == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalCost);
		            	}
					
					// Double
				
						if(this.totalTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTime);
		            	}
					
					// Double
				
						if(this.totalOrderServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalOrderServiceTime);
		            	}
					
					// Double
				
						if(this.totalBreakServiceTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalBreakServiceTime);
		            	}
					
					// Double
				
						if(this.totalTravelTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalTravelTime);
		            	}
					
					// Double
				
						if(this.totalDistance == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalDistance);
		            	}
					
					// String
				
						writeString(this.labelsAndSkills___,dos);
					
					// Double
				
						if(this.totalWaitTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalWaitTime);
		            	}
					
					// Double
				
						if(this.totalViolationTime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.totalViolationTime);
		            	}
					
					// Boolean
				
						if(this.validated == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.validated);
		            	}
					
					// String
				
						writeString(this.updated,dos);
					
					// String
				
						writeString(this.immatriculation,dos);
					
					// String
				
						writeString(this.PhotoVehiculeAvant,dos);
					
					// String
				
						writeString(this.PhotovehiculeArriere,dos);
					
					// String
				
						writeString(this.photoVehiculedroit,dos);
					
					// String
				
						writeString(this.PhotoVehicuelGauche,dos);
					
					// Double
				
						if(this.kmDepart == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.kmDepart);
		            	}
					
					// String
				
						writeString(this.startLocation,dos);
					
					// String
				
						writeString(this.endLocation,dos);
					
					// String
				
						writeString(this.startTime,dos);
					
					// String
				
						writeString(this.endTime,dos);
					
					// Double
				
						if(this.weight == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.weight);
		            	}
					
					// Double
				
						if(this.volume == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.volume);
		            	}
					
					// String
				
						writeString(this.date,dos);
					
					// String
				
						writeString(this.platform,dos);
					
					// String
				
						writeString(this.flux,dos);
					
					// String
				
						writeString(this.targetFlux,dos);
					
					// String
				
						writeString(this.picture,dos);
					
					// String
				
						writeString(this.vehicule,dos);
					
					// String
				
						writeString(this.driver,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("roundId="+roundId);
		sb.append(",roundName="+roundName);
		sb.append(",realInfoHasPrepared="+realInfoHasPrepared);
		sb.append(",realInfoHasStarted="+realInfoHasStarted);
		sb.append(",realInfoHasFinished="+realInfoHasFinished);
		sb.append(",realInfoPreparationTime="+String.valueOf(realInfoPreparationTime));
		sb.append(",realInfoHasLasted="+String.valueOf(realInfoHasLasted));
		sb.append(",reloads___="+reloads___);
		sb.append(",activity="+activity);
		sb.append(",status="+status);
		sb.append(",orderCount="+String.valueOf(orderCount));
		sb.append(",totalCost="+String.valueOf(totalCost));
		sb.append(",totalTime="+String.valueOf(totalTime));
		sb.append(",totalOrderServiceTime="+String.valueOf(totalOrderServiceTime));
		sb.append(",totalBreakServiceTime="+String.valueOf(totalBreakServiceTime));
		sb.append(",totalTravelTime="+String.valueOf(totalTravelTime));
		sb.append(",totalDistance="+String.valueOf(totalDistance));
		sb.append(",labelsAndSkills___="+labelsAndSkills___);
		sb.append(",totalWaitTime="+String.valueOf(totalWaitTime));
		sb.append(",totalViolationTime="+String.valueOf(totalViolationTime));
		sb.append(",validated="+String.valueOf(validated));
		sb.append(",updated="+updated);
		sb.append(",immatriculation="+immatriculation);
		sb.append(",PhotoVehiculeAvant="+PhotoVehiculeAvant);
		sb.append(",PhotovehiculeArriere="+PhotovehiculeArriere);
		sb.append(",photoVehiculedroit="+photoVehiculedroit);
		sb.append(",PhotoVehicuelGauche="+PhotoVehicuelGauche);
		sb.append(",kmDepart="+String.valueOf(kmDepart));
		sb.append(",startLocation="+startLocation);
		sb.append(",endLocation="+endLocation);
		sb.append(",startTime="+startTime);
		sb.append(",endTime="+endTime);
		sb.append(",weight="+String.valueOf(weight));
		sb.append(",volume="+String.valueOf(volume));
		sb.append(",date="+date);
		sb.append(",platform="+platform);
		sb.append(",flux="+flux);
		sb.append(",targetFlux="+targetFlux);
		sb.append(",picture="+picture);
		sb.append(",vehicule="+vehicule);
		sb.append(",driver="+driver);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(roundId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundId);
            			}
            		
        			sb.append("|");
        		
        				if(roundName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(roundName);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasPrepared == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasPrepared);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasStarted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasStarted);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasFinished == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasFinished);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoPreparationTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoPreparationTime);
            			}
            		
        			sb.append("|");
        		
        				if(realInfoHasLasted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(realInfoHasLasted);
            			}
            		
        			sb.append("|");
        		
        				if(reloads___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reloads___);
            			}
            		
        			sb.append("|");
        		
        				if(activity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(activity);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(orderCount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(orderCount);
            			}
            		
        			sb.append("|");
        		
        				if(totalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalCost);
            			}
            		
        			sb.append("|");
        		
        				if(totalTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalOrderServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalOrderServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalBreakServiceTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalBreakServiceTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalTravelTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalTravelTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalDistance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalDistance);
            			}
            		
        			sb.append("|");
        		
        				if(labelsAndSkills___ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(labelsAndSkills___);
            			}
            		
        			sb.append("|");
        		
        				if(totalWaitTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalWaitTime);
            			}
            		
        			sb.append("|");
        		
        				if(totalViolationTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(totalViolationTime);
            			}
            		
        			sb.append("|");
        		
        				if(validated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(validated);
            			}
            		
        			sb.append("|");
        		
        				if(updated == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated);
            			}
            		
        			sb.append("|");
        		
        				if(immatriculation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(immatriculation);
            			}
            		
        			sb.append("|");
        		
        				if(PhotoVehiculeAvant == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoVehiculeAvant);
            			}
            		
        			sb.append("|");
        		
        				if(PhotovehiculeArriere == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotovehiculeArriere);
            			}
            		
        			sb.append("|");
        		
        				if(photoVehiculedroit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(photoVehiculedroit);
            			}
            		
        			sb.append("|");
        		
        				if(PhotoVehicuelGauche == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhotoVehicuelGauche);
            			}
            		
        			sb.append("|");
        		
        				if(kmDepart == null){
        					sb.append("<null>");
        				}else{
            				sb.append(kmDepart);
            			}
            		
        			sb.append("|");
        		
        				if(startLocation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(startLocation);
            			}
            		
        			sb.append("|");
        		
        				if(endLocation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(endLocation);
            			}
            		
        			sb.append("|");
        		
        				if(startTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(startTime);
            			}
            		
        			sb.append("|");
        		
        				if(endTime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(endTime);
            			}
            		
        			sb.append("|");
        		
        				if(weight == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weight);
            			}
            		
        			sb.append("|");
        		
        				if(volume == null){
        					sb.append("<null>");
        				}else{
            				sb.append(volume);
            			}
            		
        			sb.append("|");
        		
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(platform == null){
        					sb.append("<null>");
        				}else{
            				sb.append(platform);
            			}
            		
        			sb.append("|");
        		
        				if(flux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flux);
            			}
            		
        			sb.append("|");
        		
        				if(targetFlux == null){
        					sb.append("<null>");
        				}else{
            				sb.append(targetFlux);
            			}
            		
        			sb.append("|");
        		
        				if(picture == null){
        					sb.append("<null>");
        				}else{
            				sb.append(picture);
            			}
            		
        			sb.append("|");
        		
        				if(vehicule == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vehicule);
            			}
            		
        			sb.append("|");
        		
        				if(driver == null){
        					sb.append("<null>");
        				}else{
            				sb.append(driver);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String Round;

				public String getRound () {
					return this.Round;
				}

				public Boolean RoundIsNullable(){
				    return true;
				}
				public Boolean RoundIsKey(){
				    return false;
				}
				public Integer RoundLength(){
				    return 10000;
				}
				public Integer RoundPrecision(){
				    return 0;
				}
				public String RoundDefault(){
				
					return null;
				
				}
				public String RoundComment(){
				
				    return "";
				
				}
				public String RoundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String RoundOriginalDbColumnName(){
				
					return "Round";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Round="+Round);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String Round;

				public String getRound () {
					return this.Round;
				}

				public Boolean RoundIsNullable(){
				    return true;
				}
				public Boolean RoundIsKey(){
				    return false;
				}
				public Integer RoundLength(){
				    return 10000;
				}
				public Integer RoundPrecision(){
				    return 0;
				}
				public String RoundDefault(){
				
					return null;
				
				}
				public String RoundComment(){
				
				    return "";
				
				}
				public String RoundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String RoundOriginalDbColumnName(){
				
					return "Round";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Round="+Round);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String Round;

				public String getRound () {
					return this.Round;
				}

				public Boolean RoundIsNullable(){
				    return true;
				}
				public Boolean RoundIsKey(){
				    return false;
				}
				public Integer RoundLength(){
				    return 10000;
				}
				public Integer RoundPrecision(){
				    return 0;
				}
				public String RoundDefault(){
				
					return null;
				
				}
				public String RoundComment(){
				
				    return "";
				
				}
				public String RoundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String RoundOriginalDbColumnName(){
				
					return "Round";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Round="+Round);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String Round;

				public String getRound () {
					return this.Round;
				}

				public Boolean RoundIsNullable(){
				    return true;
				}
				public Boolean RoundIsKey(){
				    return false;
				}
				public Integer RoundLength(){
				    return 10000;
				}
				public Integer RoundPrecision(){
				    return 0;
				}
				public String RoundDefault(){
				
					return null;
				
				}
				public String RoundComment(){
				
				    return "";
				
				}
				public String RoundPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String RoundOriginalDbColumnName(){
				
					return "Round";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.Round = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Round,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Round="+Round);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Round == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Round);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public String errorMessage;

				public String getErrorMessage () {
					return this.errorMessage;
				}

				public Boolean errorMessageIsNullable(){
				    return true;
				}
				public Boolean errorMessageIsKey(){
				    return false;
				}
				public Integer errorMessageLength(){
				    return null;
				}
				public Integer errorMessagePrecision(){
				    return null;
				}
				public String errorMessageDefault(){
				
					return null;
				
				}
				public String errorMessageComment(){
				
				    return "";
				
				}
				public String errorMessagePattern(){
				
					return "";
				
				}
				public String errorMessageOriginalDbColumnName(){
				
					return "errorMessage";
				
				}

				
			    public Integer errorCode;

				public Integer getErrorCode () {
					return this.errorCode;
				}

				public Boolean errorCodeIsNullable(){
				    return true;
				}
				public Boolean errorCodeIsKey(){
				    return false;
				}
				public Integer errorCodeLength(){
				    return null;
				}
				public Integer errorCodePrecision(){
				    return null;
				}
				public String errorCodeDefault(){
				
					return null;
				
				}
				public String errorCodeComment(){
				
				    return "";
				
				}
				public String errorCodePattern(){
				
					return "";
				
				}
				public String errorCodeOriginalDbColumnName(){
				
					return "errorCode";
				
				}

				
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}

				public Boolean statusCodeIsNullable(){
				    return true;
				}
				public Boolean statusCodeIsKey(){
				    return false;
				}
				public Integer statusCodeLength(){
				    return null;
				}
				public Integer statusCodePrecision(){
				    return null;
				}
				public String statusCodeDefault(){
				
					return null;
				
				}
				public String statusCodeComment(){
				
				    return "";
				
				}
				public String statusCodePattern(){
				
					return "";
				
				}
				public String statusCodeOriginalDbColumnName(){
				
					return "statusCode";
				
				}

				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return 0;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				
			    public String string;

				public String getString () {
					return this.string;
				}

				public Boolean stringIsNullable(){
				    return true;
				}
				public Boolean stringIsKey(){
				    return false;
				}
				public Integer stringLength(){
				    return 4048;
				}
				public Integer stringPrecision(){
				    return null;
				}
				public String stringDefault(){
				
					return null;
				
				}
				public String stringComment(){
				
				    return "";
				
				}
				public String stringPattern(){
				
					return "";
				
				}
				public String stringOriginalDbColumnName(){
				
					return "string";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.errorMessage = readString(dis);
					
						this.errorCode = readInteger(dis);
					
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
					this.errorMessage = readString(dis);
					
						this.errorCode = readInteger(dis);
					
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.errorMessage,dos);
					
					// Integer
				
						writeInteger(this.errorCode,dos);
					
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.errorMessage,dos);
					
					// Integer
				
						writeInteger(this.errorCode,dos);
					
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
						dos.clearInstanceCache();
						dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("errorMessage="+errorMessage);
		sb.append(",errorCode="+String.valueOf(errorCode));
		sb.append(",statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(errorMessage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(errorMessage);
            			}
            		
        			sb.append("|");
        		
        				if(errorCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(errorCode);
            			}
            		
        			sb.append("|");
        		
        				if(statusCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statusCode);
            			}
            		
        			sb.append("|");
        		
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        				if(string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];
    static byte[] commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[0];

	
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}

				public Boolean statusCodeIsNullable(){
				    return true;
				}
				public Boolean statusCodeIsKey(){
				    return false;
				}
				public Integer statusCodeLength(){
				    return null;
				}
				public Integer statusCodePrecision(){
				    return null;
				}
				public String statusCodeDefault(){
				
					return null;
				
				}
				public String statusCodeComment(){
				
				    return "";
				
				}
				public String statusCodePattern(){
				
					return "";
				
				}
				public String statusCodeOriginalDbColumnName(){
				
					return "statusCode";
				
				}

				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}

				public Boolean bodyIsNullable(){
				    return true;
				}
				public Boolean bodyIsKey(){
				    return false;
				}
				public Integer bodyLength(){
				    return 0;
				}
				public Integer bodyPrecision(){
				    return null;
				}
				public String bodyDefault(){
				
					return null;
				
				}
				public String bodyComment(){
				
				    return "";
				
				}
				public String bodyPattern(){
				
					return "";
				
				}
				public String bodyOriginalDbColumnName(){
				
					return "body";
				
				}

				
			    public String string;

				public String getString () {
					return this.string;
				}

				public Boolean stringIsNullable(){
				    return true;
				}
				public Boolean stringIsKey(){
				    return false;
				}
				public Integer stringLength(){
				    return 4048;
				}
				public Integer stringPrecision(){
				    return null;
				}
				public String stringDefault(){
				
					return null;
				
				}
				public String stringComment(){
				
				    return "";
				
				}
				public String stringPattern(){
				
					return "";
				
				}
				public String stringOriginalDbColumnName(){
				
					return "string";
				
				}

				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length) {
				if(length < 1024 && commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.length == 0) {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[1024];
				} else {
   					commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length);
			strReturn = new String(commonByteArray_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ATELIER_FACTURATION_ECOLOTRANS_URBANTZ_ROUNDS_IMPORT) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
						dos.clearInstanceCache();
						dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(statusCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(statusCode);
            			}
            		
        			sb.append("|");
        		
        				if(body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(body);
            			}
            		
        			sb.append("|");
        		
        				if(string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tLoop_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLoop_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tLoop_1");
		org.slf4j.MDC.put("_subJobPid", "BofNcU_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();
row1Struct row1 = new row1Struct();
row3Struct row3 = new row3Struct();
row2Struct row2 = new row2Struct();
row6Struct row6 = new row6Struct();
row10Struct row10 = new row10Struct();
row4Struct row4 = new row4Struct();
row13Struct row13 = new row13Struct();
copyOfout1Struct copyOfout1 = new copyOfout1Struct();
copyOfout1Struct row14 = copyOfout1;
row7Struct row7 = new row7Struct();
row9Struct row9 = new row9Struct();
row9Struct row11 = row9;



	
	/**
	 * [tLoop_1 begin ] start
	 */

				
			int NB_ITERATE_tJava_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tLoop_1", false);
		start_Hash.put("tLoop_1", System.currentTimeMillis());
		
	
	currentComponent="tLoop_1";
	
	
		int tos_count_tLoop_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLoop_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLoop_1 = new StringBuilder();
                    log4jParamters_tLoop_1.append("Parameters:");
                            log4jParamters_tLoop_1.append("FORLOOP" + " = " + "false");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("WHILELOOP" + " = " + "true");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("DECLARATION" + " = " + "int i = 0 ;");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("CONDITION" + " = " + "((Integer)globalMap.get(\"numberOfElementsInPage\"))  == 50");
                        log4jParamters_tLoop_1.append(" | ");
                            log4jParamters_tLoop_1.append("ITERATION" + " = " + "i++;");
                        log4jParamters_tLoop_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + (log4jParamters_tLoop_1) );
                    } 
                } 
            new BytesLimit65535_tLoop_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLoop_1", "tLoop_1", "tLoop");
				talendJobLogProcess(globalMap);
			}
			

int current_iteration_tLoop_1 = 0;

int i = 0 ;;
	
		log.info("tLoop_1 - Start to loop using a while loop. Initial declaration: '" + "int i = 0 ;" + "'. Condition: '" + "((Integer)globalMap.get(\"numberOfElementsInPage\"))  == 50" + "'.");
	
while(((Integer)globalMap.get("numberOfElementsInPage"))  == 50){
	
		log.debug("tLoop_1 - Current iteration value: " + current_iteration_tLoop_1);
	
current_iteration_tLoop_1++;
globalMap.put("tLoop_1_CURRENT_ITERATION",current_iteration_tLoop_1);


 



/**
 * [tLoop_1 begin ] stop
 */
	
	/**
	 * [tLoop_1 main ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 


	tos_count_tLoop_1++;

/**
 * [tLoop_1 main ] stop
 */
	
	/**
	 * [tLoop_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 process_data_begin ] stop
 */
	NB_ITERATE_tJava_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("copyOfout1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row14", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tJava_1);
					//Thread.sleep(1000);
				}				
			







	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row10");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"urbantz_round\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"urbantz_round\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_1 = 1;
         if (updateKeyCount_tDBOutput_1 == 43 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

String tableName_tDBOutput_1 = "urbantz_round";
boolean whetherReject_tDBOutput_1 = false;

java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
long date_tDBOutput_1;

java.sql.Connection conn_tDBOutput_1 = null;
		conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );

		int count_tDBOutput_1=0;
		
				
			
				String insertIgnore_tDBOutput_1 = "INSERT IGNORE INTO `" + "urbantz_round" + "` (`roundId`,`roundName`,`realInfoHasPrepared`,`realInfoHasStarted`,`realInfoHasFinished`,`realInfoPreparationTime`,`realInfoHasLasted`,`reloads___`,`activity`,`status`,`orderCount`,`totalCost`,`totalTime`,`totalOrderServiceTime`,`totalBreakServiceTime`,`totalTravelTime`,`totalDistance`,`labelsAndSkills___`,`totalWaitTime`,`totalViolationTime`,`validated`,`updated`,`immatriculation`,`PhotoVehiculeAvant`,`PhotovehiculeArriere`,`photoVehiculedroit`,`PhotoVehicuelGauche`,`kmDepart`,`startLocation`,`endLocation`,`startTime`,`endTime`,`weight`,`volume`,`date`,`platform`,`flux`,`targetFlux`,`picture`,`vehicule`,`driver`,`is_deleted`,`billingRoundName`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `roundName` = ?,`realInfoHasPrepared` = ?,`realInfoHasStarted` = ?,`realInfoHasFinished` = ?,`realInfoPreparationTime` = ?,`realInfoHasLasted` = ?,`reloads___` = ?,`activity` = ?,`status` = ?,`orderCount` = ?,`totalCost` = ?,`totalTime` = ?,`totalOrderServiceTime` = ?,`totalBreakServiceTime` = ?,`totalTravelTime` = ?,`totalDistance` = ?,`labelsAndSkills___` = ?,`totalWaitTime` = ?,`totalViolationTime` = ?,`validated` = ?,`updated` = ?,`immatriculation` = ?,`PhotoVehiculeAvant` = ?,`PhotovehiculeArriere` = ?,`photoVehiculedroit` = ?,`PhotoVehicuelGauche` = ?,`kmDepart` = ?,`startLocation` = ?,`endLocation` = ?,`startTime` = ?,`endTime` = ?,`weight` = ?,`volume` = ?,`date` = ?,`platform` = ?,`flux` = ?,`targetFlux` = ?,`picture` = ?,`vehicule` = ?,`driver` = ?,`is_deleted` = ?,`billingRoundName` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insertIgnore_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				


 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row6_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row10_tMap_1 = 0;
				
row10Struct row10_tmp = new row10Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_3", false);
		start_Hash.put("tExtractJSONFields_3", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tExtractJSONFields_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_3 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_3.append("Parameters:");
                            log4jParamters_tExtractJSONFields_3.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSONFIELD" + " = " + "Round");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("JSON_LOOP_QUERY" + " = " + "\"$\"");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"_id\"")+", SCHEMA_COLUMN="+("roundId")+"}, {QUERY="+("\"name\"")+", SCHEMA_COLUMN="+("roundName")+"}, {QUERY="+("\"realInfo.hasPrepared\"")+", SCHEMA_COLUMN="+("realInfoHasPrepared")+"}, {QUERY="+("\"realInfo.hasStarted\"")+", SCHEMA_COLUMN="+("realInfoHasStarted")+"}, {QUERY="+("\"realInfo.hasFinished\"")+", SCHEMA_COLUMN="+("realInfoHasFinished")+"}, {QUERY="+("\"realInfo.preparationTime\"")+", SCHEMA_COLUMN="+("realInfoPreparationTime")+"}, {QUERY="+("\"realInfo.hasLasted\"")+", SCHEMA_COLUMN="+("realInfoHasLasted")+"}, {QUERY="+("\"reloads[*]\"")+", SCHEMA_COLUMN="+("reloads___")+"}, {QUERY="+("\"activity\"")+", SCHEMA_COLUMN="+("activity")+"}, {QUERY="+("\"status\"")+", SCHEMA_COLUMN="+("status")+"}, {QUERY="+("\"orderCount\"")+", SCHEMA_COLUMN="+("orderCount")+"}, {QUERY="+("\"totalCost\"")+", SCHEMA_COLUMN="+("totalCost")+"}, {QUERY="+("\"totalTime\"")+", SCHEMA_COLUMN="+("totalTime")+"}, {QUERY="+("\"totalOrderServiceTime\"")+", SCHEMA_COLUMN="+("totalOrderServiceTime")+"}, {QUERY="+("\"totalBreakServiceTime\"")+", SCHEMA_COLUMN="+("totalBreakServiceTime")+"}, {QUERY="+("\"totalTravelTime\"")+", SCHEMA_COLUMN="+("totalTravelTime")+"}, {QUERY="+("\"totalDistance\"")+", SCHEMA_COLUMN="+("totalDistance")+"}, {QUERY="+("\"labelsAndSkills[*]\"")+", SCHEMA_COLUMN="+("labelsAndSkills___")+"}, {QUERY="+("\"totalWaitTime\"")+", SCHEMA_COLUMN="+("totalWaitTime")+"}, {QUERY="+("\"totalViolationTime\"")+", SCHEMA_COLUMN="+("totalViolationTime")+"}, {QUERY="+("\"validated\"")+", SCHEMA_COLUMN="+("validated")+"}, {QUERY="+("\"updated\"")+", SCHEMA_COLUMN="+("updated")+"}, {QUERY="+("\"metadata.immatriculation\"")+", SCHEMA_COLUMN="+("immatriculation")+"}, {QUERY="+("\"metadata.PhotoVehiculeAvant\"")+", SCHEMA_COLUMN="+("PhotoVehiculeAvant")+"}, {QUERY="+("\"metadata.PhotovehiculeArriere\"")+", SCHEMA_COLUMN="+("PhotovehiculeArriere")+"}, {QUERY="+("\"metadata.photoVehiculedroit\"")+", SCHEMA_COLUMN="+("photoVehiculedroit")+"}, {QUERY="+("\"metadata.PhotoVehicuelGauche\"")+", SCHEMA_COLUMN="+("PhotoVehicuelGauche")+"}, {QUERY="+("\"metadata.kmDepart\"")+", SCHEMA_COLUMN="+("kmDepart")+"}, {QUERY="+("\"startLocation\"")+", SCHEMA_COLUMN="+("startLocation")+"}, {QUERY="+("\"endLocation\"")+", SCHEMA_COLUMN="+("endLocation")+"}, {QUERY="+("\"startTime\"")+", SCHEMA_COLUMN="+("startTime")+"}, {QUERY="+("\"endTime\"")+", SCHEMA_COLUMN="+("endTime")+"}, {QUERY="+("\"dimensions.weight\"")+", SCHEMA_COLUMN="+("weight")+"}, {QUERY="+("\"dimensions.volume\"")+", SCHEMA_COLUMN="+("volume")+"}, {QUERY="+("\"date\"")+", SCHEMA_COLUMN="+("date")+"}, {QUERY="+("\"platform\"")+", SCHEMA_COLUMN="+("platform")+"}, {QUERY="+("\"flux\"")+", SCHEMA_COLUMN="+("flux")+"}, {QUERY="+("\"targetFlux\"")+", SCHEMA_COLUMN="+("targetFlux")+"}, {QUERY="+("\"picture\"")+", SCHEMA_COLUMN="+("picture")+"}, {QUERY="+("\"vehicle._id\"")+", SCHEMA_COLUMN="+("vehicule")+"}, {QUERY="+("\"driver._id\"")+", SCHEMA_COLUMN="+("driver")+"}]");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                            log4jParamters_tExtractJSONFields_3.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + (log4jParamters_tExtractJSONFields_3) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_3", "Extract_Round_Fields", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_3 = 0;
String jsonStr_tExtractJSONFields_3 = "";

	

class JsonPathCache_tExtractJSONFields_3 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_3 jsonPathCache_tExtractJSONFields_3 = new JsonPathCache_tExtractJSONFields_3();

 



/**
 * [tExtractJSONFields_3 begin ] stop
 */







	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row14");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"urbantz_stop\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "\"urbantz_stop\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_4 = 1;
         if (updateKeyCount_tDBOutput_4 == 11 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

String tableName_tDBOutput_4 = "urbantz_stop";
boolean whetherReject_tDBOutput_4 = false;

java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
calendar_tDBOutput_4.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
calendar_tDBOutput_4.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
long date_tDBOutput_4;

java.sql.Connection conn_tDBOutput_4 = null;
		conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );

		int count_tDBOutput_4=0;
		
				
			
				String insertIgnore_tDBOutput_4 = "INSERT IGNORE INTO `" + "urbantz_stop" + "` (`travelTime`,`serviceTime`,`stopType`,`type`,`arriveTime`,`departTime`,`task`,`round`,`travelDistance`,`taskId`,`sequence`) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `travelTime` = ?,`serviceTime` = ?,`stopType` = ?,`type` = ?,`arriveTime` = ?,`departTime` = ?,`round` = ?,`travelDistance` = ?,`taskId` = ?,`sequence` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insertIgnore_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
				


 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tLogRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_3", false);
		start_Hash.put("tLogRow_3", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfout1");
			
		int tos_count_tLogRow_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_3", "tLogRow_3", "tDummyRow");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tLogRow_3 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row13");
			
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_2 = new StringBuilder();
                    log4jParamters_tMap_2.append("Parameters:");
                            log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_2.append(" | ");
                            log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
                    } 
                } 
            new BytesLimit65535_tMap_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row13_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfout1_tMap_2 = 0;
				
copyOfout1Struct copyOfout1_tmp = new copyOfout1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_5", false);
		start_Hash.put("tExtractJSONFields_5", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tExtractJSONFields_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_5 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_5.append("Parameters:");
                            log4jParamters_tExtractJSONFields_5.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("JSONFIELD" + " = " + "Round");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("JSON_LOOP_QUERY" + " = " + "\"$.stops[*]\"");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"travelTime\"")+", SCHEMA_COLUMN="+("travelTime")+"}, {QUERY="+("\"serviceTime\"")+", SCHEMA_COLUMN="+("serviceTime")+"}, {QUERY="+("\"stopType\"")+", SCHEMA_COLUMN="+("stopType")+"}, {QUERY="+("\"type\"")+", SCHEMA_COLUMN="+("type")+"}, {QUERY="+("\"arriveTime\"")+", SCHEMA_COLUMN="+("arriveTime")+"}, {QUERY="+("\"departTime\"")+", SCHEMA_COLUMN="+("departTime")+"}, {QUERY="+("\"parcel\"")+", SCHEMA_COLUMN="+("task")+"}, {QUERY="+("\"$._id\"")+", SCHEMA_COLUMN="+("round")+"}, {QUERY="+("\"travelDistance\"")+", SCHEMA_COLUMN="+("travelDistance")+"}, {QUERY="+("\"taskId\"")+", SCHEMA_COLUMN="+("taskId")+"}, {QUERY="+("\"sequence\"")+", SCHEMA_COLUMN="+("sequence")+"}]");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                            log4jParamters_tExtractJSONFields_5.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_5 - "  + (log4jParamters_tExtractJSONFields_5) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_5", "Extract_Stop_Fields_From_Round", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_5 = 0;
String jsonStr_tExtractJSONFields_5 = "";

	

class JsonPathCache_tExtractJSONFields_5 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_5 jsonPathCache_tExtractJSONFields_5 = new JsonPathCache_tExtractJSONFields_5();

 



/**
 * [tExtractJSONFields_5 begin ] stop
 */






	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row11");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"urbantz_round_senders\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT_ON_DUPLICATE_KEY_UPDATE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_HINT_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "\"urbantz_round_senders\"", "tMysqlOutput");
				talendJobLogProcess(globalMap);
			}
			






        int updateKeyCount_tDBOutput_3 = 1;
         if (updateKeyCount_tDBOutput_3 == 5 && true) {
            throw new RuntimeException("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

String tableName_tDBOutput_3 = "urbantz_round_senders";
boolean whetherReject_tDBOutput_3 = false;

java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
calendar_tDBOutput_3.set(1, 0, 1, 0, 0, 0);
long year1_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
calendar_tDBOutput_3.set(10000, 0, 1, 0, 0, 0);
long year10000_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
long date_tDBOutput_3;

java.sql.Connection conn_tDBOutput_3 = null;
		conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );

		int count_tDBOutput_3=0;
		
				
			
				String insertIgnore_tDBOutput_3 = "INSERT IGNORE INTO `" + "urbantz_round_senders" + "` (`roundId`,`count`,`senderId`,`reference`,`name`) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE `count` = ?,`senderId` = ?,`reference` = ?,`name` = ?";
				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insertIgnore_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
				


 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tLogRow_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_2", "tLogRow_2", "tDummyRow");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_4", false);
		start_Hash.put("tExtractJSONFields_4", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tExtractJSONFields_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_4 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_4.append("Parameters:");
                            log4jParamters_tExtractJSONFields_4.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSONFIELD" + " = " + "Round");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("JSON_LOOP_QUERY" + " = " + "\"$.senders[*]\"");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"$._id\"")+", SCHEMA_COLUMN="+("roundId")+"}, {QUERY="+("\"count\"")+", SCHEMA_COLUMN="+("count")+"}, {QUERY="+("\"_id\"")+", SCHEMA_COLUMN="+("senderId")+"}, {QUERY="+("\"reference\"")+", SCHEMA_COLUMN="+("reference")+"}, {QUERY="+("\"name\"")+", SCHEMA_COLUMN="+("name")+"}]");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                            log4jParamters_tExtractJSONFields_4.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + (log4jParamters_tExtractJSONFields_4) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_4", "Extract_Senders_Fields_From_Round", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_4 = 0;
String jsonStr_tExtractJSONFields_4 = "";

	

class JsonPathCache_tExtractJSONFields_4 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_4 jsonPathCache_tExtractJSONFields_4 = new JsonPathCache_tExtractJSONFields_4();

 



/**
 * [tExtractJSONFields_4 begin ] stop
 */



	
	/**
	 * [tReplicate_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tReplicate_1", false);
		start_Hash.put("tReplicate_1", System.currentTimeMillis());
		
	
	currentComponent="tReplicate_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tReplicate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tReplicate_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tReplicate_1 = new StringBuilder();
                    log4jParamters_tReplicate_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + (log4jParamters_tReplicate_1) );
                    } 
                } 
            new BytesLimit65535_tReplicate_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tReplicate_1", "tReplicate_1", "tReplicate");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tReplicate_1 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tExtractJSONFields_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tExtractJSONFields_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tExtractJSONFields_1 = new StringBuilder();
                    log4jParamters_tExtractJSONFields_1.append("Parameters:");
                            log4jParamters_tExtractJSONFields_1.append("READ_BY" + " = " + "JSONPATH");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_PATH_VERSION" + " = " + "2_1_0");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSONFIELD" + " = " + "string");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("JSON_LOOP_QUERY" + " = " + "\"$[*]\"");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("MAPPING_4_JSONPATH" + " = " + "[{QUERY="+("\"@\"")+", SCHEMA_COLUMN="+("Round")+"}]");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                            log4jParamters_tExtractJSONFields_1.append("USE_LOOP_AS_ROOT" + " = " + "false");
                        log4jParamters_tExtractJSONFields_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + (log4jParamters_tExtractJSONFields_1) );
                    } 
                } 
            new BytesLimit65535_tExtractJSONFields_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_1", "Extract_Round_From_List", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tRESTClient_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tRESTClient_1", false);
		start_Hash.put("tRESTClient_1", System.currentTimeMillis());
		
	
	currentComponent="tRESTClient_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tRESTClient_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tRESTClient_1", "tRESTClient_1", "tRESTClient");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tRESTClient_1 begin ] stop
 */



	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";
	
	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_1", "tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			



 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_begin ] stop
 */

	
	/**
	 * [tRESTClient_1 main ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tJava_1","tJava_1","tJava","tRESTClient_1","tRESTClient_1","tRESTClient"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		
	row1 = null;

// expected response body
Object responseDoc_tRESTClient_1 = null;

try {
	// request body
	org.dom4j.Document requestDoc_tRESTClient_1 = null;
	String requestString_tRESTClient_1 = null;
			if (null != row8.body) {
				requestDoc_tRESTClient_1 = row8.body.getDocument();
			}
			requestString_tRESTClient_1 = row8.string;

	Object requestBody_tRESTClient_1 = requestDoc_tRESTClient_1 != null ? requestDoc_tRESTClient_1 : requestString_tRESTClient_1;

	

    //resposne class name
	Class<?> responseClass_tRESTClient_1
		= String.class;

	// create web client instance
	org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean factoryBean_tRESTClient_1 =
			new org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean();

	boolean inOSGi = routines.system.BundleUtils.inOSGi();

	final java.util.List<org.apache.cxf.feature.Feature> features_tRESTClient_1 =
			new java.util.ArrayList<org.apache.cxf.feature.Feature>();

	String url = null;
	
		url = "https://api.urbantz.com/v2/round";
		// {baseUri}tRESTClient
		factoryBean_tRESTClient_1.setServiceName(new javax.xml.namespace.QName(url, "tRESTClient"));
		factoryBean_tRESTClient_1.setAddress(url);
	

	

    boolean log_messages_tRESTClient_1 = Boolean.valueOf(false);
	if (log_messages_tRESTClient_1) {
		org.apache.cxf.ext.logging.LoggingFeature loggingFeature = new  org.apache.cxf.ext.logging.LoggingFeature();
		loggingFeature.addSensitiveProtocolHeaderNames(new java.util.HashSet<>(java.util.Arrays.asList(org.apache.cxf.helpers.HttpHeaderHelper.AUTHORIZATION)));
		loggingFeature.addSensitiveElementNames(new java.util.HashSet<>(java.util.Arrays.asList("password")));
		features_tRESTClient_1.add(loggingFeature);
	}

	

	factoryBean_tRESTClient_1.setFeatures(features_tRESTClient_1);


	java.util.List<Object> providers_tRESTClient_1 = new java.util.ArrayList<Object>();
	providers_tRESTClient_1.add(new org.apache.cxf.jaxrs.provider.dom4j.DOM4JProvider() {
		// workaround for https://jira.talendforge.org/browse/TESB-7276
		public org.dom4j.Document readFrom(Class<org.dom4j.Document> cls,
											java.lang.reflect.Type type,
											java.lang.annotation.Annotation[] anns,
											javax.ws.rs.core.MediaType mt,
											javax.ws.rs.core.MultivaluedMap<String, String> headers,
											java.io.InputStream is)
				throws IOException, javax.ws.rs.WebApplicationException {
			String contentLength = headers.getFirst("Content-Length");
			if (!org.apache.cxf.common.util.StringUtils.isEmpty(contentLength)
					&& Integer.valueOf(contentLength) <= 0) {
				try {
					return org.dom4j.DocumentHelper.parseText("<root/>");
				} catch (org.dom4j.DocumentException e_tRESTClient_1) {
					e_tRESTClient_1.printStackTrace();
				}
				return null;
			}
			return super.readFrom(cls, type, anns, mt, headers, is);
		}
	});
	org.apache.cxf.jaxrs.provider.json.JSONProvider jsonProvider_tRESTClient_1 =
			new org.apache.cxf.jaxrs.provider.json.JSONProvider();
		jsonProvider_tRESTClient_1.setIgnoreNamespaces(true);
		jsonProvider_tRESTClient_1.setAttributesToElements(true);
	
	
	
		jsonProvider_tRESTClient_1.setSupportUnwrapped(true);
		jsonProvider_tRESTClient_1.setWrapperName("root");
	
	
		jsonProvider_tRESTClient_1.setDropRootElement(false);
		jsonProvider_tRESTClient_1.setConvertTypesToStrings(false);
	providers_tRESTClient_1.add(jsonProvider_tRESTClient_1);
	factoryBean_tRESTClient_1.setProviders(providers_tRESTClient_1);
	factoryBean_tRESTClient_1.setTransportId("http://cxf.apache.org/transports/http");

	boolean use_auth_tRESTClient_1 = false;

	

	org.apache.cxf.jaxrs.client.WebClient webClient_tRESTClient_1 = null;
	
		webClient_tRESTClient_1 = factoryBean_tRESTClient_1.createWebClient();
		// set request path
		webClient_tRESTClient_1.path("");
	

	// set connection properties
	org.apache.cxf.jaxrs.client.ClientConfiguration clientConfig_tRESTClient_1 = org.apache.cxf.jaxrs.client.WebClient.getConfig(webClient_tRESTClient_1);
	org.apache.cxf.transport.http.auth.HttpAuthSupplier httpAuthSupplerHttpConduit = null;
	org.apache.cxf.transport.http.HTTPConduit conduit_tRESTClient_1 = null;

	
		conduit_tRESTClient_1 = clientConfig_tRESTClient_1.getHttpConduit();
	
	
    if (clientConfig_tRESTClient_1.getEndpoint() != null) {
		org.apache.cxf.service.model.EndpointInfo endpointInfo_tRESTClient_1 = clientConfig_tRESTClient_1.getEndpoint().getEndpointInfo();
		if(endpointInfo_tRESTClient_1 != null) {
			endpointInfo_tRESTClient_1.setProperty("enable.webclient.operation.reporting", true);
		}
    }

	

	

	if (!inOSGi) {
		conduit_tRESTClient_1.getClient().setReceiveTimeout((long)(60 * 1000L));
		conduit_tRESTClient_1.getClient().setConnectionTimeout((long)(30 * 1000L));
	}
	
	
	
		

	

	

	
		// set Accept-Type
		webClient_tRESTClient_1.accept("application/json");
	

	
		// set optional query and header properties if any
	
		webClient_tRESTClient_1.header("x-api-key", "0OCDfeE0zXfOjWYnV9rBaXepnJFnoPJngNLGSaGhhBCpCU6U");
	
	if (use_auth_tRESTClient_1 && "OAUTH2_BEARER".equals("BASIC")) {
		// set oAuth2 bearer token
		org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier authSupplier = new org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier();
		authSupplier.setAccessToken((String) "");
		conduit_tRESTClient_1.setAuthSupplier(authSupplier);
	}

	

	// if FORM request then capture query parameters into Form, otherwise set them as queries
	
		
		
			webClient_tRESTClient_1.query("pageSize" ,50);
		
			webClient_tRESTClient_1.query("page" ,i);
		
			webClient_tRESTClient_1.query("date" ,((String)globalMap.get("day_to_retrieve")));
		
	


	try {
		// start send request
		
			responseDoc_tRESTClient_1 = webClient_tRESTClient_1.get();
			javax.ws.rs.core.Response responseObjBase_tRESTClient_1 = (javax.ws.rs.core.Response)responseDoc_tRESTClient_1;
            int status_tRESTClient_1 = responseObjBase_tRESTClient_1.getStatus();
            if (status_tRESTClient_1 != 304 && status_tRESTClient_1 >= 300 && responseClass_tRESTClient_1 != javax.ws.rs.core.Response.class) {
                throw org.apache.cxf.jaxrs.utils.ExceptionUtils.toWebApplicationException((javax.ws.rs.core.Response)responseObjBase_tRESTClient_1);
            }
            if (status_tRESTClient_1 != 204 && responseObjBase_tRESTClient_1.getEntity() != null) {
				responseDoc_tRESTClient_1 = responseObjBase_tRESTClient_1.readEntity(responseClass_tRESTClient_1);
			}
		


		int webClientResponseStatus_tRESTClient_1 = webClient_tRESTClient_1.getResponse().getStatus();
		if (webClientResponseStatus_tRESTClient_1 >= 300) {
			throw new javax.ws.rs.WebApplicationException(webClient_tRESTClient_1.getResponse());
		}

		
			if (row1 == null) {
				row1 = new row1Struct();
			}

			row1.statusCode = webClientResponseStatus_tRESTClient_1;
			row1.string = "";
			
				
				{
					Object responseObj_tRESTClient_1 = responseDoc_tRESTClient_1;
				
				if(responseObj_tRESTClient_1 != null){
					if (responseClass_tRESTClient_1 == String.class && responseObj_tRESTClient_1 instanceof String) {
							row1.string = (String) responseObj_tRESTClient_1;
					} else {
						routines.system.Document responseTalendDoc_tRESTClient_1 = null;
						if (null != responseObj_tRESTClient_1) {
							responseTalendDoc_tRESTClient_1 = new routines.system.Document();
							if (responseObj_tRESTClient_1 instanceof org.dom4j.Document) {
								responseTalendDoc_tRESTClient_1.setDocument((org.dom4j.Document) responseObj_tRESTClient_1);
							}
						}
						row1.body = responseTalendDoc_tRESTClient_1;
					}
				}
			}
			

			java.util.Map<String, javax.ws.rs.core.NewCookie> cookies_tRESTClient_1 = new java.util.HashMap<String, javax.ws.rs.core.NewCookie>();

			if (webClient_tRESTClient_1.getResponse() != null && webClient_tRESTClient_1.getResponse().getCookies() != null ) { 
				cookies_tRESTClient_1.putAll(webClient_tRESTClient_1.getResponse().getCookies());
			}

			


			globalMap.put("tRESTClient_1_HEADERS", webClient_tRESTClient_1.getResponse().getHeaders());
			globalMap.put("tRESTClient_1_COOKIES", cookies_tRESTClient_1);
			
		

	} catch (javax.ws.rs.WebApplicationException ex_tRESTClient_1) {
	    globalMap.put("tRESTClient_1_ERROR_MESSAGE",ex_tRESTClient_1.getMessage());
		
			throw ex_tRESTClient_1;
		
	}

} catch(Exception e_tRESTClient_1) {
    globalMap.put("tRESTClient_1_ERROR_MESSAGE",e_tRESTClient_1.getMessage());
	
		new TalendException(e_tRESTClient_1, currentComponent, globalMap).printStackTrace();
	
}


 


	tos_count_tRESTClient_1++;

/**
 * [tRESTClient_1 main ] stop
 */
	
	/**
	 * [tRESTClient_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tRESTClient_1","tRESTClient_1","tRESTClient","tExtractJSONFields_1","Extract_Round_From_List","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

            if(row1.string!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row1.string.toString();
   
row3 = null;

	

String loopPath_tExtractJSONFields_1 = "$[*]";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
		log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row3 = null;
	row3 = new row3Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "@";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_1.startsWith("$")){
		            if(root_tExtractJSONFields_1 == null){
		                root_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(root_tExtractJSONFields_1);
		        }else{
		            value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		        }
				row3.Round = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row3.Round = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
			log.error("tExtractJSONFields_1 - " + ex_tExtractJSONFields_1.getMessage());
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row3 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
	log.debug("tExtractJSONFields_1 - Extracting the record " + nb_line_tExtractJSONFields_1 + ".");
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tReplicate_1 main ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tExtractJSONFields_1","Extract_Round_From_List","tExtractJSONFields","tReplicate_1","tReplicate_1","tReplicate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		


	row2 = new row2Struct();
						
	row2.Round = row3.Round;			
	row4 = new row4Struct();
						
	row4.Round = row3.Round;			
	row7 = new row7Struct();
						
	row7.Round = row3.Round;			


 


	tos_count_tReplicate_1++;

/**
 * [tReplicate_1 main ] stop
 */
	
	/**
	 * [tReplicate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_3 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_3","Extract_Round_Fields","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

            if(row2.Round!=null){// C_01
                jsonStr_tExtractJSONFields_3 = row2.Round.toString();
   
row6 = null;

	

String loopPath_tExtractJSONFields_3 = "$";
java.util.List<Object> resultset_tExtractJSONFields_3 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_3 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_3 = null;
try {
	document_tExtractJSONFields_3 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_3);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(loopPath_tExtractJSONFields_3);
	Object result_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(compiledLoopPath_tExtractJSONFields_3,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_3 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_3 = (net.minidev.json.JSONArray) result_tExtractJSONFields_3;
	} else {
		resultset_tExtractJSONFields_3.add(result_tExtractJSONFields_3);
	}
	
	isStructError_tExtractJSONFields_3 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",ex_tExtractJSONFields_3.getMessage());
		log.error("tExtractJSONFields_3 - " + ex_tExtractJSONFields_3.getMessage());
		System.err.println(ex_tExtractJSONFields_3.getMessage());
}

String jsonPath_tExtractJSONFields_3 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_3 = null;

Object value_tExtractJSONFields_3 = null;

Object root_tExtractJSONFields_3 = null;
for(int i_tExtractJSONFields_3=0; isStructError_tExtractJSONFields_3 || (i_tExtractJSONFields_3 < resultset_tExtractJSONFields_3.size());i_tExtractJSONFields_3++){
	if(!isStructError_tExtractJSONFields_3){
		Object row_tExtractJSONFields_3 = resultset_tExtractJSONFields_3.get(i_tExtractJSONFields_3);
            row6 = null;
	row6 = new row6Struct();
	nb_line_tExtractJSONFields_3++;
	try {
		jsonPath_tExtractJSONFields_3 = "_id";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.roundId = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.roundId = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "name";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.roundName = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.roundName = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "realInfo.hasPrepared";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.realInfoHasPrepared = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.realInfoHasPrepared = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "realInfo.hasStarted";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.realInfoHasStarted = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.realInfoHasStarted = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "realInfo.hasFinished";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.realInfoHasFinished = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.realInfoHasFinished = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "realInfo.preparationTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.realInfoPreparationTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.realInfoPreparationTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.realInfoPreparationTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "realInfo.hasLasted";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.realInfoHasLasted = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.realInfoHasLasted = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.realInfoHasLasted = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "reloads[*]";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.reloads___ = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.reloads___ = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "activity";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.activity = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.activity = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "status";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.status = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.status = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "orderCount";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.orderCount = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.orderCount = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.orderCount = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalCost";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalCost = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalCost = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalCost = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalOrderServiceTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalOrderServiceTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalOrderServiceTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalOrderServiceTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalBreakServiceTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalBreakServiceTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalBreakServiceTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalBreakServiceTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalTravelTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalTravelTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalTravelTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalTravelTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalDistance";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalDistance = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalDistance = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalDistance = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "labelsAndSkills[*]";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.labelsAndSkills___ = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.labelsAndSkills___ = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalWaitTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalWaitTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalWaitTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalWaitTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "totalViolationTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.totalViolationTime = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.totalViolationTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.totalViolationTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "validated";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.validated = ParserUtils.parseTo_Boolean(value_tExtractJSONFields_3.toString());
				} else {
					row6.validated = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.validated = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "updated";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.updated = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.updated = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.immatriculation";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.immatriculation = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.immatriculation = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.PhotoVehiculeAvant";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.PhotoVehiculeAvant = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.PhotoVehiculeAvant = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.PhotovehiculeArriere";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.PhotovehiculeArriere = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.PhotovehiculeArriere = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.photoVehiculedroit";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.photoVehiculedroit = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.photoVehiculedroit = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.PhotoVehicuelGauche";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.PhotoVehicuelGauche = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.PhotoVehicuelGauche = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "metadata.kmDepart";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.kmDepart = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.kmDepart = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.kmDepart = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "startLocation";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.startLocation = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.startLocation = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "endLocation";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.endLocation = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.endLocation = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "startTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.startTime = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.startTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "endTime";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.endTime = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.endTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "dimensions.weight";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.weight = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.weight = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.weight = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "dimensions.volume";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				if(value_tExtractJSONFields_3 != null && !value_tExtractJSONFields_3.toString().isEmpty()) {
					row6.volume = ParserUtils.parseTo_Double(value_tExtractJSONFields_3.toString());
				} else {
					row6.volume = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.volume = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "date";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.date = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.date = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "platform";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.platform = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.platform = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "flux";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.flux = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.flux = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "targetFlux";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.targetFlux = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.targetFlux = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "picture";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.picture = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.picture = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "vehicle._id";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.vehicule = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.vehicule = 

		null

;
		}
		jsonPath_tExtractJSONFields_3 = "driver._id";
		compiledJsonPath_tExtractJSONFields_3 = jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath(jsonPath_tExtractJSONFields_3);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_3.startsWith("$")){
		            if(root_tExtractJSONFields_3 == null){
		                root_tExtractJSONFields_3 = document_tExtractJSONFields_3.read(jsonPathCache_tExtractJSONFields_3.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(root_tExtractJSONFields_3);
		        }else{
		            value_tExtractJSONFields_3 = compiledJsonPath_tExtractJSONFields_3.read(row_tExtractJSONFields_3);
		        }
				row6.driver = value_tExtractJSONFields_3 == null ? 

		null

 : value_tExtractJSONFields_3.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",e_tExtractJSONFields_3.getMessage());
			row6.driver = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_3) {
globalMap.put("tExtractJSONFields_3_ERROR_MESSAGE",ex_tExtractJSONFields_3.getMessage());
			log.error("tExtractJSONFields_3 - " + ex_tExtractJSONFields_3.getMessage());
		    System.err.println(ex_tExtractJSONFields_3.getMessage());
		    row6 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_3 = false;
	
	log.debug("tExtractJSONFields_3 - Extracting the record " + nb_line_tExtractJSONFields_3 + ".");
//}


 


	tos_count_tExtractJSONFields_3++;

/**
 * [tExtractJSONFields_3 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		

 



/**
 * [tExtractJSONFields_3 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tExtractJSONFields_3","Extract_Round_Fields","tExtractJSONFields","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

row10 = null;


// # Output table : 'row10'
count_row10_tMap_1++;

row10_tmp.roundId = row6.roundId;
row10_tmp.roundName = row6.roundName;
row10_tmp.realInfoHasPrepared = row6.realInfoHasPrepared;
row10_tmp.realInfoHasStarted = row6.realInfoHasStarted;
row10_tmp.realInfoHasFinished = row6.realInfoHasFinished;
row10_tmp.realInfoPreparationTime = row6.realInfoPreparationTime;
row10_tmp.realInfoHasLasted = row6.realInfoHasLasted;
row10_tmp.reloads___ = row6.reloads___;
row10_tmp.activity = row6.activity;
row10_tmp.status = row6.status;
row10_tmp.orderCount = row6.orderCount;
row10_tmp.totalCost = row6.totalCost;
row10_tmp.totalTime = row6.totalTime;
row10_tmp.totalOrderServiceTime = row6.totalOrderServiceTime;
row10_tmp.totalBreakServiceTime = row6.totalBreakServiceTime;
row10_tmp.totalTravelTime = row6.totalTravelTime;
row10_tmp.totalDistance = row6.totalDistance;
row10_tmp.labelsAndSkills___ = row6.labelsAndSkills___;
row10_tmp.totalWaitTime = row6.totalWaitTime;
row10_tmp.totalViolationTime = row6.totalViolationTime;
row10_tmp.validated = row6.validated;
row10_tmp.updated = row6.updated;
row10_tmp.immatriculation = row6.immatriculation;
row10_tmp.PhotoVehiculeAvant = row6.PhotoVehiculeAvant;
row10_tmp.PhotovehiculeArriere = row6.PhotovehiculeArriere;
row10_tmp.photoVehiculedroit = row6.photoVehiculedroit;
row10_tmp.PhotoVehicuelGauche = row6.PhotoVehicuelGauche;
row10_tmp.kmDepart = row6.kmDepart;
row10_tmp.startLocation = row6.startLocation;
row10_tmp.endLocation = row6.endLocation;
row10_tmp.startTime = row6.startTime;
row10_tmp.endTime = row6.endTime;
row10_tmp.weight = row6.weight;
row10_tmp.volume = row6.volume;
row10_tmp.date = row6.date;
row10_tmp.platform = row6.platform;
row10_tmp.flux = row6.flux;
row10_tmp.targetFlux = row6.targetFlux;
row10_tmp.picture = row6.picture;
row10_tmp.vehicule = row6.vehicule;
row10_tmp.driver = row6.driver;
row10_tmp.is_deleted = 0;
row10_tmp.billingRoundName = row6.roundName ;
row10 = row10_tmp;
log.debug("tMap_1 - Outputting the record " + count_row10_tMap_1 + " of the output table 'row10'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "row10"
if(row10 != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row10","tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_round\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    if(row10.roundId == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, row10.roundId);
}

                    if(row10.roundName == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row10.roundName);
}

                    if(row10.realInfoHasPrepared == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row10.realInfoHasPrepared);
}

                    if(row10.realInfoHasStarted == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row10.realInfoHasStarted);
}

                    if(row10.realInfoHasFinished == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, row10.realInfoHasFinished);
}

                    if(row10.realInfoPreparationTime == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(6, row10.realInfoPreparationTime);
}

                    if(row10.realInfoHasLasted == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(7, row10.realInfoHasLasted);
}

                    if(row10.reloads___ == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row10.reloads___);
}

                    if(row10.activity == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row10.activity);
}

                    if(row10.status == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row10.status);
}

                    if(row10.orderCount == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(11, row10.orderCount);
}

                    if(row10.totalCost == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(12, row10.totalCost);
}

                    if(row10.totalTime == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(13, row10.totalTime);
}

                    if(row10.totalOrderServiceTime == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(14, row10.totalOrderServiceTime);
}

                    if(row10.totalBreakServiceTime == null) {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(15, row10.totalBreakServiceTime);
}

                    if(row10.totalTravelTime == null) {
pstmt_tDBOutput_1.setNull(16, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(16, row10.totalTravelTime);
}

                    if(row10.totalDistance == null) {
pstmt_tDBOutput_1.setNull(17, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(17, row10.totalDistance);
}

                    if(row10.labelsAndSkills___ == null) {
pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(18, row10.labelsAndSkills___);
}

                    if(row10.totalWaitTime == null) {
pstmt_tDBOutput_1.setNull(19, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(19, row10.totalWaitTime);
}

                    if(row10.totalViolationTime == null) {
pstmt_tDBOutput_1.setNull(20, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(20, row10.totalViolationTime);
}

                    if(row10.validated == null) {
pstmt_tDBOutput_1.setNull(21, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_1.setBoolean(21, row10.validated);
}

                    if(row10.updated == null) {
pstmt_tDBOutput_1.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(22, row10.updated);
}

                    if(row10.immatriculation == null) {
pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(23, row10.immatriculation);
}

                    if(row10.PhotoVehiculeAvant == null) {
pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(24, row10.PhotoVehiculeAvant);
}

                    if(row10.PhotovehiculeArriere == null) {
pstmt_tDBOutput_1.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(25, row10.PhotovehiculeArriere);
}

                    if(row10.photoVehiculedroit == null) {
pstmt_tDBOutput_1.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(26, row10.photoVehiculedroit);
}

                    if(row10.PhotoVehicuelGauche == null) {
pstmt_tDBOutput_1.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(27, row10.PhotoVehicuelGauche);
}

                    if(row10.kmDepart == null) {
pstmt_tDBOutput_1.setNull(28, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(28, row10.kmDepart);
}

                    if(row10.startLocation == null) {
pstmt_tDBOutput_1.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(29, row10.startLocation);
}

                    if(row10.endLocation == null) {
pstmt_tDBOutput_1.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(30, row10.endLocation);
}

                    if(row10.startTime == null) {
pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(31, row10.startTime);
}

                    if(row10.endTime == null) {
pstmt_tDBOutput_1.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(32, row10.endTime);
}

                    if(row10.weight == null) {
pstmt_tDBOutput_1.setNull(33, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(33, row10.weight);
}

                    if(row10.volume == null) {
pstmt_tDBOutput_1.setNull(34, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(34, row10.volume);
}

                    if(row10.date == null) {
pstmt_tDBOutput_1.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(35, row10.date);
}

                    if(row10.platform == null) {
pstmt_tDBOutput_1.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(36, row10.platform);
}

                    if(row10.flux == null) {
pstmt_tDBOutput_1.setNull(37, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(37, row10.flux);
}

                    if(row10.targetFlux == null) {
pstmt_tDBOutput_1.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(38, row10.targetFlux);
}

                    if(row10.picture == null) {
pstmt_tDBOutput_1.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(39, row10.picture);
}

                    if(row10.vehicule == null) {
pstmt_tDBOutput_1.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(40, row10.vehicule);
}

                    if(row10.driver == null) {
pstmt_tDBOutput_1.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(41, row10.driver);
}

                    if(row10.is_deleted == null) {
pstmt_tDBOutput_1.setNull(42, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(42, row10.is_deleted);
}

                    if(row10.billingRoundName == null) {
pstmt_tDBOutput_1.setNull(43, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(43, row10.billingRoundName);
}

                    if(row10.roundName == null) {
pstmt_tDBOutput_1.setNull(44 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(44 + count_tDBOutput_1, row10.roundName);
}

                    if(row10.realInfoHasPrepared == null) {
pstmt_tDBOutput_1.setNull(45 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(45 + count_tDBOutput_1, row10.realInfoHasPrepared);
}

                    if(row10.realInfoHasStarted == null) {
pstmt_tDBOutput_1.setNull(46 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(46 + count_tDBOutput_1, row10.realInfoHasStarted);
}

                    if(row10.realInfoHasFinished == null) {
pstmt_tDBOutput_1.setNull(47 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(47 + count_tDBOutput_1, row10.realInfoHasFinished);
}

                    if(row10.realInfoPreparationTime == null) {
pstmt_tDBOutput_1.setNull(48 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(48 + count_tDBOutput_1, row10.realInfoPreparationTime);
}

                    if(row10.realInfoHasLasted == null) {
pstmt_tDBOutput_1.setNull(49 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(49 + count_tDBOutput_1, row10.realInfoHasLasted);
}

                    if(row10.reloads___ == null) {
pstmt_tDBOutput_1.setNull(50 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(50 + count_tDBOutput_1, row10.reloads___);
}

                    if(row10.activity == null) {
pstmt_tDBOutput_1.setNull(51 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(51 + count_tDBOutput_1, row10.activity);
}

                    if(row10.status == null) {
pstmt_tDBOutput_1.setNull(52 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(52 + count_tDBOutput_1, row10.status);
}

                    if(row10.orderCount == null) {
pstmt_tDBOutput_1.setNull(53 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(53 + count_tDBOutput_1, row10.orderCount);
}

                    if(row10.totalCost == null) {
pstmt_tDBOutput_1.setNull(54 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(54 + count_tDBOutput_1, row10.totalCost);
}

                    if(row10.totalTime == null) {
pstmt_tDBOutput_1.setNull(55 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(55 + count_tDBOutput_1, row10.totalTime);
}

                    if(row10.totalOrderServiceTime == null) {
pstmt_tDBOutput_1.setNull(56 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(56 + count_tDBOutput_1, row10.totalOrderServiceTime);
}

                    if(row10.totalBreakServiceTime == null) {
pstmt_tDBOutput_1.setNull(57 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(57 + count_tDBOutput_1, row10.totalBreakServiceTime);
}

                    if(row10.totalTravelTime == null) {
pstmt_tDBOutput_1.setNull(58 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(58 + count_tDBOutput_1, row10.totalTravelTime);
}

                    if(row10.totalDistance == null) {
pstmt_tDBOutput_1.setNull(59 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(59 + count_tDBOutput_1, row10.totalDistance);
}

                    if(row10.labelsAndSkills___ == null) {
pstmt_tDBOutput_1.setNull(60 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(60 + count_tDBOutput_1, row10.labelsAndSkills___);
}

                    if(row10.totalWaitTime == null) {
pstmt_tDBOutput_1.setNull(61 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(61 + count_tDBOutput_1, row10.totalWaitTime);
}

                    if(row10.totalViolationTime == null) {
pstmt_tDBOutput_1.setNull(62 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(62 + count_tDBOutput_1, row10.totalViolationTime);
}

                    if(row10.validated == null) {
pstmt_tDBOutput_1.setNull(63 + count_tDBOutput_1, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_1.setBoolean(63 + count_tDBOutput_1, row10.validated);
}

                    if(row10.updated == null) {
pstmt_tDBOutput_1.setNull(64 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(64 + count_tDBOutput_1, row10.updated);
}

                    if(row10.immatriculation == null) {
pstmt_tDBOutput_1.setNull(65 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(65 + count_tDBOutput_1, row10.immatriculation);
}

                    if(row10.PhotoVehiculeAvant == null) {
pstmt_tDBOutput_1.setNull(66 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(66 + count_tDBOutput_1, row10.PhotoVehiculeAvant);
}

                    if(row10.PhotovehiculeArriere == null) {
pstmt_tDBOutput_1.setNull(67 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(67 + count_tDBOutput_1, row10.PhotovehiculeArriere);
}

                    if(row10.photoVehiculedroit == null) {
pstmt_tDBOutput_1.setNull(68 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(68 + count_tDBOutput_1, row10.photoVehiculedroit);
}

                    if(row10.PhotoVehicuelGauche == null) {
pstmt_tDBOutput_1.setNull(69 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(69 + count_tDBOutput_1, row10.PhotoVehicuelGauche);
}

                    if(row10.kmDepart == null) {
pstmt_tDBOutput_1.setNull(70 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(70 + count_tDBOutput_1, row10.kmDepart);
}

                    if(row10.startLocation == null) {
pstmt_tDBOutput_1.setNull(71 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(71 + count_tDBOutput_1, row10.startLocation);
}

                    if(row10.endLocation == null) {
pstmt_tDBOutput_1.setNull(72 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(72 + count_tDBOutput_1, row10.endLocation);
}

                    if(row10.startTime == null) {
pstmt_tDBOutput_1.setNull(73 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(73 + count_tDBOutput_1, row10.startTime);
}

                    if(row10.endTime == null) {
pstmt_tDBOutput_1.setNull(74 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(74 + count_tDBOutput_1, row10.endTime);
}

                    if(row10.weight == null) {
pstmt_tDBOutput_1.setNull(75 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(75 + count_tDBOutput_1, row10.weight);
}

                    if(row10.volume == null) {
pstmt_tDBOutput_1.setNull(76 + count_tDBOutput_1, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_1.setDouble(76 + count_tDBOutput_1, row10.volume);
}

                    if(row10.date == null) {
pstmt_tDBOutput_1.setNull(77 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(77 + count_tDBOutput_1, row10.date);
}

                    if(row10.platform == null) {
pstmt_tDBOutput_1.setNull(78 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(78 + count_tDBOutput_1, row10.platform);
}

                    if(row10.flux == null) {
pstmt_tDBOutput_1.setNull(79 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(79 + count_tDBOutput_1, row10.flux);
}

                    if(row10.targetFlux == null) {
pstmt_tDBOutput_1.setNull(80 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(80 + count_tDBOutput_1, row10.targetFlux);
}

                    if(row10.picture == null) {
pstmt_tDBOutput_1.setNull(81 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(81 + count_tDBOutput_1, row10.picture);
}

                    if(row10.vehicule == null) {
pstmt_tDBOutput_1.setNull(82 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(82 + count_tDBOutput_1, row10.vehicule);
}

                    if(row10.driver == null) {
pstmt_tDBOutput_1.setNull(83 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(83 + count_tDBOutput_1, row10.driver);
}

                    if(row10.is_deleted == null) {
pstmt_tDBOutput_1.setNull(84 + count_tDBOutput_1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(84 + count_tDBOutput_1, row10.is_deleted);
}

                    if(row10.billingRoundName == null) {
pstmt_tDBOutput_1.setNull(85 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(85 + count_tDBOutput_1, row10.billingRoundName);
}

            int count_on_duplicate_key_tDBOutput_1 = 0;
            try {
                int processedCount_tDBOutput_1 = pstmt_tDBOutput_1.executeUpdate();
                count_on_duplicate_key_tDBOutput_1 += processedCount_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                nb_line_tDBOutput_1++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_1 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_1 == 1) {
                insertedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1;
            } else {
                insertedCount_tDBOutput_1 += 1;
                updatedCount_tDBOutput_1 += count_on_duplicate_key_tDBOutput_1 - 1;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "row10"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row6"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		

 



/**
 * [tExtractJSONFields_3 process_data_end ] stop
 */




	
	/**
	 * [tExtractJSONFields_5 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_5","Extract_Stop_Fields_From_Round","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

            if(row4.Round!=null){// C_01
                jsonStr_tExtractJSONFields_5 = row4.Round.toString();
   
row13 = null;

	

String loopPath_tExtractJSONFields_5 = "$.stops[*]";
java.util.List<Object> resultset_tExtractJSONFields_5 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_5 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_5 = null;
try {
	document_tExtractJSONFields_5 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_5);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(loopPath_tExtractJSONFields_5);
	Object result_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(compiledLoopPath_tExtractJSONFields_5,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_5 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_5 = (net.minidev.json.JSONArray) result_tExtractJSONFields_5;
	} else {
		resultset_tExtractJSONFields_5.add(result_tExtractJSONFields_5);
	}
	
	isStructError_tExtractJSONFields_5 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",ex_tExtractJSONFields_5.getMessage());
		log.error("tExtractJSONFields_5 - " + ex_tExtractJSONFields_5.getMessage());
		System.err.println(ex_tExtractJSONFields_5.getMessage());
}

String jsonPath_tExtractJSONFields_5 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_5 = null;

Object value_tExtractJSONFields_5 = null;

Object root_tExtractJSONFields_5 = null;
for(int i_tExtractJSONFields_5=0; isStructError_tExtractJSONFields_5 || (i_tExtractJSONFields_5 < resultset_tExtractJSONFields_5.size());i_tExtractJSONFields_5++){
	if(!isStructError_tExtractJSONFields_5){
		Object row_tExtractJSONFields_5 = resultset_tExtractJSONFields_5.get(i_tExtractJSONFields_5);
            row13 = null;
	row13 = new row13Struct();
	nb_line_tExtractJSONFields_5++;
	try {
		jsonPath_tExtractJSONFields_5 = "travelTime";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				if(value_tExtractJSONFields_5 != null && !value_tExtractJSONFields_5.toString().isEmpty()) {
					row13.travelTime = ParserUtils.parseTo_BigDecimal(value_tExtractJSONFields_5.toString());
				} else {
					row13.travelTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.travelTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "serviceTime";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				if(value_tExtractJSONFields_5 != null && !value_tExtractJSONFields_5.toString().isEmpty()) {
					row13.serviceTime = ParserUtils.parseTo_BigDecimal(value_tExtractJSONFields_5.toString());
				} else {
					row13.serviceTime = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.serviceTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "stopType";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				if(value_tExtractJSONFields_5 != null && !value_tExtractJSONFields_5.toString().isEmpty()) {
					row13.stopType = ParserUtils.parseTo_Integer(value_tExtractJSONFields_5.toString());
				} else {
					row13.stopType = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.stopType = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "type";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.type = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.type = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "arriveTime";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.arriveTime = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.arriveTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "departTime";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.departTime = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.departTime = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "parcel";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.task = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.task = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "$._id";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.round = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.round = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "travelDistance";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				if(value_tExtractJSONFields_5 != null && !value_tExtractJSONFields_5.toString().isEmpty()) {
					row13.travelDistance = ParserUtils.parseTo_Double(value_tExtractJSONFields_5.toString());
				} else {
					row13.travelDistance = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.travelDistance = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "taskId";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				row13.taskId = value_tExtractJSONFields_5 == null ? 

		null

 : value_tExtractJSONFields_5.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.taskId = 

		null

;
		}
		jsonPath_tExtractJSONFields_5 = "sequence";
		compiledJsonPath_tExtractJSONFields_5 = jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath(jsonPath_tExtractJSONFields_5);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_5.startsWith("$")){
		            if(root_tExtractJSONFields_5 == null){
		                root_tExtractJSONFields_5 = document_tExtractJSONFields_5.read(jsonPathCache_tExtractJSONFields_5.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(root_tExtractJSONFields_5);
		        }else{
		            value_tExtractJSONFields_5 = compiledJsonPath_tExtractJSONFields_5.read(row_tExtractJSONFields_5);
		        }
				if(value_tExtractJSONFields_5 != null && !value_tExtractJSONFields_5.toString().isEmpty()) {
					row13.sequence = ParserUtils.parseTo_Integer(value_tExtractJSONFields_5.toString());
				} else {
					row13.sequence = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",e_tExtractJSONFields_5.getMessage());
			row13.sequence = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_5) {
globalMap.put("tExtractJSONFields_5_ERROR_MESSAGE",ex_tExtractJSONFields_5.getMessage());
			log.error("tExtractJSONFields_5 - " + ex_tExtractJSONFields_5.getMessage());
		    System.err.println(ex_tExtractJSONFields_5.getMessage());
		    row13 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_5 = false;
	
	log.debug("tExtractJSONFields_5 - Extracting the record " + nb_line_tExtractJSONFields_5 + ".");
//}


 


	tos_count_tExtractJSONFields_5++;

/**
 * [tExtractJSONFields_5 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_5 process_data_begin ] stop
 */
// Start of branch "row13"
if(row13 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row13","tExtractJSONFields_5","Extract_Stop_Fields_From_Round","tExtractJSONFields","tMap_2","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_2 = false;
		boolean mainRowRejected_tMap_2 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

copyOfout1 = null;


// # Output table : 'copyOfout1'
count_copyOfout1_tMap_2++;

copyOfout1_tmp.travelTime = row13.travelTime ;
copyOfout1_tmp.serviceTime = row13.serviceTime ;
copyOfout1_tmp.stopType = ""+row13.stopType ;
copyOfout1_tmp.type = row13.type != null ?row13.type : "EMPTY";
copyOfout1_tmp.arriveTime = row13.arriveTime ;
copyOfout1_tmp.departTime = row13.departTime ;
copyOfout1_tmp.task = row13.task ;
copyOfout1_tmp.round = row13.round ;
copyOfout1_tmp.travelDistance = row13.travelDistance ;
copyOfout1_tmp.taskId = row13.taskId ;
copyOfout1_tmp.sequence = row13.sequence ;
copyOfout1 = copyOfout1_tmp;
log.debug("tMap_2 - Outputting the record " + count_copyOfout1_tMap_2 + " of the output table 'copyOfout1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "copyOfout1"
if(copyOfout1 != null) { 



	
	/**
	 * [tLogRow_3 main ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"copyOfout1","tMap_2","tMap_1","tMap","tLogRow_3","tLogRow_3","tDummyRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("copyOfout1 - " + (copyOfout1==null? "": copyOfout1.toLogString()));
    			}
    		

 
     row14 = copyOfout1;


	tos_count_tLogRow_3++;

/**
 * [tLogRow_3 main ] stop
 */
	
	/**
	 * [tLogRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row14","tLogRow_3","tLogRow_3","tDummyRow","tDBOutput_4","\"urbantz_stop\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setBigDecimal(1, row14.travelTime);

                    pstmt_tDBOutput_4.setBigDecimal(2, row14.serviceTime);

                    if(row14.stopType == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(3, row14.stopType);
}

                    if(row14.type == null) {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(4, row14.type);
}

                    if(row14.arriveTime == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(5, row14.arriveTime);
}

                    if(row14.departTime == null) {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(6, row14.departTime);
}

                    if(row14.task == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(7, row14.task);
}

                    if(row14.round == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(8, row14.round);
}

                    if(row14.travelDistance == null) {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_4.setDouble(9, row14.travelDistance);
}

                    if(row14.taskId == null) {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(10, row14.taskId);
}

                    if(row14.sequence == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(11, row14.sequence);
}

                    pstmt_tDBOutput_4.setBigDecimal(12 + count_tDBOutput_4, row14.travelTime);

                    pstmt_tDBOutput_4.setBigDecimal(13 + count_tDBOutput_4, row14.serviceTime);

                    if(row14.stopType == null) {
pstmt_tDBOutput_4.setNull(14 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(14 + count_tDBOutput_4, row14.stopType);
}

                    if(row14.type == null) {
pstmt_tDBOutput_4.setNull(15 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(15 + count_tDBOutput_4, row14.type);
}

                    if(row14.arriveTime == null) {
pstmt_tDBOutput_4.setNull(16 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(16 + count_tDBOutput_4, row14.arriveTime);
}

                    if(row14.departTime == null) {
pstmt_tDBOutput_4.setNull(17 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(17 + count_tDBOutput_4, row14.departTime);
}

                    if(row14.round == null) {
pstmt_tDBOutput_4.setNull(18 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(18 + count_tDBOutput_4, row14.round);
}

                    if(row14.travelDistance == null) {
pstmt_tDBOutput_4.setNull(19 + count_tDBOutput_4, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_4.setDouble(19 + count_tDBOutput_4, row14.travelDistance);
}

                    if(row14.taskId == null) {
pstmt_tDBOutput_4.setNull(20 + count_tDBOutput_4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(20 + count_tDBOutput_4, row14.taskId);
}

                    if(row14.sequence == null) {
pstmt_tDBOutput_4.setNull(21 + count_tDBOutput_4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(21 + count_tDBOutput_4, row14.sequence);
}

            int count_on_duplicate_key_tDBOutput_4 = 0;
            try {
                int processedCount_tDBOutput_4 = pstmt_tDBOutput_4.executeUpdate();
                count_on_duplicate_key_tDBOutput_4 += processedCount_tDBOutput_4;
                rowsToCommitCount_tDBOutput_4 += processedCount_tDBOutput_4;
                nb_line_tDBOutput_4++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_4_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_4 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_4 == 1) {
                insertedCount_tDBOutput_4 += count_on_duplicate_key_tDBOutput_4;
            } else {
                insertedCount_tDBOutput_4 += 1;
                updatedCount_tDBOutput_4 += count_on_duplicate_key_tDBOutput_4 - 1;
            }

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 process_data_end ] stop
 */

} // End of branch "copyOfout1"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row13"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_5 process_data_end ] stop
 */




	
	/**
	 * [tExtractJSONFields_4 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_4","Extract_Senders_Fields_From_Round","tExtractJSONFields"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

            if(row7.Round!=null){// C_01
                jsonStr_tExtractJSONFields_4 = row7.Round.toString();
   
row9 = null;

	

String loopPath_tExtractJSONFields_4 = "$.senders[*]";
java.util.List<Object> resultset_tExtractJSONFields_4 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_4 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_4 = null;
try {
	document_tExtractJSONFields_4 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_4);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(loopPath_tExtractJSONFields_4);
	Object result_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(compiledLoopPath_tExtractJSONFields_4,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_4 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_4 = (net.minidev.json.JSONArray) result_tExtractJSONFields_4;
	} else {
		resultset_tExtractJSONFields_4.add(result_tExtractJSONFields_4);
	}
	
	isStructError_tExtractJSONFields_4 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",ex_tExtractJSONFields_4.getMessage());
		log.error("tExtractJSONFields_4 - " + ex_tExtractJSONFields_4.getMessage());
		System.err.println(ex_tExtractJSONFields_4.getMessage());
}

String jsonPath_tExtractJSONFields_4 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_4 = null;

Object value_tExtractJSONFields_4 = null;

Object root_tExtractJSONFields_4 = null;
for(int i_tExtractJSONFields_4=0; isStructError_tExtractJSONFields_4 || (i_tExtractJSONFields_4 < resultset_tExtractJSONFields_4.size());i_tExtractJSONFields_4++){
	if(!isStructError_tExtractJSONFields_4){
		Object row_tExtractJSONFields_4 = resultset_tExtractJSONFields_4.get(i_tExtractJSONFields_4);
            row9 = null;
	row9 = new row9Struct();
	nb_line_tExtractJSONFields_4++;
	try {
		jsonPath_tExtractJSONFields_4 = "$._id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row9.roundId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row9.roundId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "count";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				if(value_tExtractJSONFields_4 != null && !value_tExtractJSONFields_4.toString().isEmpty()) {
					row9.count = ParserUtils.parseTo_Integer(value_tExtractJSONFields_4.toString());
				} else {
					row9.count = 

		null

;
				}
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row9.count = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "_id";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row9.senderId = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row9.senderId = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "reference";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row9.reference = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row9.reference = 

		null

;
		}
		jsonPath_tExtractJSONFields_4 = "name";
		compiledJsonPath_tExtractJSONFields_4 = jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath(jsonPath_tExtractJSONFields_4);
		
		try {
		    
		        if(jsonPath_tExtractJSONFields_4.startsWith("$")){
		            if(root_tExtractJSONFields_4 == null){
		                root_tExtractJSONFields_4 = document_tExtractJSONFields_4.read(jsonPathCache_tExtractJSONFields_4.getCompiledJsonPath("$"));
					   }
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(root_tExtractJSONFields_4);
		        }else{
		            value_tExtractJSONFields_4 = compiledJsonPath_tExtractJSONFields_4.read(row_tExtractJSONFields_4);
		        }
				row9.name = value_tExtractJSONFields_4 == null ? 

		null

 : value_tExtractJSONFields_4.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",e_tExtractJSONFields_4.getMessage());
			row9.name = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_4) {
globalMap.put("tExtractJSONFields_4_ERROR_MESSAGE",ex_tExtractJSONFields_4.getMessage());
			log.error("tExtractJSONFields_4 - " + ex_tExtractJSONFields_4.getMessage());
		    System.err.println(ex_tExtractJSONFields_4.getMessage());
		    row9 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_4 = false;
	
	log.debug("tExtractJSONFields_4 - Extracting the record " + nb_line_tExtractJSONFields_4 + ".");
//}


 


	tos_count_tExtractJSONFields_4++;

/**
 * [tExtractJSONFields_4 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_4 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tExtractJSONFields_4","Extract_Senders_Fields_From_Round","tExtractJSONFields","tLogRow_2","tLogRow_2","tDummyRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

 
     row11 = row9;


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row11","tLogRow_2","tLogRow_2","tDummyRow","tDBOutput_3","\"urbantz_round_senders\"","tMysqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    if(row11.roundId == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, row11.roundId);
}

                    if(row11.count == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(2, row11.count);
}

                    if(row11.senderId == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row11.senderId);
}

                    if(row11.reference == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, row11.reference);
}

                    if(row11.name == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row11.name);
}

                    if(row11.count == null) {
pstmt_tDBOutput_3.setNull(6 + count_tDBOutput_3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(6 + count_tDBOutput_3, row11.count);
}

                    if(row11.senderId == null) {
pstmt_tDBOutput_3.setNull(7 + count_tDBOutput_3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7 + count_tDBOutput_3, row11.senderId);
}

                    if(row11.reference == null) {
pstmt_tDBOutput_3.setNull(8 + count_tDBOutput_3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8 + count_tDBOutput_3, row11.reference);
}

                    if(row11.name == null) {
pstmt_tDBOutput_3.setNull(9 + count_tDBOutput_3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9 + count_tDBOutput_3, row11.name);
}

            int count_on_duplicate_key_tDBOutput_3 = 0;
            try {
                int processedCount_tDBOutput_3 = pstmt_tDBOutput_3.executeUpdate();
                count_on_duplicate_key_tDBOutput_3 += processedCount_tDBOutput_3;
                rowsToCommitCount_tDBOutput_3 += processedCount_tDBOutput_3;
                nb_line_tDBOutput_3++;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Inserting on duplicate key updating")  + (" the record.") );
            } catch(java.lang.Exception e) {
                globalMap.put("tDBOutput_3_ERROR_MESSAGE",e.getMessage());
                whetherReject_tDBOutput_3 = true;
                    throw(e);
            }
            if(count_on_duplicate_key_tDBOutput_3 == 1) {
                insertedCount_tDBOutput_3 += count_on_duplicate_key_tDBOutput_3;
            } else {
                insertedCount_tDBOutput_3 += 1;
                updatedCount_tDBOutput_3 += count_on_duplicate_key_tDBOutput_3 - 1;
            }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "row9"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_4 process_data_end ] stop
 */



	
	/**
	 * [tReplicate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 process_data_end ] stop
 */

} // End of branch "row3"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tRESTClient_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 process_data_end ] stop
 */



	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */

	
	/**
	 * [tRESTClient_1 end ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	


if (globalMap.get("tRESTClient_1_NB_LINE") == null) {
	globalMap.put("tRESTClient_1_NB_LINE", 1);
}

// [tRESTCliend_end]
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tJava_1","tJava_1","tJava","tRESTClient_1","tRESTClient_1","tRESTClient","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tRESTClient_1", true);
end_Hash.put("tRESTClient_1", System.currentTimeMillis());




/**
 * [tRESTClient_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);
	log.debug("tExtractJSONFields_1 - Extracted records count: " + nb_line_tExtractJSONFields_1 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tRESTClient_1","tRESTClient_1","tRESTClient","tExtractJSONFields_1","Extract_Round_From_List","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_1 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());




/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tReplicate_1 end ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tExtractJSONFields_1","Extract_Round_From_List","tExtractJSONFields","tReplicate_1","tReplicate_1","tReplicate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tReplicate_1 - "  + ("Done.") );

ok_Hash.put("tReplicate_1", true);
end_Hash.put("tReplicate_1", System.currentTimeMillis());

   			if ( 1==1) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				tJava_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tReplicate_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_3 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		
   globalMap.put("tExtractJSONFields_3_NB_LINE", nb_line_tExtractJSONFields_3);
	log.debug("tExtractJSONFields_3 - Extracted records count: " + nb_line_tExtractJSONFields_3 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_3","Extract_Round_Fields","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_3 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_3", true);
end_Hash.put("tExtractJSONFields_3", System.currentTimeMillis());




/**
 * [tExtractJSONFields_3 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'row10': " + count_row10_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tExtractJSONFields_3","Extract_Round_Fields","tExtractJSONFields","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		



		

		if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_1", true);
	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row10",2,0,
			 			"tMap_1","tMap_1","tMap","tDBOutput_1","\"urbantz_round\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */










	
	/**
	 * [tExtractJSONFields_5 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		
   globalMap.put("tExtractJSONFields_5_NB_LINE", nb_line_tExtractJSONFields_5);
	log.debug("tExtractJSONFields_5 - Extracted records count: " + nb_line_tExtractJSONFields_5 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_5","Extract_Stop_Fields_From_Round","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_5 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_5", true);
end_Hash.put("tExtractJSONFields_5", System.currentTimeMillis());




/**
 * [tExtractJSONFields_5 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'copyOfout1': " + count_copyOfout1_tMap_2 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row13",2,0,
			 			"tExtractJSONFields_5","Extract_Stop_Fields_From_Round","tExtractJSONFields","tMap_2","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tLogRow_3 end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfout1",2,0,
			 			"tMap_2","tMap_1","tMap","tLogRow_3","tLogRow_3","tDummyRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_3", true);
end_Hash.put("tLogRow_3", System.currentTimeMillis());




/**
 * [tLogRow_3 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		



		

		if(pstmt_tDBOutput_4 != null) {
			
				pstmt_tDBOutput_4.close();
				resourceMap.remove("pstmt_tDBOutput_4");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_4", true);
	

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row14",2,0,
			 			"tLogRow_3","tLogRow_3","tDummyRow","tDBOutput_4","\"urbantz_stop\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */













	
	/**
	 * [tExtractJSONFields_4 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		
   globalMap.put("tExtractJSONFields_4_NB_LINE", nb_line_tExtractJSONFields_4);
	log.debug("tExtractJSONFields_4 - Extracted records count: " + nb_line_tExtractJSONFields_4 + " .");


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tReplicate_1","tReplicate_1","tReplicate","tExtractJSONFields_4","Extract_Senders_Fields_From_Round","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tExtractJSONFields_4 - "  + ("Done.") );

ok_Hash.put("tExtractJSONFields_4", true);
end_Hash.put("tExtractJSONFields_4", System.currentTimeMillis());




/**
 * [tExtractJSONFields_4 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tExtractJSONFields_4","Extract_Senders_Fields_From_Round","tExtractJSONFields","tLogRow_2","tLogRow_2","tDummyRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		



		

		if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
		}
		
	resourceMap.put("statementClosed_tDBOutput_3", true);
	

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row11",2,0,
			 			"tLogRow_2","tLogRow_2","tDummyRow","tDBOutput_3","\"urbantz_round_senders\"","tMysqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */


















						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tJava_1);
						}				
					




	
	/**
	 * [tLoop_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 process_data_end ] stop
 */
	
	/**
	 * [tLoop_1 end ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	




i++;;


}


 
                if(log.isDebugEnabled())
            log.debug("tLoop_1 - "  + ("Done.") );

ok_Hash.put("tLoop_1", true);
end_Hash.put("tLoop_1", System.currentTimeMillis());




/**
 * [tLoop_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLoop_1 finally ] start
	 */

	

	
	
	currentComponent="tLoop_1";
	
	

 



/**
 * [tLoop_1 finally ] stop
 */

	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 finally ] stop
 */

	
	/**
	 * [tRESTClient_1 finally ] start
	 */

	

	
	
	currentComponent="tRESTClient_1";
	
	

 



/**
 * [tRESTClient_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";
	
	
			cLabel="Extract_Round_From_List";
		

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tReplicate_1 finally ] start
	 */

	

	
	
	currentComponent="tReplicate_1";
	
	

 



/**
 * [tReplicate_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_3 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_3";
	
	
			cLabel="Extract_Round_Fields";
		

 



/**
 * [tExtractJSONFields_3 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"urbantz_round\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */










	
	/**
	 * [tExtractJSONFields_5 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_5";
	
	
			cLabel="Extract_Stop_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_5 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";
	
	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tLogRow_3 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_3";
	
	

 



/**
 * [tLogRow_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"urbantz_stop\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */













	
	/**
	 * [tExtractJSONFields_4 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_4";
	
	
			cLabel="Extract_Senders_Fields_From_Round";
		

 



/**
 * [tExtractJSONFields_4 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"urbantz_round_senders\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */





















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLoop_1_SUBPROCESS_STATE", 1);
	}
	


public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_2");
		org.slf4j.MDC.put("_subJobPid", "nYWklZ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";
	
	
		int tos_count_tJava_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_2", "tJava_2", "tJava");
				talendJobLogProcess(globalMap);
			}
			



globalMap.put("numberOfElementsInPage", ((Integer)globalMap.get("tExtractJSONFields_1_NB_LINE")));
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "qywZop_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tWarn_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_2");
		org.slf4j.MDC.put("_subJobPid", "Naylzd_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";
	
	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
                    log4jParamters_tWarn_2.append("Parameters:");
                            log4jParamters_tWarn_2.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
                    } 
                } 
            new BytesLimit65535_tWarn_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_2", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_2 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_2_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_2_WARN_PRIORITY", 4);
	globalMap.put("tWarn_2_WARN_CODE", 42);
	
} catch (Exception e_tWarn_2) {
globalMap.put("tWarn_2_ERROR_MESSAGE",e_tWarn_2.getMessage());
	logIgnoredError(String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2), e_tWarn_2);
}


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_end ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "mwTfEb_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ECOLOTRANS_URBANTZ_ROUNDS_IMPORT ECOLOTRANS_URBANTZ_ROUNDS_IMPORTClass = new ECOLOTRANS_URBANTZ_ROUNDS_IMPORT();

        int exitCode = ECOLOTRANS_URBANTZ_ROUNDS_IMPORTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_ROUNDS_IMPORT' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ECOLOTRANS_URBANTZ_ROUNDS_IMPORT' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_f6JAsJidEeyH_6mQlKsMew");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-03-05T16:44:22.520466800Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.class.getClassLoader().getResourceAsStream("atelier_facturation/ecolotrans_urbantz_rounds_import_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ECOLOTRANS_URBANTZ_ROUNDS_IMPORT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("Round_directory", "id_String");
                        if(context.getStringValue("Round_directory") == null) {
                            context.Round_directory = null;
                        } else {
                            context.Round_directory=(String) context.getProperty("Round_directory");
                        }
                        context.setContextType("Round_file_name", "id_String");
                        if(context.getStringValue("Round_file_name") == null) {
                            context.Round_file_name = null;
                        } else {
                            context.Round_file_name=(String) context.getProperty("Round_file_name");
                        }
                        context.setContextType("Round_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Minus_Days") == null) {
                            context.Round_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Minus_Days", e.getMessage()));
                                context.Round_Minus_Days=null;
                            }
                        }
                        context.setContextType("start_date", "id_String");
                        if(context.getStringValue("start_date") == null) {
                            context.start_date = null;
                        } else {
                            context.start_date=(String) context.getProperty("start_date");
                        }
                        context.setContextType("Max_Extarction_Hour_HH", "id_Integer");
                        if(context.getStringValue("Max_Extarction_Hour_HH") == null) {
                            context.Max_Extarction_Hour_HH = null;
                        } else {
                            try{
                                context.Max_Extarction_Hour_HH=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Max_Extarction_Hour_HH"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Max_Extarction_Hour_HH", e.getMessage()));
                                context.Max_Extarction_Hour_HH=null;
                            }
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("Round_directory")) {
                context.Round_directory = (String) parentContextMap.get("Round_directory");
            }if (parentContextMap.containsKey("Round_file_name")) {
                context.Round_file_name = (String) parentContextMap.get("Round_file_name");
            }if (parentContextMap.containsKey("Round_Minus_Days")) {
                context.Round_Minus_Days = (Integer) parentContextMap.get("Round_Minus_Days");
            }if (parentContextMap.containsKey("start_date")) {
                context.start_date = (String) parentContextMap.get("start_date");
            }if (parentContextMap.containsKey("Max_Extarction_Hour_HH")) {
                context.Max_Extarction_Hour_HH = (Integer) parentContextMap.get("Max_Extarction_Hour_HH");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ECOLOTRANS_URBANTZ_ROUNDS_IMPORT' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs


this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ECOLOTRANS_URBANTZ_ROUNDS_IMPORT");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ECOLOTRANS_URBANTZ_ROUNDS_IMPORT' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     584186 characters generated by Talend Cloud Data Integration 
 *     on the 5 mars 2024 à 17:44:22 WAT
 ************************************************************************************************/
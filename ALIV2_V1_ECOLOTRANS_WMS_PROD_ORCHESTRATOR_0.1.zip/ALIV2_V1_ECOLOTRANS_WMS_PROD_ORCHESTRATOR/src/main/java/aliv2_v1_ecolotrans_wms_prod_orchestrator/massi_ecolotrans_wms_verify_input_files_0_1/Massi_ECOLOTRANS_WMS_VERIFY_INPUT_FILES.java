
package aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_input_files_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_3
	import java.io.File;
import java.util.HashMap;  
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Cell;  


@SuppressWarnings("unused")

/**
 * Job: Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES implements TalendJob {
	static {System.setProperty("TalendJob.log", "Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Billing_BSO_Months != null){
				
					this.setProperty("Billing_BSO_Months", Billing_BSO_Months.toString());
				
			}
			
			if(Billing_BSO_Start_Year != null){
				
					this.setProperty("Billing_BSO_Start_Year", Billing_BSO_Start_Year.toString());
				
			}
			
			if(Billing_Comptabilite_File != null){
				
					this.setProperty("Billing_Comptabilite_File", Billing_Comptabilite_File.toString());
				
			}
			
			if(Billing_Comptabilite_Folder != null){
				
					this.setProperty("Billing_Comptabilite_Folder", Billing_Comptabilite_Folder.toString());
				
			}
			
			if(Billing_Distant_Rep != null){
				
					this.setProperty("Billing_Distant_Rep", Billing_Distant_Rep.toString());
				
			}
			
			if(Billing_File_Masque != null){
				
					this.setProperty("Billing_File_Masque", Billing_File_Masque.toString());
				
			}
			
			if(Billing_Local_Rep != null){
				
					this.setProperty("Billing_Local_Rep", Billing_Local_Rep.toString());
				
			}
			
			if(Billing_Name != null){
				
					this.setProperty("Billing_Name", Billing_Name.toString());
				
			}
			
			if(Billing_Start_Number != null){
				
					this.setProperty("Billing_Start_Number", Billing_Start_Number.toString());
				
			}
			
			if(Billing_TVA_default_value != null){
				
					this.setProperty("Billing_TVA_default_value", Billing_TVA_default_value.toString());
				
			}
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(ODS_Database != null){
				
					this.setProperty("ODS_Database", ODS_Database.toString());
				
			}
			
			if(PBI_Database != null){
				
					this.setProperty("PBI_Database", PBI_Database.toString());
				
			}
			
			if(PBI_PC_Database != null){
				
					this.setProperty("PBI_PC_Database", PBI_PC_Database.toString());
				
			}
			
			if(PBI_RT_Database != null){
				
					this.setProperty("PBI_RT_Database", PBI_RT_Database.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(DataMart_Clean_Database != null){
				
					this.setProperty("DataMart_Clean_Database", DataMart_Clean_Database.toString());
				
			}
			
			if(DataMart_Clean_Max_Date != null){
				
					this.setProperty("DataMart_Clean_Max_Date", DataMart_Clean_Max_Date.toString());
				
			}
			
			if(DataMart_Clean_Min_Date != null){
				
					this.setProperty("DataMart_Clean_Min_Date", DataMart_Clean_Min_Date.toString());
				
			}
			
			if(DataMart_Closure_Date_PlusX != null){
				
					this.setProperty("DataMart_Closure_Date_PlusX", DataMart_Closure_Date_PlusX.toString());
				
			}
			
			if(Limit_Percent != null){
				
					this.setProperty("Limit_Percent", Limit_Percent.toString());
				
			}
			
			if(Logistic_Max_Date_Plus_One != null){
				
					this.setProperty("Logistic_Max_Date_Plus_One", Logistic_Max_Date_Plus_One.toString());
				
			}
			
			if(Logistic_Min_Date_Minus_One != null){
				
					this.setProperty("Logistic_Min_Date_Minus_One", Logistic_Min_Date_Minus_One.toString());
				
			}
			
			if(deleted_J_minus_X != null){
				
					this.setProperty("deleted_J_minus_X", deleted_J_minus_X.toString());
				
			}
			
			if(deleted_J_plusOne_X != null){
				
					this.setProperty("deleted_J_plusOne_X", deleted_J_plusOne_X.toString());
				
			}
			
			if(FTP_DistantRep != null){
				
					this.setProperty("FTP_DistantRep", FTP_DistantRep.toString());
				
			}
			
			if(FTP_FileMasque != null){
				
					this.setProperty("FTP_FileMasque", FTP_FileMasque.toString());
				
			}
			
			if(FTP_Hote != null){
				
					this.setProperty("FTP_Hote", FTP_Hote.toString());
				
			}
			
			if(FTP_Password != null){
				
					this.setProperty("FTP_Password", FTP_Password.toString());
				
			}
			
			if(FTP_Port != null){
				
					this.setProperty("FTP_Port", FTP_Port.toString());
				
			}
			
			if(FTP_ST_DistantRep != null){
				
					this.setProperty("FTP_ST_DistantRep", FTP_ST_DistantRep.toString());
				
			}
			
			if(FTP_User != null){
				
					this.setProperty("FTP_User", FTP_User.toString());
				
			}
			
			if(FTP_Wms_Port != null){
				
					this.setProperty("FTP_Wms_Port", FTP_Wms_Port.toString());
				
			}
			
			if(keyStore_file_name != null){
				
					this.setProperty("keyStore_file_name", keyStore_file_name.toString());
				
			}
			
			if(KeyStore_Repo != null){
				
					this.setProperty("KeyStore_Repo", KeyStore_Repo.toString());
				
			}
			
			if(mail_password != null){
				
					this.setProperty("mail_password", mail_password.toString());
				
			}
			
			if(send_mail_from != null){
				
					this.setProperty("send_mail_from", send_mail_from.toString());
				
			}
			
			if(send_mail_to != null){
				
					this.setProperty("send_mail_to", send_mail_to.toString());
				
			}
			
			if(send_to_second_mail != null){
				
					this.setProperty("send_to_second_mail", send_to_second_mail.toString());
				
			}
			
			if(send_to_third_mail != null){
				
					this.setProperty("send_to_third_mail", send_to_third_mail.toString());
				
			}
			
			if(Clients_Masque != null){
				
					this.setProperty("Clients_Masque", Clients_Masque.toString());
				
			}
			
			if(Code_client_masque != null){
				
					this.setProperty("Code_client_masque", Code_client_masque.toString());
				
			}
			
			if(Command_Logistic_Invalid_Date != null){
				
					this.setProperty("Command_Logistic_Invalid_Date", Command_Logistic_Invalid_Date.toString());
				
			}
			
			if(Command_Logistic_Masque != null){
				
					this.setProperty("Command_Logistic_Masque", Command_Logistic_Masque.toString());
				
			}
			
			if(Command_Transport_Masque != null){
				
					this.setProperty("Command_Transport_Masque", Command_Transport_Masque.toString());
				
			}
			
			if(Command_Transport_Masque_Express != null){
				
					this.setProperty("Command_Transport_Masque_Express", Command_Transport_Masque_Express.toString());
				
			}
			
			if(Ecolotrans_JP != null){
				
					this.setProperty("Ecolotrans_JP", Ecolotrans_JP.toString());
				
			}
			
			if(Holiday_Days_Masque != null){
				
					this.setProperty("Holiday_Days_Masque", Holiday_Days_Masque.toString());
				
			}
			
			if(Livraisons_Exception != null){
				
					this.setProperty("Livraisons_Exception", Livraisons_Exception.toString());
				
			}
			
			if(Livraisons_Masque != null){
				
					this.setProperty("Livraisons_Masque", Livraisons_Masque.toString());
				
			}
			
			if(Livraisons_Ok != null){
				
					this.setProperty("Livraisons_Ok", Livraisons_Ok.toString());
				
			}
			
			if(ST_Drivers != null){
				
					this.setProperty("ST_Drivers", ST_Drivers.toString());
				
			}
			
			if(Tarification_Logistic_Masque != null){
				
					this.setProperty("Tarification_Logistic_Masque", Tarification_Logistic_Masque.toString());
				
			}
			
			if(Tarification_Transport_Masque != null){
				
					this.setProperty("Tarification_Transport_Masque", Tarification_Transport_Masque.toString());
				
			}
			
			if(Tournee_Masque != null){
				
					this.setProperty("Tournee_Masque", Tournee_Masque.toString());
				
			}
			
			if(TVA_Exceptions != null){
				
					this.setProperty("TVA_Exceptions", TVA_Exceptions.toString());
				
			}
			
			if(Backup != null){
				
					this.setProperty("Backup", Backup.toString());
				
			}
			
			if(Server_Clean != null){
				
					this.setProperty("Server_Clean", Server_Clean.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Server_Out != null){
				
					this.setProperty("Server_Out", Server_Out.toString());
				
			}
			
			if(Server_Out_DataMart != null){
				
					this.setProperty("Server_Out_DataMart", Server_Out_DataMart.toString());
				
			}
			
			if(Art_masque != null){
				
					this.setProperty("Art_masque", Art_masque.toString());
				
			}
			
			if(Cdc_masque != null){
				
					this.setProperty("Cdc_masque", Cdc_masque.toString());
				
			}
			
			if(Cre_masque != null){
				
					this.setProperty("Cre_masque", Cre_masque.toString());
				
			}
			
			if(Crp_masque != null){
				
					this.setProperty("Crp_masque", Crp_masque.toString());
				
			}
			
			if(Crr_masque != null){
				
					this.setProperty("Crr_masque", Crr_masque.toString());
				
			}
			
			if(Distant_Magistor_Clients_Input != null){
				
					this.setProperty("Distant_Magistor_Clients_Input", Distant_Magistor_Clients_Input.toString());
				
			}
			
			if(Distant_Magistor_Clients_Test_Input != null){
				
					this.setProperty("Distant_Magistor_Clients_Test_Input", Distant_Magistor_Clients_Test_Input.toString());
				
			}
			
			if(Distant_Magistor1_Input != null){
				
					this.setProperty("Distant_Magistor1_Input", Distant_Magistor1_Input.toString());
				
			}
			
			if(Distant_Magistor1_Output != null){
				
					this.setProperty("Distant_Magistor1_Output", Distant_Magistor1_Output.toString());
				
			}
			
			if(Distant_Magistor1_Test_Input != null){
				
					this.setProperty("Distant_Magistor1_Test_Input", Distant_Magistor1_Test_Input.toString());
				
			}
			
			if(Distant_Magistor1_Test_Output != null){
				
					this.setProperty("Distant_Magistor1_Test_Output", Distant_Magistor1_Test_Output.toString());
				
			}
			
			if(Distant_Magistor2_Input != null){
				
					this.setProperty("Distant_Magistor2_Input", Distant_Magistor2_Input.toString());
				
			}
			
			if(Distant_Magistor2_Output != null){
				
					this.setProperty("Distant_Magistor2_Output", Distant_Magistor2_Output.toString());
				
			}
			
			if(Distant_Magistor2_Test_Input != null){
				
					this.setProperty("Distant_Magistor2_Test_Input", Distant_Magistor2_Test_Input.toString());
				
			}
			
			if(Distant_Magistor2_Test_Output != null){
				
					this.setProperty("Distant_Magistor2_Test_Output", Distant_Magistor2_Test_Output.toString());
				
			}
			
			if(Drc_masque != null){
				
					this.setProperty("Drc_masque", Drc_masque.toString());
				
			}
			
			if(Mvt_masque != null){
				
					this.setProperty("Mvt_masque", Mvt_masque.toString());
				
			}
			
			if(Stk_masque != null){
				
					this.setProperty("Stk_masque", Stk_masque.toString());
				
			}
			
			if(Xml_File_Masque != null){
				
					this.setProperty("Xml_File_Masque", Xml_File_Masque.toString());
				
			}
			
			if(Article_Exceptions != null){
				
					this.setProperty("Article_Exceptions", Article_Exceptions.toString());
				
			}
			
			if(Cleaning_Reject_Logistic_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Logistic_price_is_zero", Cleaning_Reject_Logistic_price_is_zero.toString());
				
			}
			
			if(Cleaning_Reject_Rep != null){
				
					this.setProperty("Cleaning_Reject_Rep", Cleaning_Reject_Rep.toString());
				
			}
			
			if(Cleaning_Reject_Transport_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Transport_price_is_zero", Cleaning_Reject_Transport_price_is_zero.toString());
				
			}
			
			if(Cleaning_Transport_no_PostalCode != null){
				
					this.setProperty("Cleaning_Transport_no_PostalCode", Cleaning_Transport_no_PostalCode.toString());
				
			}
			
			if(Commande_Exceptions != null){
				
					this.setProperty("Commande_Exceptions", Commande_Exceptions.toString());
				
			}
			
			if(Conditionnement_Exceptions != null){
				
					this.setProperty("Conditionnement_Exceptions", Conditionnement_Exceptions.toString());
				
			}
			
			if(CR_Reception_Exceptions != null){
				
					this.setProperty("CR_Reception_Exceptions", CR_Reception_Exceptions.toString());
				
			}
			
			if(Csv_File_Masque != null){
				
					this.setProperty("Csv_File_Masque", Csv_File_Masque.toString());
				
			}
			
			if(Diagnostic_Reject_Command_Error != null){
				
					this.setProperty("Diagnostic_Reject_Command_Error", Diagnostic_Reject_Command_Error.toString());
				
			}
			
			if(Diagnostic_Reject_Day_Not_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Day_Not_Ok", Diagnostic_Reject_Day_Not_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Postal_Code_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Postal_Code_Ok", Diagnostic_Reject_Postal_Code_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Rep != null){
				
					this.setProperty("Diagnostic_Reject_Rep", Diagnostic_Reject_Rep.toString());
				
			}
			
			if(Dossier_Reception_Exceptions != null){
				
					this.setProperty("Dossier_Reception_Exceptions", Dossier_Reception_Exceptions.toString());
				
			}
			
			if(Excel_File_Masque != null){
				
					this.setProperty("Excel_File_Masque", Excel_File_Masque.toString());
				
			}
			
			if(Ligne_Commande_Exceptions != null){
				
					this.setProperty("Ligne_Commande_Exceptions", Ligne_Commande_Exceptions.toString());
				
			}
			
			if(Migration_Billing_Not_Ok != null){
				
					this.setProperty("Migration_Billing_Not_Ok", Migration_Billing_Not_Ok.toString());
				
			}
			
			if(Reject_Client_File != null){
				
					this.setProperty("Reject_Client_File", Reject_Client_File.toString());
				
			}
			
			if(Reject_Client_Local_Rep != null){
				
					this.setProperty("Reject_Client_Local_Rep", Reject_Client_Local_Rep.toString());
				
			}
			
			if(Reject_Command_Logisitc_Code_Client != null){
				
					this.setProperty("Reject_Command_Logisitc_Code_Client", Reject_Command_Logisitc_Code_Client.toString());
				
			}
			
			if(Reject_Command_Transport_Code_Client != null){
				
					this.setProperty("Reject_Command_Transport_Code_Client", Reject_Command_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Distant_Rep != null){
				
					this.setProperty("Reject_Distant_Rep", Reject_Distant_Rep.toString());
				
			}
			
			if(Reject_Distant_Rep_DataMart != null){
				
					this.setProperty("Reject_Distant_Rep_DataMart", Reject_Distant_Rep_DataMart.toString());
				
			}
			
			if(Reject_Duplicated_Client_File != null){
				
					this.setProperty("Reject_Duplicated_Client_File", Reject_Duplicated_Client_File.toString());
				
			}
			
			if(Reject_Migration_Local_Rep != null){
				
					this.setProperty("Reject_Migration_Local_Rep", Reject_Migration_Local_Rep.toString());
				
			}
			
			if(Reject_Not_Complet_Client != null){
				
					this.setProperty("Reject_Not_Complet_Client", Reject_Not_Complet_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Local_Rep != null){
				
					this.setProperty("Reject_Service_Detail_Local_Rep", Reject_Service_Detail_Local_Rep.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_DB != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_DB", Reject_Service_Detail_Logistic_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_Unknown_Client", Reject_Service_Detail_Logistic_Unknown_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_DB != null){
				
					this.setProperty("Reject_Service_Detail_Transport_DB", Reject_Service_Detail_Transport_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Transport_Unknown_Client", Reject_Service_Detail_Transport_Unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Local_Rep != null){
				
					this.setProperty("Reject_Tarification_Local_Rep", Reject_Tarification_Local_Rep.toString());
				
			}
			
			if(Reject_Tarification_Logistic_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_Code_Client", Reject_Tarification_Logistic_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Logistic_DB != null){
				
					this.setProperty("Reject_Tarification_Logistic_DB", Reject_Tarification_Logistic_DB.toString());
				
			}
			
			if(Reject_Tarification_Logistic_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_unknown_Client", Reject_Tarification_Logistic_unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_Code_Client", Reject_Tarification_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_DB != null){
				
					this.setProperty("Reject_Tarification_Transport_DB", Reject_Tarification_Transport_DB.toString());
				
			}
			
			if(Reject_Tarification_Transport_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_unknown_Client", Reject_Tarification_Transport_unknown_Client.toString());
				
			}
			
			if(code_client_length != null){
				
					this.setProperty("code_client_length", code_client_length.toString());
				
			}
			
			if(code_client_regex != null){
				
					this.setProperty("code_client_regex", code_client_regex.toString());
				
			}
			
			if(Livraison_directory != null){
				
					this.setProperty("Livraison_directory", Livraison_directory.toString());
				
			}
			
			if(Round_Delay_Minus_Days != null){
				
					this.setProperty("Round_Delay_Minus_Days", Round_Delay_Minus_Days.toString());
				
			}
			
			if(Round_Delay_Plus_Days_Plus_One != null){
				
					this.setProperty("Round_Delay_Plus_Days_Plus_One", Round_Delay_Plus_Days_Plus_One.toString());
				
			}
			
			if(Round_directory != null){
				
					this.setProperty("Round_directory", Round_directory.toString());
				
			}
			
			if(Round_file_name != null){
				
					this.setProperty("Round_file_name", Round_file_name.toString());
				
			}
			
			if(Round_Minus_Days != null){
				
					this.setProperty("Round_Minus_Days", Round_Minus_Days.toString());
				
			}
			
			if(Salesforce_Name != null){
				
					this.setProperty("Salesforce_Name", Salesforce_Name.toString());
				
			}
			
			if(Salesforce_Password != null){
				
					this.setProperty("Salesforce_Password", Salesforce_Password.toString());
				
			}
			
			if(Salesforce_Security_Token != null){
				
					this.setProperty("Salesforce_Security_Token", Salesforce_Security_Token.toString());
				
			}
			
			if(Salesforce_User_ID != null){
				
					this.setProperty("Salesforce_User_ID", Salesforce_User_ID.toString());
				
			}
			
			if(comptabilite_analytique_month != null){
				
					this.setProperty("comptabilite_analytique_month", comptabilite_analytique_month.toString());
				
			}
			
			if(comptabilite_analytique_year != null){
				
					this.setProperty("comptabilite_analytique_year", comptabilite_analytique_year.toString());
				
			}
			
			if(Ecolotrans_JP_Month_MM != null){
				
					this.setProperty("Ecolotrans_JP_Month_MM", Ecolotrans_JP_Month_MM.toString());
				
			}
			
			if(end_date != null){
				
					this.setProperty("end_date", end_date.toString());
				
			}
			
			if(Extraction_Aprm != null){
				
					this.setProperty("Extraction_Aprm", Extraction_Aprm.toString());
				
			}
			
			if(Extraction_Jour != null){
				
					this.setProperty("Extraction_Jour", Extraction_Jour.toString());
				
			}
			
			if(Extraction_Matin != null){
				
					this.setProperty("Extraction_Matin", Extraction_Matin.toString());
				
			}
			
			if(start_date != null){
				
					this.setProperty("start_date", start_date.toString());
				
			}
			
			if(Urbantz_directory != null){
				
					this.setProperty("Urbantz_directory", Urbantz_directory.toString());
				
			}
			
			if(urbantz_extraction_date != null){
				
					this.setProperty("urbantz_extraction_date", urbantz_extraction_date.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Billing_BSO_Months;
public String getBilling_BSO_Months(){
	return this.Billing_BSO_Months;
}
public Integer Billing_BSO_Start_Year;
public Integer getBilling_BSO_Start_Year(){
	return this.Billing_BSO_Start_Year;
}
public String Billing_Comptabilite_File;
public String getBilling_Comptabilite_File(){
	return this.Billing_Comptabilite_File;
}
public String Billing_Comptabilite_Folder;
public String getBilling_Comptabilite_Folder(){
	return this.Billing_Comptabilite_Folder;
}
public String Billing_Distant_Rep;
public String getBilling_Distant_Rep(){
	return this.Billing_Distant_Rep;
}
public String Billing_File_Masque;
public String getBilling_File_Masque(){
	return this.Billing_File_Masque;
}
public String Billing_Local_Rep;
public String getBilling_Local_Rep(){
	return this.Billing_Local_Rep;
}
public String Billing_Name;
public String getBilling_Name(){
	return this.Billing_Name;
}
public Integer Billing_Start_Number;
public Integer getBilling_Start_Number(){
	return this.Billing_Start_Number;
}
public Float Billing_TVA_default_value;
public Float getBilling_TVA_default_value(){
	return this.Billing_TVA_default_value;
}
public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String ODS_Database;
public String getODS_Database(){
	return this.ODS_Database;
}
public String PBI_Database;
public String getPBI_Database(){
	return this.PBI_Database;
}
public String PBI_PC_Database;
public String getPBI_PC_Database(){
	return this.PBI_PC_Database;
}
public String PBI_RT_Database;
public String getPBI_RT_Database(){
	return this.PBI_RT_Database;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String DataMart_Clean_Database;
public String getDataMart_Clean_Database(){
	return this.DataMart_Clean_Database;
}
public String DataMart_Clean_Max_Date;
public String getDataMart_Clean_Max_Date(){
	return this.DataMart_Clean_Max_Date;
}
public String DataMart_Clean_Min_Date;
public String getDataMart_Clean_Min_Date(){
	return this.DataMart_Clean_Min_Date;
}
public Integer DataMart_Closure_Date_PlusX;
public Integer getDataMart_Closure_Date_PlusX(){
	return this.DataMart_Closure_Date_PlusX;
}
public Integer Limit_Percent;
public Integer getLimit_Percent(){
	return this.Limit_Percent;
}
public String Logistic_Max_Date_Plus_One;
public String getLogistic_Max_Date_Plus_One(){
	return this.Logistic_Max_Date_Plus_One;
}
public String Logistic_Min_Date_Minus_One;
public String getLogistic_Min_Date_Minus_One(){
	return this.Logistic_Min_Date_Minus_One;
}
public Integer deleted_J_minus_X;
public Integer getDeleted_J_minus_X(){
	return this.deleted_J_minus_X;
}
public Integer deleted_J_plusOne_X;
public Integer getDeleted_J_plusOne_X(){
	return this.deleted_J_plusOne_X;
}
		public String FTP_DistantRep;
		public String getFTP_DistantRep(){
			return this.FTP_DistantRep;
		}
		
public String FTP_FileMasque;
public String getFTP_FileMasque(){
	return this.FTP_FileMasque;
}
public String FTP_Hote;
public String getFTP_Hote(){
	return this.FTP_Hote;
}
public java.lang.String FTP_Password;
public java.lang.String getFTP_Password(){
	return this.FTP_Password;
}
public Integer FTP_Port;
public Integer getFTP_Port(){
	return this.FTP_Port;
}
public String FTP_ST_DistantRep;
public String getFTP_ST_DistantRep(){
	return this.FTP_ST_DistantRep;
}
public String FTP_User;
public String getFTP_User(){
	return this.FTP_User;
}
public Integer FTP_Wms_Port;
public Integer getFTP_Wms_Port(){
	return this.FTP_Wms_Port;
}
public String keyStore_file_name;
public String getKeyStore_file_name(){
	return this.keyStore_file_name;
}
public String KeyStore_Repo;
public String getKeyStore_Repo(){
	return this.KeyStore_Repo;
}
public String mail_password;
public String getMail_password(){
	return this.mail_password;
}
public String send_mail_from;
public String getSend_mail_from(){
	return this.send_mail_from;
}
public String send_mail_to;
public String getSend_mail_to(){
	return this.send_mail_to;
}
public String send_to_second_mail;
public String getSend_to_second_mail(){
	return this.send_to_second_mail;
}
public String send_to_third_mail;
public String getSend_to_third_mail(){
	return this.send_to_third_mail;
}
public String Clients_Masque;
public String getClients_Masque(){
	return this.Clients_Masque;
}
public String Code_client_masque;
public String getCode_client_masque(){
	return this.Code_client_masque;
}
public String Command_Logistic_Invalid_Date;
public String getCommand_Logistic_Invalid_Date(){
	return this.Command_Logistic_Invalid_Date;
}
public String Command_Logistic_Masque;
public String getCommand_Logistic_Masque(){
	return this.Command_Logistic_Masque;
}
public String Command_Transport_Masque;
public String getCommand_Transport_Masque(){
	return this.Command_Transport_Masque;
}
public String Command_Transport_Masque_Express;
public String getCommand_Transport_Masque_Express(){
	return this.Command_Transport_Masque_Express;
}
public String Ecolotrans_JP;
public String getEcolotrans_JP(){
	return this.Ecolotrans_JP;
}
public String Holiday_Days_Masque;
public String getHoliday_Days_Masque(){
	return this.Holiday_Days_Masque;
}
public String Livraisons_Exception;
public String getLivraisons_Exception(){
	return this.Livraisons_Exception;
}
public String Livraisons_Masque;
public String getLivraisons_Masque(){
	return this.Livraisons_Masque;
}
public String Livraisons_Ok;
public String getLivraisons_Ok(){
	return this.Livraisons_Ok;
}
public String ST_Drivers;
public String getST_Drivers(){
	return this.ST_Drivers;
}
public String Tarification_Logistic_Masque;
public String getTarification_Logistic_Masque(){
	return this.Tarification_Logistic_Masque;
}
public String Tarification_Transport_Masque;
public String getTarification_Transport_Masque(){
	return this.Tarification_Transport_Masque;
}
public String Tournee_Masque;
public String getTournee_Masque(){
	return this.Tournee_Masque;
}
public String TVA_Exceptions;
public String getTVA_Exceptions(){
	return this.TVA_Exceptions;
}
public String Backup;
public String getBackup(){
	return this.Backup;
}
public String Server_Clean;
public String getServer_Clean(){
	return this.Server_Clean;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Server_Out;
public String getServer_Out(){
	return this.Server_Out;
}
public String Server_Out_DataMart;
public String getServer_Out_DataMart(){
	return this.Server_Out_DataMart;
}
public String Art_masque;
public String getArt_masque(){
	return this.Art_masque;
}
public String Cdc_masque;
public String getCdc_masque(){
	return this.Cdc_masque;
}
public String Cre_masque;
public String getCre_masque(){
	return this.Cre_masque;
}
public String Crp_masque;
public String getCrp_masque(){
	return this.Crp_masque;
}
public String Crr_masque;
public String getCrr_masque(){
	return this.Crr_masque;
}
public String Distant_Magistor_Clients_Input;
public String getDistant_Magistor_Clients_Input(){
	return this.Distant_Magistor_Clients_Input;
}
public String Distant_Magistor_Clients_Test_Input;
public String getDistant_Magistor_Clients_Test_Input(){
	return this.Distant_Magistor_Clients_Test_Input;
}
public String Distant_Magistor1_Input;
public String getDistant_Magistor1_Input(){
	return this.Distant_Magistor1_Input;
}
public String Distant_Magistor1_Output;
public String getDistant_Magistor1_Output(){
	return this.Distant_Magistor1_Output;
}
public String Distant_Magistor1_Test_Input;
public String getDistant_Magistor1_Test_Input(){
	return this.Distant_Magistor1_Test_Input;
}
public String Distant_Magistor1_Test_Output;
public String getDistant_Magistor1_Test_Output(){
	return this.Distant_Magistor1_Test_Output;
}
public String Distant_Magistor2_Input;
public String getDistant_Magistor2_Input(){
	return this.Distant_Magistor2_Input;
}
public String Distant_Magistor2_Output;
public String getDistant_Magistor2_Output(){
	return this.Distant_Magistor2_Output;
}
public String Distant_Magistor2_Test_Input;
public String getDistant_Magistor2_Test_Input(){
	return this.Distant_Magistor2_Test_Input;
}
public String Distant_Magistor2_Test_Output;
public String getDistant_Magistor2_Test_Output(){
	return this.Distant_Magistor2_Test_Output;
}
public String Drc_masque;
public String getDrc_masque(){
	return this.Drc_masque;
}
public String Mvt_masque;
public String getMvt_masque(){
	return this.Mvt_masque;
}
public String Stk_masque;
public String getStk_masque(){
	return this.Stk_masque;
}
public String Xml_File_Masque;
public String getXml_File_Masque(){
	return this.Xml_File_Masque;
}
public String Article_Exceptions;
public String getArticle_Exceptions(){
	return this.Article_Exceptions;
}
public String Cleaning_Reject_Logistic_price_is_zero;
public String getCleaning_Reject_Logistic_price_is_zero(){
	return this.Cleaning_Reject_Logistic_price_is_zero;
}
public String Cleaning_Reject_Rep;
public String getCleaning_Reject_Rep(){
	return this.Cleaning_Reject_Rep;
}
public String Cleaning_Reject_Transport_price_is_zero;
public String getCleaning_Reject_Transport_price_is_zero(){
	return this.Cleaning_Reject_Transport_price_is_zero;
}
public String Cleaning_Transport_no_PostalCode;
public String getCleaning_Transport_no_PostalCode(){
	return this.Cleaning_Transport_no_PostalCode;
}
public String Commande_Exceptions;
public String getCommande_Exceptions(){
	return this.Commande_Exceptions;
}
public String Conditionnement_Exceptions;
public String getConditionnement_Exceptions(){
	return this.Conditionnement_Exceptions;
}
public String CR_Reception_Exceptions;
public String getCR_Reception_Exceptions(){
	return this.CR_Reception_Exceptions;
}
public String Csv_File_Masque;
public String getCsv_File_Masque(){
	return this.Csv_File_Masque;
}
public String Diagnostic_Reject_Command_Error;
public String getDiagnostic_Reject_Command_Error(){
	return this.Diagnostic_Reject_Command_Error;
}
public String Diagnostic_Reject_Day_Not_Ok;
public String getDiagnostic_Reject_Day_Not_Ok(){
	return this.Diagnostic_Reject_Day_Not_Ok;
}
public String Diagnostic_Reject_Postal_Code_Ok;
public String getDiagnostic_Reject_Postal_Code_Ok(){
	return this.Diagnostic_Reject_Postal_Code_Ok;
}
public String Diagnostic_Reject_Rep;
public String getDiagnostic_Reject_Rep(){
	return this.Diagnostic_Reject_Rep;
}
public String Dossier_Reception_Exceptions;
public String getDossier_Reception_Exceptions(){
	return this.Dossier_Reception_Exceptions;
}
public String Excel_File_Masque;
public String getExcel_File_Masque(){
	return this.Excel_File_Masque;
}
public String Ligne_Commande_Exceptions;
public String getLigne_Commande_Exceptions(){
	return this.Ligne_Commande_Exceptions;
}
public String Migration_Billing_Not_Ok;
public String getMigration_Billing_Not_Ok(){
	return this.Migration_Billing_Not_Ok;
}
public String Reject_Client_File;
public String getReject_Client_File(){
	return this.Reject_Client_File;
}
public String Reject_Client_Local_Rep;
public String getReject_Client_Local_Rep(){
	return this.Reject_Client_Local_Rep;
}
public String Reject_Command_Logisitc_Code_Client;
public String getReject_Command_Logisitc_Code_Client(){
	return this.Reject_Command_Logisitc_Code_Client;
}
public String Reject_Command_Transport_Code_Client;
public String getReject_Command_Transport_Code_Client(){
	return this.Reject_Command_Transport_Code_Client;
}
public String Reject_Distant_Rep;
public String getReject_Distant_Rep(){
	return this.Reject_Distant_Rep;
}
public String Reject_Distant_Rep_DataMart;
public String getReject_Distant_Rep_DataMart(){
	return this.Reject_Distant_Rep_DataMart;
}
public String Reject_Duplicated_Client_File;
public String getReject_Duplicated_Client_File(){
	return this.Reject_Duplicated_Client_File;
}
public String Reject_Migration_Local_Rep;
public String getReject_Migration_Local_Rep(){
	return this.Reject_Migration_Local_Rep;
}
public String Reject_Not_Complet_Client;
public String getReject_Not_Complet_Client(){
	return this.Reject_Not_Complet_Client;
}
public String Reject_Service_Detail_Local_Rep;
public String getReject_Service_Detail_Local_Rep(){
	return this.Reject_Service_Detail_Local_Rep;
}
public String Reject_Service_Detail_Logistic_DB;
public String getReject_Service_Detail_Logistic_DB(){
	return this.Reject_Service_Detail_Logistic_DB;
}
public String Reject_Service_Detail_Logistic_Unknown_Client;
public String getReject_Service_Detail_Logistic_Unknown_Client(){
	return this.Reject_Service_Detail_Logistic_Unknown_Client;
}
public String Reject_Service_Detail_Transport_DB;
public String getReject_Service_Detail_Transport_DB(){
	return this.Reject_Service_Detail_Transport_DB;
}
public String Reject_Service_Detail_Transport_Unknown_Client;
public String getReject_Service_Detail_Transport_Unknown_Client(){
	return this.Reject_Service_Detail_Transport_Unknown_Client;
}
public String Reject_Tarification_Local_Rep;
public String getReject_Tarification_Local_Rep(){
	return this.Reject_Tarification_Local_Rep;
}
public String Reject_Tarification_Logistic_Code_Client;
public String getReject_Tarification_Logistic_Code_Client(){
	return this.Reject_Tarification_Logistic_Code_Client;
}
public String Reject_Tarification_Logistic_DB;
public String getReject_Tarification_Logistic_DB(){
	return this.Reject_Tarification_Logistic_DB;
}
public String Reject_Tarification_Logistic_unknown_Client;
public String getReject_Tarification_Logistic_unknown_Client(){
	return this.Reject_Tarification_Logistic_unknown_Client;
}
public String Reject_Tarification_Transport_Code_Client;
public String getReject_Tarification_Transport_Code_Client(){
	return this.Reject_Tarification_Transport_Code_Client;
}
public String Reject_Tarification_Transport_DB;
public String getReject_Tarification_Transport_DB(){
	return this.Reject_Tarification_Transport_DB;
}
public String Reject_Tarification_Transport_unknown_Client;
public String getReject_Tarification_Transport_unknown_Client(){
	return this.Reject_Tarification_Transport_unknown_Client;
}
public Integer code_client_length;
public Integer getCode_client_length(){
	return this.code_client_length;
}
public String code_client_regex;
public String getCode_client_regex(){
	return this.code_client_regex;
}
public String Livraison_directory;
public String getLivraison_directory(){
	return this.Livraison_directory;
}
public Integer Round_Delay_Minus_Days;
public Integer getRound_Delay_Minus_Days(){
	return this.Round_Delay_Minus_Days;
}
public Integer Round_Delay_Plus_Days_Plus_One;
public Integer getRound_Delay_Plus_Days_Plus_One(){
	return this.Round_Delay_Plus_Days_Plus_One;
}
public String Round_directory;
public String getRound_directory(){
	return this.Round_directory;
}
public String Round_file_name;
public String getRound_file_name(){
	return this.Round_file_name;
}
public Integer Round_Minus_Days;
public Integer getRound_Minus_Days(){
	return this.Round_Minus_Days;
}
public String Salesforce_Name;
public String getSalesforce_Name(){
	return this.Salesforce_Name;
}
public java.lang.String Salesforce_Password;
public java.lang.String getSalesforce_Password(){
	return this.Salesforce_Password;
}
public java.lang.String Salesforce_Security_Token;
public java.lang.String getSalesforce_Security_Token(){
	return this.Salesforce_Security_Token;
}
public String Salesforce_User_ID;
public String getSalesforce_User_ID(){
	return this.Salesforce_User_ID;
}
public String comptabilite_analytique_month;
public String getComptabilite_analytique_month(){
	return this.comptabilite_analytique_month;
}
public String comptabilite_analytique_year;
public String getComptabilite_analytique_year(){
	return this.comptabilite_analytique_year;
}
public String Ecolotrans_JP_Month_MM;
public String getEcolotrans_JP_Month_MM(){
	return this.Ecolotrans_JP_Month_MM;
}
public String end_date;
public String getEnd_date(){
	return this.end_date;
}
public Integer Extraction_Aprm;
public Integer getExtraction_Aprm(){
	return this.Extraction_Aprm;
}
public Integer Extraction_Jour;
public Integer getExtraction_Jour(){
	return this.Extraction_Jour;
}
public Integer Extraction_Matin;
public Integer getExtraction_Matin(){
	return this.Extraction_Matin;
}
public String start_date;
public String getStart_date(){
	return this.start_date;
}
public String Urbantz_directory;
public String getUrbantz_directory(){
	return this.Urbantz_directory;
}
public String urbantz_extraction_date;
public String getUrbantz_extraction_date(){
	return this.urbantz_extraction_date;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
	private final String projectName = "ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_zbxZFHZ4Ee6j9cQuSh5lZA", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileList_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPFileList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPGet_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPPut_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPPut_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPDelete_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPFileList_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPFileExist_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSleep_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSleep_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileList_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSleep_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSleep_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPClose_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPClose_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPPut_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPDelete_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSleep_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSleep_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPClose_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_1");
		org.slf4j.MDC.put("_subJobPid", "n7SmSK_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";
	
	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
                    log4jParamters_tWarn_1.append("Parameters:");
                            log4jParamters_tWarn_1.append("MESSAGE" + " = " + "jobName + \" STARTED\"");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_1.append(" | ");
                            log4jParamters_tWarn_1.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
                    } 
                } 
            new BytesLimit65535_tWarn_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_1", "tWarn_1", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "WARN","",jobName + " STARTED","", "");
            log.warn("tWarn_1 - "  + ("Message: ")  + (jobName + " STARTED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_1_WARN_MESSAGES", jobName + " STARTED"); 
	globalMap.put("tWarn_1_WARN_PRIORITY", 4);
	globalMap.put("tWarn_1_WARN_CODE", 42);
	
} catch (Exception e_tWarn_1) {
globalMap.put("tWarn_1_ERROR_MESSAGE",e_tWarn_1.getMessage());
	logIgnoredError(String.format("tWarn_1 - tWarn failed to log message due to internal error: %s", e_tWarn_1), e_tWarn_1);
}


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 process_data_end ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tWarn_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tSetGlobalVar_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";
	
	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSetGlobalVar_1");
		org.slf4j.MDC.put("_subJobPid", "2ninUX_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";
	
	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSetGlobalVar_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
                    log4jParamters_tSetGlobalVar_1.append("Parameters:");
                            log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("TalendDate.getDate(\"ddMMyyyy\")")+", KEY="+("\"input_today_date\"")+"}, {VALUE="+("TalendDate.getDate(\"yyyyMMddHHmm\")")+", KEY="+("\"output_today_date\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"error\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"notificationMails\"")+"}, {VALUE="+("false")+", KEY="+("\"unknown_format_found\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"magistor_cdc_clients\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"currentFileType\"")+"}]");
                        log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
                    } 
                } 
            new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSetGlobalVar_1", "tSetGlobalVar_1", "tSetGlobalVar");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

globalMap.put("input_today_date", TalendDate.getDate("ddMMyyyy"));
globalMap.put("output_today_date", TalendDate.getDate("yyyyMMddHHmm"));
globalMap.put("error", "");
globalMap.put("notificationMails", "");
globalMap.put("unknown_format_found", false);
globalMap.put("magistor_cdc_clients", "");
globalMap.put("currentFileType", "");

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 process_data_end ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tFTPConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";
	
	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPConnection_1");
		org.slf4j.MDC.put("_subJobPid", "CGE5kG_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPConnection_1", false);
		start_Hash.put("tFTPConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPConnection_1";
	
	
		int tos_count_tFTPConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPConnection_1 = new StringBuilder();
                    log4jParamters_tFTPConnection_1.append("Parameters:");
                            log4jParamters_tFTPConnection_1.append("HOST" + " = " + "context.FTP_Hote");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("PORT" + " = " + "context.FTP_Port");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USER" + " = " + "context.FTP_User");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:PhdEkWZDDAMdE4XGXAnJSWZYuFBmISOTDnjJYWnVb/SJch8stzp3").substring(0, 4) + "...");     
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("SFTP" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("FTPS" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("CONNECT_MODE" + " = " + "PASSIVE");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USE_PROXY" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("CONNECTION_TIMEOUT" + " = " + "0");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USE_STRICT_REPLY_PARSING" + " = " + "true");
                        log4jParamters_tFTPConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + (log4jParamters_tFTPConnection_1) );
                    } 
                } 
            new BytesLimit65535_tFTPConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPConnection_1", "tFTPConnection_1", "tFTPConnection");
				talendJobLogProcess(globalMap);
			}
			

 
int connectionTimeout_tFTPConnection_1 = Integer.valueOf(0);
    org.apache.commons.net.ftp.FTPClient ftp_tFTPConnection_1 = null;

    try {
    if(("true").equals(System.getProperty("http.proxySet")) ){

//check if the host is in the excludes for proxy
    boolean isHostIgnored_tFTPConnection_1 = false;
    String nonProxyHostsString_tFTPConnection_1 = System.getProperty("http.nonProxyHosts");
    String[] nonProxyHosts_tFTPConnection_1 = (nonProxyHostsString_tFTPConnection_1 == null) ? new String[0] : nonProxyHostsString_tFTPConnection_1.split("\\|");
    for (String nonProxyHost : nonProxyHosts_tFTPConnection_1) {
        if ((context.FTP_Hote).matches(nonProxyHost.trim())) {
            isHostIgnored_tFTPConnection_1 = true;
            break;
        }
    }
        if (!isHostIgnored_tFTPConnection_1) {
            String httpProxyHost = System.getProperty("http.proxyHost");
            int httpProxyPort = Integer.getInteger("http.proxyPort");
            String httpProxyUser = System.getProperty("http.proxyUser");
            String httpProxyPass = System.getProperty("http.proxyPassword");
            ftp_tFTPConnection_1 = new org.apache.commons.net.ftp.FTPHTTPClient(httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);
        } else {
            ftp_tFTPConnection_1 = new org.apache.commons.net.ftp.FTPClient();
        }
    } else if ("local".equals(System.getProperty("http.proxySet"))) {
        String uriString = context.FTP_Hote + ":" + 990;
        java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);

        if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {
            java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();

            String httpProxyHost = proxyAddress.getAddress().getHostAddress();
            int httpProxyPort = proxyAddress.getPort();
            String httpProxyUser = "";
            String httpProxyPass = ""; //leave it empty if proxy creds weren't specified

            org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(httpProxyHost + ":" + httpProxyPort);
            if (proxyCreds != null) {
                httpProxyUser = proxyCreds.getUser();
                    httpProxyPass = proxyCreds.getPass();
            }

            ftp_tFTPConnection_1 = new org.apache.commons.net.ftp.FTPHTTPClient(httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);

        } else { //no http proxy for ftp host defined
            ftp_tFTPConnection_1 = new org.apache.commons.net.ftp.FTPClient();
        }
    } else {
        ftp_tFTPConnection_1 = new org.apache.commons.net.ftp.FTPClient();
    }
    
        ftp_tFTPConnection_1.setControlEncoding("UTF-8");

            log.info("tFTPConnection_1 - Attempt to connect to '" + context.FTP_Hote + "' with username '" + context.FTP_User+ "'.");

        if (connectionTimeout_tFTPConnection_1 > 0) {
            ftp_tFTPConnection_1.setDefaultTimeout(connectionTimeout_tFTPConnection_1);
        }

        ftp_tFTPConnection_1.setStrictReplyParsing(true);
        ftp_tFTPConnection_1.connect(context.FTP_Hote,context.FTP_Port);
            log.info("tFTPConnection_1 - Connect to '" + context.FTP_Hote + "' has succeeded.");
 
	final String decryptedPassword_tFTPConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:MpYBCp2f82XyyoGnApo3rTTG+FSg0PVT+4EmQeEna17uG67ZVFZU");

        boolean isLoginSuccessful_tFTPConnection_1 = ftp_tFTPConnection_1.login(context.FTP_User, decryptedPassword_tFTPConnection_1);

        if (!isLoginSuccessful_tFTPConnection_1) {
            throw new RuntimeException("Login failed");
        }

        ftp_tFTPConnection_1.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
    } catch (Exception e) {
            log.error("tFTPConnection_1 - Can't create connection: " + e.getMessage());
        throw e;
    }

        ftp_tFTPConnection_1.enterLocalPassiveMode();
            log.debug("tFTPConnection_1 - Using the passive mode.");

    globalMap.put("conn_tFTPConnection_1",ftp_tFTPConnection_1);

 



/**
 * [tFTPConnection_1 begin ] stop
 */
	
	/**
	 * [tFTPConnection_1 main ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	

 


	tos_count_tFTPConnection_1++;

/**
 * [tFTPConnection_1 main ] stop
 */
	
	/**
	 * [tFTPConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	

 



/**
 * [tFTPConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	

 



/**
 * [tFTPConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPConnection_1 end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + ("Done.") );

ok_Hash.put("tFTPConnection_1", true);
end_Hash.put("tFTPConnection_1", System.currentTimeMillis());




/**
 * [tFTPConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFTPConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tFileInputExcel_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	

 



/**
 * [tFTPConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Mail;

				public String getMail () {
					return this.Mail;
				}

				public Boolean MailIsNullable(){
				    return true;
				}
				public Boolean MailIsKey(){
				    return false;
				}
				public Integer MailLength(){
				    return null;
				}
				public Integer MailPrecision(){
				    return null;
				}
				public String MailDefault(){
				
					return null;
				
				}
				public String MailComment(){
				
				    return "";
				
				}
				public String MailPattern(){
				
					return "";
				
				}
				public String MailOriginalDbColumnName(){
				
					return "Mail";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Mail="+Mail);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Mail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Mail);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_2");
		org.slf4j.MDC.put("_subJobPid", "pQg4Dy_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row21Struct row21 = new row21Struct();




	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row21");
			
		int tos_count_tJavaRow_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJavaRow_1", "tJavaRow_1", "tJavaRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_2", false);
		start_Hash.put("tFileInputExcel_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		
		int tos_count_tFileInputExcel_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_2 = new StringBuilder();
                    log4jParamters_tFileInputExcel_2.append("Parameters:");
                            log4jParamters_tFileInputExcel_2.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("FILENAME" + " = " + "context.Server_In + \"MagistorNotificationMails.xlsx\"");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:vSJIMDZRnf2AGftbwD8DAGwq3j+rcJYsWpBwDQ==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Mails\"")+"}]");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                            log4jParamters_tFileInputExcel_2.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_2 - "  + (log4jParamters_tFileInputExcel_2) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_2", "tFileInputExcel_2<br> notifications mail", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:039XUyHOtv1x/BunbAeyykXjGWwD4CeGWDFu9A==");
        String password_tFileInputExcel_2 = decryptedPassword_tFileInputExcel_2;
        if (password_tFileInputExcel_2.isEmpty()){
            password_tFileInputExcel_2 = null;
        }
			class RegexUtil_tFileInputExcel_2 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_2 regexUtil_tFileInputExcel_2 = new RegexUtil_tFileInputExcel_2();

		Object source_tFileInputExcel_2 = context.Server_In + "MagistorNotificationMails.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_2 = null;
		
		if(source_tFileInputExcel_2 instanceof String){
			workbook_tFileInputExcel_2 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_2), password_tFileInputExcel_2, true);
		} else if(source_tFileInputExcel_2 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_2 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_2, password_tFileInputExcel_2);
		} else{
			workbook_tFileInputExcel_2 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_2 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_2.addAll(regexUtil_tFileInputExcel_2.getSheets(workbook_tFileInputExcel_2, "Mails", false));
    	if(sheetList_tFileInputExcel_2.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_2 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_2 : sheetList_tFileInputExcel_2) {
			if(sheet_FilterNull_tFileInputExcel_2!=null && sheetList_FilterNull_tFileInputExcel_2.iterator()!=null && sheet_FilterNull_tFileInputExcel_2.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_2.add(sheet_FilterNull_tFileInputExcel_2);
			}
		}
		sheetList_tFileInputExcel_2 = sheetList_FilterNull_tFileInputExcel_2;
		int nb_line_tFileInputExcel_2 = 0;
	if(sheetList_tFileInputExcel_2.size()>0){

        int begin_line_tFileInputExcel_2 = 1;

        int footer_input_tFileInputExcel_2 = 0;

        int end_line_tFileInputExcel_2=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_2:sheetList_tFileInputExcel_2){
			end_line_tFileInputExcel_2+=(sheet_tFileInputExcel_2.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_2 -= footer_input_tFileInputExcel_2;
        int limit_tFileInputExcel_2 = -1;
        int start_column_tFileInputExcel_2 = 1-1;
        int end_column_tFileInputExcel_2 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_2 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(0);
        int rowCount_tFileInputExcel_2 = 0;
        int sheetIndex_tFileInputExcel_2 = 0;
        int currentRows_tFileInputExcel_2 = (sheetList_tFileInputExcel_2.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_2 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_2 = df_tFileInputExcel_2.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_2 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_2 = begin_line_tFileInputExcel_2; i_tFileInputExcel_2 < end_line_tFileInputExcel_2; i_tFileInputExcel_2++){

        	int emptyColumnCount_tFileInputExcel_2 = 0;

        	if (limit_tFileInputExcel_2 != -1 && nb_line_tFileInputExcel_2 >= limit_tFileInputExcel_2) {
        		break;
        	}

            while (i_tFileInputExcel_2 >= rowCount_tFileInputExcel_2 + currentRows_tFileInputExcel_2) {
                rowCount_tFileInputExcel_2 += currentRows_tFileInputExcel_2;
                sheet_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(++sheetIndex_tFileInputExcel_2);
                currentRows_tFileInputExcel_2 = (sheet_tFileInputExcel_2.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_2_CURRENT_SHEET",sheet_tFileInputExcel_2.getSheetName());
            if (rowCount_tFileInputExcel_2 <= i_tFileInputExcel_2) {
                row_tFileInputExcel_2 = sheet_tFileInputExcel_2.getRow(i_tFileInputExcel_2 - rowCount_tFileInputExcel_2);
            }
		    row21 = null;
					int tempRowLength_tFileInputExcel_2 = 1;
				
				int columnIndex_tFileInputExcel_2 = 0;
			
			String[] temp_row_tFileInputExcel_2 = new String[tempRowLength_tFileInputExcel_2];
			int excel_end_column_tFileInputExcel_2;
			if(row_tFileInputExcel_2==null){
				excel_end_column_tFileInputExcel_2=0;
			}else{
				excel_end_column_tFileInputExcel_2=row_tFileInputExcel_2.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_2;
			if(end_column_tFileInputExcel_2 == -1){
				actual_end_column_tFileInputExcel_2 = excel_end_column_tFileInputExcel_2;
			}
			else{
				actual_end_column_tFileInputExcel_2 = end_column_tFileInputExcel_2 >	excel_end_column_tFileInputExcel_2 ? excel_end_column_tFileInputExcel_2 : end_column_tFileInputExcel_2;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_2 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_2;i++){
				if(i + start_column_tFileInputExcel_2 < actual_end_column_tFileInputExcel_2){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_2 = row_tFileInputExcel_2.getCell(i + start_column_tFileInputExcel_2);
					if(cell_tFileInputExcel_2!=null){
					switch (cell_tFileInputExcel_2.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_2[i] = cell_tFileInputExcel_2.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_2)) {
									temp_row_tFileInputExcel_2[i] =cell_tFileInputExcel_2.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_2[i] = df_tFileInputExcel_2.format(cell_tFileInputExcel_2.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_2[i] =String.valueOf(cell_tFileInputExcel_2.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_2.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_2[i] = cell_tFileInputExcel_2.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_2)) {
											temp_row_tFileInputExcel_2[i] =cell_tFileInputExcel_2.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_2 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_2.getNumericCellValue());
										temp_row_tFileInputExcel_2[i] = ne_tFileInputExcel_2.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_2[i] =String.valueOf(cell_tFileInputExcel_2.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_2[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_2[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_2[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_2[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_2 = false;
			row21 = new row21Struct();
			int curColNum_tFileInputExcel_2 = -1;
			String curColName_tFileInputExcel_2 = "";
			try{
							columnIndex_tFileInputExcel_2 = 0;
						
			if( temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].trim().length() > 0) {
				curColNum_tFileInputExcel_2=columnIndex_tFileInputExcel_2 + start_column_tFileInputExcel_2 + 1;
				curColName_tFileInputExcel_2 = "Mail";

				row21.Mail = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].trim();
			}else{
				row21.Mail = null;
				emptyColumnCount_tFileInputExcel_2++;
			}

        if(emptyColumnCount_tFileInputExcel_2 >= 1){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_2++;
				
				log.debug("tFileInputExcel_2 - Retrieving the record " + (nb_line_tFileInputExcel_2) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_2_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_2 = true;
						log.error("tFileInputExcel_2 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row21 = null;
			}


		



 



/**
 * [tFileInputExcel_2 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		

 


	tos_count_tFileInputExcel_2++;

/**
 * [tFileInputExcel_2 main ] stop
 */
	
	/**
	 * [tFileInputExcel_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		

 



/**
 * [tFileInputExcel_2 process_data_begin ] stop
 */
// Start of branch "row21"
if(row21 != null) { 



	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row21","tFileInputExcel_2","tFileInputExcel_2<br> notifications mail","tFileInputExcel","tJavaRow_1","tJavaRow_1","tJavaRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row21 - " + (row21==null? "": row21.toLogString()));
    			}
    		

    String notificationMails = (String)globalMap.get("notificationMails");
notificationMails += ("".equals(notificationMails) ? row21.Mail : ";" + row21.Mail);
globalMap.put("notificationMails", notificationMails);
System.out.println("Mails : " + notificationMails);


    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */
	
	/**
	 * [tJavaRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tJavaRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 process_data_end ] stop
 */

} // End of branch "row21"




	
	/**
	 * [tFileInputExcel_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		

 



/**
 * [tFileInputExcel_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		

			}
			
			
				log.debug("tFileInputExcel_2 - Retrieved records count: "+ nb_line_tFileInputExcel_2 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_2_NB_LINE",nb_line_tFileInputExcel_2);
		} finally {
				
  				if(!(source_tFileInputExcel_2 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_2.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_2 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_2", true);
end_Hash.put("tFileInputExcel_2", System.currentTimeMillis());




/**
 * [tFileInputExcel_2 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row21",2,0,
			 			"tFileInputExcel_2","tFileInputExcel_2<br> notifications mail","tFileInputExcel","tJavaRow_1","tJavaRow_1","tJavaRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tFileInputExcel_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";
	
	
			cLabel="tFileInputExcel_2<br> notifications mail";
		

 



/**
 * [tFileInputExcel_2 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";
	
	

 



/**
 * [tJavaRow_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_2_SUBPROCESS_STATE", 1);
	}
	


public static class row48Struct implements routines.system.IPersistableRow<row48Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row48Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_6");
		org.slf4j.MDC.put("_subJobPid", "haAtO8_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row48Struct row48 = new row48Struct();




	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row48");
			
		int tos_count_tJavaRow_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJavaRow_2", "tJavaRow_2", "tJavaRow");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_6", false);
		start_Hash.put("tFileInputExcel_6", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		
		int tos_count_tFileInputExcel_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_6 = new StringBuilder();
                    log4jParamters_tFileInputExcel_6.append("Parameters:");
                            log4jParamters_tFileInputExcel_6.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("FILENAME" + " = " + "context.Server_In + \"MagistorCdcClients.xlsx\"");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:j0Urdfv7O9bdAJXaaI7KMipHr7+nStDnrETvYg==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                            log4jParamters_tFileInputExcel_6.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_6 - "  + (log4jParamters_tFileInputExcel_6) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_6", "tFileInputExcel_6<br> clients CDC", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_6 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ulRuCw+uNj7oTxoL3WCK5KKxCF0yUeAffJaW/g==");
        String password_tFileInputExcel_6 = decryptedPassword_tFileInputExcel_6;
        if (password_tFileInputExcel_6.isEmpty()){
            password_tFileInputExcel_6 = null;
        }
			class RegexUtil_tFileInputExcel_6 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_6 regexUtil_tFileInputExcel_6 = new RegexUtil_tFileInputExcel_6();

		Object source_tFileInputExcel_6 = context.Server_In + "MagistorCdcClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_6 = null;
		
		if(source_tFileInputExcel_6 instanceof String){
			workbook_tFileInputExcel_6 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_6), password_tFileInputExcel_6, true);
		} else if(source_tFileInputExcel_6 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_6 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_6, password_tFileInputExcel_6);
		} else{
			workbook_tFileInputExcel_6 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_6 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_6.addAll(regexUtil_tFileInputExcel_6.getSheets(workbook_tFileInputExcel_6, "Clients", false));
    	if(sheetList_tFileInputExcel_6.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_6 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_6 : sheetList_tFileInputExcel_6) {
			if(sheet_FilterNull_tFileInputExcel_6!=null && sheetList_FilterNull_tFileInputExcel_6.iterator()!=null && sheet_FilterNull_tFileInputExcel_6.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_6.add(sheet_FilterNull_tFileInputExcel_6);
			}
		}
		sheetList_tFileInputExcel_6 = sheetList_FilterNull_tFileInputExcel_6;
		int nb_line_tFileInputExcel_6 = 0;
	if(sheetList_tFileInputExcel_6.size()>0){

        int begin_line_tFileInputExcel_6 = 1;

        int footer_input_tFileInputExcel_6 = 0;

        int end_line_tFileInputExcel_6=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_6:sheetList_tFileInputExcel_6){
			end_line_tFileInputExcel_6+=(sheet_tFileInputExcel_6.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_6 -= footer_input_tFileInputExcel_6;
        int limit_tFileInputExcel_6 = -1;
        int start_column_tFileInputExcel_6 = 1-1;
        int end_column_tFileInputExcel_6 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_6 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_6 = sheetList_tFileInputExcel_6.get(0);
        int rowCount_tFileInputExcel_6 = 0;
        int sheetIndex_tFileInputExcel_6 = 0;
        int currentRows_tFileInputExcel_6 = (sheetList_tFileInputExcel_6.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_6 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_6 = df_tFileInputExcel_6.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_6 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_6 = begin_line_tFileInputExcel_6; i_tFileInputExcel_6 < end_line_tFileInputExcel_6; i_tFileInputExcel_6++){

        	int emptyColumnCount_tFileInputExcel_6 = 0;

        	if (limit_tFileInputExcel_6 != -1 && nb_line_tFileInputExcel_6 >= limit_tFileInputExcel_6) {
        		break;
        	}

            while (i_tFileInputExcel_6 >= rowCount_tFileInputExcel_6 + currentRows_tFileInputExcel_6) {
                rowCount_tFileInputExcel_6 += currentRows_tFileInputExcel_6;
                sheet_tFileInputExcel_6 = sheetList_tFileInputExcel_6.get(++sheetIndex_tFileInputExcel_6);
                currentRows_tFileInputExcel_6 = (sheet_tFileInputExcel_6.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_6_CURRENT_SHEET",sheet_tFileInputExcel_6.getSheetName());
            if (rowCount_tFileInputExcel_6 <= i_tFileInputExcel_6) {
                row_tFileInputExcel_6 = sheet_tFileInputExcel_6.getRow(i_tFileInputExcel_6 - rowCount_tFileInputExcel_6);
            }
		    row48 = null;
					int tempRowLength_tFileInputExcel_6 = 1;
				
				int columnIndex_tFileInputExcel_6 = 0;
			
			String[] temp_row_tFileInputExcel_6 = new String[tempRowLength_tFileInputExcel_6];
			int excel_end_column_tFileInputExcel_6;
			if(row_tFileInputExcel_6==null){
				excel_end_column_tFileInputExcel_6=0;
			}else{
				excel_end_column_tFileInputExcel_6=row_tFileInputExcel_6.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_6;
			if(end_column_tFileInputExcel_6 == -1){
				actual_end_column_tFileInputExcel_6 = excel_end_column_tFileInputExcel_6;
			}
			else{
				actual_end_column_tFileInputExcel_6 = end_column_tFileInputExcel_6 >	excel_end_column_tFileInputExcel_6 ? excel_end_column_tFileInputExcel_6 : end_column_tFileInputExcel_6;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_6 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_6;i++){
				if(i + start_column_tFileInputExcel_6 < actual_end_column_tFileInputExcel_6){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_6 = row_tFileInputExcel_6.getCell(i + start_column_tFileInputExcel_6);
					if(cell_tFileInputExcel_6!=null){
					switch (cell_tFileInputExcel_6.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_6[i] = cell_tFileInputExcel_6.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_6)) {
									temp_row_tFileInputExcel_6[i] =cell_tFileInputExcel_6.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_6[i] = df_tFileInputExcel_6.format(cell_tFileInputExcel_6.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_6[i] =String.valueOf(cell_tFileInputExcel_6.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_6.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_6[i] = cell_tFileInputExcel_6.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_6)) {
											temp_row_tFileInputExcel_6[i] =cell_tFileInputExcel_6.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_6 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_6.getNumericCellValue());
										temp_row_tFileInputExcel_6[i] = ne_tFileInputExcel_6.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_6[i] =String.valueOf(cell_tFileInputExcel_6.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_6[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_6[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_6[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_6[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_6 = false;
			row48 = new row48Struct();
			int curColNum_tFileInputExcel_6 = -1;
			String curColName_tFileInputExcel_6 = "";
			try{
							columnIndex_tFileInputExcel_6 = 0;
						
			if( temp_row_tFileInputExcel_6[columnIndex_tFileInputExcel_6].trim().length() > 0) {
				curColNum_tFileInputExcel_6=columnIndex_tFileInputExcel_6 + start_column_tFileInputExcel_6 + 1;
				curColName_tFileInputExcel_6 = "Name";

				row48.Name = temp_row_tFileInputExcel_6[columnIndex_tFileInputExcel_6].trim();
			}else{
				row48.Name = null;
				emptyColumnCount_tFileInputExcel_6++;
			}

        if(emptyColumnCount_tFileInputExcel_6 >= 1){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_6++;
				
				log.debug("tFileInputExcel_6 - Retrieving the record " + (nb_line_tFileInputExcel_6) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_6_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_6 = true;
						log.error("tFileInputExcel_6 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row48 = null;
			}


		



 



/**
 * [tFileInputExcel_6 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_6 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		

 


	tos_count_tFileInputExcel_6++;

/**
 * [tFileInputExcel_6 main ] stop
 */
	
	/**
	 * [tFileInputExcel_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		

 



/**
 * [tFileInputExcel_6 process_data_begin ] stop
 */
// Start of branch "row48"
if(row48 != null) { 



	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row48","tFileInputExcel_6","tFileInputExcel_6<br> clients CDC","tFileInputExcel","tJavaRow_2","tJavaRow_2","tJavaRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row48 - " + (row48==null? "": row48.toLogString()));
    			}
    		

    String cdcClients = (String)globalMap.get("magistor_cdc_clients");
cdcClients += ("".equals(cdcClients) ? row48.Name : "," + row48.Name);
globalMap.put("magistor_cdc_clients", cdcClients);
System.out.println("Cdc : " + cdcClients);


    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */
	
	/**
	 * [tJavaRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tJavaRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 process_data_end ] stop
 */

} // End of branch "row48"




	
	/**
	 * [tFileInputExcel_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		

 



/**
 * [tFileInputExcel_6 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_6 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		

			}
			
			
				log.debug("tFileInputExcel_6 - Retrieved records count: "+ nb_line_tFileInputExcel_6 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_6_NB_LINE",nb_line_tFileInputExcel_6);
		} finally {
				
  				if(!(source_tFileInputExcel_6 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_6.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_6 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_6", true);
end_Hash.put("tFileInputExcel_6", System.currentTimeMillis());




/**
 * [tFileInputExcel_6 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row48",2,0,
			 			"tFileInputExcel_6","tFileInputExcel_6<br> clients CDC","tFileInputExcel","tJavaRow_2","tJavaRow_2","tJavaRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tFileInputExcel_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_6 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_6";
	
	
			cLabel="tFileInputExcel_6<br> clients CDC";
		

 



/**
 * [tFileInputExcel_6 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_6_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_1");
		org.slf4j.MDC.put("_subJobPid", "BF0WsB_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tFileList_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFlowToIterate_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
                    log4jParamters_tFlowToIterate_1.append("Parameters:");
                            log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                        log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
                    } 
                } 
            new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_1", "tFlowToIterate_1", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		
		int tos_count_tFileInputExcel_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
                    log4jParamters_tFileInputExcel_1.append("Parameters:");
                            log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FILENAME" + " = " + "context.Server_In + \"MagistorClients.xlsx\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:TFAWb2GlKsWQDPC0ejoFiIZGscDo0KjycQwYWQ==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + (log4jParamters_tFileInputExcel_1) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_1", "tFileInputExcel_1<br> vider clients magistor", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:coI0tUJuxvncTTC38rUZyy2W03whVgCgS61wvA==");
        String password_tFileInputExcel_1 = decryptedPassword_tFileInputExcel_1;
        if (password_tFileInputExcel_1.isEmpty()){
            password_tFileInputExcel_1 = null;
        }
			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();

		Object source_tFileInputExcel_1 = context.Server_In + "MagistorClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_1 = null;
		
		if(source_tFileInputExcel_1 instanceof String){
			workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_1), password_tFileInputExcel_1, true);
		} else if(source_tFileInputExcel_1 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_1 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_1, password_tFileInputExcel_1);
		} else{
			workbook_tFileInputExcel_1 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_1.addAll(regexUtil_tFileInputExcel_1.getSheets(workbook_tFileInputExcel_1, "Clients", false));
    	if(sheetList_tFileInputExcel_1.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
			if(sheet_FilterNull_tFileInputExcel_1!=null && sheetList_FilterNull_tFileInputExcel_1.iterator()!=null && sheet_FilterNull_tFileInputExcel_1.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
			}
		}
		sheetList_tFileInputExcel_1 = sheetList_FilterNull_tFileInputExcel_1;
		int nb_line_tFileInputExcel_1 = 0;
	if(sheetList_tFileInputExcel_1.size()>0){

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
			end_line_tFileInputExcel_1+=(sheet_tFileInputExcel_1.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_1 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = (sheetList_tFileInputExcel_1.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = (sheet_tFileInputExcel_1.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getSheetName());
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
		    row9 = null;
					int tempRowLength_tFileInputExcel_1 = 1;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int excel_end_column_tFileInputExcel_1;
			if(row_tFileInputExcel_1==null){
				excel_end_column_tFileInputExcel_1=0;
			}else{
				excel_end_column_tFileInputExcel_1=row_tFileInputExcel_1.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_1;
			if(end_column_tFileInputExcel_1 == -1){
				actual_end_column_tFileInputExcel_1 = excel_end_column_tFileInputExcel_1;
			}
			else{
				actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	excel_end_column_tFileInputExcel_1 ? excel_end_column_tFileInputExcel_1 : end_column_tFileInputExcel_1;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_1 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){
				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1.getCell(i + start_column_tFileInputExcel_1);
					if(cell_tFileInputExcel_1!=null){
					switch (cell_tFileInputExcel_1.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
									temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_1[i] = df_tFileInputExcel_1.format(cell_tFileInputExcel_1.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_1.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_1)) {
											temp_row_tFileInputExcel_1[i] =cell_tFileInputExcel_1.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_1 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_1.getNumericCellValue());
										temp_row_tFileInputExcel_1[i] = ne_tFileInputExcel_1.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_1[i] =String.valueOf(cell_tFileInputExcel_1.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_1[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_1[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_1[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_1 = false;
			row9 = new row9Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try{
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim().length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Name";

				row9.Name = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].trim();
			}else{
				row9.Name = null;
				emptyColumnCount_tFileInputExcel_1++;
			}

        if(emptyColumnCount_tFileInputExcel_1 >= 1){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_1++;
				
				log.debug("tFileInputExcel_1 - Retrieving the record " + (nb_line_tFileInputExcel_1) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_1 = true;
						log.error("tFileInputExcel_1 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row9 = null;
			}


		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tFileInputExcel_1","tFileInputExcel_1<br> vider clients magistor","tFileInputExcel","tFlowToIterate_1","tFlowToIterate_1","tFlowToIterate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row9.Name, value=")  + (row9.Name)  + (".") );            
            globalMap.put("row9.Name", row9.Name);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	
	/**
	 * [tFlowToIterate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";
	
	

 



/**
 * [tFlowToIterate_1 process_data_begin ] stop
 */
	NB_ITERATE_tFileList_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate8", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tFileList_2);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileList_2 begin ] start
	 */

				
			int NB_ITERATE_tFileDelete_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFileList_2", false);
		start_Hash.put("tFileList_2", System.currentTimeMillis());
		
	
	currentComponent="tFileList_2";
	
	
		int tos_count_tFileList_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileList_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileList_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileList_2 = new StringBuilder();
                    log4jParamters_tFileList_2.append("Parameters:");
                            log4jParamters_tFileList_2.append("DIRECTORY" + " = " + "context.Server_In + \"Magistor/\" + ((String)globalMap.get(\"row9.Name\"))");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("LIST_MODE" + " = " + "FILES");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("INCLUDSUBDIR" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("CASE_SENSITIVE" + " = " + "YES");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ERROR" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("GLOBEXPRESSIONS" + " = " + "true");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("FILES" + " = " + "[{FILEMASK="+("context.Art_masque + \"_\" + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Cdc_masque + \"_\" + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Drc_masque + \"_\" + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Art_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Cdc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Drc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_BY_NOTHING" + " = " + "true");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_BY_FILENAME" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_BY_FILESIZE" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_BY_MODIFIEDDATE" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_ACTION_ASC" + " = " + "true");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("ORDER_ACTION_DESC" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("IFEXCLUDE" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                            log4jParamters_tFileList_2.append("FORMAT_FILEPATH_TO_SLASH" + " = " + "false");
                        log4jParamters_tFileList_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileList_2 - "  + (log4jParamters_tFileList_2) );
                    } 
                } 
            new BytesLimit65535_tFileList_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileList_2", "tFileList_1", "tFileList");
				talendJobLogProcess(globalMap);
			}
			
	
 
  
				final StringBuffer log4jSb_tFileList_2 = new StringBuffer();
			   
    
  String directory_tFileList_2 = context.Server_In + "Magistor/" + ((String)globalMap.get("row9.Name"));
  final java.util.List<String> maskList_tFileList_2 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_tFileList_2 = new java.util.ArrayList<java.util.regex.Pattern>(); 
    maskList_tFileList_2.add(context.Art_masque + "_" + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_2.add(context.Cdc_masque + "_" + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_2.add(context.Drc_masque + "_" + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_2.add(context.Art_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_2.add(context.Cdc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_2.add(context.Drc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque);  
  for (final String filemask_tFileList_2 : maskList_tFileList_2) {
	String filemask_compile_tFileList_2 = filemask_tFileList_2;
	
		filemask_compile_tFileList_2 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_tFileList_2.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_tFileList_2 = java.util.regex.Pattern.compile(filemask_compile_tFileList_2);
	patternList_tFileList_2.add(fileNamePattern_tFileList_2);
  }
  int NB_FILEtFileList_2 = 0;

  final boolean case_sensitive_tFileList_2 = true;
	
	
		log.info("tFileList_2 - Starting to search for matching entries.");
	
	
    final java.util.List<java.io.File> list_tFileList_2 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_tFileList_2 = new java.util.HashSet<String>();
	java.io.File file_tFileList_2 = new java.io.File(directory_tFileList_2);
     
		file_tFileList_2.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
                if (!file.isDirectory()) {
                	
    	String fileName_tFileList_2 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_tFileList_2 : patternList_tFileList_2) {
          	if (fileNamePattern_tFileList_2.matcher(fileName_tFileList_2).matches()){
					if(!filePath_tFileList_2.contains(file.getAbsolutePath())) {
			          list_tFileList_2.add(file);
			          filePath_tFileList_2.add(file.getAbsolutePath());
			        }
			}
		}
                }
              return true;
            }
          }
      ); 
      java.util.Collections.sort(list_tFileList_2);
    
		log.info("tFileList_2 - Start to list files.");
	
    for (int i_tFileList_2 = 0; i_tFileList_2 < list_tFileList_2.size(); i_tFileList_2++){
      java.io.File files_tFileList_2 = list_tFileList_2.get(i_tFileList_2);
      String fileName_tFileList_2 = files_tFileList_2.getName();
      
      String currentFileName_tFileList_2 = files_tFileList_2.getName(); 
      String currentFilePath_tFileList_2 = files_tFileList_2.getAbsolutePath();
      String currentFileDirectory_tFileList_2 = files_tFileList_2.getParent();
      String currentFileExtension_tFileList_2 = null;
      
      if (files_tFileList_2.getName().contains(".") && files_tFileList_2.isFile()){
        currentFileExtension_tFileList_2 = files_tFileList_2.getName().substring(files_tFileList_2.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_tFileList_2 = "";
      }
      
      NB_FILEtFileList_2 ++;
      globalMap.put("tFileList_2_CURRENT_FILE", currentFileName_tFileList_2);
      globalMap.put("tFileList_2_CURRENT_FILEPATH", currentFilePath_tFileList_2);
      globalMap.put("tFileList_2_CURRENT_FILEDIRECTORY", currentFileDirectory_tFileList_2);
      globalMap.put("tFileList_2_CURRENT_FILEEXTENSION", currentFileExtension_tFileList_2);
      globalMap.put("tFileList_2_NB_FILE", NB_FILEtFileList_2);
      
		log.info("tFileList_2 - Current file or directory path : " + currentFilePath_tFileList_2);
	  
 



/**
 * [tFileList_2 begin ] stop
 */
	
	/**
	 * [tFileList_2 main ] start
	 */

	

	
	
	currentComponent="tFileList_2";
	
	

 


	tos_count_tFileList_2++;

/**
 * [tFileList_2 main ] stop
 */
	
	/**
	 * [tFileList_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileList_2";
	
	

 



/**
 * [tFileList_2 process_data_begin ] stop
 */
	NB_ITERATE_tFileDelete_2++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate8", 1, "exec" + NB_ITERATE_tFileDelete_2);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileDelete_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_2", false);
		start_Hash.put("tFileDelete_2", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_2";
	
	
		int tos_count_tFileDelete_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileDelete_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileDelete_2 = new StringBuilder();
                    log4jParamters_tFileDelete_2.append("Parameters:");
                            log4jParamters_tFileDelete_2.append("FILENAME" + " = " + "((String)globalMap.get(\"tFileList_2_CURRENT_FILEPATH\"))");
                        log4jParamters_tFileDelete_2.append(" | ");
                            log4jParamters_tFileDelete_2.append("FAILON" + " = " + "true");
                        log4jParamters_tFileDelete_2.append(" | ");
                            log4jParamters_tFileDelete_2.append("FOLDER" + " = " + "false");
                        log4jParamters_tFileDelete_2.append(" | ");
                            log4jParamters_tFileDelete_2.append("FOLDER_FILE" + " = " + "false");
                        log4jParamters_tFileDelete_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + (log4jParamters_tFileDelete_2) );
                    } 
                } 
            new BytesLimit65535_tFileDelete_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileDelete_2", "tFileDelete_1", "tFileDelete");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tFileDelete_2 begin ] stop
 */
	
	/**
	 * [tFileDelete_2 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";
	
	

 

				final StringBuffer log4jSb_tFileDelete_2 = new StringBuffer();
			
class DeleteFoldertFileDelete_2{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_2=new java.io.File(((String)globalMap.get("tFileList_2_CURRENT_FILEPATH")));
    if(file_tFileDelete_2.exists()&& file_tFileDelete_2.isFile()){
    	if(file_tFileDelete_2.delete()){
    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_2 - File : "+ file_tFileDelete_2.getAbsolutePath() + " is deleted.");
		}else{
			globalMap.put("tFileDelete_2_CURRENT_STATUS", "No file deleted.");
				throw new RuntimeException("File " + file_tFileDelete_2.getAbsolutePath() + " can not be deleted.");
		}
	}else{
		globalMap.put("tFileDelete_2_CURRENT_STATUS", "File does not exist or is invalid.");
			throw new RuntimeException("File " + file_tFileDelete_2.getAbsolutePath() + " does not exist or is invalid or is not a file.");
	}
	globalMap.put("tFileDelete_2_DELETE_PATH",((String)globalMap.get("tFileList_2_CURRENT_FILEPATH")));
 


	tos_count_tFileDelete_2++;

/**
 * [tFileDelete_2 main ] stop
 */
	
	/**
	 * [tFileDelete_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";
	
	

 



/**
 * [tFileDelete_2 process_data_begin ] stop
 */
	
	/**
	 * [tFileDelete_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";
	
	

 



/**
 * [tFileDelete_2 process_data_end ] stop
 */
	
	/**
	 * [tFileDelete_2 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + ("Done.") );

ok_Hash.put("tFileDelete_2", true);
end_Hash.put("tFileDelete_2", System.currentTimeMillis());




/**
 * [tFileDelete_2 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate8", 2, "exec" + NB_ITERATE_tFileDelete_2);
						}				
					




	
	/**
	 * [tFileList_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileList_2";
	
	

 



/**
 * [tFileList_2 process_data_end ] stop
 */
	
	/**
	 * [tFileList_2 end ] start
	 */

	

	
	
	currentComponent="tFileList_2";
	
	

  
    }
  globalMap.put("tFileList_2_NB_FILE", NB_FILEtFileList_2);
  
    log.info("tFileList_2 - File or directory count : " + NB_FILEtFileList_2);

  
 

 
                if(log.isDebugEnabled())
            log.debug("tFileList_2 - "  + ("Done.") );

ok_Hash.put("tFileList_2", true);
end_Hash.put("tFileList_2", System.currentTimeMillis());




/**
 * [tFileList_2 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tFileList_2);
						}				
					




	
	/**
	 * [tFlowToIterate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";
	
	

 



/**
 * [tFlowToIterate_1 process_data_end ] stop
 */

} // End of branch "row9"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		

			}
			
			
				log.debug("tFileInputExcel_1 - Retrieved records count: "+ nb_line_tFileInputExcel_1 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
		} finally {
				
  				if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_1.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";
	
	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tFileInputExcel_1","tFileInputExcel_1<br> vider clients magistor","tFileInputExcel","tFlowToIterate_1","tFlowToIterate_1","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tFileInputExcel_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";
	
	
			cLabel="tFileInputExcel_1<br> vider clients magistor";
		

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";
	
	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tFileList_2 finally ] start
	 */

	

	
	
	currentComponent="tFileList_2";
	
	

 



/**
 * [tFileList_2 finally ] stop
 */

	
	/**
	 * [tFileDelete_2 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";
	
	

 



/**
 * [tFileDelete_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	


public static class distantClientsNamesStruct implements routines.system.IPersistableRow<distantClientsNamesStruct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(distantClientsNamesStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_3");
		org.slf4j.MDC.put("_subJobPid", "7RGGYM_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
distantClientsNamesStruct distantClientsNames = new distantClientsNamesStruct();





	
	/**
	 * [tFlowToIterate_4 begin ] start
	 */

				
			int NB_ITERATE_tFTPFileList_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_4", false);
		start_Hash.put("tFlowToIterate_4", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"distantClientsNames");
			
		int tos_count_tFlowToIterate_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFlowToIterate_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFlowToIterate_4 = new StringBuilder();
                    log4jParamters_tFlowToIterate_4.append("Parameters:");
                            log4jParamters_tFlowToIterate_4.append("DEFAULT_MAP" + " = " + "true");
                        log4jParamters_tFlowToIterate_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + (log4jParamters_tFlowToIterate_4) );
                    } 
                } 
            new BytesLimit65535_tFlowToIterate_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_4", "tFlowToIterate_2", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_4 = 0;
int counter_tFlowToIterate_4 = 0;

 



/**
 * [tFlowToIterate_4 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row1_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_distantClientsNames_tMap_1 = 0;
				
distantClientsNamesStruct distantClientsNames_tmp = new distantClientsNamesStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_3", false);
		start_Hash.put("tFileInputExcel_3", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		
		int tos_count_tFileInputExcel_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_3 = new StringBuilder();
                    log4jParamters_tFileInputExcel_3.append("Parameters:");
                            log4jParamters_tFileInputExcel_3.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("FILENAME" + " = " + "context.Server_In + \"MagistorClients.xlsx\"");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:1S/nJm13Ss8hpbyVOUBnwBZUaVz6eLOgue0pGw==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                            log4jParamters_tFileInputExcel_3.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_3 - "  + (log4jParamters_tFileInputExcel_3) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_3", "tFileInputExcel_3<br>mise a jour local MC", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:Hwn7w4j9Q8VcnejrBhQAOvmXwZdN3mnZJ1zcgQ==");
        String password_tFileInputExcel_3 = decryptedPassword_tFileInputExcel_3;
        if (password_tFileInputExcel_3.isEmpty()){
            password_tFileInputExcel_3 = null;
        }
			class RegexUtil_tFileInputExcel_3 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_3 regexUtil_tFileInputExcel_3 = new RegexUtil_tFileInputExcel_3();

		Object source_tFileInputExcel_3 = context.Server_In + "MagistorClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_3 = null;
		
		if(source_tFileInputExcel_3 instanceof String){
			workbook_tFileInputExcel_3 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_3), password_tFileInputExcel_3, true);
		} else if(source_tFileInputExcel_3 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_3 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_3, password_tFileInputExcel_3);
		} else{
			workbook_tFileInputExcel_3 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_3 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_3.addAll(regexUtil_tFileInputExcel_3.getSheets(workbook_tFileInputExcel_3, "Clients", false));
    	if(sheetList_tFileInputExcel_3.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_3 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_3 : sheetList_tFileInputExcel_3) {
			if(sheet_FilterNull_tFileInputExcel_3!=null && sheetList_FilterNull_tFileInputExcel_3.iterator()!=null && sheet_FilterNull_tFileInputExcel_3.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_3.add(sheet_FilterNull_tFileInputExcel_3);
			}
		}
		sheetList_tFileInputExcel_3 = sheetList_FilterNull_tFileInputExcel_3;
		int nb_line_tFileInputExcel_3 = 0;
	if(sheetList_tFileInputExcel_3.size()>0){

        int begin_line_tFileInputExcel_3 = 1;

        int footer_input_tFileInputExcel_3 = 0;

        int end_line_tFileInputExcel_3=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_3:sheetList_tFileInputExcel_3){
			end_line_tFileInputExcel_3+=(sheet_tFileInputExcel_3.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_3 -= footer_input_tFileInputExcel_3;
        int limit_tFileInputExcel_3 = -1;
        int start_column_tFileInputExcel_3 = 1-1;
        int end_column_tFileInputExcel_3 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_3 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_3 = sheetList_tFileInputExcel_3.get(0);
        int rowCount_tFileInputExcel_3 = 0;
        int sheetIndex_tFileInputExcel_3 = 0;
        int currentRows_tFileInputExcel_3 = (sheetList_tFileInputExcel_3.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_3 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_3 = df_tFileInputExcel_3.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_3 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_3 = begin_line_tFileInputExcel_3; i_tFileInputExcel_3 < end_line_tFileInputExcel_3; i_tFileInputExcel_3++){

        	int emptyColumnCount_tFileInputExcel_3 = 0;

        	if (limit_tFileInputExcel_3 != -1 && nb_line_tFileInputExcel_3 >= limit_tFileInputExcel_3) {
        		break;
        	}

            while (i_tFileInputExcel_3 >= rowCount_tFileInputExcel_3 + currentRows_tFileInputExcel_3) {
                rowCount_tFileInputExcel_3 += currentRows_tFileInputExcel_3;
                sheet_tFileInputExcel_3 = sheetList_tFileInputExcel_3.get(++sheetIndex_tFileInputExcel_3);
                currentRows_tFileInputExcel_3 = (sheet_tFileInputExcel_3.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_3_CURRENT_SHEET",sheet_tFileInputExcel_3.getSheetName());
            if (rowCount_tFileInputExcel_3 <= i_tFileInputExcel_3) {
                row_tFileInputExcel_3 = sheet_tFileInputExcel_3.getRow(i_tFileInputExcel_3 - rowCount_tFileInputExcel_3);
            }
		    row1 = null;
					int tempRowLength_tFileInputExcel_3 = 1;
				
				int columnIndex_tFileInputExcel_3 = 0;
			
			String[] temp_row_tFileInputExcel_3 = new String[tempRowLength_tFileInputExcel_3];
			int excel_end_column_tFileInputExcel_3;
			if(row_tFileInputExcel_3==null){
				excel_end_column_tFileInputExcel_3=0;
			}else{
				excel_end_column_tFileInputExcel_3=row_tFileInputExcel_3.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_3;
			if(end_column_tFileInputExcel_3 == -1){
				actual_end_column_tFileInputExcel_3 = excel_end_column_tFileInputExcel_3;
			}
			else{
				actual_end_column_tFileInputExcel_3 = end_column_tFileInputExcel_3 >	excel_end_column_tFileInputExcel_3 ? excel_end_column_tFileInputExcel_3 : end_column_tFileInputExcel_3;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_3 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_3;i++){
				if(i + start_column_tFileInputExcel_3 < actual_end_column_tFileInputExcel_3){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_3 = row_tFileInputExcel_3.getCell(i + start_column_tFileInputExcel_3);
					if(cell_tFileInputExcel_3!=null){
					switch (cell_tFileInputExcel_3.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_3[i] = cell_tFileInputExcel_3.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_3)) {
									temp_row_tFileInputExcel_3[i] =cell_tFileInputExcel_3.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_3[i] = df_tFileInputExcel_3.format(cell_tFileInputExcel_3.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_3[i] =String.valueOf(cell_tFileInputExcel_3.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_3.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_3[i] = cell_tFileInputExcel_3.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_3)) {
											temp_row_tFileInputExcel_3[i] =cell_tFileInputExcel_3.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_3 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_3.getNumericCellValue());
										temp_row_tFileInputExcel_3[i] = ne_tFileInputExcel_3.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_3[i] =String.valueOf(cell_tFileInputExcel_3.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_3[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_3[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_3[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_3[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_3 = false;
			row1 = new row1Struct();
			int curColNum_tFileInputExcel_3 = -1;
			String curColName_tFileInputExcel_3 = "";
			try{
							columnIndex_tFileInputExcel_3 = 0;
						
			if( temp_row_tFileInputExcel_3[columnIndex_tFileInputExcel_3].trim().length() > 0) {
				curColNum_tFileInputExcel_3=columnIndex_tFileInputExcel_3 + start_column_tFileInputExcel_3 + 1;
				curColName_tFileInputExcel_3 = "Name";

				row1.Name = temp_row_tFileInputExcel_3[columnIndex_tFileInputExcel_3].trim();
			}else{
				row1.Name = null;
				emptyColumnCount_tFileInputExcel_3++;
			}

        if(emptyColumnCount_tFileInputExcel_3 >= 1){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_3++;
				
				log.debug("tFileInputExcel_3 - Retrieving the record " + (nb_line_tFileInputExcel_3) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_3_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_3 = true;
						log.error("tFileInputExcel_3 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row1 = null;
			}


		



 



/**
 * [tFileInputExcel_3 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_3 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		

 


	tos_count_tFileInputExcel_3++;

/**
 * [tFileInputExcel_3 main ] stop
 */
	
	/**
	 * [tFileInputExcel_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		

 



/**
 * [tFileInputExcel_3 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tFileInputExcel_3","tFileInputExcel_3<br>mise a jour local MC","tFileInputExcel","tMap_1","tMap_1","tMap"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

distantClientsNames = null;


// # Output table : 'distantClientsNames'
count_distantClientsNames_tMap_1++;

distantClientsNames_tmp.Name = row1.Name;
distantClientsNames = distantClientsNames_tmp;
log.debug("tMap_1 - Outputting the record " + count_distantClientsNames_tMap_1 + " of the output table 'distantClientsNames'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "distantClientsNames"
if(distantClientsNames != null) { 



	
	/**
	 * [tFlowToIterate_4 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"distantClientsNames","tMap_1","tMap_1","tMap","tFlowToIterate_4","tFlowToIterate_2","tFlowToIterate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("distantClientsNames - " + (distantClientsNames==null? "": distantClientsNames.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=distantClientsNames.Name, value=")  + (distantClientsNames.Name)  + (".") );            
            globalMap.put("distantClientsNames.Name", distantClientsNames.Name);
    	
 
	   nb_line_tFlowToIterate_4++;  
       counter_tFlowToIterate_4++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_4)  + (".") );
       globalMap.put("tFlowToIterate_4_CURRENT_ITERATION", counter_tFlowToIterate_4);
 


	tos_count_tFlowToIterate_4++;

/**
 * [tFlowToIterate_4 main ] stop
 */
	
	/**
	 * [tFlowToIterate_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";
	
	

 



/**
 * [tFlowToIterate_4 process_data_begin ] stop
 */
	NB_ITERATE_tFTPFileList_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate11", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate10", 1, "exec" + NB_ITERATE_tFTPFileList_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFTPFileList_1 begin ] start
	 */

				
			int NB_ITERATE_tFTPGet_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFTPFileList_1", false);
		start_Hash.put("tFTPFileList_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPFileList_1";
	
	
		int tos_count_tFTPFileList_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPFileList_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPFileList_1 = new StringBuilder();
                    log4jParamters_tFTPFileList_1.append("Parameters:");
                            log4jParamters_tFTPFileList_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("CONNECTION" + " = " + "tFTPConnection_1");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("REMOTEDIR" + " = " + "context.Distant_Magistor_Clients_Input+ ((String)globalMap.get(\"distantClientsNames.Name\")) + \"/IN\"");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("MOVE_TO_THE_CURRENT_DIRECTORY" + " = " + "false");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("DIR_FULL" + " = " + "false");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("FILES" + " = " + "[{FILEMASK="+("context.Art_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Cdc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Drc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFTPFileList_1.append(" | ");
                            log4jParamters_tFTPFileList_1.append("IGNORE_FAILURE_AT_QUIT" + " = " + "false");
                        log4jParamters_tFTPFileList_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_1 - "  + (log4jParamters_tFTPFileList_1) );
                    } 
                } 
            new BytesLimit65535_tFTPFileList_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPFileList_1", "tFTPFileList_1", "tFTPFileList");
				talendJobLogProcess(globalMap);
			}
			

 
	java.util.List<String> maskList_tFTPFileList_1 = new java.util.ArrayList<String>();
 
		maskList_tFTPFileList_1.add(context.Art_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque);  
		maskList_tFTPFileList_1.add(context.Cdc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque);  
		maskList_tFTPFileList_1.add(context.Drc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
        org.apache.commons.net.ftp.FTPClient ftp_tFTPFileList_1 = null;
            ftp_tFTPFileList_1 = (org.apache.commons.net.ftp.FTPClient) globalMap.get("conn_tFTPConnection_1");
                if(ftp_tFTPFileList_1!=null) {
                    log.info("tFTPFileList_1 - Use an existing connection. Connection hostname: " +  ftp_tFTPFileList_1.getRemoteAddress().toString() + ", Connection port: " + ftp_tFTPFileList_1.getRemotePort() + ".");
                } 
    int nb_file_tFTPFileList_1 = 0;
    org.apache.commons.net.ftp.FTPFile[] ftpFiles_tFTPFileList_1 = null;
    String rootDir_tFTPFileList_1 = ftp_tFTPFileList_1.printWorkingDirectory();
    List<org.apache.commons.net.ftp.FTPFile> fileListTemp_tFTPFileList_1 = new java.util.ArrayList<>();

    String remotedir_tFTPFileList_1 = (context.Distant_Magistor_Clients_Input+ ((String)globalMap.get("distantClientsNames.Name")) + "/IN").replaceAll("\\\\","/");
    boolean cwdSuccess_tFTPFileList_1 = ftp_tFTPFileList_1.changeWorkingDirectory(remotedir_tFTPFileList_1);

    if (!cwdSuccess_tFTPFileList_1) {
        throw new RuntimeException("Failed to change remote directory. " + ftp_tFTPFileList_1.getReplyString());
    }

    ftpFiles_tFTPFileList_1 = ftp_tFTPFileList_1.listFiles();
	
	String[] nameLists_tFTPFileList_1 = ftp_tFTPFileList_1.listNames();
	List<String> nameListsTemp_tFTPFileList_1 = new java.util.ArrayList<>();
	
	


    ftp_tFTPFileList_1.changeWorkingDirectory(rootDir_tFTPFileList_1);
    for (String filemask_tFTPFileList_1 : maskList_tFTPFileList_1) {
        java.util.regex.Pattern fileNamePattern_tFTPFileList_1 = java.util.regex.Pattern.compile(filemask_tFTPFileList_1.replaceAll("\\.", "\\\\.").replaceAll("\\*", ".*"));
	
        if(nameLists_tFTPFileList_1 != null){
            for (String ftpFile_tFTPFileList_1 : nameLists_tFTPFileList_1) {
                if (fileNamePattern_tFTPFileList_1.matcher(ftpFile_tFTPFileList_1).matches()) {
                    nameListsTemp_tFTPFileList_1.add(ftpFile_tFTPFileList_1);
                }
            }
        }
    }

    String currentFilePath_tFTPFileList_1 = remotedir_tFTPFileList_1;
    if(!remotedir_tFTPFileList_1.endsWith("/")&&!remotedir_tFTPFileList_1.endsWith("\\")){
        currentFilePath_tFTPFileList_1 += "/";
    }
    for (String ftpFile_tFTPFileList_1 : nameListsTemp_tFTPFileList_1) {
        String currentFileName_tFTPFileList_1 = ftpFile_tFTPFileList_1;

            log.debug("tFTPFileList_1 - List file : '" + currentFilePath_tFTPFileList_1 + "' ."); 
        globalMap.put("tFTPFileList_1_CURRENT_FILE", currentFileName_tFTPFileList_1);
		
        globalMap.put("tFTPFileList_1_CURRENT_FILEPATH", currentFilePath_tFTPFileList_1 + currentFileName_tFTPFileList_1);

        nb_file_tFTPFileList_1++;

 



/**
 * [tFTPFileList_1 begin ] stop
 */
	
	/**
	 * [tFTPFileList_1 main ] start
	 */

	

	
	
	currentComponent="tFTPFileList_1";
	
	

 


	tos_count_tFTPFileList_1++;

/**
 * [tFTPFileList_1 main ] stop
 */
	
	/**
	 * [tFTPFileList_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPFileList_1";
	
	

 



/**
 * [tFTPFileList_1 process_data_begin ] stop
 */
	NB_ITERATE_tFTPGet_1++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate11", 1, "exec" + NB_ITERATE_tFTPGet_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFTPGet_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPGet_1", false);
		start_Hash.put("tFTPGet_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPGet_1";
	
	
		int tos_count_tFTPGet_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPGet_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPGet_1 = new StringBuilder();
                    log4jParamters_tFTPGet_1.append("Parameters:");
                            log4jParamters_tFTPGet_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("CONNECTION" + " = " + "tFTPConnection_1");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("LOCALDIR" + " = " + "context.Server_In +  \"Magistor/\" + ((String)globalMap.get(\"distantClientsNames.Name\"))");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("REMOTEDIR" + " = " + "context.Distant_Magistor_Clients_Input+ ((String)globalMap.get(\"distantClientsNames.Name\")) + \"/IN\"");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("MOVE_TO_THE_CURRENT_DIRECTORY" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("MODE" + " = " + "binary");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("OVERWRITE" + " = " + "always");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("APPEND" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("PERL5_REGEX" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("FILES" + " = " + "[{FILEMASK="+("((String)globalMap.get(\"tFTPFileList_1_CURRENT_FILE\"))")+"}]");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("IGNORE_FAILURE_AT_QUIT" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("PRINT_MESSAGE" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + (log4jParamters_tFTPGet_1) );
                    } 
                } 
            new BytesLimit65535_tFTPGet_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPGet_1", "tFTPGet_1", "tFTPGet");
				talendJobLogProcess(globalMap);
			}
			

 
int nb_file_tFTPGet_1 = 0;
    abstract class FTPGetter_tFTPGet_1 {
        protected org.apache.commons.net.ftp.FTPClient ftpClient = null;
        protected int count = 0;

        public void getAllFiles(String remoteDirectory, String localDirectory)
            throws IllegalStateException, IOException, java.io.FileNotFoundException {

            if(!chdir(remoteDirectory)){
                //change dir fail
                log.error("Change dir fail. Skip Directory: " + remoteDirectory);
                return;
            }
            String path = ftpClient.printWorkingDirectory();
            org.apache.commons.net.ftp.FTPFile[] ftpFiles = null;
            ftpFiles = ftpClient.listFiles();
            String[] nameLists = null;
            try {
                 nameLists = ftpClient.listNames();
            } catch (IOException e) {
                 e.printStackTrace();
            }
            if( nameLists!=null && (ftpFiles == null || ftpFiles.length == 0)){
            	//if the file is folder, catch the FTPException and recur
                for (String ftpFileName : nameLists){
                try{
                    downloadFile(localDirectory + "/" + ftpFileName,ftpFileName);
                } catch (IOException e) {
            		
            			log.warn("tFTPGet_1 - " + e.getMessage());
            		
                  	java.io.File localFile = new java.io.File(localDirectory + "/" + ftpFileName);

                    if (!localFile.exists()) {
                    	localFile.mkdir();
                    }
            	    getAllFiles(path + "/" + ftpFileName, localDirectory + "/" + ftpFileName);
                  	chdir(remoteDirectory);
            	}
            	}
            }else{
                for (org.apache.commons.net.ftp.FTPFile ftpFile : ftpFiles) {

                    if (ftpFile.isDirectory()) {

                        if ((!(".").equals(ftpFile.getName())) && (!("..").equals(ftpFile.getName()))) {
                            java.io.File localFile = new java.io.File(localDirectory + "/" + ftpFile.getName());

                            if (!localFile.exists()) {
                                localFile.mkdir();
                            }
                            getAllFiles(path + "/" + ftpFile.getName(), localDirectory + "/" + ftpFile.getName());
                            chdir(path);
                        }
                    } else if (!ftpFile.isSymbolicLink()) {
                        downloadFile(localDirectory + "/" + ftpFile.getName(),ftpFile.getName());
                    }
                }
            }
        }

        public void getFiles(String remoteDirectory, String localDirectory, String maskStr) 
            throws IllegalStateException, IOException, java.io.FileNotFoundException {

            chdir(remoteDirectory);
            String[] nameLists = ftpClient.listNames();
            if(nameLists != null){
                for (String fileName : nameLists) {
                    if (fileName.matches(maskStr)) {
                        downloadFile(localDirectory + "/" + fileName,fileName);
                    }
                }
            }
        }

        public boolean chdir(String path) throws IllegalStateException, IOException {
            if (!".".equals(path)) {
                return ftpClient.changeWorkingDirectory(path);
            }
            return true;
        }

        public String pwd() throws IllegalStateException, IOException {
            return ftpClient.printWorkingDirectory();
        }

        protected abstract void downloadFile(String localFileName, String remoteFileName)
            throws IllegalStateException, java.io.FileNotFoundException, IOException;
    }
        org.apache.commons.net.ftp.FTPClient ftp_tFTPGet_1 = null;
            ftp_tFTPGet_1 = (org.apache.commons.net.ftp.FTPClient) globalMap.get("conn_tFTPConnection_1");
			
				String rootDir_tFTPGet_1 = ftp_tFTPGet_1.printWorkingDirectory();
			
			
                if(ftp_tFTPGet_1!=null) {
                    log.info("tFTPGet_1 - Use an existing connection. Connection hostname: " +  ftp_tFTPGet_1.getRemoteAddress().toString() + ", Connection port: " + ftp_tFTPGet_1.getRemotePort() + ".");
                }
            ftp_tFTPGet_1.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
        final java.util.List<String> msg_tFTPGet_1 = new java.util.ArrayList<String>();
        FTPGetter_tFTPGet_1 getter_tFTPGet_1 = new FTPGetter_tFTPGet_1() {
            @Override
            protected void downloadFile(String localFileName, String remoteFileName)
            throws IllegalStateException, java.io.FileNotFoundException, IOException {
                java.io.File localFile = new java.io.File(localFileName);
                    downloadFileWithOverwrite(localFileName, remoteFileName);
            }
            
            private boolean downloadFileWithOverwrite(String localFileName, String remoteFileName)
                throws IllegalStateException, java.io.FileNotFoundException, IOException {
                try (java.io.FileOutputStream localFos = new java.io.FileOutputStream(localFileName)) {
                        boolean status = ftpClient.retrieveFile(remoteFileName, localFos);
                        if(status){
                                log.debug("tFTPGet_1 - Downloaded file " + (count +1) +  " : '" + remoteFileName + "' successfully.");
                            msg_tFTPGet_1.add("file [" + remoteFileName + "] downloaded successfully.");
                            globalMap.put("tFTPGet_1_CURRENT_STATUS", "File transfer OK.");
                            count++;
                        }
                        return status;
                    } catch (IOException e) {
                        globalMap.put("tFTPGet_1_ERROR_MESSAGE",e.getMessage());
                        msg_tFTPGet_1.add("file [" + remoteFileName + "] downloaded unsuccessfully.");
                        globalMap.put("tFTPGet_1_CURRENT_STATUS", "File transfer fail.");
                        throw e;
                    }
            }
        };
        getter_tFTPGet_1.ftpClient = ftp_tFTPGet_1;
    String remotedir_tFTPGet_1 = context.Distant_Magistor_Clients_Input+ ((String)globalMap.get("distantClientsNames.Name")) + "/IN";
    if (!".".equals(remotedir_tFTPGet_1)) {
        boolean cwdSuccess_tFTPGet_1 = ftp_tFTPGet_1.changeWorkingDirectory(remotedir_tFTPGet_1);

        if (!cwdSuccess_tFTPGet_1) {
            throw new RuntimeException("Failed to change remote directory. " + ftp_tFTPGet_1.getReplyString());
        }
	}
java.util.List<String> maskList_tFTPGet_1 = new java.util.ArrayList<String>();

  maskList_tFTPGet_1.add(((String)globalMap.get("tFTPFileList_1_CURRENT_FILE")));
String localdir_tFTPGet_1  = context.Server_In +  "Magistor/" + ((String)globalMap.get("distantClientsNames.Name"));  
//create folder if local direcotry (assigned by property) not exists
java.io.File dirHandle_tFTPGet_1 = new java.io.File(localdir_tFTPGet_1);

if (!dirHandle_tFTPGet_1.exists()) {
  dirHandle_tFTPGet_1.mkdirs();
}
String root_tFTPGet_1 = getter_tFTPGet_1.pwd();
if ("/".equals(root_tFTPGet_1)) {
	root_tFTPGet_1 = ".";
}

	log.info("tFTPGet_1 - Downloading files from the server.");
for (String maskStr_tFTPGet_1 : maskList_tFTPGet_1) { 

 



/**
 * [tFTPGet_1 begin ] stop
 */
	
	/**
	 * [tFTPGet_1 main ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

	try {
		globalMap.put("tFTPGet_1_CURRENT_STATUS", "No file transfered.");
		String dir_tFTPGet_1 = root_tFTPGet_1;
		
			String mask_tFTPGet_1 = maskStr_tFTPGet_1.replaceAll("\\\\", "/") ;
		
		int i_tFTPGet_1 = mask_tFTPGet_1.lastIndexOf('/'); 

		if (i_tFTPGet_1 != -1){
			dir_tFTPGet_1 = mask_tFTPGet_1.substring(0, i_tFTPGet_1); 
			mask_tFTPGet_1 = mask_tFTPGet_1.substring(i_tFTPGet_1+1);  
		}
  
		
			mask_tFTPGet_1 = org.apache.oro.text.GlobCompiler.globToPerl5(mask_tFTPGet_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
		
  
		if (dir_tFTPGet_1!=null && !"".equals(dir_tFTPGet_1)){
			if ((".*").equals(mask_tFTPGet_1)) {
				getter_tFTPGet_1.getAllFiles(dir_tFTPGet_1, localdir_tFTPGet_1);
			} else {
				getter_tFTPGet_1.getFiles(dir_tFTPGet_1, localdir_tFTPGet_1 ,mask_tFTPGet_1);
			}
		}
		getter_tFTPGet_1.chdir(root_tFTPGet_1);
	} catch(java.lang.Exception e) {
globalMap.put("tFTPGet_1_ERROR_MESSAGE",e.getMessage());
		
    		throw(e);
  		
	}

 


	tos_count_tFTPGet_1++;

/**
 * [tFTPGet_1 main ] stop
 */
	
	/**
	 * [tFTPGet_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPGet_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPGet_1 end ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	
}
nb_file_tFTPGet_1 = getter_tFTPGet_1.count;

	msg_tFTPGet_1.add(getter_tFTPGet_1.count + " files have been downloaded.");
	String[] msgAll_tFTPGet_1 = msg_tFTPGet_1.toArray(new String[0]);
	StringBuffer sb_tFTPGet_1 = new StringBuffer();

	if (msgAll_tFTPGet_1 != null) {
    	for (String item_tFTPGet_1 : msgAll_tFTPGet_1) {
			sb_tFTPGet_1.append(item_tFTPGet_1).append("\n");
    	}
	}
	globalMap.put("tFTPGet_1_TRANSFER_MESSAGES", sb_tFTPGet_1.toString());

	  		ftp_tFTPGet_1.changeWorkingDirectory(rootDir_tFTPGet_1);
	globalMap.put("tFTPGet_1_NB_FILE",nb_file_tFTPGet_1);
	log.info("tFTPGet_1 - Downloaded files count: " + nb_file_tFTPGet_1  + ".");


 
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + ("Done.") );

ok_Hash.put("tFTPGet_1", true);
end_Hash.put("tFTPGet_1", System.currentTimeMillis());




/**
 * [tFTPGet_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate11", 2, "exec" + NB_ITERATE_tFTPGet_1);
						}				
					




	
	/**
	 * [tFTPFileList_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPFileList_1";
	
	

 



/**
 * [tFTPFileList_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPFileList_1 end ] start
	 */

	

	
	
	currentComponent="tFTPFileList_1";
	
	
}
globalMap.put("tFTPFileList_1_NB_FILE",nb_file_tFTPFileList_1);

	log.info("tFTPFileList_1 - Listed files count: " + nb_file_tFTPFileList_1  + ".");
 
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_1 - "  + ("Done.") );

ok_Hash.put("tFTPFileList_1", true);
end_Hash.put("tFTPFileList_1", System.currentTimeMillis());




/**
 * [tFTPFileList_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate10", 2, "exec" + NB_ITERATE_tFTPFileList_1);
						}				
					




	
	/**
	 * [tFlowToIterate_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";
	
	

 



/**
 * [tFlowToIterate_4 process_data_end ] stop
 */

} // End of branch "distantClientsNames"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputExcel_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		

 



/**
 * [tFileInputExcel_3 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_3 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		

			}
			
			
				log.debug("tFileInputExcel_3 - Retrieved records count: "+ nb_line_tFileInputExcel_3 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_3_NB_LINE",nb_line_tFileInputExcel_3);
		} finally {
				
  				if(!(source_tFileInputExcel_3 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_3.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_3 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_3", true);
end_Hash.put("tFileInputExcel_3", System.currentTimeMillis());




/**
 * [tFileInputExcel_3 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'distantClientsNames': " + count_distantClientsNames_tMap_1 + ".");





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tFileInputExcel_3","tFileInputExcel_3<br>mise a jour local MC","tFileInputExcel","tMap_1","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_4 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";
	
	

globalMap.put("tFlowToIterate_4_NB_LINE",nb_line_tFlowToIterate_4);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"distantClientsNames",2,0,
			 			"tMap_1","tMap_1","tMap","tFlowToIterate_4","tFlowToIterate_2","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_4", true);
end_Hash.put("tFlowToIterate_4", System.currentTimeMillis());




/**
 * [tFlowToIterate_4 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tFileInputExcel_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_3 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_3";
	
	
			cLabel="tFileInputExcel_3<br>mise a jour local MC";
		

 



/**
 * [tFileInputExcel_3 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_4 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";
	
	

 



/**
 * [tFlowToIterate_4 finally ] stop
 */

	
	/**
	 * [tFTPFileList_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPFileList_1";
	
	

 



/**
 * [tFTPFileList_1 finally ] stop
 */

	
	/**
	 * [tFTPGet_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_3_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String Key;

				public String getKey () {
					return this.Key;
				}

				public Boolean KeyIsNullable(){
				    return true;
				}
				public Boolean KeyIsKey(){
				    return false;
				}
				public Integer KeyLength(){
				    return null;
				}
				public Integer KeyPrecision(){
				    return null;
				}
				public String KeyDefault(){
				
					return null;
				
				}
				public String KeyComment(){
				
				    return "";
				
				}
				public String KeyPattern(){
				
					return "";
				
				}
				public String KeyOriginalDbColumnName(){
				
					return "Key";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Key="+Key);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Key);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_7");
		org.slf4j.MDC.put("_subJobPid", "BiUj1X_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tFlowToIterate_5 begin ] start
	 */

				
			int NB_ITERATE_tFileList_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_5", false);
		start_Hash.put("tFlowToIterate_5", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_5";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tFlowToIterate_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFlowToIterate_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFlowToIterate_5 = new StringBuilder();
                    log4jParamters_tFlowToIterate_5.append("Parameters:");
                            log4jParamters_tFlowToIterate_5.append("DEFAULT_MAP" + " = " + "true");
                        log4jParamters_tFlowToIterate_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + (log4jParamters_tFlowToIterate_5) );
                    } 
                } 
            new BytesLimit65535_tFlowToIterate_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_5", "tFlowToIterate_5", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_5 = 0;
int counter_tFlowToIterate_5 = 0;

 



/**
 * [tFlowToIterate_5 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_7", false);
		start_Hash.put("tFileInputExcel_7", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		
		int tos_count_tFileInputExcel_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_7 = new StringBuilder();
                    log4jParamters_tFileInputExcel_7.append("Parameters:");
                            log4jParamters_tFileInputExcel_7.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("FILENAME" + " = " + "context.Server_In + \"MagistorClients.xlsx\"");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:1Z51tQQH6Y+VLw1DpTw7GMGy16zpo9Icps433w==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                            log4jParamters_tFileInputExcel_7.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_7 - "  + (log4jParamters_tFileInputExcel_7) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_7", "tFileInputExcel_7<br> mise a jour distant MC", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_7 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:NQ8yn4IhMvKKm+9/wkS8QvZgy6LsltuXAhPD+g==");
        String password_tFileInputExcel_7 = decryptedPassword_tFileInputExcel_7;
        if (password_tFileInputExcel_7.isEmpty()){
            password_tFileInputExcel_7 = null;
        }
			class RegexUtil_tFileInputExcel_7 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_7 regexUtil_tFileInputExcel_7 = new RegexUtil_tFileInputExcel_7();

		Object source_tFileInputExcel_7 = context.Server_In + "MagistorClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_7 = null;
		
		if(source_tFileInputExcel_7 instanceof String){
			workbook_tFileInputExcel_7 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_7), password_tFileInputExcel_7, true);
		} else if(source_tFileInputExcel_7 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_7 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_7, password_tFileInputExcel_7);
		} else{
			workbook_tFileInputExcel_7 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_7 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_7.addAll(regexUtil_tFileInputExcel_7.getSheets(workbook_tFileInputExcel_7, "Clients", false));
    	if(sheetList_tFileInputExcel_7.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_7 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_7 : sheetList_tFileInputExcel_7) {
			if(sheet_FilterNull_tFileInputExcel_7!=null && sheetList_FilterNull_tFileInputExcel_7.iterator()!=null && sheet_FilterNull_tFileInputExcel_7.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_7.add(sheet_FilterNull_tFileInputExcel_7);
			}
		}
		sheetList_tFileInputExcel_7 = sheetList_FilterNull_tFileInputExcel_7;
		int nb_line_tFileInputExcel_7 = 0;
	if(sheetList_tFileInputExcel_7.size()>0){

        int begin_line_tFileInputExcel_7 = 1;

        int footer_input_tFileInputExcel_7 = 0;

        int end_line_tFileInputExcel_7=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_7:sheetList_tFileInputExcel_7){
			end_line_tFileInputExcel_7+=(sheet_tFileInputExcel_7.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_7 -= footer_input_tFileInputExcel_7;
        int limit_tFileInputExcel_7 = -1;
        int start_column_tFileInputExcel_7 = 1-1;
        int end_column_tFileInputExcel_7 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_7 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_7 = sheetList_tFileInputExcel_7.get(0);
        int rowCount_tFileInputExcel_7 = 0;
        int sheetIndex_tFileInputExcel_7 = 0;
        int currentRows_tFileInputExcel_7 = (sheetList_tFileInputExcel_7.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_7 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_7 = df_tFileInputExcel_7.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_7 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_7 = begin_line_tFileInputExcel_7; i_tFileInputExcel_7 < end_line_tFileInputExcel_7; i_tFileInputExcel_7++){

        	int emptyColumnCount_tFileInputExcel_7 = 0;

        	if (limit_tFileInputExcel_7 != -1 && nb_line_tFileInputExcel_7 >= limit_tFileInputExcel_7) {
        		break;
        	}

            while (i_tFileInputExcel_7 >= rowCount_tFileInputExcel_7 + currentRows_tFileInputExcel_7) {
                rowCount_tFileInputExcel_7 += currentRows_tFileInputExcel_7;
                sheet_tFileInputExcel_7 = sheetList_tFileInputExcel_7.get(++sheetIndex_tFileInputExcel_7);
                currentRows_tFileInputExcel_7 = (sheet_tFileInputExcel_7.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_7_CURRENT_SHEET",sheet_tFileInputExcel_7.getSheetName());
            if (rowCount_tFileInputExcel_7 <= i_tFileInputExcel_7) {
                row_tFileInputExcel_7 = sheet_tFileInputExcel_7.getRow(i_tFileInputExcel_7 - rowCount_tFileInputExcel_7);
            }
		    row3 = null;
					int tempRowLength_tFileInputExcel_7 = 2;
				
				int columnIndex_tFileInputExcel_7 = 0;
			
			String[] temp_row_tFileInputExcel_7 = new String[tempRowLength_tFileInputExcel_7];
			int excel_end_column_tFileInputExcel_7;
			if(row_tFileInputExcel_7==null){
				excel_end_column_tFileInputExcel_7=0;
			}else{
				excel_end_column_tFileInputExcel_7=row_tFileInputExcel_7.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_7;
			if(end_column_tFileInputExcel_7 == -1){
				actual_end_column_tFileInputExcel_7 = excel_end_column_tFileInputExcel_7;
			}
			else{
				actual_end_column_tFileInputExcel_7 = end_column_tFileInputExcel_7 >	excel_end_column_tFileInputExcel_7 ? excel_end_column_tFileInputExcel_7 : end_column_tFileInputExcel_7;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_7 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_7;i++){
				if(i + start_column_tFileInputExcel_7 < actual_end_column_tFileInputExcel_7){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_7 = row_tFileInputExcel_7.getCell(i + start_column_tFileInputExcel_7);
					if(cell_tFileInputExcel_7!=null){
					switch (cell_tFileInputExcel_7.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_7[i] = cell_tFileInputExcel_7.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_7)) {
									temp_row_tFileInputExcel_7[i] =cell_tFileInputExcel_7.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_7[i] = df_tFileInputExcel_7.format(cell_tFileInputExcel_7.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_7[i] =String.valueOf(cell_tFileInputExcel_7.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_7.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_7[i] = cell_tFileInputExcel_7.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_7)) {
											temp_row_tFileInputExcel_7[i] =cell_tFileInputExcel_7.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_7 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_7.getNumericCellValue());
										temp_row_tFileInputExcel_7[i] = ne_tFileInputExcel_7.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_7[i] =String.valueOf(cell_tFileInputExcel_7.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_7[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_7[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_7[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_7[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_7 = false;
			row3 = new row3Struct();
			int curColNum_tFileInputExcel_7 = -1;
			String curColName_tFileInputExcel_7 = "";
			try{
							columnIndex_tFileInputExcel_7 = 0;
						
			if( temp_row_tFileInputExcel_7[columnIndex_tFileInputExcel_7].trim().length() > 0) {
				curColNum_tFileInputExcel_7=columnIndex_tFileInputExcel_7 + start_column_tFileInputExcel_7 + 1;
				curColName_tFileInputExcel_7 = "Name";

				row3.Name = temp_row_tFileInputExcel_7[columnIndex_tFileInputExcel_7].trim();
			}else{
				row3.Name = null;
				emptyColumnCount_tFileInputExcel_7++;
			}
							columnIndex_tFileInputExcel_7 = 1;
						
			if( temp_row_tFileInputExcel_7[columnIndex_tFileInputExcel_7].trim().length() > 0) {
				curColNum_tFileInputExcel_7=columnIndex_tFileInputExcel_7 + start_column_tFileInputExcel_7 + 1;
				curColName_tFileInputExcel_7 = "Key";

				row3.Key = temp_row_tFileInputExcel_7[columnIndex_tFileInputExcel_7].trim();
			}else{
				row3.Key = null;
				emptyColumnCount_tFileInputExcel_7++;
			}

        if(emptyColumnCount_tFileInputExcel_7 >= 2){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_7++;
				
				log.debug("tFileInputExcel_7 - Retrieving the record " + (nb_line_tFileInputExcel_7) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_7_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_7 = true;
						log.error("tFileInputExcel_7 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row3 = null;
			}


		



 



/**
 * [tFileInputExcel_7 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_7 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		

 


	tos_count_tFileInputExcel_7++;

/**
 * [tFileInputExcel_7 main ] stop
 */
	
	/**
	 * [tFileInputExcel_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		

 



/**
 * [tFileInputExcel_7 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tFlowToIterate_5 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tFileInputExcel_7","tFileInputExcel_7<br> mise a jour distant MC","tFileInputExcel","tFlowToIterate_5","tFlowToIterate_5","tFlowToIterate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row3.Name, value=")  + (row3.Name)  + (".") );            
            globalMap.put("row3.Name", row3.Name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row3.Key, value=")  + (row3.Key)  + (".") );            
            globalMap.put("row3.Key", row3.Key);
    	
 
	   nb_line_tFlowToIterate_5++;  
       counter_tFlowToIterate_5++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_5)  + (".") );
       globalMap.put("tFlowToIterate_5_CURRENT_ITERATION", counter_tFlowToIterate_5);
 


	tos_count_tFlowToIterate_5++;

/**
 * [tFlowToIterate_5 main ] stop
 */
	
	/**
	 * [tFlowToIterate_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";
	
	

 



/**
 * [tFlowToIterate_5 process_data_begin ] stop
 */
	NB_ITERATE_tFileList_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk2", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate14", 1, "exec" + NB_ITERATE_tFileList_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileList_1 begin ] start
	 */

				
			int NB_ITERATE_tJava_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFileList_1", false);
		start_Hash.put("tFileList_1", System.currentTimeMillis());
		
	
	currentComponent="tFileList_1";
	
	
		int tos_count_tFileList_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileList_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileList_1 = new StringBuilder();
                    log4jParamters_tFileList_1.append("Parameters:");
                            log4jParamters_tFileList_1.append("DIRECTORY" + " = " + "context.Server_In + \"Magistor/\" + ((String)globalMap.get(\"row3.Name\"))");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("LIST_MODE" + " = " + "FILES");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("INCLUDSUBDIR" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("CASE_SENSITIVE" + " = " + "YES");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ERROR" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("GLOBEXPRESSIONS" + " = " + "true");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("FILES" + " = " + "[{FILEMASK="+("context.Art_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Cdc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Drc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_BY_NOTHING" + " = " + "true");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_BY_FILENAME" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_BY_FILESIZE" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_BY_MODIFIEDDATE" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_ACTION_ASC" + " = " + "true");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("ORDER_ACTION_DESC" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("IFEXCLUDE" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                            log4jParamters_tFileList_1.append("FORMAT_FILEPATH_TO_SLASH" + " = " + "false");
                        log4jParamters_tFileList_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + (log4jParamters_tFileList_1) );
                    } 
                } 
            new BytesLimit65535_tFileList_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileList_1", "tFileList_1", "tFileList");
				talendJobLogProcess(globalMap);
			}
			
	
 
  
				final StringBuffer log4jSb_tFileList_1 = new StringBuffer();
			   
    
  String directory_tFileList_1 = context.Server_In + "Magistor/" + ((String)globalMap.get("row3.Name"));
  final java.util.List<String> maskList_tFileList_1 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_tFileList_1 = new java.util.ArrayList<java.util.regex.Pattern>(); 
    maskList_tFileList_1.add(context.Art_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_1.add(context.Cdc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_1.add(context.Drc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque);  
  for (final String filemask_tFileList_1 : maskList_tFileList_1) {
	String filemask_compile_tFileList_1 = filemask_tFileList_1;
	
		filemask_compile_tFileList_1 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_tFileList_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_tFileList_1 = java.util.regex.Pattern.compile(filemask_compile_tFileList_1);
	patternList_tFileList_1.add(fileNamePattern_tFileList_1);
  }
  int NB_FILEtFileList_1 = 0;

  final boolean case_sensitive_tFileList_1 = true;
	
	
		log.info("tFileList_1 - Starting to search for matching entries.");
	
	
    final java.util.List<java.io.File> list_tFileList_1 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_tFileList_1 = new java.util.HashSet<String>();
	java.io.File file_tFileList_1 = new java.io.File(directory_tFileList_1);
     
		file_tFileList_1.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
                if (!file.isDirectory()) {
                	
    	String fileName_tFileList_1 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_tFileList_1 : patternList_tFileList_1) {
          	if (fileNamePattern_tFileList_1.matcher(fileName_tFileList_1).matches()){
					if(!filePath_tFileList_1.contains(file.getAbsolutePath())) {
			          list_tFileList_1.add(file);
			          filePath_tFileList_1.add(file.getAbsolutePath());
			        }
			}
		}
                }
              return true;
            }
          }
      ); 
      java.util.Collections.sort(list_tFileList_1);
    
		log.info("tFileList_1 - Start to list files.");
	
    for (int i_tFileList_1 = 0; i_tFileList_1 < list_tFileList_1.size(); i_tFileList_1++){
      java.io.File files_tFileList_1 = list_tFileList_1.get(i_tFileList_1);
      String fileName_tFileList_1 = files_tFileList_1.getName();
      
      String currentFileName_tFileList_1 = files_tFileList_1.getName(); 
      String currentFilePath_tFileList_1 = files_tFileList_1.getAbsolutePath();
      String currentFileDirectory_tFileList_1 = files_tFileList_1.getParent();
      String currentFileExtension_tFileList_1 = null;
      
      if (files_tFileList_1.getName().contains(".") && files_tFileList_1.isFile()){
        currentFileExtension_tFileList_1 = files_tFileList_1.getName().substring(files_tFileList_1.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_tFileList_1 = "";
      }
      
      NB_FILEtFileList_1 ++;
      globalMap.put("tFileList_1_CURRENT_FILE", currentFileName_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEPATH", currentFilePath_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEDIRECTORY", currentFileDirectory_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEEXTENSION", currentFileExtension_tFileList_1);
      globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
      
		log.info("tFileList_1 - Current file or directory path : " + currentFilePath_tFileList_1);
	  
 



/**
 * [tFileList_1 begin ] stop
 */
	
	/**
	 * [tFileList_1 main ] start
	 */

	

	
	
	currentComponent="tFileList_1";
	
	

 


	tos_count_tFileList_1++;

/**
 * [tFileList_1 main ] stop
 */
	
	/**
	 * [tFileList_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileList_1";
	
	

 



/**
 * [tFileList_1 process_data_begin ] stop
 */
	NB_ITERATE_tJava_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk2", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate15", 1, "exec" + NB_ITERATE_tJava_2);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";
	
	
		int tos_count_tJava_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_2", "tJava_2", "tJava");
				talendJobLogProcess(globalMap);
			}
			


globalMap.put("currentFileType", "");
String currentFile = (String)globalMap.get("tFileList_1_CURRENT_FILE");
String currentFileType = currentFile != null && currentFile.length() >= 5  ? currentFile.substring(0,5) : currentFile;
if (currentFileType.matches("^(ART|CDC|REC)01$")){
globalMap.put("currentFileType", currentFileType);}
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

   			if (! ("".equals((String)globalMap.get("currentFileType")))) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				tFTPConnection_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJava_2 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate15", 2, "exec" + NB_ITERATE_tJava_2);
						}				
					




	
	/**
	 * [tFileList_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileList_1";
	
	

 



/**
 * [tFileList_1 process_data_end ] stop
 */
	
	/**
	 * [tFileList_1 end ] start
	 */

	

	
	
	currentComponent="tFileList_1";
	
	

  
    }
  globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
  
    log.info("tFileList_1 - File or directory count : " + NB_FILEtFileList_1);

  
 

 
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + ("Done.") );

ok_Hash.put("tFileList_1", true);
end_Hash.put("tFileList_1", System.currentTimeMillis());




/**
 * [tFileList_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate14", 2, "exec" + NB_ITERATE_tFileList_1);
						}				
					




	
	/**
	 * [tFlowToIterate_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";
	
	

 



/**
 * [tFlowToIterate_5 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tFileInputExcel_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		

 



/**
 * [tFileInputExcel_7 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_7 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		

			}
			
			
				log.debug("tFileInputExcel_7 - Retrieved records count: "+ nb_line_tFileInputExcel_7 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_7_NB_LINE",nb_line_tFileInputExcel_7);
		} finally {
				
  				if(!(source_tFileInputExcel_7 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_7.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_7 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_7", true);
end_Hash.put("tFileInputExcel_7", System.currentTimeMillis());




/**
 * [tFileInputExcel_7 end ] stop
 */

	
	/**
	 * [tFlowToIterate_5 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";
	
	

globalMap.put("tFlowToIterate_5_NB_LINE",nb_line_tFlowToIterate_5);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tFileInputExcel_7","tFileInputExcel_7<br> mise a jour distant MC","tFileInputExcel","tFlowToIterate_5","tFlowToIterate_5","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_5", true);
end_Hash.put("tFlowToIterate_5", System.currentTimeMillis());




/**
 * [tFlowToIterate_5 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tFileInputExcel_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_7 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_7";
	
	
			cLabel="tFileInputExcel_7<br> mise a jour distant MC";
		

 



/**
 * [tFileInputExcel_7 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_5 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";
	
	

 



/**
 * [tFlowToIterate_5 finally ] stop
 */

	
	/**
	 * [tFileList_1 finally ] start
	 */

	

	
	
	currentComponent="tFileList_1";
	
	

 



/**
 * [tFileList_1 finally ] stop
 */

	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_7_SUBPROCESS_STATE", 1);
	}
	


public void tFTPConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPConnection_2");
		org.slf4j.MDC.put("_subJobPid", "Dw0V2s_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPConnection_2", false);
		start_Hash.put("tFTPConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tFTPConnection_2";
	
	
		int tos_count_tFTPConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPConnection_2 = new StringBuilder();
                    log4jParamters_tFTPConnection_2.append("Parameters:");
                            log4jParamters_tFTPConnection_2.append("HOST" + " = " + "context.FTP_Hote");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("PORT" + " = " + "context.FTP_Wms_Port");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USER" + " = " + "(String)globalMap.get(\"row3.Name\")");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword((String)globalMap.get("row3.Key"))).substring(0, 4) + "...");     
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("SFTP" + " = " + "true");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("AUTH_METHOD" + " = " + "PASSWORD");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_ENCODING" + " = " + "false");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_PROXY" + " = " + "false");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("CONNECTION_TIMEOUT" + " = " + "0");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_STRICT_REPLY_PARSING" + " = " + "true");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("CONFIG_CLIENT" + " = " + "true");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("CLIENT_PARAMETERS" + " = " + "[{VALUE="+("\"ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group14-sha1,diffie-hellman-group-exchange-sha256,diffie-hellman-group-exchange-sha1,diffie-hellman-group1-sha1,curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,diffie-hellman-group14-sha256\"")+", PARAMETER="+("\"kex\"")+"}, {VALUE="+("\"ssh-rsa,ssh-dss,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521,rsa-sha2-512,rsa-sha2-256\"")+", PARAMETER="+("\"server_host_key\"")+"}, {VALUE="+("\"aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-ctr,aes192-cbc,aes256-ctr,aes256-cbc,aes128-gcm@openssh.com,aes256-gcm@openssh.com\"")+", PARAMETER="+("\"cipher.s2c\"")+"}, {VALUE="+("\"aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-ctr,aes192-cbc,aes256-ctr,aes256-cbc,aes128-gcm@openssh.com,aes256-gcm@openssh.com\"")+", PARAMETER="+("\"cipher.c2s\"")+"}, {VALUE="+("\"hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96,hmac-sha2-256-etm@openssh.com,hmac-sha2-512-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512\"")+", PARAMETER="+("\"mac.s2c\"")+"}, {VALUE="+("\"hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96,hmac-sha2-256-etm@openssh.com,hmac-sha2-512-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512\"")+", PARAMETER="+("\"mac.c2s\"")+"}]");
                        log4jParamters_tFTPConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + (log4jParamters_tFTPConnection_2) );
                    } 
                } 
            new BytesLimit65535_tFTPConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPConnection_2", "tFTPConnection_1", "tFTPConnection");
				talendJobLogProcess(globalMap);
			}
			

 
int connectionTimeout_tFTPConnection_2 = Integer.valueOf(0);	
	


class MyUserInfo_tFTPConnection_2 implements com.jcraft.jsch.UserInfo, com.jcraft.jsch.UIKeyboardInteractive {

    public String getPassphrase() { return "secret"; }

    public boolean promptPassword(String arg0) { return true; } 

    public boolean promptPassphrase(String arg0) { return true; } 

    public boolean promptYesNo(String arg0) { return true; } 

    public void showMessage(String arg0) { } 

    public String[] promptKeyboardInteractive(String destination, String name, String instruction, String[] prompt,
    boolean[] echo) {
        return new String[] {getPassword()};
    }

    public String getPassword() {

	final String decryptedPassword_tFTPConnection_2 = (String)globalMap.get("row3.Key"); 

            return decryptedPassword_tFTPConnection_2;
    }
};
final com.jcraft.jsch.UserInfo defaultUserInfo_tFTPConnection_2 = new MyUserInfo_tFTPConnection_2();


boolean retry_tFTPConnection_2 = false;
int retry_count_tFTPConnection_2 = 0;
int retry_max_tFTPConnection_2 = 5;

com.jcraft.jsch.Session session_tFTPConnection_2 = null;
com.jcraft.jsch.Channel channel_tFTPConnection_2 = null;

class JschLogger_tFTPConnection_2 implements com.jcraft.jsch.Logger {
    public boolean isEnabled(int level){
        return true;
    }
    public void log(int level, String message){
    	
        	log.debug(message);
    }
}

do {
    retry_tFTPConnection_2 = false;

    		com.jcraft.jsch.JSch.setConfig("kex", "ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group14-sha1,diffie-hellman-group-exchange-sha256,diffie-hellman-group-exchange-sha1,diffie-hellman-group1-sha1,curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,diffie-hellman-group14-sha256");
    		com.jcraft.jsch.JSch.setConfig("server_host_key", "ssh-rsa,ssh-dss,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521,rsa-sha2-512,rsa-sha2-256");
    		com.jcraft.jsch.JSch.setConfig("cipher.s2c", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-ctr,aes192-cbc,aes256-ctr,aes256-cbc,aes128-gcm@openssh.com,aes256-gcm@openssh.com");
    		com.jcraft.jsch.JSch.setConfig("cipher.c2s", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-ctr,aes192-cbc,aes256-ctr,aes256-cbc,aes128-gcm@openssh.com,aes256-gcm@openssh.com");
    		com.jcraft.jsch.JSch.setConfig("mac.s2c", "hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96,hmac-sha2-256-etm@openssh.com,hmac-sha2-512-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512");
    		com.jcraft.jsch.JSch.setConfig("mac.c2s", "hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96,hmac-sha2-256-etm@openssh.com,hmac-sha2-512-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512");
    com.jcraft.jsch.JSch.setLogger(new JschLogger_tFTPConnection_2());
    com.jcraft.jsch.JSch jsch_tFTPConnection_2 = new com.jcraft.jsch.JSch(); 


    session_tFTPConnection_2 = jsch_tFTPConnection_2.getSession((String)globalMap.get("row3.Name"), context.FTP_Hote, context.FTP_Wms_Port);
    session_tFTPConnection_2.setConfig("PreferredAuthentications", "publickey,password,keyboard-interactive,gssapi-with-mic");

            log.info("tFTPConnection_2 - SFTP authentication using a password.");

	final String decryptedPassword_tFTPConnection_2 = (String)globalMap.get("row3.Key"); 

        session_tFTPConnection_2.setPassword(decryptedPassword_tFTPConnection_2); 

    session_tFTPConnection_2.setUserInfo(defaultUserInfo_tFTPConnection_2); 
        if(("true").equals(System.getProperty("http.proxySet"))) {

//check if the host is in the excludes for proxy
    boolean isHostIgnored_tFTPConnection_2 = false;
    String nonProxyHostsString_tFTPConnection_2 = System.getProperty("http.nonProxyHosts");
    String[] nonProxyHosts_tFTPConnection_2 = (nonProxyHostsString_tFTPConnection_2 == null) ? new String[0] : nonProxyHostsString_tFTPConnection_2.split("\\|");
    for (String nonProxyHost : nonProxyHosts_tFTPConnection_2) {
        if ((context.FTP_Hote).matches(nonProxyHost.trim())) {
            isHostIgnored_tFTPConnection_2 = true;
            break;
        }
    }
            if (!isHostIgnored_tFTPConnection_2) {
                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_2 = new com.jcraft.jsch.ProxyHTTP(System.getProperty("http.proxyHost"),Integer.parseInt(System.getProperty("http.proxyPort")));
                if(!"".equals(System.getProperty("http.proxyUser"))){
                    proxy_tFTPConnection_2.setUserPasswd(System.getProperty("http.proxyUser"),System.getProperty("http.proxyPassword"));
                }
                session_tFTPConnection_2.setProxy(proxy_tFTPConnection_2);
            }
        } else if ("local".equals(System.getProperty("http.proxySet"))) {
            String uriString = context.FTP_Hote + ":" + context.FTP_Wms_Port;
            java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);

            if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {
                java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();
                String proxyHost = proxyAddress.getAddress().getHostAddress();
                int proxyPort = proxyAddress.getPort();

                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_2 = new com.jcraft.jsch.ProxyHTTP(proxyHost, proxyPort);

                org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(proxyHost + ":" + proxyPort);
                if (proxyCreds != null) {
                    proxy_tFTPConnection_2.setUserPasswd(proxyCreds.getUser(), proxyCreds.getPass());
                }

                session_tFTPConnection_2.setProxy(proxy_tFTPConnection_2);
            }
        }

        log.info("tFTPConnection_2 - Attempt to connect to  '" + context.FTP_Hote + "' with username '" + (String)globalMap.get("row3.Name") + "'.");

    channel_tFTPConnection_2 = null;
    try {
        if (connectionTimeout_tFTPConnection_2 > 0) {
            session_tFTPConnection_2.connect(connectionTimeout_tFTPConnection_2);
        } else {
            session_tFTPConnection_2.connect();
        }
        channel_tFTPConnection_2 = session_tFTPConnection_2.openChannel("sftp");
        if (connectionTimeout_tFTPConnection_2 > 0) {
            channel_tFTPConnection_2.connect(connectionTimeout_tFTPConnection_2);
        } else {
            channel_tFTPConnection_2.connect();
        }
            log.info("tFTPConnection_2 - Connect to '" + context.FTP_Hote + "' has succeeded.");
    } catch (com.jcraft.jsch.JSchException e_tFTPConnection_2) {
        try {
            if(channel_tFTPConnection_2!=null) {
                channel_tFTPConnection_2.disconnect();
            }

            if(session_tFTPConnection_2!=null) {
                session_tFTPConnection_2.disconnect();
            }
        } catch(java.lang.Exception ce_tFTPConnection_2) {
                log.warn("tFTPConnection_2 - close sftp connection failed : " + ce_tFTPConnection_2.getClass() + " : " + ce_tFTPConnection_2.getMessage());
        }

        String message_tFTPConnection_2 = new TalendException(null, null, null).getExceptionCauseMessage(e_tFTPConnection_2);
        if(message_tFTPConnection_2.contains("Signature length not correct") || message_tFTPConnection_2.contains("connection is closed by foreign host")) {
            retry_tFTPConnection_2 = true;
            retry_count_tFTPConnection_2++;
            log.info("tFTPConnection_2 - connect: Signature length not correct or connection is closed by foreign host, so retry, retry time : " + retry_count_tFTPConnection_2);
        } else {
            throw e_tFTPConnection_2;
        }
    }
} while(retry_tFTPConnection_2 && (retry_count_tFTPConnection_2 < retry_max_tFTPConnection_2));

com.jcraft.jsch.ChannelSftp c_tFTPConnection_2 = (com.jcraft.jsch.ChannelSftp)channel_tFTPConnection_2;
	
	
	
	globalMap.put("conn_tFTPConnection_2", c_tFTPConnection_2);

 



/**
 * [tFTPConnection_2 begin ] stop
 */
	
	/**
	 * [tFTPConnection_2 main ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 


	tos_count_tFTPConnection_2++;

/**
 * [tFTPConnection_2 main ] stop
 */
	
	/**
	 * [tFTPConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tFTPConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tFTPConnection_2 end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + ("Done.") );

ok_Hash.put("tFTPConnection_2", true);
end_Hash.put("tFTPConnection_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tFTPPut_1Process(globalMap);



/**
 * [tFTPConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPConnection_2_SUBPROCESS_STATE", 1);
	}
	


public void tFTPPut_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPPut_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPPut_1");
		org.slf4j.MDC.put("_subJobPid", "HOr9dH_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPPut_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPPut_1", false);
		start_Hash.put("tFTPPut_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPPut_1";
	
	
		int tos_count_tFTPPut_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPPut_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPPut_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPPut_1 = new StringBuilder();
                    log4jParamters_tFTPPut_1.append("Parameters:");
                            log4jParamters_tFTPPut_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("CONNECTION" + " = " + "tFTPConnection_2");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("LOCALDIR" + " = " + "context.Server_In + \"Magistor/\" + ((String)globalMap.get(\"row3.Name\"))");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("REMOTEDIR" + " = " + " \"/ARCHIVE\"");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("CREATE_DIR_IF_NOT_EXIST" + " = " + "false");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("SFTPOVERWRITE" + " = " + "overwrite");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("PERL5_REGEX" + " = " + "false");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("FILES" + " = " + "[{FILEMASK="+("((String)globalMap.get(\"currentFileType\")) + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+", NEWNAME="+("((String)globalMap.get(\"currentFileType\")) + ((String)globalMap.get(\"output_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tFTPPut_1.append(" | ");
                            log4jParamters_tFTPPut_1.append("RENAME_AFTER" + " = " + "false");
                        log4jParamters_tFTPPut_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPPut_1 - "  + (log4jParamters_tFTPPut_1) );
                    } 
                } 
            new BytesLimit65535_tFTPPut_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPPut_1", "tFTPPut_1", "tFTPPut");
				talendJobLogProcess(globalMap);
			}
			


int nb_file_tFTPPut_1 = 0;
// *** sftp *** //

	class MyProgressMonitor_tFTPPut_1 implements com.jcraft.jsch.SftpProgressMonitor {
		public void init(int op, String src, String dest, long max) {}
    	public boolean count(long count) { return true;}
    	public void end() {}
  	}

	
    	com.jcraft.jsch.ChannelSftp c_tFTPPut_1 = (com.jcraft.jsch.ChannelSftp)globalMap.get("conn_tFTPConnection_2");
		
			if(c_tFTPPut_1!=null && c_tFTPPut_1.getSession()!=null) {
				log.info("tFTPPut_1 - Uses an existing connection. Connection username " + c_tFTPPut_1.getSession().getUserName() + ", Connection hostname: " + c_tFTPPut_1.getSession().getHost() + ", Connection port: " + c_tFTPPut_1.getSession().getPort() + "."); 
			}
		
    	if(c_tFTPPut_1.getHome()!=null && !c_tFTPPut_1.getHome().equals(c_tFTPPut_1.pwd())){
  			c_tFTPPut_1.cd(c_tFTPPut_1.getHome());
  		}
	

	// because there is not the same method in JSch class as FTPClient class, define a list here
	java.util.List<String> msg_tFTPPut_1 = new java.util.ArrayList<String>();
	com.jcraft.jsch.SftpProgressMonitor monitortFTPPut_1 = new MyProgressMonitor_tFTPPut_1();
	java.util.List<java.util.Map<String,String>> listtFTPPut_1 = new java.util.ArrayList<java.util.Map<String,String>>();
  
			java.util.Map<String,String> maptFTPPut_10 = new java.util.HashMap<String,String>();
		    maptFTPPut_10.put(((String)globalMap.get("currentFileType")) + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque, ((String)globalMap.get("currentFileType")) + ((String)globalMap.get("output_today_date")) + context.Excel_File_Masque);    
		    listtFTPPut_1.add(maptFTPPut_10);         
	String localdirtFTPPut_1 = context.Server_In + "Magistor/" + ((String)globalMap.get("row3.Name"));
	
		log.info("tFTPPut_1 - Putting file to the server.");
	
	
	class StatCheck_tFTPPut_1 {
			
			boolean statOK(com.jcraft.jsch.ChannelSftp client, String path) {
					try {
							return client.stat(path).getAtimeString() != null;
					} catch (Exception e) {
globalMap.put("tFTPPut_1_ERROR_MESSAGE",e.getMessage());
							
							log.warn("tFTPPut_1 - Directory or file permission denied for checking the status of the path : " + path);
							
					}
					
					return false;
			}
			
	}
	
	StatCheck_tFTPPut_1 sc_tFTPPut_1 = new StatCheck_tFTPPut_1();
	
	for (java.util.Map<String, String> maptFTPPut_1 : listtFTPPut_1) {


 



/**
 * [tFTPPut_1 begin ] stop
 */
	
	/**
	 * [tFTPPut_1 main ] start
	 */

	

	
	
	currentComponent="tFTPPut_1";
	
	

try{
        globalMap.put("tFTPPut_1_CURRENT_STATUS", "No file transfered.");
        java.util.Set<String> keySettFTPPut_1 = maptFTPPut_1.keySet();
        for (String keytFTPPut_1 : keySettFTPPut_1){
            if(keytFTPPut_1 == null || "".equals(keytFTPPut_1)){
                    log.error("tFTPPut_1 - file name invalid!");
                System.err.println("file name invalid!");
                continue;
            }
            String tempdirtFTPPut_1 =  localdirtFTPPut_1;
            String filemasktFTPPut_1 = keytFTPPut_1;
            String dirtFTPPut_1 = null;
                String masktFTPPut_1 = filemasktFTPPut_1.replaceAll("\\\\", "/") ;
            int itFTPPut_1 = masktFTPPut_1.lastIndexOf('/');
            if (itFTPPut_1!=-1){
                dirtFTPPut_1 = masktFTPPut_1.substring(0, itFTPPut_1);
                masktFTPPut_1 = masktFTPPut_1.substring(itFTPPut_1+1);
            }
            if (dirtFTPPut_1!=null && !"".equals(dirtFTPPut_1)) tempdirtFTPPut_1 = tempdirtFTPPut_1 + "/" + dirtFTPPut_1;
                masktFTPPut_1 = masktFTPPut_1.replaceAll("\\.", "\\\\.").replaceAll("\\*", ".*");
            final String finalMasktFTPPut_1 = masktFTPPut_1;
            java.io.File[] listingstFTPPut_1 = null;
            java.io.File filetFTPPut_1 = new java.io.File(tempdirtFTPPut_1);
            if (filetFTPPut_1.isDirectory()) {
                listingstFTPPut_1 = filetFTPPut_1.listFiles(new java.io.FileFilter() {
                    public boolean accept(java.io.File pathname) {
                        boolean result = false;
                        if (pathname != null && pathname.isFile()) {
                                result = java.util.regex.Pattern.compile(finalMasktFTPPut_1).matcher(pathname.getName()).find();
                            }
                        return result;
                    }
                });
            }
            if(listingstFTPPut_1 != null && listingstFTPPut_1.length > 0){
                for (int mtFTPPut_1 = 0; mtFTPPut_1 < listingstFTPPut_1.length; mtFTPPut_1++){
                    if (listingstFTPPut_1[mtFTPPut_1].getName().matches(masktFTPPut_1)){

                        int modetFTPPut_1 = com.jcraft.jsch.ChannelSftp.OVERWRITE;
                        boolean putSuccess_tFTPPut_1 = false;
                        
                        String remoteDir_tFTPPut_1 =  "/ARCHIVE";
                        if(remoteDir_tFTPPut_1==null) {
                        		remoteDir_tFTPPut_1 = "";
                        }
                        remoteDir_tFTPPut_1 = remoteDir_tFTPPut_1.trim();
                        if(remoteDir_tFTPPut_1.endsWith("/")) {
                        		remoteDir_tFTPPut_1 = remoteDir_tFTPPut_1.substring(0, remoteDir_tFTPPut_1.length()-1);
                        }
                        String destRename_tFTPPut_1 =  maptFTPPut_1.get(keytFTPPut_1);
                        final String dest_tFTPPut_1;
                                if (destRename_tFTPPut_1 == null || destRename_tFTPPut_1.isEmpty()) {
                                    dest_tFTPPut_1 = remoteDir_tFTPPut_1 + "/" + listingstFTPPut_1[mtFTPPut_1].getName();
                                } else {
                                    dest_tFTPPut_1 = remoteDir_tFTPPut_1 + "/" + destRename_tFTPPut_1;
                                }
                        
                        try{
                            c_tFTPPut_1.put(listingstFTPPut_1[mtFTPPut_1].getAbsolutePath(), dest_tFTPPut_1, monitortFTPPut_1, modetFTPPut_1);
                            // add info to list will return
                            msg_tFTPPut_1.add("file: " + listingstFTPPut_1[mtFTPPut_1].getAbsolutePath() + ", size: "
                                + listingstFTPPut_1[mtFTPPut_1].length() + " bytes upload successfully");
                                log.debug("tFTPPut_1 - Uploaded file '" + listingstFTPPut_1[mtFTPPut_1].getName() + "' successfully.");
                            globalMap.put("tFTPPut_1_CURRENT_STATUS", "File transfer OK.");
                            
                            putSuccess_tFTPPut_1 = true;
                            
                            if(sc_tFTPPut_1.statOK(c_tFTPPut_1, dest_tFTPPut_1)){
                                globalMap.put("tFTPPut_1_CURRENT_FILE_EXISTS",true);
                            }
                        }catch(com.jcraft.jsch.SftpException e_tFTPPut_1) {
globalMap.put("tFTPPut_1_ERROR_MESSAGE",e_tFTPPut_1.getMessage());
                                log.error("tFTPPut_1 - File transfer fail."+e_tFTPPut_1.getMessage());
                            globalMap.put("tFTPPut_1_CURRENT_STATUS", "File transfer fail.");
                            
                            if(!putSuccess_tFTPPut_1) {
                                if(sc_tFTPPut_1.statOK(c_tFTPPut_1, dest_tFTPPut_1)){
                                    globalMap.put("tFTPPut_1_CURRENT_FILE_EXISTS",true);
                                }
                            }
                            throw(e_tFTPPut_1);
                        }catch(java.lang.Exception e_tFTPPut_1){
globalMap.put("tFTPPut_1_ERROR_MESSAGE",e_tFTPPut_1.getMessage());
                           if(!(e_tFTPPut_1 instanceof com.jcraft.jsch.SftpException)) {
                                msg_tFTPPut_1.add("file " + listingstFTPPut_1[mtFTPPut_1].getAbsolutePath() + " not found?");

                                globalMap.put("tFTPPut_1_CURRENT_FILE_EXISTS",false);
                            }
                            throw e_tFTPPut_1;
                        }
                        nb_file_tFTPPut_1++;
                    }
                }
            }else{
                    log.warn("tFTPPut_1 - No matches found for mask '" + keytFTPPut_1 + "'!");
                System.err.println("No matches found for mask '" + keytFTPPut_1 + "'!");
            }
                    }

    }catch(java.lang.Exception e_tFTPPut_1){
globalMap.put("tFTPPut_1_ERROR_MESSAGE",e_tFTPPut_1.getMessage());
            msg_tFTPPut_1.add("file not found?: " + e_tFTPPut_1.getMessage());
            throw(e_tFTPPut_1);
    }
 


	tos_count_tFTPPut_1++;

/**
 * [tFTPPut_1 main ] stop
 */
	
	/**
	 * [tFTPPut_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPPut_1";
	
	

 



/**
 * [tFTPPut_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPPut_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPPut_1";
	
	

 



/**
 * [tFTPPut_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPPut_1 end ] start
	 */

	

	
	
	currentComponent="tFTPPut_1";
	
	

 	}
    msg_tFTPPut_1.add(nb_file_tFTPPut_1 + " files have been uploaded.");  
    	
	StringBuffer sb_tFTPPut_1 = new StringBuffer();
    for (String item_tFTPPut_1 : msg_tFTPPut_1) {
        sb_tFTPPut_1.append(item_tFTPPut_1).append("\n");
    }
	globalMap.put("tFTPPut_1_TRANSFER_MESSAGES", sb_tFTPPut_1.toString());
        if(nb_file_tFTPPut_1 == 0 && !listtFTPPut_1.isEmpty()){
            throw new RuntimeException("Error during component operation!");
        }
	
	
globalMap.put("tFTPPut_1_NB_FILE",nb_file_tFTPPut_1);
	log.info("tFTPPut_1 - Uploaded files count: " + nb_file_tFTPPut_1 +  ".");
    if(nb_file_tFTPPut_1 == 0 && !listtFTPPut_1.isEmpty()){
        throw new RuntimeException("Error during component operation!");
    }

 
                if(log.isDebugEnabled())
            log.debug("tFTPPut_1 - "  + ("Done.") );

ok_Hash.put("tFTPPut_1", true);
end_Hash.put("tFTPPut_1", System.currentTimeMillis());




/**
 * [tFTPPut_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFTPPut_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tFTPDelete_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPPut_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPPut_1";
	
	

 



/**
 * [tFTPPut_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPPut_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPDelete_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPDelete_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPDelete_1");
		org.slf4j.MDC.put("_subJobPid", "yYGvaI_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPDelete_1", false);
		start_Hash.put("tFTPDelete_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPDelete_1";
	
	
		int tos_count_tFTPDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPDelete_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPDelete_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPDelete_1 = new StringBuilder();
                    log4jParamters_tFTPDelete_1.append("Parameters:");
                            log4jParamters_tFTPDelete_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("CONNECTION" + " = " + "tFTPConnection_2");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("REMOTEDIR" + " = " + "\"/IN\"");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("PERL5_REGEX" + " = " + "false");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("FILES" + " = " + "[{FILEMASK="+("((String)globalMap.get(\"currentFileType\"))+ ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("TARGET_TYPE" + " = " + "FILE");
                        log4jParamters_tFTPDelete_1.append(" | ");
                            log4jParamters_tFTPDelete_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tFTPDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPDelete_1 - "  + (log4jParamters_tFTPDelete_1) );
                    } 
                } 
            new BytesLimit65535_tFTPDelete_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPDelete_1", "tFTPDelete_1", "tFTPDelete");
				talendJobLogProcess(globalMap);
			}
			

 
int nb_file_tFTPDelete_1 = 0;
    
			com.jcraft.jsch.ChannelSftp c_tFTPDelete_1 = (com.jcraft.jsch.ChannelSftp)globalMap.get("conn_tFTPConnection_2");
			
				if(c_tFTPDelete_1!=null && c_tFTPDelete_1.getSession()!=null) {
					log.info("tFTPDelete_1 - Uses an existing connection. Connection username: " + c_tFTPDelete_1.getSession().getUserName() + ", Connection hostname: " + c_tFTPDelete_1.getSession().getHost() + ", Connection port: " + c_tFTPDelete_1.getSession().getPort() + "."); 
				}
			
		    if(c_tFTPDelete_1.getHome()!=null && !c_tFTPDelete_1.getHome().equals(c_tFTPDelete_1.pwd())){
		  		c_tFTPDelete_1.cd(c_tFTPDelete_1.getHome());
			}
		
		java.util.List<java.util.Map<String,String>> listtFTPDelete_1 = new java.util.ArrayList<java.util.Map<String,String>>();

		    
				java.util.Map<String,String> maptFTPDelete_10 = new java.util.HashMap<String,String>();
		    	maptFTPDelete_10.put(((String)globalMap.get("currentFileType"))+ ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque,"");
		    	listtFTPDelete_1.add(maptFTPDelete_10);       
  		  

		
			
				log.info("tFTPDelete_1 - Deleting file from server.");
			
		
		for (java.util.Map<String, String> maptFTPDelete_1 : listtFTPDelete_1) {

 



/**
 * [tFTPDelete_1 begin ] stop
 */
	
	/**
	 * [tFTPDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFTPDelete_1";
	
	

	try{
		globalMap.put("tFTPDelete_1_CURRENT_STATUS", "No file deleted.");
		java.util.Set<String> keySettFTPDelete_1 = maptFTPDelete_1.keySet(); 
			for (String keytFTPDelete_1 : keySettFTPDelete_1) {     
				String filemasktFTPDelete_1 = keytFTPDelete_1; 
		    	String dirtFTPDelete_1 = null;
        		
		        	String masktFTPDelete_1 = filemasktFTPDelete_1.replaceAll("\\\\", "/") ;
        		
		    	int itFTPDelete_1 = masktFTPDelete_1.lastIndexOf('/');
				if (itFTPDelete_1!=-1) {
					dirtFTPDelete_1 = masktFTPDelete_1.substring(0, itFTPDelete_1); 
					masktFTPDelete_1 = masktFTPDelete_1.substring(itFTPDelete_1+1); 
    			} 
		        
        			masktFTPDelete_1 = org.apache.oro.text.GlobCompiler.globToPerl5(masktFTPDelete_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
		        
				java.util.Vector listingstFTPDelete_1 = c_tFTPDelete_1.ls("/IN");
				for (int mtFTPDelete_1 = 0; mtFTPDelete_1 < listingstFTPDelete_1.size(); mtFTPDelete_1++) { 
					String filePathtFTPDelete_1 =  ((com.jcraft.jsch.ChannelSftp.LsEntry) listingstFTPDelete_1.elementAt(mtFTPDelete_1)).getFilename() ;
					if ( filePathtFTPDelete_1.matches(masktFTPDelete_1)) {
						try {			
							 	c_tFTPDelete_1.rm(("/IN")+"/"+ filePathtFTPDelete_1);
								
									log.debug("tFTPDelete_1 - File '" + filePathtFTPDelete_1  + "' was deleted from the remote directory " + "/IN" + ".");
								
							 globalMap.put("tFTPDelete_1_CURRENT_STATUS", "File deleted.");
						} catch (com.jcraft.jsch.SftpException e_tFTPDelete_1) {
						    globalMap.put("tFTPDelete_1_ERROR_MESSAGE",e_tFTPDelete_1.getMessage());
							globalMap.put("tFTPDelete_1_CURRENT_STATUS", "Deleting file action error");
            	           throw e_tFTPDelete_1;
                		}
						nb_file_tFTPDelete_1++;
					}
				}	     
			}  


   
    
	}catch(java.lang.Exception e_tFTPDelete_1){
globalMap.put("tFTPDelete_1_ERROR_MESSAGE",e_tFTPDelete_1.getMessage());
    		throw(e_tFTPDelete_1);
	}

 


	tos_count_tFTPDelete_1++;

/**
 * [tFTPDelete_1 main ] stop
 */
	
	/**
	 * [tFTPDelete_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPDelete_1";
	
	

 



/**
 * [tFTPDelete_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPDelete_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPDelete_1";
	
	

 



/**
 * [tFTPDelete_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFTPDelete_1";
	
	

	} 


globalMap.put("tFTPDelete_1_NB_FILE",nb_file_tFTPDelete_1);

	log.info("tFTPDelete_1 - Deleted files count: " + nb_file_tFTPDelete_1  + ".");

 
                if(log.isDebugEnabled())
            log.debug("tFTPDelete_1 - "  + ("Done.") );

ok_Hash.put("tFTPDelete_1", true);
end_Hash.put("tFTPDelete_1", System.currentTimeMillis());




/**
 * [tFTPDelete_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFTPDelete_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tFTPClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPDelete_1";
	
	

 



/**
 * [tFTPDelete_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPDelete_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPClose_1");
		org.slf4j.MDC.put("_subJobPid", "u3YETo_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFTPClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPClose_1", false);
		start_Hash.put("tFTPClose_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPClose_1";
	
	
		int tos_count_tFTPClose_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFTPClose_1", "tFTPClose_1", "tFTPClose");
				talendJobLogProcess(globalMap);
			}
			
	 Object connObj = globalMap.get("conn_tFTPConnection_2");
	 if (connObj != null) {
      try {
			
              com.jcraft.jsch.ChannelSftp channel = (com.jcraft.jsch.ChannelSftp) connObj; 
              com.jcraft.jsch.Session session = channel.getSession();
			  channel.disconnect();
              session.disconnect();
			
      } catch (Exception e) {
           globalMap.put("tFTPClose_1_ERROR_MESSAGE", e.getMessage()); 
           throw e;
      }
  }
 



/**
 * [tFTPClose_1 begin ] stop
 */
	
	/**
	 * [tFTPClose_1 main ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 


	tos_count_tFTPClose_1++;

/**
 * [tFTPClose_1 main ] stop
 */
	
	/**
	 * [tFTPClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 



/**
 * [tFTPClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 



/**
 * [tFTPClose_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPClose_1 end ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 

ok_Hash.put("tFTPClose_1", true);
end_Hash.put("tFTPClose_1", System.currentTimeMillis());




/**
 * [tFTPClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPClose_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	
	 Object connObj = globalMap.get("conn_tFTPConnection_2");
	 if (connObj != null) {   
              com.jcraft.jsch.ChannelSftp channel = (com.jcraft.jsch.ChannelSftp) connObj; 
              com.jcraft.jsch.Session session = channel.getSession();
              channel.disconnect();
			  session.disconnect();
     
  }
 



/**
 * [tFTPClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPClose_1_SUBPROCESS_STATE", 1);
	}
	


public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String Key;

				public String getKey () {
					return this.Key;
				}

				public Boolean KeyIsNullable(){
				    return true;
				}
				public Boolean KeyIsKey(){
				    return false;
				}
				public Integer KeyLength(){
				    return null;
				}
				public Integer KeyPrecision(){
				    return null;
				}
				public String KeyDefault(){
				
					return null;
				
				}
				public String KeyComment(){
				
				    return "";
				
				}
				public String KeyPattern(){
				
					return "";
				
				}
				public String KeyOriginalDbColumnName(){
				
					return "Key";
				
				}

				
			    public String Mail;

				public String getMail () {
					return this.Mail;
				}

				public Boolean MailIsNullable(){
				    return true;
				}
				public Boolean MailIsKey(){
				    return false;
				}
				public Integer MailLength(){
				    return null;
				}
				public Integer MailPrecision(){
				    return null;
				}
				public String MailDefault(){
				
					return null;
				
				}
				public String MailComment(){
				
				    return "";
				
				}
				public String MailPattern(){
				
					return "";
				
				}
				public String MailOriginalDbColumnName(){
				
					return "Mail";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Key="+Key);
		sb.append(",Mail="+Mail);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Key);
            			}
            		
        			sb.append("|");
        		
        				if(Mail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Mail);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_5");
		org.slf4j.MDC.put("_subJobPid", "m0NwYF_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row20Struct row20 = new row20Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tFTPFileList_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row20");
			
		int tos_count_tFlowToIterate_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFlowToIterate_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFlowToIterate_3 = new StringBuilder();
                    log4jParamters_tFlowToIterate_3.append("Parameters:");
                            log4jParamters_tFlowToIterate_3.append("DEFAULT_MAP" + " = " + "true");
                        log4jParamters_tFlowToIterate_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + (log4jParamters_tFlowToIterate_3) );
                    } 
                } 
            new BytesLimit65535_tFlowToIterate_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_3", "tFlowToIterate_3", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_5", false);
		start_Hash.put("tFileInputExcel_5", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		
		int tos_count_tFileInputExcel_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_5 = new StringBuilder();
                    log4jParamters_tFileInputExcel_5.append("Parameters:");
                            log4jParamters_tFileInputExcel_5.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("FILENAME" + " = " + "context.Server_In + \"MagistorClients.xlsx\"");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:s8T6C2lz4nbpQXUIyzzrTx+lkbdqJqzPhDlAwQ==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                            log4jParamters_tFileInputExcel_5.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_5 - "  + (log4jParamters_tFileInputExcel_5) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_5", "tFileInputExcel_5<br> v\u00E9rification format fichier", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_5 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:Z7SOd2W5L8xmdFvq6Z1NfJmuI+fksPz2Gn5wPQ==");
        String password_tFileInputExcel_5 = decryptedPassword_tFileInputExcel_5;
        if (password_tFileInputExcel_5.isEmpty()){
            password_tFileInputExcel_5 = null;
        }
			class RegexUtil_tFileInputExcel_5 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_5 regexUtil_tFileInputExcel_5 = new RegexUtil_tFileInputExcel_5();

		Object source_tFileInputExcel_5 = context.Server_In + "MagistorClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_5 = null;
		
		if(source_tFileInputExcel_5 instanceof String){
			workbook_tFileInputExcel_5 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_5), password_tFileInputExcel_5, true);
		} else if(source_tFileInputExcel_5 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_5 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_5, password_tFileInputExcel_5);
		} else{
			workbook_tFileInputExcel_5 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_5 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_5.addAll(regexUtil_tFileInputExcel_5.getSheets(workbook_tFileInputExcel_5, "Clients", false));
    	if(sheetList_tFileInputExcel_5.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_5 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_5 : sheetList_tFileInputExcel_5) {
			if(sheet_FilterNull_tFileInputExcel_5!=null && sheetList_FilterNull_tFileInputExcel_5.iterator()!=null && sheet_FilterNull_tFileInputExcel_5.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_5.add(sheet_FilterNull_tFileInputExcel_5);
			}
		}
		sheetList_tFileInputExcel_5 = sheetList_FilterNull_tFileInputExcel_5;
		int nb_line_tFileInputExcel_5 = 0;
	if(sheetList_tFileInputExcel_5.size()>0){

        int begin_line_tFileInputExcel_5 = 1;

        int footer_input_tFileInputExcel_5 = 0;

        int end_line_tFileInputExcel_5=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_5:sheetList_tFileInputExcel_5){
			end_line_tFileInputExcel_5+=(sheet_tFileInputExcel_5.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_5 -= footer_input_tFileInputExcel_5;
        int limit_tFileInputExcel_5 = -1;
        int start_column_tFileInputExcel_5 = 1-1;
        int end_column_tFileInputExcel_5 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_5 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_5 = sheetList_tFileInputExcel_5.get(0);
        int rowCount_tFileInputExcel_5 = 0;
        int sheetIndex_tFileInputExcel_5 = 0;
        int currentRows_tFileInputExcel_5 = (sheetList_tFileInputExcel_5.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_5 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_5 = df_tFileInputExcel_5.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_5 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_5 = begin_line_tFileInputExcel_5; i_tFileInputExcel_5 < end_line_tFileInputExcel_5; i_tFileInputExcel_5++){

        	int emptyColumnCount_tFileInputExcel_5 = 0;

        	if (limit_tFileInputExcel_5 != -1 && nb_line_tFileInputExcel_5 >= limit_tFileInputExcel_5) {
        		break;
        	}

            while (i_tFileInputExcel_5 >= rowCount_tFileInputExcel_5 + currentRows_tFileInputExcel_5) {
                rowCount_tFileInputExcel_5 += currentRows_tFileInputExcel_5;
                sheet_tFileInputExcel_5 = sheetList_tFileInputExcel_5.get(++sheetIndex_tFileInputExcel_5);
                currentRows_tFileInputExcel_5 = (sheet_tFileInputExcel_5.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_5_CURRENT_SHEET",sheet_tFileInputExcel_5.getSheetName());
            if (rowCount_tFileInputExcel_5 <= i_tFileInputExcel_5) {
                row_tFileInputExcel_5 = sheet_tFileInputExcel_5.getRow(i_tFileInputExcel_5 - rowCount_tFileInputExcel_5);
            }
		    row20 = null;
					int tempRowLength_tFileInputExcel_5 = 3;
				
				int columnIndex_tFileInputExcel_5 = 0;
			
			String[] temp_row_tFileInputExcel_5 = new String[tempRowLength_tFileInputExcel_5];
			int excel_end_column_tFileInputExcel_5;
			if(row_tFileInputExcel_5==null){
				excel_end_column_tFileInputExcel_5=0;
			}else{
				excel_end_column_tFileInputExcel_5=row_tFileInputExcel_5.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_5;
			if(end_column_tFileInputExcel_5 == -1){
				actual_end_column_tFileInputExcel_5 = excel_end_column_tFileInputExcel_5;
			}
			else{
				actual_end_column_tFileInputExcel_5 = end_column_tFileInputExcel_5 >	excel_end_column_tFileInputExcel_5 ? excel_end_column_tFileInputExcel_5 : end_column_tFileInputExcel_5;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_5 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_5;i++){
				if(i + start_column_tFileInputExcel_5 < actual_end_column_tFileInputExcel_5){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_5 = row_tFileInputExcel_5.getCell(i + start_column_tFileInputExcel_5);
					if(cell_tFileInputExcel_5!=null){
					switch (cell_tFileInputExcel_5.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_5[i] = cell_tFileInputExcel_5.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_5)) {
									temp_row_tFileInputExcel_5[i] =cell_tFileInputExcel_5.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_5[i] = df_tFileInputExcel_5.format(cell_tFileInputExcel_5.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_5[i] =String.valueOf(cell_tFileInputExcel_5.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_5.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_5[i] = cell_tFileInputExcel_5.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_5)) {
											temp_row_tFileInputExcel_5[i] =cell_tFileInputExcel_5.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_5 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_5.getNumericCellValue());
										temp_row_tFileInputExcel_5[i] = ne_tFileInputExcel_5.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_5[i] =String.valueOf(cell_tFileInputExcel_5.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_5[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_5[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_5[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_5[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_5 = false;
			row20 = new row20Struct();
			int curColNum_tFileInputExcel_5 = -1;
			String curColName_tFileInputExcel_5 = "";
			try{
							columnIndex_tFileInputExcel_5 = 0;
						
			if( temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim().length() > 0) {
				curColNum_tFileInputExcel_5=columnIndex_tFileInputExcel_5 + start_column_tFileInputExcel_5 + 1;
				curColName_tFileInputExcel_5 = "Name";

				row20.Name = temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim();
			}else{
				row20.Name = null;
				emptyColumnCount_tFileInputExcel_5++;
			}
							columnIndex_tFileInputExcel_5 = 1;
						
			if( temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim().length() > 0) {
				curColNum_tFileInputExcel_5=columnIndex_tFileInputExcel_5 + start_column_tFileInputExcel_5 + 1;
				curColName_tFileInputExcel_5 = "Key";

				row20.Key = temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim();
			}else{
				row20.Key = null;
				emptyColumnCount_tFileInputExcel_5++;
			}
							columnIndex_tFileInputExcel_5 = 2;
						
			if( temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim().length() > 0) {
				curColNum_tFileInputExcel_5=columnIndex_tFileInputExcel_5 + start_column_tFileInputExcel_5 + 1;
				curColName_tFileInputExcel_5 = "Mail";

				row20.Mail = temp_row_tFileInputExcel_5[columnIndex_tFileInputExcel_5].trim();
			}else{
				row20.Mail = null;
				emptyColumnCount_tFileInputExcel_5++;
			}

        if(emptyColumnCount_tFileInputExcel_5 >= 3){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_5++;
				
				log.debug("tFileInputExcel_5 - Retrieving the record " + (nb_line_tFileInputExcel_5) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_5_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_5 = true;
						log.error("tFileInputExcel_5 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row20 = null;
			}


		



 



/**
 * [tFileInputExcel_5 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_5 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		

 


	tos_count_tFileInputExcel_5++;

/**
 * [tFileInputExcel_5 main ] stop
 */
	
	/**
	 * [tFileInputExcel_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		

 



/**
 * [tFileInputExcel_5 process_data_begin ] stop
 */
// Start of branch "row20"
if(row20 != null) { 



	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row20","tFileInputExcel_5","tFileInputExcel_5<br> v\u00E9rification format fichier","tFileInputExcel","tFlowToIterate_3","tFlowToIterate_3","tFlowToIterate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row20 - " + (row20==null? "": row20.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row20.Name, value=")  + (row20.Name)  + (".") );            
            globalMap.put("row20.Name", row20.Name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row20.Key, value=")  + (row20.Key)  + (".") );            
            globalMap.put("row20.Key", row20.Key);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row20.Mail, value=")  + (row20.Mail)  + (".") );            
            globalMap.put("row20.Mail", row20.Mail);
    	
 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_3)  + (".") );
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	
	/**
	 * [tFlowToIterate_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";
	
	

 



/**
 * [tFlowToIterate_3 process_data_begin ] stop
 */
	NB_ITERATE_tFTPFileList_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tFTPFileList_2);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFTPFileList_2 begin ] start
	 */

				
			int NB_ITERATE_tFTPFileExist_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFTPFileList_2", false);
		start_Hash.put("tFTPFileList_2", System.currentTimeMillis());
		
	
	currentComponent="tFTPFileList_2";
	
	
		int tos_count_tFTPFileList_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPFileList_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPFileList_2 = new StringBuilder();
                    log4jParamters_tFTPFileList_2.append("Parameters:");
                            log4jParamters_tFTPFileList_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("CONNECTION" + " = " + "tFTPConnection_1");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("REMOTEDIR" + " = " + "context.Distant_Magistor_Clients_Input + ((String)globalMap.get(\"row20.Name\")) + \"/IN\"");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("MOVE_TO_THE_CURRENT_DIRECTORY" + " = " + "true");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("DIR_FULL" + " = " + "false");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("FILES" + " = " + "[]");
                        log4jParamters_tFTPFileList_2.append(" | ");
                            log4jParamters_tFTPFileList_2.append("IGNORE_FAILURE_AT_QUIT" + " = " + "false");
                        log4jParamters_tFTPFileList_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_2 - "  + (log4jParamters_tFTPFileList_2) );
                    } 
                } 
            new BytesLimit65535_tFTPFileList_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPFileList_2", "tFTPFileList_2", "tFTPFileList");
				talendJobLogProcess(globalMap);
			}
			

 
	java.util.List<String> maskList_tFTPFileList_2 = new java.util.ArrayList<String>();

	maskList_tFTPFileList_2.add("*");
        org.apache.commons.net.ftp.FTPClient ftp_tFTPFileList_2 = null;
            ftp_tFTPFileList_2 = (org.apache.commons.net.ftp.FTPClient) globalMap.get("conn_tFTPConnection_1");
                if(ftp_tFTPFileList_2!=null) {
                    log.info("tFTPFileList_2 - Use an existing connection. Connection hostname: " +  ftp_tFTPFileList_2.getRemoteAddress().toString() + ", Connection port: " + ftp_tFTPFileList_2.getRemotePort() + ".");
                } 
    int nb_file_tFTPFileList_2 = 0;
    org.apache.commons.net.ftp.FTPFile[] ftpFiles_tFTPFileList_2 = null;
    String rootDir_tFTPFileList_2 = ftp_tFTPFileList_2.printWorkingDirectory();
    List<org.apache.commons.net.ftp.FTPFile> fileListTemp_tFTPFileList_2 = new java.util.ArrayList<>();

    String remotedir_tFTPFileList_2 = (context.Distant_Magistor_Clients_Input + ((String)globalMap.get("row20.Name")) + "/IN").replaceAll("\\\\","/");
    boolean cwdSuccess_tFTPFileList_2 = ftp_tFTPFileList_2.changeWorkingDirectory(remotedir_tFTPFileList_2);

    if (!cwdSuccess_tFTPFileList_2) {
        throw new RuntimeException("Failed to change remote directory. " + ftp_tFTPFileList_2.getReplyString());
    }

    ftpFiles_tFTPFileList_2 = ftp_tFTPFileList_2.listFiles();
	
	String[] nameLists_tFTPFileList_2 = ftp_tFTPFileList_2.listNames();
	List<String> nameListsTemp_tFTPFileList_2 = new java.util.ArrayList<>();
	
	


    for (String filemask_tFTPFileList_2 : maskList_tFTPFileList_2) {
        java.util.regex.Pattern fileNamePattern_tFTPFileList_2 = java.util.regex.Pattern.compile(filemask_tFTPFileList_2.replaceAll("\\.", "\\\\.").replaceAll("\\*", ".*"));
	
        if(nameLists_tFTPFileList_2 != null){
            for (String ftpFile_tFTPFileList_2 : nameLists_tFTPFileList_2) {
                if (fileNamePattern_tFTPFileList_2.matcher(ftpFile_tFTPFileList_2).matches()) {
                    nameListsTemp_tFTPFileList_2.add(ftpFile_tFTPFileList_2);
                }
            }
        }
    }

    String currentFilePath_tFTPFileList_2 = remotedir_tFTPFileList_2;
    if(!remotedir_tFTPFileList_2.endsWith("/")&&!remotedir_tFTPFileList_2.endsWith("\\")){
        currentFilePath_tFTPFileList_2 += "/";
    }
    for (String ftpFile_tFTPFileList_2 : nameListsTemp_tFTPFileList_2) {
        String currentFileName_tFTPFileList_2 = ftpFile_tFTPFileList_2;

            log.debug("tFTPFileList_2 - List file : '" + currentFilePath_tFTPFileList_2 + "' ."); 
        globalMap.put("tFTPFileList_2_CURRENT_FILE", currentFileName_tFTPFileList_2);
		
        globalMap.put("tFTPFileList_2_CURRENT_FILEPATH", currentFilePath_tFTPFileList_2 + currentFileName_tFTPFileList_2);

        nb_file_tFTPFileList_2++;

 



/**
 * [tFTPFileList_2 begin ] stop
 */
	
	/**
	 * [tFTPFileList_2 main ] start
	 */

	

	
	
	currentComponent="tFTPFileList_2";
	
	

 


	tos_count_tFTPFileList_2++;

/**
 * [tFTPFileList_2 main ] stop
 */
	
	/**
	 * [tFTPFileList_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPFileList_2";
	
	

 



/**
 * [tFTPFileList_2 process_data_begin ] stop
 */
	NB_ITERATE_tFTPFileExist_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate5", 1, "exec" + NB_ITERATE_tFTPFileExist_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFTPFileExist_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPFileExist_1", false);
		start_Hash.put("tFTPFileExist_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPFileExist_1";
	
	
		int tos_count_tFTPFileExist_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPFileExist_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPFileExist_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPFileExist_1 = new StringBuilder();
                    log4jParamters_tFTPFileExist_1.append("Parameters:");
                            log4jParamters_tFTPFileExist_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("CONNECTION" + " = " + "tFTPConnection_1");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("REMOTEDIR" + " = " + "context.Distant_Magistor_Clients_Input + ((String)globalMap.get(\"row20.Name\")) + \"/IN\"");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("MOVE_TO_THE_CURRENT_DIRECTORY" + " = " + "true");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("TARGETTYPE" + " = " + "FILE");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("FILENAME" + " = " + "((String)globalMap.get(\"tFTPFileList_2_CURRENT_FILE\"))");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                            log4jParamters_tFTPFileExist_1.append("IGNORE_FAILURE_AT_QUIT" + " = " + "false");
                        log4jParamters_tFTPFileExist_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPFileExist_1 - "  + (log4jParamters_tFTPFileExist_1) );
                    } 
                } 
            new BytesLimit65535_tFTPFileExist_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPFileExist_1", "tFTPFileExist_1", "tFTPFileExist");
				talendJobLogProcess(globalMap);
			}
			

 
        org.apache.commons.net.ftp.FTPClient ftp_tFTPFileExist_1 = null;
            ftp_tFTPFileExist_1 = (org.apache.commons.net.ftp.FTPClient) globalMap.get("conn_tFTPConnection_1");
                if(ftp_tFTPFileExist_1!=null) {
                    log.info("tFTPFileExist_1 - Use an existing connection. Connection hostname: " +  ftp_tFTPFileExist_1.getRemoteAddress().toString() + ", Connection port: " + ftp_tFTPFileExist_1.getRemotePort() + ".");
                }

 



/**
 * [tFTPFileExist_1 begin ] stop
 */
	
	/**
	 * [tFTPFileExist_1 main ] start
	 */

	

	
	
	currentComponent="tFTPFileExist_1";
	
	

	//change working dir and save root
	String remoteDir_tFTPFileExist_1 = (context.Distant_Magistor_Clients_Input + ((String)globalMap.get("row20.Name")) + "/IN").replaceAll("\\\\","/");
	String rootDir_tFTPFileExist_1 = ftp_tFTPFileExist_1.printWorkingDirectory();
	boolean cwdSuccess_tFTPFileExist_1 = ftp_tFTPFileExist_1.changeWorkingDirectory(remoteDir_tFTPFileExist_1);

	if (!cwdSuccess_tFTPFileExist_1) {
		throw new RuntimeException("Failed to change remote directory. " + ftp_tFTPFileExist_1.getReplyString());
	}
		String fileName_tFTPFileExist_1 = (((String)globalMap.get("tFTPFileList_2_CURRENT_FILE"))).replaceAll("\\\\","/");
		String dirName_tFTPFileExist_1 = null;
		boolean dirExist_tFTPFileExist_1 = false;
		boolean needDirChange_tFTPFileExist_1 = false;
		String[] allFileNames_tFTPFileExist_1 = null;

		if (fileName_tFTPFileExist_1.contains("/")) {
			needDirChange_tFTPFileExist_1 = true;
			//change directory if exist
			dirName_tFTPFileExist_1 = fileName_tFTPFileExist_1.substring(0, fileName_tFTPFileExist_1.lastIndexOf("/"));
			fileName_tFTPFileExist_1 = fileName_tFTPFileExist_1.substring(fileName_tFTPFileExist_1.lastIndexOf('/') + 1, fileName_tFTPFileExist_1.length());

			dirExist_tFTPFileExist_1 = ftp_tFTPFileExist_1.changeWorkingDirectory(dirName_tFTPFileExist_1);
			if (!dirExist_tFTPFileExist_1) {
				
					log.warn("Directory " + dirName_tFTPFileExist_1 + " doesn't exist. Can't seek for file " + fileName_tFTPFileExist_1);
				
			}
		}

		if (!needDirChange_tFTPFileExist_1 || dirExist_tFTPFileExist_1) {
			allFileNames_tFTPFileExist_1 = java.util.Arrays.stream(ftp_tFTPFileExist_1.listFiles()).filter(org.apache.commons.net.ftp.FTPFile::isFile).map(org.apache.commons.net.ftp.FTPFile::getName)
				.filter(fileName_tFTPFileExist_1::equals).toArray(String[]::new);
		}

		boolean fileExist_tFTPFileExist_1 = (null != allFileNames_tFTPFileExist_1) && (allFileNames_tFTPFileExist_1.length > 0);

		if (fileExist_tFTPFileExist_1) {
			
				log.debug("tFTPFileExist_1 - '" + ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")) + "' exists in the remote directory '"+ context.Distant_Magistor_Clients_Input + ((String)globalMap.get("row20.Name")) + "/IN" + "' .");
			
			globalMap.put("tFTPFileExist_1_EXISTS", true);
		} else {
			
				log.debug("tFTPFileExist_1 - '" + ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")) + "' doesn't exist in the remote directory '"+ context.Distant_Magistor_Clients_Input + ((String)globalMap.get("row20.Name")) + "/IN" + "' .");
			
			globalMap.put("tFTPFileExist_1_EXISTS", false);
		}

		globalMap.put("tFTPFileExist_1_FILENAME", ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")));

	ftp_tFTPFileExist_1.changeWorkingDirectory(rootDir_tFTPFileExist_1);
		ftp_tFTPFileExist_1.changeWorkingDirectory(remoteDir_tFTPFileExist_1);
 


	tos_count_tFTPFileExist_1++;

/**
 * [tFTPFileExist_1 main ] stop
 */
	
	/**
	 * [tFTPFileExist_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPFileExist_1";
	
	

 



/**
 * [tFTPFileExist_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPFileExist_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPFileExist_1";
	
	

 



/**
 * [tFTPFileExist_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPFileExist_1 end ] start
	 */

	

	
	
	currentComponent="tFTPFileExist_1";
	
	


 
                if(log.isDebugEnabled())
            log.debug("tFTPFileExist_1 - "  + ("Done.") );

ok_Hash.put("tFTPFileExist_1", true);
end_Hash.put("tFTPFileExist_1", System.currentTimeMillis());

   			if ((Boolean)globalMap.get("tFTPFileExist_1_EXISTS")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				tJava_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tFTPFileExist_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate5", 2, "exec" + NB_ITERATE_tFTPFileExist_1);
						}				
					




	
	/**
	 * [tFTPFileList_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPFileList_2";
	
	

 



/**
 * [tFTPFileList_2 process_data_end ] stop
 */
	
	/**
	 * [tFTPFileList_2 end ] start
	 */

	

	
	
	currentComponent="tFTPFileList_2";
	
	
}
globalMap.put("tFTPFileList_2_NB_FILE",nb_file_tFTPFileList_2);

	log.info("tFTPFileList_2 - Listed files count: " + nb_file_tFTPFileList_2  + ".");
 
                if(log.isDebugEnabled())
            log.debug("tFTPFileList_2 - "  + ("Done.") );

ok_Hash.put("tFTPFileList_2", true);
end_Hash.put("tFTPFileList_2", System.currentTimeMillis());




/**
 * [tFTPFileList_2 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tFTPFileList_2);
						}				
					




	
	/**
	 * [tFlowToIterate_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";
	
	

 



/**
 * [tFlowToIterate_3 process_data_end ] stop
 */

} // End of branch "row20"




	
	/**
	 * [tFileInputExcel_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		

 



/**
 * [tFileInputExcel_5 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_5 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		

			}
			
			
				log.debug("tFileInputExcel_5 - Retrieved records count: "+ nb_line_tFileInputExcel_5 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_5_NB_LINE",nb_line_tFileInputExcel_5);
		} finally {
				
  				if(!(source_tFileInputExcel_5 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_5.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_5 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_5", true);
end_Hash.put("tFileInputExcel_5", System.currentTimeMillis());




/**
 * [tFileInputExcel_5 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";
	
	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row20",2,0,
			 			"tFileInputExcel_5","tFileInputExcel_5<br> v\u00E9rification format fichier","tFileInputExcel","tFlowToIterate_3","tFlowToIterate_3","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk9", 0, "ok");
								} 
							
							tFileInputExcel_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_5 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_5";
	
	
			cLabel="tFileInputExcel_5<br> v\u00E9rification format fichier";
		

 



/**
 * [tFileInputExcel_5 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";
	
	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tFTPFileList_2 finally ] start
	 */

	

	
	
	currentComponent="tFTPFileList_2";
	
	

 



/**
 * [tFTPFileList_2 finally ] stop
 */

	
	/**
	 * [tFTPFileExist_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPFileExist_1";
	
	

 



/**
 * [tFTPFileExist_1 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_5_SUBPROCESS_STATE", 1);
	}
	


public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tJava_1");
		org.slf4j.MDC.put("_subJobPid", "fbkE8J_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";
	
	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_1", "tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			


String fileName = (String)globalMap.get("tFTPFileList_2_CURRENT_FILE");
String fileType = fileName != null && fileName.length() >= 3 ? fileName.substring(0,3) : fileName;
String fileFormat = fileType.matches("^(ART|CDC|REC)$") ? fileType : "(ART ou CDC ou CSV)";
String todayDate = (String)globalMap.get("input_today_date");
globalMap.put("unknown_format_found", false);

fileFormat += "01" + todayDate + context.Excel_File_Masque;
globalMap.put("currentFileFormat", fileFormat);
if (! fileName.matches("^(ART|CDC|REC)01" + todayDate + "\\" + context.Excel_File_Masque + "$"))
{globalMap.put("unknown_format_found", true);}
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

   			if ((Boolean)globalMap.get("unknown_format_found")) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				tSendMail_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public void tSendMail_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSendMail_2");
		org.slf4j.MDC.put("_subJobPid", "oOM0Uy_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSendMail_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_2", false);
		start_Hash.put("tSendMail_2", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_2";
	
	
		int tos_count_tSendMail_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSendMail_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSendMail_2 = new StringBuilder();
                    log4jParamters_tSendMail_2.append("Parameters:");
                            log4jParamters_tSendMail_2.append("TO" + " = " + "(String)globalMap.get(\"notificationMails\")");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("FROM" + " = " + "\"commandes.wms@ecolotrans.com\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("NEED_PERSONAL_NAME" + " = " + "true");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("PERSONAL_NAME" + " = " + "\"MAGISTOR - DATA TEAM\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("CC" + " = " + "(String)globalMap.get(\"row20.Mail\")");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("BCC" + " = " + "");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SUBJECT" + " = " + "\"MAGISTOR - FORMAT DE FICHIER INCONNU - \" + ((String)globalMap.get(\"row20.Name\"))");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("MESSAGE" + " = " + "\"<div style=\\\" padding: 5px ; \\\">\"+  \"<div style=\\\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \\\">\"+  \"<B style=\\\"font-size: 15px;\\\"><span style=\\\"color:#e1f5ee;   \\\">ECOLOTRANS</B>\" +  \"</div>\"+    \"<div style=\\\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \\\">\"+  \"<span style=\\\"padding-left:5% ;color: #1b1c1c; \\\">Bonjour ,</span> \"+  \"<p style=\\\"padding-left: 5%;color: #1b1c1c; \\\">Le fichier \" + ((String)globalMap.get(\"tFTPFileList_2_CURRENT_FILE\")) + \" dans le dossier 'IN' du client \" + ((String)globalMap.get(\"row20.Name\")) + \" ne sera pas traité car il a un format inconnu. Le nom du fichier doit suivre le format : \" + (String)globalMap.get(\"currentFileFormat\") + \"</p>\"+  \"<p  style=\\\"padding-left: 5%; color: #1b1c1c;\\\">Cordialement,</p>\"+  \"<p  style=\\\"padding-left: 5%; color: #1b1c1c;\\\"> </p>\"+  \"</div>\"+  \"</div>\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("CHECK_ATTACHMENT" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("ATTACHMENTS" + " = " + "[]");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("HEADERS" + " = " + "[]");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SMTP_HOST" + " = " + "\"smtp.office365.com\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SMTP_PORT" + " = " + "587");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SSL" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("STARTTLS" + " = " + "true");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("IMPORTANCE" + " = " + "High");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("AUTH_MODE" + " = " + "BASIC");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("AUTH_USERNAME" + " = " + "\"commandes.wms@ecolotrans.com\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("AUTH_PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:sb0lSu6GX/4ptU68quoYMBpzseVoa9o5X4CbECtJaW4V7HAd").substring(0, 4) + "...");     
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("TEXT_SUBTYPE" + " = " + "html");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("ENCODING" + " = " + "\"ISO-8859-1\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SET_LOCALHOST" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("CONFIGS" + " = " + "[]");
                        log4jParamters_tSendMail_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + (log4jParamters_tSendMail_2) );
                    } 
                } 
            new BytesLimit65535_tSendMail_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSendMail_2", "tSendMail_1", "tSendMail");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSendMail_2 begin ] stop
 */
	
	/**
	 * [tSendMail_2 main ] start
	 */

	

	
	
	currentComponent="tSendMail_2";
	
	

 

	String smtpHost_tSendMail_2 = "smtp.office365.com";
        String smtpPort_tSendMail_2 = "587";
	String from_tSendMail_2 = ("commandes.wms@ecolotrans.com");
    String to_tSendMail_2 = ((String)globalMap.get("notificationMails")).replace(";",",");
    String cc_tSendMail_2 = (((String)globalMap.get("row20.Mail"))==null || "".equals((String)globalMap.get("row20.Mail")))?null:((String)globalMap.get("row20.Mail")).replace(";",",");
    String bcc_tSendMail_2 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_2 = ("MAGISTOR - FORMAT DE FICHIER INCONNU - " + ((String)globalMap.get("row20.Name")));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_2 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_2 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_2 = new java.util.ArrayList<String>();

	String message_tSendMail_2 = (("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row20.Name")) + " ne sera pas traité car il a un format inconnu. Le nom du fichier doit suivre le format : " + (String)globalMap.get("currentFileFormat") + "</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>") == null || "".equals("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row20.Name")) + " ne sera pas traité car il a un format inconnu. Le nom du fichier doit suivre le format : " + (String)globalMap.get("currentFileFormat") + "</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>")) ? "\"\"" : ("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFTPFileList_2_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row20.Name")) + " ne sera pas traité car il a un format inconnu. Le nom du fichier doit suivre le format : " + (String)globalMap.get("currentFileFormat") + "</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>") ;
	java.util.Properties props_tSendMail_2 = System.getProperties();     
	props_tSendMail_2.put("mail.smtp.host", smtpHost_tSendMail_2);
	props_tSendMail_2.put("mail.smtp.port", smtpPort_tSendMail_2);
	
		props_tSendMail_2.put("mail.mime.encodefilename", "true");
		props_tSendMail_2.put("mail.smtp.starttls.enable","true");     
	try {
		
			log.info("tSendMail_2 - Connection attempt to '" + smtpHost_tSendMail_2 +"'.");
		
		
			props_tSendMail_2.put("mail.smtp.auth", "true");
			javax.mail.Session session_tSendMail_2 = javax.mail.Session.getInstance(props_tSendMail_2, new javax.mail.Authenticator(){         
				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				
                 
	final String decryptedPassword_tSendMail_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:lKCK2K7G7U5WCLHzk4nfVpV5/GnpSRyBrHMjxtkQlYLusPfY");
				
				
				return new javax.mail.PasswordAuthentication("commandes.wms@ecolotrans.com", decryptedPassword_tSendMail_2); 
				}         
			});   
		
		
			log.info("tSendMail_2 - Connection to '" + smtpHost_tSendMail_2 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_2 = new javax.mail.internet.MimeMessage(session_tSendMail_2);
		msg_tSendMail_2.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_2, "MAGISTOR - DATA TEAM"));
		msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_2, false));
		if (cc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_2, false));
		if (bcc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_2, false));
		msg_tSendMail_2.setSubject(subject_tSendMail_2);

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < headers_tSendMail_2.size(); i_tSendMail_2++) {
			java.util.Map<String, String> header_tSendMail_2 = headers_tSendMail_2.get(i_tSendMail_2);
			msg_tSendMail_2.setHeader(header_tSendMail_2.get("KEY"), header_tSendMail_2.get("VALUE"));    
		}  
		msg_tSendMail_2.setSentDate(new Date());
		msg_tSendMail_2.setHeader("X-Priority", "1"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_2 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_2.setText(message_tSendMail_2,"ISO-8859-1", "html");
		mp_tSendMail_2.addBodyPart(mbpText_tSendMail_2);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_2 = null;

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < attachments_tSendMail_2.size(); i_tSendMail_2++){
			String filename_tSendMail_2 = attachments_tSendMail_2.get(i_tSendMail_2);
			javax.activation.FileDataSource fds_tSendMail_2 = null;
			java.io.File file_tSendMail_2 = new java.io.File(filename_tSendMail_2);
			
				if (!file_tSendMail_2.exists()){
					continue;
				}
			
    		if (file_tSendMail_2.isDirectory()){
				java.io.File[] subFiles_tSendMail_2 = file_tSendMail_2.listFiles();
				for(java.io.File subFile_tSendMail_2 : subFiles_tSendMail_2){
					if (subFile_tSendMail_2.isFile()){
						fds_tSendMail_2 = new javax.activation.FileDataSource(subFile_tSendMail_2.getAbsolutePath());
						mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2));
						mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
						if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
					}
				}
    		}else{
				mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_2 = new javax.activation.FileDataSource(filename_tSendMail_2);
				mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2)); 
				mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
				if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
			}
		}
		// -- set the content --
		msg_tSendMail_2.setContent(mp_tSendMail_2);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_2 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_2.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_2.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_2.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_2.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_2.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_2);
		// add com.sun.mail.handlers to job imports / depenencies (TESB-27110)
		com.sun.mail.handlers.text_plain text_plain_h_tSendMail_2 = null;
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_2);
	} catch(java.lang.Exception e){
globalMap.put("tSendMail_2_ERROR_MESSAGE",e.getMessage());
  		
			throw(e);
		
	}finally{
		props_tSendMail_2.remove("mail.smtp.host");
		props_tSendMail_2.remove("mail.smtp.port");
		
		props_tSendMail_2.remove("mail.mime.encodefilename");
		
			props_tSendMail_2.remove("mail.smtp.starttls.enable");
		
		props_tSendMail_2.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_2++;

/**
 * [tSendMail_2 main ] stop
 */
	
	/**
	 * [tSendMail_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSendMail_2";
	
	

 



/**
 * [tSendMail_2 process_data_begin ] stop
 */
	
	/**
	 * [tSendMail_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";
	
	

 



/**
 * [tSendMail_2 process_data_end ] stop
 */
	
	/**
	 * [tSendMail_2 end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Done.") );

ok_Hash.put("tSendMail_2", true);
end_Hash.put("tSendMail_2", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				tSleep_2Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tSendMail_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_2 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_2";
	
	

 



/**
 * [tSendMail_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_2_SUBPROCESS_STATE", 1);
	}
	


public void tSleep_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSleep_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSleep_2");
		org.slf4j.MDC.put("_subJobPid", "coApYt_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSleep_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSleep_2", false);
		start_Hash.put("tSleep_2", System.currentTimeMillis());
		
	
	currentComponent="tSleep_2";
	
	
		int tos_count_tSleep_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSleep_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSleep_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSleep_2 = new StringBuilder();
                    log4jParamters_tSleep_2.append("Parameters:");
                            log4jParamters_tSleep_2.append("PAUSE" + " = " + "2");
                        log4jParamters_tSleep_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSleep_2 - "  + (log4jParamters_tSleep_2) );
                    } 
                } 
            new BytesLimit65535_tSleep_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSleep_2", "tSleep_1", "tSleep");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSleep_2 begin ] stop
 */
	
	/**
	 * [tSleep_2 main ] start
	 */

	

	
	
	currentComponent="tSleep_2";
	
	

    Thread.sleep((2)*1000);

 


	tos_count_tSleep_2++;

/**
 * [tSleep_2 main ] stop
 */
	
	/**
	 * [tSleep_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSleep_2";
	
	

 



/**
 * [tSleep_2 process_data_begin ] stop
 */
	
	/**
	 * [tSleep_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSleep_2";
	
	

 



/**
 * [tSleep_2 process_data_end ] stop
 */
	
	/**
	 * [tSleep_2 end ] start
	 */

	

	
	
	currentComponent="tSleep_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSleep_2 - "  + ("Done.") );

ok_Hash.put("tSleep_2", true);
end_Hash.put("tSleep_2", System.currentTimeMillis());




/**
 * [tSleep_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSleep_2 finally ] start
	 */

	

	
	
	currentComponent="tSleep_2";
	
	

 



/**
 * [tSleep_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSleep_2_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return true;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return null;
				}
				public Integer NamePrecision(){
				    return null;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public String Key;

				public String getKey () {
					return this.Key;
				}

				public Boolean KeyIsNullable(){
				    return true;
				}
				public Boolean KeyIsKey(){
				    return false;
				}
				public Integer KeyLength(){
				    return null;
				}
				public Integer KeyPrecision(){
				    return null;
				}
				public String KeyDefault(){
				
					return null;
				
				}
				public String KeyComment(){
				
				    return "";
				
				}
				public String KeyPattern(){
				
					return "";
				
				}
				public String KeyOriginalDbColumnName(){
				
					return "Key";
				
				}

				
			    public String Mail;

				public String getMail () {
					return this.Mail;
				}

				public Boolean MailIsNullable(){
				    return true;
				}
				public Boolean MailIsKey(){
				    return false;
				}
				public Integer MailLength(){
				    return null;
				}
				public Integer MailPrecision(){
				    return null;
				}
				public String MailDefault(){
				
					return null;
				
				}
				public String MailComment(){
				
				    return "";
				
				}
				public String MailPattern(){
				
					return "";
				
				}
				public String MailOriginalDbColumnName(){
				
					return "Mail";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Key = readString(dis);
					
					this.Mail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Key,dos);
					
					// String
				
						writeString(this.Mail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Key="+Key);
		sb.append(",Mail="+Mail);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Key);
            			}
            		
        			sb.append("|");
        		
        				if(Mail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Mail);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputExcel_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputExcel_4");
		org.slf4j.MDC.put("_subJobPid", "FuIU7s_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tFileList_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tFlowToIterate_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFlowToIterate_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFlowToIterate_2 = new StringBuilder();
                    log4jParamters_tFlowToIterate_2.append("Parameters:");
                            log4jParamters_tFlowToIterate_2.append("DEFAULT_MAP" + " = " + "true");
                        log4jParamters_tFlowToIterate_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + (log4jParamters_tFlowToIterate_2) );
                    } 
                } 
            new BytesLimit65535_tFlowToIterate_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_2", "tFlowToIterate_2", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_4", false);
		start_Hash.put("tFileInputExcel_4", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		
		int tos_count_tFileInputExcel_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_4 = new StringBuilder();
                    log4jParamters_tFileInputExcel_4.append("Parameters:");
                            log4jParamters_tFileInputExcel_4.append("VERSION_2007" + " = " + "true");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("FILENAME" + " = " + "context.Server_In + \"MagistorClients.xlsx\"");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:3sGNLG/bLaUbhDCDJ1qSEYeoxaj7E09nta8ZMA==").substring(0, 4) + "...");     
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("ALL_SHEETS" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("SHEETLIST" + " = " + "[{USE_REGEX="+("false")+", SHEETNAME="+("\"Clients\"")+"}]");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("TRIMALL" + " = " + "true");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("CONVERTDATETOSTRING" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("STOPREAD_ON_EMPTYROW" + " = " + "true");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("GENERATION_MODE" + " = " + "USER_MODE");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                            log4jParamters_tFileInputExcel_4.append("CONFIGURE_INFLATION_RATIO" + " = " + "false");
                        log4jParamters_tFileInputExcel_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_4 - "  + (log4jParamters_tFileInputExcel_4) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputExcel_4", "tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			

 
	final String decryptedPassword_tFileInputExcel_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:k+rF6o8OWw0tirlWadPDIK1Sl+RbHlKIabP4zw==");
        String password_tFileInputExcel_4 = decryptedPassword_tFileInputExcel_4;
        if (password_tFileInputExcel_4.isEmpty()){
            password_tFileInputExcel_4 = null;
        }
			class RegexUtil_tFileInputExcel_4 {

		    	public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

			        if(useRegex){//this part process the regex issue

				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				            String sheetName = sheet.getSheetName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	if(sheet != null){
				                	list.add((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
				                }
				            }
				        }

			        }else{
			        	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(org.apache.poi.xssf.usermodel.XSSFWorkbook workbook, int index, boolean useRegex) {
			    	java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list =  new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
			    	org.apache.poi.xssf.usermodel.XSSFSheet sheet = (org.apache.poi.xssf.usermodel.XSSFSheet) workbook.getSheetAt(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}
		RegexUtil_tFileInputExcel_4 regexUtil_tFileInputExcel_4 = new RegexUtil_tFileInputExcel_4();

		Object source_tFileInputExcel_4 = context.Server_In + "MagistorClients.xlsx";
		org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_4 = null;
		
		if(source_tFileInputExcel_4 instanceof String){
			workbook_tFileInputExcel_4 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create(new java.io.File((String)source_tFileInputExcel_4), password_tFileInputExcel_4, true);
		} else if(source_tFileInputExcel_4 instanceof java.io.InputStream) {
     		workbook_tFileInputExcel_4 = (org.apache.poi.xssf.usermodel.XSSFWorkbook) org.apache.poi.ss.usermodel.WorkbookFactory.create((java.io.InputStream)source_tFileInputExcel_4, password_tFileInputExcel_4);
		} else{
			workbook_tFileInputExcel_4 = null;
			throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
		}
		try {

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_4 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
        sheetList_tFileInputExcel_4.addAll(regexUtil_tFileInputExcel_4.getSheets(workbook_tFileInputExcel_4, "Clients", false));
    	if(sheetList_tFileInputExcel_4.size() <= 0){
            throw new RuntimeException("Special sheets not exist!");
        }

		java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_4 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
		for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_4 : sheetList_tFileInputExcel_4) {
			if(sheet_FilterNull_tFileInputExcel_4!=null && sheetList_FilterNull_tFileInputExcel_4.iterator()!=null && sheet_FilterNull_tFileInputExcel_4.iterator().hasNext()){
				sheetList_FilterNull_tFileInputExcel_4.add(sheet_FilterNull_tFileInputExcel_4);
			}
		}
		sheetList_tFileInputExcel_4 = sheetList_FilterNull_tFileInputExcel_4;
		int nb_line_tFileInputExcel_4 = 0;
	if(sheetList_tFileInputExcel_4.size()>0){

        int begin_line_tFileInputExcel_4 = 1;

        int footer_input_tFileInputExcel_4 = 0;

        int end_line_tFileInputExcel_4=0;
        for(org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_4:sheetList_tFileInputExcel_4){
			end_line_tFileInputExcel_4+=(sheet_tFileInputExcel_4.getLastRowNum()+1);
        }
        end_line_tFileInputExcel_4 -= footer_input_tFileInputExcel_4;
        int limit_tFileInputExcel_4 = -1;
        int start_column_tFileInputExcel_4 = 1-1;
        int end_column_tFileInputExcel_4 = -1;

        org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_4 = null;
        org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_4 = sheetList_tFileInputExcel_4.get(0);
        int rowCount_tFileInputExcel_4 = 0;
        int sheetIndex_tFileInputExcel_4 = 0;
        int currentRows_tFileInputExcel_4 = (sheetList_tFileInputExcel_4.get(0).getLastRowNum()+1);

		//for the number format
        java.text.DecimalFormat df_tFileInputExcel_4 = new java.text.DecimalFormat("#.####################################");
        char decimalChar_tFileInputExcel_4 = df_tFileInputExcel_4.getDecimalFormatSymbols().getDecimalSeparator();
						log.debug("tFileInputExcel_4 - Retrieving records from the datasource.");
			
        for(int i_tFileInputExcel_4 = begin_line_tFileInputExcel_4; i_tFileInputExcel_4 < end_line_tFileInputExcel_4; i_tFileInputExcel_4++){

        	int emptyColumnCount_tFileInputExcel_4 = 0;

        	if (limit_tFileInputExcel_4 != -1 && nb_line_tFileInputExcel_4 >= limit_tFileInputExcel_4) {
        		break;
        	}

            while (i_tFileInputExcel_4 >= rowCount_tFileInputExcel_4 + currentRows_tFileInputExcel_4) {
                rowCount_tFileInputExcel_4 += currentRows_tFileInputExcel_4;
                sheet_tFileInputExcel_4 = sheetList_tFileInputExcel_4.get(++sheetIndex_tFileInputExcel_4);
                currentRows_tFileInputExcel_4 = (sheet_tFileInputExcel_4.getLastRowNum()+1);
            }
            globalMap.put("tFileInputExcel_4_CURRENT_SHEET",sheet_tFileInputExcel_4.getSheetName());
            if (rowCount_tFileInputExcel_4 <= i_tFileInputExcel_4) {
                row_tFileInputExcel_4 = sheet_tFileInputExcel_4.getRow(i_tFileInputExcel_4 - rowCount_tFileInputExcel_4);
            }
		    row2 = null;
					int tempRowLength_tFileInputExcel_4 = 3;
				
				int columnIndex_tFileInputExcel_4 = 0;
			
			String[] temp_row_tFileInputExcel_4 = new String[tempRowLength_tFileInputExcel_4];
			int excel_end_column_tFileInputExcel_4;
			if(row_tFileInputExcel_4==null){
				excel_end_column_tFileInputExcel_4=0;
			}else{
				excel_end_column_tFileInputExcel_4=row_tFileInputExcel_4.getLastCellNum();
			}
			int actual_end_column_tFileInputExcel_4;
			if(end_column_tFileInputExcel_4 == -1){
				actual_end_column_tFileInputExcel_4 = excel_end_column_tFileInputExcel_4;
			}
			else{
				actual_end_column_tFileInputExcel_4 = end_column_tFileInputExcel_4 >	excel_end_column_tFileInputExcel_4 ? excel_end_column_tFileInputExcel_4 : end_column_tFileInputExcel_4;
			}
			org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_4 = null;
			for(int i=0;i<tempRowLength_tFileInputExcel_4;i++){
				if(i + start_column_tFileInputExcel_4 < actual_end_column_tFileInputExcel_4){
					org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_4 = row_tFileInputExcel_4.getCell(i + start_column_tFileInputExcel_4);
					if(cell_tFileInputExcel_4!=null){
					switch (cell_tFileInputExcel_4.getCellType()) {
                        case STRING:
                            temp_row_tFileInputExcel_4[i] = cell_tFileInputExcel_4.getRichStringCellValue().getString();
                            break;
                        case NUMERIC:
                            if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_4)) {
									temp_row_tFileInputExcel_4[i] =cell_tFileInputExcel_4.getDateCellValue().toString();
                            } else {
                                temp_row_tFileInputExcel_4[i] = df_tFileInputExcel_4.format(cell_tFileInputExcel_4.getNumericCellValue());
                            }
                            break;
                        case BOOLEAN:
                            temp_row_tFileInputExcel_4[i] =String.valueOf(cell_tFileInputExcel_4.getBooleanCellValue());
                            break;
                        case FORMULA:
        					switch (cell_tFileInputExcel_4.getCachedFormulaResultType()) {
                                case STRING:
                                    temp_row_tFileInputExcel_4[i] = cell_tFileInputExcel_4.getRichStringCellValue().getString();
                                    break;
                                case NUMERIC:
                                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell_tFileInputExcel_4)) {
											temp_row_tFileInputExcel_4[i] =cell_tFileInputExcel_4.getDateCellValue().toString();
                                    } else {
	                                    ne_tFileInputExcel_4 = new org.apache.poi.ss.formula.eval.NumberEval(cell_tFileInputExcel_4.getNumericCellValue());
										temp_row_tFileInputExcel_4[i] = ne_tFileInputExcel_4.getStringValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    temp_row_tFileInputExcel_4[i] =String.valueOf(cell_tFileInputExcel_4.getBooleanCellValue());
                                    break;
                                default:
                            		temp_row_tFileInputExcel_4[i] = "";
                            }
                            break;
                        default:
                            temp_row_tFileInputExcel_4[i] = "";
                        }
                	}
                	else{
                		temp_row_tFileInputExcel_4[i]="";
                	}

				}else{
					temp_row_tFileInputExcel_4[i]="";
				}
			}
			boolean whetherReject_tFileInputExcel_4 = false;
			row2 = new row2Struct();
			int curColNum_tFileInputExcel_4 = -1;
			String curColName_tFileInputExcel_4 = "";
			try{
							columnIndex_tFileInputExcel_4 = 0;
						
			if( temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim().length() > 0) {
				curColNum_tFileInputExcel_4=columnIndex_tFileInputExcel_4 + start_column_tFileInputExcel_4 + 1;
				curColName_tFileInputExcel_4 = "Name";

				row2.Name = temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim();
			}else{
				row2.Name = null;
				emptyColumnCount_tFileInputExcel_4++;
			}
							columnIndex_tFileInputExcel_4 = 1;
						
			if( temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim().length() > 0) {
				curColNum_tFileInputExcel_4=columnIndex_tFileInputExcel_4 + start_column_tFileInputExcel_4 + 1;
				curColName_tFileInputExcel_4 = "Key";

				row2.Key = temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim();
			}else{
				row2.Key = null;
				emptyColumnCount_tFileInputExcel_4++;
			}
							columnIndex_tFileInputExcel_4 = 2;
						
			if( temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim().length() > 0) {
				curColNum_tFileInputExcel_4=columnIndex_tFileInputExcel_4 + start_column_tFileInputExcel_4 + 1;
				curColName_tFileInputExcel_4 = "Mail";

				row2.Mail = temp_row_tFileInputExcel_4[columnIndex_tFileInputExcel_4].trim();
			}else{
				row2.Mail = null;
				emptyColumnCount_tFileInputExcel_4++;
			}

        if(emptyColumnCount_tFileInputExcel_4 >= 3){
        	break; //if meet the empty row, there will break the iterate.
        }
				nb_line_tFileInputExcel_4++;
				
				log.debug("tFileInputExcel_4 - Retrieving the record " + (nb_line_tFileInputExcel_4) + ".");
			
			}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_4_ERROR_MESSAGE",e.getMessage());
			whetherReject_tFileInputExcel_4 = true;
						log.error("tFileInputExcel_4 - " + e.getMessage());
					
					 System.err.println(e.getMessage());
					 row2 = null;
			}


		



 



/**
 * [tFileInputExcel_4 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_4 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		

 


	tos_count_tFileInputExcel_4++;

/**
 * [tFileInputExcel_4 main ] stop
 */
	
	/**
	 * [tFileInputExcel_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		

 



/**
 * [tFileInputExcel_4 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tFileInputExcel_4","tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel","tFileInputExcel","tFlowToIterate_2","tFlowToIterate_2","tFlowToIterate"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=row2.Name, value=")  + (row2.Name)  + (".") );            
            globalMap.put("row2.Name", row2.Name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=row2.Key, value=")  + (row2.Key)  + (".") );            
            globalMap.put("row2.Key", row2.Key);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=row2.Mail, value=")  + (row2.Mail)  + (".") );            
            globalMap.put("row2.Mail", row2.Mail);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_2)  + (".") );
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	
	/**
	 * [tFlowToIterate_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";
	
	

 



/**
 * [tFlowToIterate_2 process_data_begin ] stop
 */
	NB_ITERATE_tFileList_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tFileList_3);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileList_3 begin ] start
	 */

				
			int NB_ITERATE_tJava_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFileList_3", false);
		start_Hash.put("tFileList_3", System.currentTimeMillis());
		
	
	currentComponent="tFileList_3";
	
	
		int tos_count_tFileList_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileList_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileList_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileList_3 = new StringBuilder();
                    log4jParamters_tFileList_3.append("Parameters:");
                            log4jParamters_tFileList_3.append("DIRECTORY" + " = " + "context.Server_In + \"Magistor/\" + ((String)globalMap.get(\"row2.Name\"))");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("LIST_MODE" + " = " + "FILES");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("INCLUDSUBDIR" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("CASE_SENSITIVE" + " = " + "YES");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ERROR" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("GLOBEXPRESSIONS" + " = " + "true");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("FILES" + " = " + "[{FILEMASK="+("context.Art_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Cdc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}, {FILEMASK="+("context.Drc_masque + ((String)globalMap.get(\"input_today_date\")) + context.Excel_File_Masque")+"}]");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_BY_NOTHING" + " = " + "true");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_BY_FILENAME" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_BY_FILESIZE" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_BY_MODIFIEDDATE" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_ACTION_ASC" + " = " + "true");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("ORDER_ACTION_DESC" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("IFEXCLUDE" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                            log4jParamters_tFileList_3.append("FORMAT_FILEPATH_TO_SLASH" + " = " + "false");
                        log4jParamters_tFileList_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileList_3 - "  + (log4jParamters_tFileList_3) );
                    } 
                } 
            new BytesLimit65535_tFileList_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileList_3", "tFileList_1", "tFileList");
				talendJobLogProcess(globalMap);
			}
			
	
 
  
				final StringBuffer log4jSb_tFileList_3 = new StringBuffer();
			   
    
  String directory_tFileList_3 = context.Server_In + "Magistor/" + ((String)globalMap.get("row2.Name"));
  final java.util.List<String> maskList_tFileList_3 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_tFileList_3 = new java.util.ArrayList<java.util.regex.Pattern>(); 
    maskList_tFileList_3.add(context.Art_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_3.add(context.Cdc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque); 
    maskList_tFileList_3.add(context.Drc_masque + ((String)globalMap.get("input_today_date")) + context.Excel_File_Masque);  
  for (final String filemask_tFileList_3 : maskList_tFileList_3) {
	String filemask_compile_tFileList_3 = filemask_tFileList_3;
	
		filemask_compile_tFileList_3 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_tFileList_3.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_tFileList_3 = java.util.regex.Pattern.compile(filemask_compile_tFileList_3);
	patternList_tFileList_3.add(fileNamePattern_tFileList_3);
  }
  int NB_FILEtFileList_3 = 0;

  final boolean case_sensitive_tFileList_3 = true;
	
	
		log.info("tFileList_3 - Starting to search for matching entries.");
	
	
    final java.util.List<java.io.File> list_tFileList_3 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_tFileList_3 = new java.util.HashSet<String>();
	java.io.File file_tFileList_3 = new java.io.File(directory_tFileList_3);
     
		file_tFileList_3.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
                if (!file.isDirectory()) {
                	
    	String fileName_tFileList_3 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_tFileList_3 : patternList_tFileList_3) {
          	if (fileNamePattern_tFileList_3.matcher(fileName_tFileList_3).matches()){
					if(!filePath_tFileList_3.contains(file.getAbsolutePath())) {
			          list_tFileList_3.add(file);
			          filePath_tFileList_3.add(file.getAbsolutePath());
			        }
			}
		}
                }
              return true;
            }
          }
      ); 
      java.util.Collections.sort(list_tFileList_3);
    
		log.info("tFileList_3 - Start to list files.");
	
    for (int i_tFileList_3 = 0; i_tFileList_3 < list_tFileList_3.size(); i_tFileList_3++){
      java.io.File files_tFileList_3 = list_tFileList_3.get(i_tFileList_3);
      String fileName_tFileList_3 = files_tFileList_3.getName();
      
      String currentFileName_tFileList_3 = files_tFileList_3.getName(); 
      String currentFilePath_tFileList_3 = files_tFileList_3.getAbsolutePath();
      String currentFileDirectory_tFileList_3 = files_tFileList_3.getParent();
      String currentFileExtension_tFileList_3 = null;
      
      if (files_tFileList_3.getName().contains(".") && files_tFileList_3.isFile()){
        currentFileExtension_tFileList_3 = files_tFileList_3.getName().substring(files_tFileList_3.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_tFileList_3 = "";
      }
      
      NB_FILEtFileList_3 ++;
      globalMap.put("tFileList_3_CURRENT_FILE", currentFileName_tFileList_3);
      globalMap.put("tFileList_3_CURRENT_FILEPATH", currentFilePath_tFileList_3);
      globalMap.put("tFileList_3_CURRENT_FILEDIRECTORY", currentFileDirectory_tFileList_3);
      globalMap.put("tFileList_3_CURRENT_FILEEXTENSION", currentFileExtension_tFileList_3);
      globalMap.put("tFileList_3_NB_FILE", NB_FILEtFileList_3);
      
		log.info("tFileList_3 - Current file or directory path : " + currentFilePath_tFileList_3);
	  
 



/**
 * [tFileList_3 begin ] stop
 */
	
	/**
	 * [tFileList_3 main ] start
	 */

	

	
	
	currentComponent="tFileList_3";
	
	

 


	tos_count_tFileList_3++;

/**
 * [tFileList_3 main ] stop
 */
	
	/**
	 * [tFileList_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileList_3";
	
	

 



/**
 * [tFileList_3 process_data_begin ] stop
 */
	NB_ITERATE_tJava_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate9", 1, "exec" + NB_ITERATE_tJava_3);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";
	
	
		int tos_count_tJava_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_3", "tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			


String currentClient = (String)globalMap.get("row2.Name");
String magistorCdcClients = (String)globalMap.get("magistor_cdc_clients");
File inputFile = new File((String)globalMap.get("tFileList_3_CURRENT_FILEPATH"));
Workbook wb = WorkbookFactory.create(inputFile);
String error = "";
String fileType = ((String)globalMap.get("tFileList_3_CURRENT_FILE")).substring(0, 3);
HashMap<String,String> fileColumns = new HashMap<String,String>();
String fileSheets = "ART01-CND01;CDC01-LCD01;REC01-LRC01";
String currentFileSheets = "";
int nbSheets = wb.getNumberOfSheets();

// Nombre se feuilles
if (nbSheets != 2){
  error = " ne sera pas traité car il a un nombre de feuilles différent de 2. Ce fichier doit contenir respectivement les feuilles ";
  switch (fileType){
  case "ART" : error += fileSheets.split(";")[0].replaceAll("-", ",");break;
  case "CDC" : error += fileSheets.split(";")[1].replaceAll("-", ",");break;
  case "REC" : error += fileSheets.split(";")[2].replaceAll("-", ",");break;
  }
 }
else
 {
// Noms de feuilles
  for (int i=0; i< nbSheets; i++){
   currentFileSheets += (currentFileSheets.length() == 0 ? "" : "-") + wb.getSheetName(i);
  }
  System.out.println("- " + currentFileSheets);
  switch (fileType){
  case "ART" : error = fileSheets.split(";")[0].equals(currentFileSheets) ? "" : " ne sera pas traité. Il doit contenir respectivement les feuilles " + fileSheets.split(";")[0].replaceAll("-", ",");break;
  case "CDC" : error = fileSheets.split(";")[1].equals(currentFileSheets) ? "" : " ne sera pas traité. Il doit contenir respectivement les feuilles " + fileSheets.split(";")[1].replaceAll("-", ",");break;
  case "REC" : error = fileSheets.split(";")[2].equals(currentFileSheets) ? "" : " ne sera pas traité. Il doit contenir respectivement les feuilles " + fileSheets.split(";")[2].replaceAll("-", ",");break;
  }
 }
//Colonnes
if ("".equals(error))
{
fileColumns.put("ART01","17-OP_CODE;OP_ACTION;CODE_SOC;CODE_ARTICLE;REF_FOURNISSEUR;LIBELLE_ARTICLE;FAMILLE;VALEUR;GESTION_LOT;GESTION_DATE;GESTION_NS;LONGEUR_UNITAIRE;LARGEUR_UNITAIRE;HAUTEUR_UNITAIRE;EAN;IS_COUPE;SEUIL_BLOCAGE_PERIME");
fileColumns.put("CND01","11-OP_CODE;OP_ACTION;CODE_SOC;CODE_ARTICLE;TYPE_COND;QTE;POIDS;LONGEUR;LARGEUR;HAUTEUR;EAN");

if (magistorCdcClients.contains(currentClient))
{
fileColumns.put("CDC01","28-OP_CODE;OP_ACTION;CODE_SOC;N_CDE;TYPE_CDE;DATE_CDE;DATE_DDEE;HEURE_DDEE;NO_CLIENT;REF_CLIENT;AFAC_INDIVIDU;AFAC_RAISON_SOCIALE;AFAC_ADRESSE1;AFAC_CP;AFAC_VILLE;AFAC_PAYS;AFAC_TEL;AFAC_MAIL;ALIV_INDIVIDU;ALIV_RAISON_SOCIALE;ALIV_ADRESSE1;ALIV_CP;ALIV_VILLE;ALIV_PAYS;ALIV_TEL;ALIV_MAIL;TRANSPORTEUR;TOURNEE");


}

else{
fileColumns.put("CDC01","26-OP_CODE;OP_ACTION;CODE_SOC;N_CDE;TYPE_CDE;DATE_CDE;DATE_DDEE;HEURE_DDEE;NO_CLIENT;REF_CLIENT;AFAC_INDIVIDU;AFAC_RAISON_SOCIALE;AFAC_ADRESSE1;AFAC_CP;AFAC_VILLE;AFAC_PAYS;AFAC_TEL;AFAC_MAIL;ALIV_INDIVIDU;ALIV_RAISON_SOCIALE;ALIV_ADRESSE1;ALIV_CP;ALIV_VILLE;ALIV_PAYS;ALIV_TEL;ALIV_MAIL");


}

if (currentClient.equals("MY_BRAZIL_FACTORY"))
{

fileColumns.put("LCD01", "7-OP_CODE;OP_ACTION;CODE_SOC;N_CDE;CODE_ART;QTE_CDE;DLC");

}
else
{
fileColumns.put("LCD01","6-OP_CODE;OP_ACTION;CODE_SOC;N_CDE;CODE_ART;QTE_CDE");
}

fileColumns.put("REC01","8-OP_CODE;OP_ACTION;CODE_SOC;CODE_FRN;N_PIECE;TYPE_RECEP;REF_COMMANDE;DATE_ATTENDUE");
fileColumns.put("LRC01","5-OP_CODE;CODE_SOC;N_PIECE;CODE_ART;QTE_RECEP"); 
 for (int i=0; i< nbSheets; i++){
  if (wb.getSheetAt(i).getPhysicalNumberOfRows() != 0)
  {
  System.out.println("--> Nombre des colonnes dans la feuille : " +  wb.getSheetName(i) + " : " + wb.getSheetAt(i).getRow(0).getLastCellNum());
   if (wb.getSheetAt(i).getRow(0).getLastCellNum() != Integer.parseInt(fileColumns.get(wb.getSheetName(i)).split("-")[0])){
    error += "".equals(error) ? " ne sera pas traité car le nombre des colonnes dans la feuille " + wb.getSheetName(i) +" est différent de " + fileColumns.get(wb.getSheetName(i)).split("-")[0] : " et le nombre des colonnes dans la feuille " + wb.getSheetName(i) +" est différent de " + fileColumns.get(wb.getSheetName(i)).split("-")[0];
   }
   else{
    for (int j=0; j<wb.getSheetAt(i).getRow(0).getLastCellNum(); j++){
     if (wb.getSheetAt(i).getRow(0).getCell(j) != null && !fileColumns.get(wb.getSheetName(i)).split("-")[1].split(";")[j].equals(wb.getSheetAt(i).getRow(0).getCell(j).getStringCellValue())){
     if ("".equals(error)){
      error +=  " ne sera pas traité car l'ordre ou le nom des colonnes est incorrect dans la feuille " + wb.getSheetName(i);
     }
     else
     {
       error +=  error.contains("ordre") ? " et aussi dans la feuille " + wb.getSheetName(i) : " et l'ordre ou le nom des colonnes est incorrect dans la feuille " + wb.getSheetName(i);
     }
    
     break;
     }
    }
   }
  }
  else{
   error += "".equals(error) ? " ne sera pas traité car la feuille " + wb.getSheetName(i) + " est vide": " et la feuille " + wb.getSheetName(i) + " est vide"; 
  }
 }
}
System.out.println(error);
globalMap.put("error",error);
 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_begin ] stop
 */
	
	/**
	 * [tJava_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 process_data_end ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

   			if (!"".equals((String)globalMap.get("error"))) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				tSendMail_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}



/**
 * [tJava_3 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate9", 2, "exec" + NB_ITERATE_tJava_3);
						}				
					




	
	/**
	 * [tFileList_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileList_3";
	
	

 



/**
 * [tFileList_3 process_data_end ] stop
 */
	
	/**
	 * [tFileList_3 end ] start
	 */

	

	
	
	currentComponent="tFileList_3";
	
	

  
    }
  globalMap.put("tFileList_3_NB_FILE", NB_FILEtFileList_3);
  
    log.info("tFileList_3 - File or directory count : " + NB_FILEtFileList_3);

  
 

 
                if(log.isDebugEnabled())
            log.debug("tFileList_3 - "  + ("Done.") );

ok_Hash.put("tFileList_3", true);
end_Hash.put("tFileList_3", System.currentTimeMillis());




/**
 * [tFileList_3 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tFileList_3);
						}				
					




	
	/**
	 * [tFlowToIterate_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";
	
	

 



/**
 * [tFlowToIterate_2 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputExcel_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		

 



/**
 * [tFileInputExcel_4 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_4 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		

			}
			
			
				log.debug("tFileInputExcel_4 - Retrieved records count: "+ nb_line_tFileInputExcel_4 + " .");
			
			
			
				}
			

			globalMap.put("tFileInputExcel_4_NB_LINE",nb_line_tFileInputExcel_4);
		} finally {
				
  				if(!(source_tFileInputExcel_4 instanceof java.io.InputStream)){
  					workbook_tFileInputExcel_4.getPackage().revert();
  				}
				
		}	
		

 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_4 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_4", true);
end_Hash.put("tFileInputExcel_4", System.currentTimeMillis());




/**
 * [tFileInputExcel_4 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";
	
	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tFileInputExcel_4","tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel","tFileInputExcel","tFlowToIterate_2","tFlowToIterate_2","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tFTPClose_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_4 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_4";
	
	
			cLabel="tFileInputExcel_4<br>v\u00E9rifier la structure fichier excel";
		

 



/**
 * [tFileInputExcel_4 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";
	
	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tFileList_3 finally ] start
	 */

	

	
	
	currentComponent="tFileList_3";
	
	

 



/**
 * [tFileList_3 finally ] stop
 */

	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";
	
	

 



/**
 * [tJava_3 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_4_SUBPROCESS_STATE", 1);
	}
	


public void tSendMail_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSendMail_1");
		org.slf4j.MDC.put("_subJobPid", "u3vvch_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSendMail_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_1", false);
		start_Hash.put("tSendMail_1", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_1";
	
	
		int tos_count_tSendMail_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSendMail_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSendMail_1 = new StringBuilder();
                    log4jParamters_tSendMail_1.append("Parameters:");
                            log4jParamters_tSendMail_1.append("TO" + " = " + "(String)globalMap.get(\"notificationMails\")");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("FROM" + " = " + "\"commandes.wms@ecolotrans.com\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("NEED_PERSONAL_NAME" + " = " + "true");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("PERSONAL_NAME" + " = " + "\"MAGISTOR - DATA TEAM\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("CC" + " = " + "(String)globalMap.get(\"row2.Mail\")");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("BCC" + " = " + "");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SUBJECT" + " = " + "\"MAGISTOR - STRUCTURE DE FICHIER INVALIDE - \" + ((String)globalMap.get(\"row2.Name\"))");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("MESSAGE" + " = " + "\"<div style=\\\" padding: 5px ; \\\">\"+  \"<div style=\\\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \\\">\"+  \"<B style=\\\"font-size: 15px;\\\"><span style=\\\"color:#e1f5ee;   \\\">ECOLOTRANS</B>\" +  \"</div>\"+    \"<div style=\\\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \\\">\"+  \"<span style=\\\"padding-left:5% ;color: #1b1c1c; \\\">Bonjour ,</span> \"+  \"<p style=\\\"padding-left: 5%;color: #1b1c1c; \\\">Le fichier \" + ((String)globalMap.get(\"tFileList_3_CURRENT_FILE\")) + \" dans le dossier 'IN' du client \" + ((String)globalMap.get(\"row2.Name\")) + ((String)globalMap.get(\"error\")) + \".</p>\"+  \"<p  style=\\\"padding-left: 5%; color: #1b1c1c;\\\">Cordialement,</p>\"+  \"<p  style=\\\"padding-left: 5%; color: #1b1c1c;\\\"> </p>\"+  \"</div>\"+  \"</div>\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("CHECK_ATTACHMENT" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("ATTACHMENTS" + " = " + "[{CONTENT_TRANSFER_ENCODING="+("DEFAULT")+", FILE="+("(String)globalMap.get(\"tFileList_3_CURRENT_FILEPATH\")")+"}]");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("HEADERS" + " = " + "[]");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SMTP_HOST" + " = " + "\"smtp.office365.com\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SMTP_PORT" + " = " + "587");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SSL" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("STARTTLS" + " = " + "true");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("IMPORTANCE" + " = " + "High");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("AUTH_MODE" + " = " + "BASIC");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("AUTH_USERNAME" + " = " + "\"commandes.wms@ecolotrans.com\"  ");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("AUTH_PASSWORD" + " = " + String.valueOf("enc:routine.encryption.key.v1:Qb/mXUbSmHlN1AlxPkm0qLwzB7QE/AU7/6Q04v2VPKX5IHbq").substring(0, 4) + "...");     
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("TEXT_SUBTYPE" + " = " + "html");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("ENCODING" + " = " + "\"ISO-8859-1\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SET_LOCALHOST" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("CONFIGS" + " = " + "[]");
                        log4jParamters_tSendMail_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + (log4jParamters_tSendMail_1) );
                    } 
                } 
            new BytesLimit65535_tSendMail_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSendMail_1", "tSendMail_1", "tSendMail");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSendMail_1 begin ] stop
 */
	
	/**
	 * [tSendMail_1 main ] start
	 */

	

	
	
	currentComponent="tSendMail_1";
	
	

 

	String smtpHost_tSendMail_1 = "smtp.office365.com";
        String smtpPort_tSendMail_1 = "587";
	String from_tSendMail_1 = ("commandes.wms@ecolotrans.com");
    String to_tSendMail_1 = ((String)globalMap.get("notificationMails")).replace(";",",");
    String cc_tSendMail_1 = (((String)globalMap.get("row2.Mail"))==null || "".equals((String)globalMap.get("row2.Mail")))?null:((String)globalMap.get("row2.Mail")).replace(";",",");
    String bcc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_1 = ("MAGISTOR - STRUCTURE DE FICHIER INVALIDE - " + ((String)globalMap.get("row2.Name")));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_1 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_1 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_1 = new java.util.ArrayList<String>();
		attachments_tSendMail_1.add((String)globalMap.get("tFileList_3_CURRENT_FILEPATH"));
		contentTransferEncoding_tSendMail_1.add("DEFAULT");	

	String message_tSendMail_1 = (("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFileList_3_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row2.Name")) + ((String)globalMap.get("error")) + ".</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>") == null || "".equals("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFileList_3_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row2.Name")) + ((String)globalMap.get("error")) + ".</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>")) ? "\"\"" : ("<div style=\" padding: 5px ; \">"+
"<div style=\" width:80%;padding: 25px; background-color: #00a18e;  color: #f9fcf2;font-size: 14px \">"+
"<B style=\"font-size: 15px;\"><span style=\"color:#e1f5ee;   \">ECOLOTRANS</B>" +
"</div>"+

"<div style=\" width:80%;padding: 25px; background-color: #eaeef0;  font-size: 14px \">"+
"<span style=\"padding-left:5% ;color: #1b1c1c; \">Bonjour ,</span> "+
"<p style=\"padding-left: 5%;color: #1b1c1c; \">Le fichier " + ((String)globalMap.get("tFileList_3_CURRENT_FILE")) + " dans le dossier 'IN' du client " + ((String)globalMap.get("row2.Name")) + ((String)globalMap.get("error")) + ".</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\">Cordialement,</p>"+
"<p  style=\"padding-left: 5%; color: #1b1c1c;\"> </p>"+
"</div>"+
"</div>") ;
	java.util.Properties props_tSendMail_1 = System.getProperties();     
	props_tSendMail_1.put("mail.smtp.host", smtpHost_tSendMail_1);
	props_tSendMail_1.put("mail.smtp.port", smtpPort_tSendMail_1);
	
		props_tSendMail_1.put("mail.mime.encodefilename", "true");
		props_tSendMail_1.put("mail.smtp.starttls.enable","true");     
	try {
		
			log.info("tSendMail_1 - Connection attempt to '" + smtpHost_tSendMail_1 +"'.");
		
		
			props_tSendMail_1.put("mail.smtp.auth", "true");
			javax.mail.Session session_tSendMail_1 = javax.mail.Session.getInstance(props_tSendMail_1, new javax.mail.Authenticator(){         
				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				
                 
	final String decryptedPassword_tSendMail_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:a46le0N6+zCsbU/lOcQHYhCJF87QIbbAQ3hrQrCI6VoeE7cA");
				
				
				return new javax.mail.PasswordAuthentication("commandes.wms@ecolotrans.com"
, decryptedPassword_tSendMail_1); 
				}         
			});   
		
		
			log.info("tSendMail_1 - Connection to '" + smtpHost_tSendMail_1 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_1 = new javax.mail.internet.MimeMessage(session_tSendMail_1);
		msg_tSendMail_1.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_1, "MAGISTOR - DATA TEAM"));
		msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_1, false));
		if (cc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_1, false));
		if (bcc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_1, false));
		msg_tSendMail_1.setSubject(subject_tSendMail_1);

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < headers_tSendMail_1.size(); i_tSendMail_1++) {
			java.util.Map<String, String> header_tSendMail_1 = headers_tSendMail_1.get(i_tSendMail_1);
			msg_tSendMail_1.setHeader(header_tSendMail_1.get("KEY"), header_tSendMail_1.get("VALUE"));    
		}  
		msg_tSendMail_1.setSentDate(new Date());
		msg_tSendMail_1.setHeader("X-Priority", "1"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_1 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_1.setText(message_tSendMail_1,"ISO-8859-1", "html");
		mp_tSendMail_1.addBodyPart(mbpText_tSendMail_1);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_1 = null;

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < attachments_tSendMail_1.size(); i_tSendMail_1++){
			String filename_tSendMail_1 = attachments_tSendMail_1.get(i_tSendMail_1);
			javax.activation.FileDataSource fds_tSendMail_1 = null;
			java.io.File file_tSendMail_1 = new java.io.File(filename_tSendMail_1);
			
				if (!file_tSendMail_1.exists()){
					continue;
				}
			
    		if (file_tSendMail_1.isDirectory()){
				java.io.File[] subFiles_tSendMail_1 = file_tSendMail_1.listFiles();
				for(java.io.File subFile_tSendMail_1 : subFiles_tSendMail_1){
					if (subFile_tSendMail_1.isFile()){
						fds_tSendMail_1 = new javax.activation.FileDataSource(subFile_tSendMail_1.getAbsolutePath());
						mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1));
						mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
						if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
					}
				}
    		}else{
				mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_1 = new javax.activation.FileDataSource(filename_tSendMail_1);
				mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1)); 
				mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
				if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
			}
		}
		// -- set the content --
		msg_tSendMail_1.setContent(mp_tSendMail_1);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_1 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_1.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_1.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_1.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_1.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_1.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_1);
		// add com.sun.mail.handlers to job imports / depenencies (TESB-27110)
		com.sun.mail.handlers.text_plain text_plain_h_tSendMail_1 = null;
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_1);
	} catch(java.lang.Exception e){
globalMap.put("tSendMail_1_ERROR_MESSAGE",e.getMessage());
  		
			throw(e);
		
	}finally{
		props_tSendMail_1.remove("mail.smtp.host");
		props_tSendMail_1.remove("mail.smtp.port");
		
		props_tSendMail_1.remove("mail.mime.encodefilename");
		
			props_tSendMail_1.remove("mail.smtp.starttls.enable");
		
		props_tSendMail_1.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_1++;

/**
 * [tSendMail_1 main ] stop
 */
	
	/**
	 * [tSendMail_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSendMail_1";
	
	

 



/**
 * [tSendMail_1 process_data_begin ] stop
 */
	
	/**
	 * [tSendMail_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";
	
	

 



/**
 * [tSendMail_1 process_data_end ] stop
 */
	
	/**
	 * [tSendMail_1 end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Done.") );

ok_Hash.put("tSendMail_1", true);
end_Hash.put("tSendMail_1", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				tSleep_1Process(globalMap);
			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileDelete_3Process(globalMap);



/**
 * [tSendMail_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_1 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_1";
	
	

 



/**
 * [tSendMail_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_1_SUBPROCESS_STATE", 1);
	}
	


public void tSleep_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSleep_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tSleep_1");
		org.slf4j.MDC.put("_subJobPid", "xQ6QK3_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSleep_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSleep_1", false);
		start_Hash.put("tSleep_1", System.currentTimeMillis());
		
	
	currentComponent="tSleep_1";
	
	
		int tos_count_tSleep_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSleep_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSleep_1 = new StringBuilder();
                    log4jParamters_tSleep_1.append("Parameters:");
                            log4jParamters_tSleep_1.append("PAUSE" + " = " + "2");
                        log4jParamters_tSleep_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + (log4jParamters_tSleep_1) );
                    } 
                } 
            new BytesLimit65535_tSleep_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tSleep_1", "tSleep_1", "tSleep");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSleep_1 begin ] stop
 */
	
	/**
	 * [tSleep_1 main ] start
	 */

	

	
	
	currentComponent="tSleep_1";
	
	

    Thread.sleep((2)*1000);

 


	tos_count_tSleep_1++;

/**
 * [tSleep_1 main ] stop
 */
	
	/**
	 * [tSleep_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSleep_1";
	
	

 



/**
 * [tSleep_1 process_data_begin ] stop
 */
	
	/**
	 * [tSleep_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSleep_1";
	
	

 



/**
 * [tSleep_1 process_data_end ] stop
 */
	
	/**
	 * [tSleep_1 end ] start
	 */

	

	
	
	currentComponent="tSleep_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + ("Done.") );

ok_Hash.put("tSleep_1", true);
end_Hash.put("tSleep_1", System.currentTimeMillis());




/**
 * [tSleep_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSleep_1 finally ] start
	 */

	

	
	
	currentComponent="tSleep_1";
	
	

 



/**
 * [tSleep_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSleep_1_SUBPROCESS_STATE", 1);
	}
	


public void tFileDelete_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileDelete_3");
		org.slf4j.MDC.put("_subJobPid", "cHY6KV_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileDelete_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_3", false);
		start_Hash.put("tFileDelete_3", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_3";
	
	
		int tos_count_tFileDelete_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileDelete_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileDelete_3 = new StringBuilder();
                    log4jParamters_tFileDelete_3.append("Parameters:");
                            log4jParamters_tFileDelete_3.append("FILENAME" + " = " + "(String)globalMap.get(\"tFileList_3_CURRENT_FILEPATH\")");
                        log4jParamters_tFileDelete_3.append(" | ");
                            log4jParamters_tFileDelete_3.append("FAILON" + " = " + "true");
                        log4jParamters_tFileDelete_3.append(" | ");
                            log4jParamters_tFileDelete_3.append("FOLDER" + " = " + "false");
                        log4jParamters_tFileDelete_3.append(" | ");
                            log4jParamters_tFileDelete_3.append("FOLDER_FILE" + " = " + "false");
                        log4jParamters_tFileDelete_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + (log4jParamters_tFileDelete_3) );
                    } 
                } 
            new BytesLimit65535_tFileDelete_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileDelete_3", "tFileDelete_1", "tFileDelete");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tFileDelete_3 begin ] stop
 */
	
	/**
	 * [tFileDelete_3 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";
	
	

 

				final StringBuffer log4jSb_tFileDelete_3 = new StringBuffer();
			
class DeleteFoldertFileDelete_3{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_3=new java.io.File((String)globalMap.get("tFileList_3_CURRENT_FILEPATH"));
    if(file_tFileDelete_3.exists()&& file_tFileDelete_3.isFile()){
    	if(file_tFileDelete_3.delete()){
    		globalMap.put("tFileDelete_3_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_3 - File : "+ file_tFileDelete_3.getAbsolutePath() + " is deleted.");
		}else{
			globalMap.put("tFileDelete_3_CURRENT_STATUS", "No file deleted.");
				throw new RuntimeException("File " + file_tFileDelete_3.getAbsolutePath() + " can not be deleted.");
		}
	}else{
		globalMap.put("tFileDelete_3_CURRENT_STATUS", "File does not exist or is invalid.");
			throw new RuntimeException("File " + file_tFileDelete_3.getAbsolutePath() + " does not exist or is invalid or is not a file.");
	}
	globalMap.put("tFileDelete_3_DELETE_PATH",(String)globalMap.get("tFileList_3_CURRENT_FILEPATH"));
 


	tos_count_tFileDelete_3++;

/**
 * [tFileDelete_3 main ] stop
 */
	
	/**
	 * [tFileDelete_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";
	
	

 



/**
 * [tFileDelete_3 process_data_begin ] stop
 */
	
	/**
	 * [tFileDelete_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";
	
	

 



/**
 * [tFileDelete_3 process_data_end ] stop
 */
	
	/**
	 * [tFileDelete_3 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + ("Done.") );

ok_Hash.put("tFileDelete_3", true);
end_Hash.put("tFileDelete_3", System.currentTimeMillis());




/**
 * [tFileDelete_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_3 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";
	
	

 



/**
 * [tFileDelete_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_3_SUBPROCESS_STATE", 1);
	}
	


public void tFTPClose_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPClose_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPClose_4");
		org.slf4j.MDC.put("_subJobPid", "w6aSVR_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPClose_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPClose_4", false);
		start_Hash.put("tFTPClose_4", System.currentTimeMillis());
		
	
	currentComponent="tFTPClose_4";
	
	
		int tos_count_tFTPClose_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFTPClose_4", "tFTPClose_1", "tFTPClose");
				talendJobLogProcess(globalMap);
			}
			
	 Object connObj = globalMap.get("conn_tFTPConnection_1");
	 if (connObj != null) {
      try {
			
              org.apache.commons.net.ftp.FTPClient conn = (org.apache.commons.net.ftp.FTPClient) connObj;
              conn.logout();
              conn.disconnect();
			
      } catch (Exception e) {
           globalMap.put("tFTPClose_4_ERROR_MESSAGE", e.getMessage()); 
           throw e;
      }
  }
 



/**
 * [tFTPClose_4 begin ] stop
 */
	
	/**
	 * [tFTPClose_4 main ] start
	 */

	

	
	
	currentComponent="tFTPClose_4";
	
	

 


	tos_count_tFTPClose_4++;

/**
 * [tFTPClose_4 main ] stop
 */
	
	/**
	 * [tFTPClose_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPClose_4";
	
	

 



/**
 * [tFTPClose_4 process_data_begin ] stop
 */
	
	/**
	 * [tFTPClose_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPClose_4";
	
	

 



/**
 * [tFTPClose_4 process_data_end ] stop
 */
	
	/**
	 * [tFTPClose_4 end ] start
	 */

	

	
	
	currentComponent="tFTPClose_4";
	
	

 

ok_Hash.put("tFTPClose_4", true);
end_Hash.put("tFTPClose_4", System.currentTimeMillis());




/**
 * [tFTPClose_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFTPClose_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tWarn_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPClose_4 finally ] start
	 */

	

	
	
	currentComponent="tFTPClose_4";
	
	
	 Object connObj = globalMap.get("conn_tFTPConnection_1");
	 if (connObj != null) {   
              org.apache.commons.net.ftp.FTPClient conn = (org.apache.commons.net.ftp.FTPClient) connObj;
              conn.disconnect();
     
  }
 



/**
 * [tFTPClose_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPClose_4_SUBPROCESS_STATE", 1);
	}
	


public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tWarn_2");
		org.slf4j.MDC.put("_subJobPid", "z271aK_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";
	
	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tWarn_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
                    log4jParamters_tWarn_2.append("Parameters:");
                            log4jParamters_tWarn_2.append("MESSAGE" + " = " + "jobName + \" ENDED\"");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("CODE" + " = " + "42");
                        log4jParamters_tWarn_2.append(" | ");
                            log4jParamters_tWarn_2.append("PRIORITY" + " = " + "4");
                        log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
                    } 
                } 
            new BytesLimit65535_tWarn_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tWarn_2", "tWarn_2", "tWarn");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

		
try {
	
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "WARN","",jobName + " ENDED","", "");
            log.warn("tWarn_2 - "  + ("Message: ")  + (jobName + " ENDED")  + (". Code: ")  + (42) );
	globalMap.put("tWarn_2_WARN_MESSAGES", jobName + " ENDED"); 
	globalMap.put("tWarn_2_WARN_PRIORITY", 4);
	globalMap.put("tWarn_2_WARN_CODE", 42);
	
} catch (Exception e_tWarn_2) {
globalMap.put("tWarn_2_ERROR_MESSAGE",e_tWarn_2.getMessage());
	logIgnoredError(String.format("tWarn_2 - tWarn failed to log message due to internal error: %s", e_tWarn_2), e_tWarn_2);
}


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_begin ] stop
 */
	
	/**
	 * [tWarn_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 process_data_end ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";
	
	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "GGvocW_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILESClass = new Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES();

        int exitCode = Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILESClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_zbxZFHZ4Ee6j9cQuSh5lZA");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-04-18T11:49:14.306389300Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.class.getClassLoader().getResourceAsStream("aliv2_v1_ecolotrans_wms_prod_orchestrator/massi_ecolotrans_wms_verify_input_files_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Billing_BSO_Months", "id_String");
                        if(context.getStringValue("Billing_BSO_Months") == null) {
                            context.Billing_BSO_Months = null;
                        } else {
                            context.Billing_BSO_Months=(String) context.getProperty("Billing_BSO_Months");
                        }
                        context.setContextType("Billing_BSO_Start_Year", "id_Integer");
                        if(context.getStringValue("Billing_BSO_Start_Year") == null) {
                            context.Billing_BSO_Start_Year = null;
                        } else {
                            try{
                                context.Billing_BSO_Start_Year=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Billing_BSO_Start_Year"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_BSO_Start_Year", e.getMessage()));
                                context.Billing_BSO_Start_Year=null;
                            }
                        }
                        context.setContextType("Billing_Comptabilite_File", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_File") == null) {
                            context.Billing_Comptabilite_File = null;
                        } else {
                            context.Billing_Comptabilite_File=(String) context.getProperty("Billing_Comptabilite_File");
                        }
                        context.setContextType("Billing_Comptabilite_Folder", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_Folder") == null) {
                            context.Billing_Comptabilite_Folder = null;
                        } else {
                            context.Billing_Comptabilite_Folder=(String) context.getProperty("Billing_Comptabilite_Folder");
                        }
                        context.setContextType("Billing_Distant_Rep", "id_String");
                        if(context.getStringValue("Billing_Distant_Rep") == null) {
                            context.Billing_Distant_Rep = null;
                        } else {
                            context.Billing_Distant_Rep=(String) context.getProperty("Billing_Distant_Rep");
                        }
                        context.setContextType("Billing_File_Masque", "id_String");
                        if(context.getStringValue("Billing_File_Masque") == null) {
                            context.Billing_File_Masque = null;
                        } else {
                            context.Billing_File_Masque=(String) context.getProperty("Billing_File_Masque");
                        }
                        context.setContextType("Billing_Local_Rep", "id_String");
                        if(context.getStringValue("Billing_Local_Rep") == null) {
                            context.Billing_Local_Rep = null;
                        } else {
                            context.Billing_Local_Rep=(String) context.getProperty("Billing_Local_Rep");
                        }
                        context.setContextType("Billing_Name", "id_String");
                        if(context.getStringValue("Billing_Name") == null) {
                            context.Billing_Name = null;
                        } else {
                            context.Billing_Name=(String) context.getProperty("Billing_Name");
                        }
                        context.setContextType("Billing_Start_Number", "id_Integer");
                        if(context.getStringValue("Billing_Start_Number") == null) {
                            context.Billing_Start_Number = null;
                        } else {
                            try{
                                context.Billing_Start_Number=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Billing_Start_Number"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_Start_Number", e.getMessage()));
                                context.Billing_Start_Number=null;
                            }
                        }
                        context.setContextType("Billing_TVA_default_value", "id_Float");
                        if(context.getStringValue("Billing_TVA_default_value") == null) {
                            context.Billing_TVA_default_value = null;
                        } else {
                            try{
                                context.Billing_TVA_default_value=routines.system.ParserUtils.parseTo_Float (context.getProperty("Billing_TVA_default_value"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_TVA_default_value", e.getMessage()));
                                context.Billing_TVA_default_value=null;
                            }
                        }
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("ODS_Database", "id_String");
                        if(context.getStringValue("ODS_Database") == null) {
                            context.ODS_Database = null;
                        } else {
                            context.ODS_Database=(String) context.getProperty("ODS_Database");
                        }
                        context.setContextType("PBI_Database", "id_String");
                        if(context.getStringValue("PBI_Database") == null) {
                            context.PBI_Database = null;
                        } else {
                            context.PBI_Database=(String) context.getProperty("PBI_Database");
                        }
                        context.setContextType("PBI_PC_Database", "id_String");
                        if(context.getStringValue("PBI_PC_Database") == null) {
                            context.PBI_PC_Database = null;
                        } else {
                            context.PBI_PC_Database=(String) context.getProperty("PBI_PC_Database");
                        }
                        context.setContextType("PBI_RT_Database", "id_String");
                        if(context.getStringValue("PBI_RT_Database") == null) {
                            context.PBI_RT_Database = null;
                        } else {
                            context.PBI_RT_Database=(String) context.getProperty("PBI_RT_Database");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("DataMart_Clean_Database", "id_String");
                        if(context.getStringValue("DataMart_Clean_Database") == null) {
                            context.DataMart_Clean_Database = null;
                        } else {
                            context.DataMart_Clean_Database=(String) context.getProperty("DataMart_Clean_Database");
                        }
                        context.setContextType("DataMart_Clean_Max_Date", "id_String");
                        if(context.getStringValue("DataMart_Clean_Max_Date") == null) {
                            context.DataMart_Clean_Max_Date = null;
                        } else {
                            context.DataMart_Clean_Max_Date=(String) context.getProperty("DataMart_Clean_Max_Date");
                        }
                        context.setContextType("DataMart_Clean_Min_Date", "id_String");
                        if(context.getStringValue("DataMart_Clean_Min_Date") == null) {
                            context.DataMart_Clean_Min_Date = null;
                        } else {
                            context.DataMart_Clean_Min_Date=(String) context.getProperty("DataMart_Clean_Min_Date");
                        }
                        context.setContextType("DataMart_Closure_Date_PlusX", "id_Integer");
                        if(context.getStringValue("DataMart_Closure_Date_PlusX") == null) {
                            context.DataMart_Closure_Date_PlusX = null;
                        } else {
                            try{
                                context.DataMart_Closure_Date_PlusX=routines.system.ParserUtils.parseTo_Integer (context.getProperty("DataMart_Closure_Date_PlusX"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "DataMart_Closure_Date_PlusX", e.getMessage()));
                                context.DataMart_Closure_Date_PlusX=null;
                            }
                        }
                        context.setContextType("Limit_Percent", "id_Integer");
                        if(context.getStringValue("Limit_Percent") == null) {
                            context.Limit_Percent = null;
                        } else {
                            try{
                                context.Limit_Percent=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Limit_Percent"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Limit_Percent", e.getMessage()));
                                context.Limit_Percent=null;
                            }
                        }
                        context.setContextType("Logistic_Max_Date_Plus_One", "id_String");
                        if(context.getStringValue("Logistic_Max_Date_Plus_One") == null) {
                            context.Logistic_Max_Date_Plus_One = null;
                        } else {
                            context.Logistic_Max_Date_Plus_One=(String) context.getProperty("Logistic_Max_Date_Plus_One");
                        }
                        context.setContextType("Logistic_Min_Date_Minus_One", "id_String");
                        if(context.getStringValue("Logistic_Min_Date_Minus_One") == null) {
                            context.Logistic_Min_Date_Minus_One = null;
                        } else {
                            context.Logistic_Min_Date_Minus_One=(String) context.getProperty("Logistic_Min_Date_Minus_One");
                        }
                        context.setContextType("deleted_J_minus_X", "id_Integer");
                        if(context.getStringValue("deleted_J_minus_X") == null) {
                            context.deleted_J_minus_X = null;
                        } else {
                            try{
                                context.deleted_J_minus_X=routines.system.ParserUtils.parseTo_Integer (context.getProperty("deleted_J_minus_X"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "deleted_J_minus_X", e.getMessage()));
                                context.deleted_J_minus_X=null;
                            }
                        }
                        context.setContextType("deleted_J_plusOne_X", "id_Integer");
                        if(context.getStringValue("deleted_J_plusOne_X") == null) {
                            context.deleted_J_plusOne_X = null;
                        } else {
                            try{
                                context.deleted_J_plusOne_X=routines.system.ParserUtils.parseTo_Integer (context.getProperty("deleted_J_plusOne_X"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "deleted_J_plusOne_X", e.getMessage()));
                                context.deleted_J_plusOne_X=null;
                            }
                        }
                        context.setContextType("FTP_DistantRep", "id_Directory");
                        if(context.getStringValue("FTP_DistantRep") == null) {
                            context.FTP_DistantRep = null;
                        } else {
                            context.FTP_DistantRep=(String) context.getProperty("FTP_DistantRep");
                        }
                        context.setContextType("FTP_FileMasque", "id_String");
                        if(context.getStringValue("FTP_FileMasque") == null) {
                            context.FTP_FileMasque = null;
                        } else {
                            context.FTP_FileMasque=(String) context.getProperty("FTP_FileMasque");
                        }
                        context.setContextType("FTP_Hote", "id_String");
                        if(context.getStringValue("FTP_Hote") == null) {
                            context.FTP_Hote = null;
                        } else {
                            context.FTP_Hote=(String) context.getProperty("FTP_Hote");
                        }
                        context.setContextType("FTP_Password", "id_Password");
                        if(context.getStringValue("FTP_Password") == null) {
                            context.FTP_Password = null;
                        } else {
                            String pwd_FTP_Password_value = context.getProperty("FTP_Password");
                            context.FTP_Password = null;
                            if(pwd_FTP_Password_value!=null) {
                                if(context_param.containsKey("FTP_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.FTP_Password = pwd_FTP_Password_value;
                                } else if (!pwd_FTP_Password_value.isEmpty()) {
                                    try {
                                        context.FTP_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_FTP_Password_value);
                                        context.put("FTP_Password",context.FTP_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("FTP_Port", "id_Integer");
                        if(context.getStringValue("FTP_Port") == null) {
                            context.FTP_Port = null;
                        } else {
                            try{
                                context.FTP_Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("FTP_Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "FTP_Port", e.getMessage()));
                                context.FTP_Port=null;
                            }
                        }
                        context.setContextType("FTP_ST_DistantRep", "id_String");
                        if(context.getStringValue("FTP_ST_DistantRep") == null) {
                            context.FTP_ST_DistantRep = null;
                        } else {
                            context.FTP_ST_DistantRep=(String) context.getProperty("FTP_ST_DistantRep");
                        }
                        context.setContextType("FTP_User", "id_String");
                        if(context.getStringValue("FTP_User") == null) {
                            context.FTP_User = null;
                        } else {
                            context.FTP_User=(String) context.getProperty("FTP_User");
                        }
                        context.setContextType("FTP_Wms_Port", "id_Integer");
                        if(context.getStringValue("FTP_Wms_Port") == null) {
                            context.FTP_Wms_Port = null;
                        } else {
                            try{
                                context.FTP_Wms_Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("FTP_Wms_Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "FTP_Wms_Port", e.getMessage()));
                                context.FTP_Wms_Port=null;
                            }
                        }
                        context.setContextType("keyStore_file_name", "id_String");
                        if(context.getStringValue("keyStore_file_name") == null) {
                            context.keyStore_file_name = null;
                        } else {
                            context.keyStore_file_name=(String) context.getProperty("keyStore_file_name");
                        }
                        context.setContextType("KeyStore_Repo", "id_String");
                        if(context.getStringValue("KeyStore_Repo") == null) {
                            context.KeyStore_Repo = null;
                        } else {
                            context.KeyStore_Repo=(String) context.getProperty("KeyStore_Repo");
                        }
                        context.setContextType("mail_password", "id_String");
                        if(context.getStringValue("mail_password") == null) {
                            context.mail_password = null;
                        } else {
                            context.mail_password=(String) context.getProperty("mail_password");
                        }
                        context.setContextType("send_mail_from", "id_String");
                        if(context.getStringValue("send_mail_from") == null) {
                            context.send_mail_from = null;
                        } else {
                            context.send_mail_from=(String) context.getProperty("send_mail_from");
                        }
                        context.setContextType("send_mail_to", "id_String");
                        if(context.getStringValue("send_mail_to") == null) {
                            context.send_mail_to = null;
                        } else {
                            context.send_mail_to=(String) context.getProperty("send_mail_to");
                        }
                        context.setContextType("send_to_second_mail", "id_String");
                        if(context.getStringValue("send_to_second_mail") == null) {
                            context.send_to_second_mail = null;
                        } else {
                            context.send_to_second_mail=(String) context.getProperty("send_to_second_mail");
                        }
                        context.setContextType("send_to_third_mail", "id_String");
                        if(context.getStringValue("send_to_third_mail") == null) {
                            context.send_to_third_mail = null;
                        } else {
                            context.send_to_third_mail=(String) context.getProperty("send_to_third_mail");
                        }
                        context.setContextType("Clients_Masque", "id_String");
                        if(context.getStringValue("Clients_Masque") == null) {
                            context.Clients_Masque = null;
                        } else {
                            context.Clients_Masque=(String) context.getProperty("Clients_Masque");
                        }
                        context.setContextType("Code_client_masque", "id_String");
                        if(context.getStringValue("Code_client_masque") == null) {
                            context.Code_client_masque = null;
                        } else {
                            context.Code_client_masque=(String) context.getProperty("Code_client_masque");
                        }
                        context.setContextType("Command_Logistic_Invalid_Date", "id_String");
                        if(context.getStringValue("Command_Logistic_Invalid_Date") == null) {
                            context.Command_Logistic_Invalid_Date = null;
                        } else {
                            context.Command_Logistic_Invalid_Date=(String) context.getProperty("Command_Logistic_Invalid_Date");
                        }
                        context.setContextType("Command_Logistic_Masque", "id_String");
                        if(context.getStringValue("Command_Logistic_Masque") == null) {
                            context.Command_Logistic_Masque = null;
                        } else {
                            context.Command_Logistic_Masque=(String) context.getProperty("Command_Logistic_Masque");
                        }
                        context.setContextType("Command_Transport_Masque", "id_String");
                        if(context.getStringValue("Command_Transport_Masque") == null) {
                            context.Command_Transport_Masque = null;
                        } else {
                            context.Command_Transport_Masque=(String) context.getProperty("Command_Transport_Masque");
                        }
                        context.setContextType("Command_Transport_Masque_Express", "id_String");
                        if(context.getStringValue("Command_Transport_Masque_Express") == null) {
                            context.Command_Transport_Masque_Express = null;
                        } else {
                            context.Command_Transport_Masque_Express=(String) context.getProperty("Command_Transport_Masque_Express");
                        }
                        context.setContextType("Ecolotrans_JP", "id_String");
                        if(context.getStringValue("Ecolotrans_JP") == null) {
                            context.Ecolotrans_JP = null;
                        } else {
                            context.Ecolotrans_JP=(String) context.getProperty("Ecolotrans_JP");
                        }
                        context.setContextType("Holiday_Days_Masque", "id_String");
                        if(context.getStringValue("Holiday_Days_Masque") == null) {
                            context.Holiday_Days_Masque = null;
                        } else {
                            context.Holiday_Days_Masque=(String) context.getProperty("Holiday_Days_Masque");
                        }
                        context.setContextType("Livraisons_Exception", "id_String");
                        if(context.getStringValue("Livraisons_Exception") == null) {
                            context.Livraisons_Exception = null;
                        } else {
                            context.Livraisons_Exception=(String) context.getProperty("Livraisons_Exception");
                        }
                        context.setContextType("Livraisons_Masque", "id_String");
                        if(context.getStringValue("Livraisons_Masque") == null) {
                            context.Livraisons_Masque = null;
                        } else {
                            context.Livraisons_Masque=(String) context.getProperty("Livraisons_Masque");
                        }
                        context.setContextType("Livraisons_Ok", "id_String");
                        if(context.getStringValue("Livraisons_Ok") == null) {
                            context.Livraisons_Ok = null;
                        } else {
                            context.Livraisons_Ok=(String) context.getProperty("Livraisons_Ok");
                        }
                        context.setContextType("ST_Drivers", "id_String");
                        if(context.getStringValue("ST_Drivers") == null) {
                            context.ST_Drivers = null;
                        } else {
                            context.ST_Drivers=(String) context.getProperty("ST_Drivers");
                        }
                        context.setContextType("Tarification_Logistic_Masque", "id_String");
                        if(context.getStringValue("Tarification_Logistic_Masque") == null) {
                            context.Tarification_Logistic_Masque = null;
                        } else {
                            context.Tarification_Logistic_Masque=(String) context.getProperty("Tarification_Logistic_Masque");
                        }
                        context.setContextType("Tarification_Transport_Masque", "id_String");
                        if(context.getStringValue("Tarification_Transport_Masque") == null) {
                            context.Tarification_Transport_Masque = null;
                        } else {
                            context.Tarification_Transport_Masque=(String) context.getProperty("Tarification_Transport_Masque");
                        }
                        context.setContextType("Tournee_Masque", "id_String");
                        if(context.getStringValue("Tournee_Masque") == null) {
                            context.Tournee_Masque = null;
                        } else {
                            context.Tournee_Masque=(String) context.getProperty("Tournee_Masque");
                        }
                        context.setContextType("TVA_Exceptions", "id_String");
                        if(context.getStringValue("TVA_Exceptions") == null) {
                            context.TVA_Exceptions = null;
                        } else {
                            context.TVA_Exceptions=(String) context.getProperty("TVA_Exceptions");
                        }
                        context.setContextType("Backup", "id_String");
                        if(context.getStringValue("Backup") == null) {
                            context.Backup = null;
                        } else {
                            context.Backup=(String) context.getProperty("Backup");
                        }
                        context.setContextType("Server_Clean", "id_String");
                        if(context.getStringValue("Server_Clean") == null) {
                            context.Server_Clean = null;
                        } else {
                            context.Server_Clean=(String) context.getProperty("Server_Clean");
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Server_Out", "id_String");
                        if(context.getStringValue("Server_Out") == null) {
                            context.Server_Out = null;
                        } else {
                            context.Server_Out=(String) context.getProperty("Server_Out");
                        }
                        context.setContextType("Server_Out_DataMart", "id_String");
                        if(context.getStringValue("Server_Out_DataMart") == null) {
                            context.Server_Out_DataMart = null;
                        } else {
                            context.Server_Out_DataMart=(String) context.getProperty("Server_Out_DataMart");
                        }
                        context.setContextType("Art_masque", "id_String");
                        if(context.getStringValue("Art_masque") == null) {
                            context.Art_masque = null;
                        } else {
                            context.Art_masque=(String) context.getProperty("Art_masque");
                        }
                        context.setContextType("Cdc_masque", "id_String");
                        if(context.getStringValue("Cdc_masque") == null) {
                            context.Cdc_masque = null;
                        } else {
                            context.Cdc_masque=(String) context.getProperty("Cdc_masque");
                        }
                        context.setContextType("Cre_masque", "id_String");
                        if(context.getStringValue("Cre_masque") == null) {
                            context.Cre_masque = null;
                        } else {
                            context.Cre_masque=(String) context.getProperty("Cre_masque");
                        }
                        context.setContextType("Crp_masque", "id_String");
                        if(context.getStringValue("Crp_masque") == null) {
                            context.Crp_masque = null;
                        } else {
                            context.Crp_masque=(String) context.getProperty("Crp_masque");
                        }
                        context.setContextType("Crr_masque", "id_String");
                        if(context.getStringValue("Crr_masque") == null) {
                            context.Crr_masque = null;
                        } else {
                            context.Crr_masque=(String) context.getProperty("Crr_masque");
                        }
                        context.setContextType("Distant_Magistor_Clients_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor_Clients_Input") == null) {
                            context.Distant_Magistor_Clients_Input = null;
                        } else {
                            context.Distant_Magistor_Clients_Input=(String) context.getProperty("Distant_Magistor_Clients_Input");
                        }
                        context.setContextType("Distant_Magistor_Clients_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor_Clients_Test_Input") == null) {
                            context.Distant_Magistor_Clients_Test_Input = null;
                        } else {
                            context.Distant_Magistor_Clients_Test_Input=(String) context.getProperty("Distant_Magistor_Clients_Test_Input");
                        }
                        context.setContextType("Distant_Magistor1_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Input") == null) {
                            context.Distant_Magistor1_Input = null;
                        } else {
                            context.Distant_Magistor1_Input=(String) context.getProperty("Distant_Magistor1_Input");
                        }
                        context.setContextType("Distant_Magistor1_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Output") == null) {
                            context.Distant_Magistor1_Output = null;
                        } else {
                            context.Distant_Magistor1_Output=(String) context.getProperty("Distant_Magistor1_Output");
                        }
                        context.setContextType("Distant_Magistor1_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Test_Input") == null) {
                            context.Distant_Magistor1_Test_Input = null;
                        } else {
                            context.Distant_Magistor1_Test_Input=(String) context.getProperty("Distant_Magistor1_Test_Input");
                        }
                        context.setContextType("Distant_Magistor1_Test_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Test_Output") == null) {
                            context.Distant_Magistor1_Test_Output = null;
                        } else {
                            context.Distant_Magistor1_Test_Output=(String) context.getProperty("Distant_Magistor1_Test_Output");
                        }
                        context.setContextType("Distant_Magistor2_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Input") == null) {
                            context.Distant_Magistor2_Input = null;
                        } else {
                            context.Distant_Magistor2_Input=(String) context.getProperty("Distant_Magistor2_Input");
                        }
                        context.setContextType("Distant_Magistor2_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Output") == null) {
                            context.Distant_Magistor2_Output = null;
                        } else {
                            context.Distant_Magistor2_Output=(String) context.getProperty("Distant_Magistor2_Output");
                        }
                        context.setContextType("Distant_Magistor2_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Test_Input") == null) {
                            context.Distant_Magistor2_Test_Input = null;
                        } else {
                            context.Distant_Magistor2_Test_Input=(String) context.getProperty("Distant_Magistor2_Test_Input");
                        }
                        context.setContextType("Distant_Magistor2_Test_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Test_Output") == null) {
                            context.Distant_Magistor2_Test_Output = null;
                        } else {
                            context.Distant_Magistor2_Test_Output=(String) context.getProperty("Distant_Magistor2_Test_Output");
                        }
                        context.setContextType("Drc_masque", "id_String");
                        if(context.getStringValue("Drc_masque") == null) {
                            context.Drc_masque = null;
                        } else {
                            context.Drc_masque=(String) context.getProperty("Drc_masque");
                        }
                        context.setContextType("Mvt_masque", "id_String");
                        if(context.getStringValue("Mvt_masque") == null) {
                            context.Mvt_masque = null;
                        } else {
                            context.Mvt_masque=(String) context.getProperty("Mvt_masque");
                        }
                        context.setContextType("Stk_masque", "id_String");
                        if(context.getStringValue("Stk_masque") == null) {
                            context.Stk_masque = null;
                        } else {
                            context.Stk_masque=(String) context.getProperty("Stk_masque");
                        }
                        context.setContextType("Xml_File_Masque", "id_String");
                        if(context.getStringValue("Xml_File_Masque") == null) {
                            context.Xml_File_Masque = null;
                        } else {
                            context.Xml_File_Masque=(String) context.getProperty("Xml_File_Masque");
                        }
                        context.setContextType("Article_Exceptions", "id_String");
                        if(context.getStringValue("Article_Exceptions") == null) {
                            context.Article_Exceptions = null;
                        } else {
                            context.Article_Exceptions=(String) context.getProperty("Article_Exceptions");
                        }
                        context.setContextType("Cleaning_Reject_Logistic_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Logistic_price_is_zero") == null) {
                            context.Cleaning_Reject_Logistic_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Logistic_price_is_zero=(String) context.getProperty("Cleaning_Reject_Logistic_price_is_zero");
                        }
                        context.setContextType("Cleaning_Reject_Rep", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Rep") == null) {
                            context.Cleaning_Reject_Rep = null;
                        } else {
                            context.Cleaning_Reject_Rep=(String) context.getProperty("Cleaning_Reject_Rep");
                        }
                        context.setContextType("Cleaning_Reject_Transport_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Transport_price_is_zero") == null) {
                            context.Cleaning_Reject_Transport_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Transport_price_is_zero=(String) context.getProperty("Cleaning_Reject_Transport_price_is_zero");
                        }
                        context.setContextType("Cleaning_Transport_no_PostalCode", "id_String");
                        if(context.getStringValue("Cleaning_Transport_no_PostalCode") == null) {
                            context.Cleaning_Transport_no_PostalCode = null;
                        } else {
                            context.Cleaning_Transport_no_PostalCode=(String) context.getProperty("Cleaning_Transport_no_PostalCode");
                        }
                        context.setContextType("Commande_Exceptions", "id_String");
                        if(context.getStringValue("Commande_Exceptions") == null) {
                            context.Commande_Exceptions = null;
                        } else {
                            context.Commande_Exceptions=(String) context.getProperty("Commande_Exceptions");
                        }
                        context.setContextType("Conditionnement_Exceptions", "id_String");
                        if(context.getStringValue("Conditionnement_Exceptions") == null) {
                            context.Conditionnement_Exceptions = null;
                        } else {
                            context.Conditionnement_Exceptions=(String) context.getProperty("Conditionnement_Exceptions");
                        }
                        context.setContextType("CR_Reception_Exceptions", "id_String");
                        if(context.getStringValue("CR_Reception_Exceptions") == null) {
                            context.CR_Reception_Exceptions = null;
                        } else {
                            context.CR_Reception_Exceptions=(String) context.getProperty("CR_Reception_Exceptions");
                        }
                        context.setContextType("Csv_File_Masque", "id_String");
                        if(context.getStringValue("Csv_File_Masque") == null) {
                            context.Csv_File_Masque = null;
                        } else {
                            context.Csv_File_Masque=(String) context.getProperty("Csv_File_Masque");
                        }
                        context.setContextType("Diagnostic_Reject_Command_Error", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Command_Error") == null) {
                            context.Diagnostic_Reject_Command_Error = null;
                        } else {
                            context.Diagnostic_Reject_Command_Error=(String) context.getProperty("Diagnostic_Reject_Command_Error");
                        }
                        context.setContextType("Diagnostic_Reject_Day_Not_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Day_Not_Ok") == null) {
                            context.Diagnostic_Reject_Day_Not_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Day_Not_Ok=(String) context.getProperty("Diagnostic_Reject_Day_Not_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Postal_Code_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Postal_Code_Ok") == null) {
                            context.Diagnostic_Reject_Postal_Code_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Postal_Code_Ok=(String) context.getProperty("Diagnostic_Reject_Postal_Code_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Rep", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Rep") == null) {
                            context.Diagnostic_Reject_Rep = null;
                        } else {
                            context.Diagnostic_Reject_Rep=(String) context.getProperty("Diagnostic_Reject_Rep");
                        }
                        context.setContextType("Dossier_Reception_Exceptions", "id_String");
                        if(context.getStringValue("Dossier_Reception_Exceptions") == null) {
                            context.Dossier_Reception_Exceptions = null;
                        } else {
                            context.Dossier_Reception_Exceptions=(String) context.getProperty("Dossier_Reception_Exceptions");
                        }
                        context.setContextType("Excel_File_Masque", "id_String");
                        if(context.getStringValue("Excel_File_Masque") == null) {
                            context.Excel_File_Masque = null;
                        } else {
                            context.Excel_File_Masque=(String) context.getProperty("Excel_File_Masque");
                        }
                        }

                private void processContext_1() {
                        context.setContextType("Ligne_Commande_Exceptions", "id_String");
                        if(context.getStringValue("Ligne_Commande_Exceptions") == null) {
                            context.Ligne_Commande_Exceptions = null;
                        } else {
                            context.Ligne_Commande_Exceptions=(String) context.getProperty("Ligne_Commande_Exceptions");
                        }
                        context.setContextType("Migration_Billing_Not_Ok", "id_String");
                        if(context.getStringValue("Migration_Billing_Not_Ok") == null) {
                            context.Migration_Billing_Not_Ok = null;
                        } else {
                            context.Migration_Billing_Not_Ok=(String) context.getProperty("Migration_Billing_Not_Ok");
                        }
                        context.setContextType("Reject_Client_File", "id_String");
                        if(context.getStringValue("Reject_Client_File") == null) {
                            context.Reject_Client_File = null;
                        } else {
                            context.Reject_Client_File=(String) context.getProperty("Reject_Client_File");
                        }
                        context.setContextType("Reject_Client_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Client_Local_Rep") == null) {
                            context.Reject_Client_Local_Rep = null;
                        } else {
                            context.Reject_Client_Local_Rep=(String) context.getProperty("Reject_Client_Local_Rep");
                        }
                        context.setContextType("Reject_Command_Logisitc_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Logisitc_Code_Client") == null) {
                            context.Reject_Command_Logisitc_Code_Client = null;
                        } else {
                            context.Reject_Command_Logisitc_Code_Client=(String) context.getProperty("Reject_Command_Logisitc_Code_Client");
                        }
                        context.setContextType("Reject_Command_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Transport_Code_Client") == null) {
                            context.Reject_Command_Transport_Code_Client = null;
                        } else {
                            context.Reject_Command_Transport_Code_Client=(String) context.getProperty("Reject_Command_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Distant_Rep", "id_String");
                        if(context.getStringValue("Reject_Distant_Rep") == null) {
                            context.Reject_Distant_Rep = null;
                        } else {
                            context.Reject_Distant_Rep=(String) context.getProperty("Reject_Distant_Rep");
                        }
                        context.setContextType("Reject_Distant_Rep_DataMart", "id_String");
                        if(context.getStringValue("Reject_Distant_Rep_DataMart") == null) {
                            context.Reject_Distant_Rep_DataMart = null;
                        } else {
                            context.Reject_Distant_Rep_DataMart=(String) context.getProperty("Reject_Distant_Rep_DataMart");
                        }
                        context.setContextType("Reject_Duplicated_Client_File", "id_String");
                        if(context.getStringValue("Reject_Duplicated_Client_File") == null) {
                            context.Reject_Duplicated_Client_File = null;
                        } else {
                            context.Reject_Duplicated_Client_File=(String) context.getProperty("Reject_Duplicated_Client_File");
                        }
                        context.setContextType("Reject_Migration_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Migration_Local_Rep") == null) {
                            context.Reject_Migration_Local_Rep = null;
                        } else {
                            context.Reject_Migration_Local_Rep=(String) context.getProperty("Reject_Migration_Local_Rep");
                        }
                        context.setContextType("Reject_Not_Complet_Client", "id_String");
                        if(context.getStringValue("Reject_Not_Complet_Client") == null) {
                            context.Reject_Not_Complet_Client = null;
                        } else {
                            context.Reject_Not_Complet_Client=(String) context.getProperty("Reject_Not_Complet_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Local_Rep") == null) {
                            context.Reject_Service_Detail_Local_Rep = null;
                        } else {
                            context.Reject_Service_Detail_Local_Rep=(String) context.getProperty("Reject_Service_Detail_Local_Rep");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_DB") == null) {
                            context.Reject_Service_Detail_Logistic_DB = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_DB=(String) context.getProperty("Reject_Service_Detail_Logistic_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Logistic_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Logistic_Unknown_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_DB") == null) {
                            context.Reject_Service_Detail_Transport_DB = null;
                        } else {
                            context.Reject_Service_Detail_Transport_DB=(String) context.getProperty("Reject_Service_Detail_Transport_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Transport_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Transport_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Transport_Unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Tarification_Local_Rep") == null) {
                            context.Reject_Tarification_Local_Rep = null;
                        } else {
                            context.Reject_Tarification_Local_Rep=(String) context.getProperty("Reject_Tarification_Local_Rep");
                        }
                        context.setContextType("Reject_Tarification_Logistic_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_Code_Client") == null) {
                            context.Reject_Tarification_Logistic_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_Code_Client=(String) context.getProperty("Reject_Tarification_Logistic_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_DB") == null) {
                            context.Reject_Tarification_Logistic_DB = null;
                        } else {
                            context.Reject_Tarification_Logistic_DB=(String) context.getProperty("Reject_Tarification_Logistic_DB");
                        }
                        context.setContextType("Reject_Tarification_Logistic_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_unknown_Client") == null) {
                            context.Reject_Tarification_Logistic_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_unknown_Client=(String) context.getProperty("Reject_Tarification_Logistic_unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_Code_Client") == null) {
                            context.Reject_Tarification_Transport_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_Code_Client=(String) context.getProperty("Reject_Tarification_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_DB") == null) {
                            context.Reject_Tarification_Transport_DB = null;
                        } else {
                            context.Reject_Tarification_Transport_DB=(String) context.getProperty("Reject_Tarification_Transport_DB");
                        }
                        context.setContextType("Reject_Tarification_Transport_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_unknown_Client") == null) {
                            context.Reject_Tarification_Transport_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_unknown_Client=(String) context.getProperty("Reject_Tarification_Transport_unknown_Client");
                        }
                        context.setContextType("code_client_length", "id_Integer");
                        if(context.getStringValue("code_client_length") == null) {
                            context.code_client_length = null;
                        } else {
                            try{
                                context.code_client_length=routines.system.ParserUtils.parseTo_Integer (context.getProperty("code_client_length"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "code_client_length", e.getMessage()));
                                context.code_client_length=null;
                            }
                        }
                        context.setContextType("code_client_regex", "id_String");
                        if(context.getStringValue("code_client_regex") == null) {
                            context.code_client_regex = null;
                        } else {
                            context.code_client_regex=(String) context.getProperty("code_client_regex");
                        }
                        context.setContextType("Livraison_directory", "id_String");
                        if(context.getStringValue("Livraison_directory") == null) {
                            context.Livraison_directory = null;
                        } else {
                            context.Livraison_directory=(String) context.getProperty("Livraison_directory");
                        }
                        context.setContextType("Round_Delay_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Delay_Minus_Days") == null) {
                            context.Round_Delay_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Delay_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Delay_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Delay_Minus_Days", e.getMessage()));
                                context.Round_Delay_Minus_Days=null;
                            }
                        }
                        context.setContextType("Round_Delay_Plus_Days_Plus_One", "id_Integer");
                        if(context.getStringValue("Round_Delay_Plus_Days_Plus_One") == null) {
                            context.Round_Delay_Plus_Days_Plus_One = null;
                        } else {
                            try{
                                context.Round_Delay_Plus_Days_Plus_One=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Delay_Plus_Days_Plus_One"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Delay_Plus_Days_Plus_One", e.getMessage()));
                                context.Round_Delay_Plus_Days_Plus_One=null;
                            }
                        }
                        context.setContextType("Round_directory", "id_String");
                        if(context.getStringValue("Round_directory") == null) {
                            context.Round_directory = null;
                        } else {
                            context.Round_directory=(String) context.getProperty("Round_directory");
                        }
                        context.setContextType("Round_file_name", "id_String");
                        if(context.getStringValue("Round_file_name") == null) {
                            context.Round_file_name = null;
                        } else {
                            context.Round_file_name=(String) context.getProperty("Round_file_name");
                        }
                        context.setContextType("Round_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Minus_Days") == null) {
                            context.Round_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Minus_Days", e.getMessage()));
                                context.Round_Minus_Days=null;
                            }
                        }
                        context.setContextType("Salesforce_Name", "id_String");
                        if(context.getStringValue("Salesforce_Name") == null) {
                            context.Salesforce_Name = null;
                        } else {
                            context.Salesforce_Name=(String) context.getProperty("Salesforce_Name");
                        }
                        context.setContextType("Salesforce_Password", "id_Password");
                        if(context.getStringValue("Salesforce_Password") == null) {
                            context.Salesforce_Password = null;
                        } else {
                            String pwd_Salesforce_Password_value = context.getProperty("Salesforce_Password");
                            context.Salesforce_Password = null;
                            if(pwd_Salesforce_Password_value!=null) {
                                if(context_param.containsKey("Salesforce_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Password = pwd_Salesforce_Password_value;
                                } else if (!pwd_Salesforce_Password_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Password_value);
                                        context.put("Salesforce_Password",context.Salesforce_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_Security_Token", "id_Password");
                        if(context.getStringValue("Salesforce_Security_Token") == null) {
                            context.Salesforce_Security_Token = null;
                        } else {
                            String pwd_Salesforce_Security_Token_value = context.getProperty("Salesforce_Security_Token");
                            context.Salesforce_Security_Token = null;
                            if(pwd_Salesforce_Security_Token_value!=null) {
                                if(context_param.containsKey("Salesforce_Security_Token")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Security_Token = pwd_Salesforce_Security_Token_value;
                                } else if (!pwd_Salesforce_Security_Token_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Security_Token = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Security_Token_value);
                                        context.put("Salesforce_Security_Token",context.Salesforce_Security_Token);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_User_ID", "id_String");
                        if(context.getStringValue("Salesforce_User_ID") == null) {
                            context.Salesforce_User_ID = null;
                        } else {
                            context.Salesforce_User_ID=(String) context.getProperty("Salesforce_User_ID");
                        }
                        context.setContextType("comptabilite_analytique_month", "id_String");
                        if(context.getStringValue("comptabilite_analytique_month") == null) {
                            context.comptabilite_analytique_month = null;
                        } else {
                            context.comptabilite_analytique_month=(String) context.getProperty("comptabilite_analytique_month");
                        }
                        context.setContextType("comptabilite_analytique_year", "id_String");
                        if(context.getStringValue("comptabilite_analytique_year") == null) {
                            context.comptabilite_analytique_year = null;
                        } else {
                            context.comptabilite_analytique_year=(String) context.getProperty("comptabilite_analytique_year");
                        }
                        context.setContextType("Ecolotrans_JP_Month_MM", "id_String");
                        if(context.getStringValue("Ecolotrans_JP_Month_MM") == null) {
                            context.Ecolotrans_JP_Month_MM = null;
                        } else {
                            context.Ecolotrans_JP_Month_MM=(String) context.getProperty("Ecolotrans_JP_Month_MM");
                        }
                        context.setContextType("end_date", "id_String");
                        if(context.getStringValue("end_date") == null) {
                            context.end_date = null;
                        } else {
                            context.end_date=(String) context.getProperty("end_date");
                        }
                        context.setContextType("Extraction_Aprm", "id_Integer");
                        if(context.getStringValue("Extraction_Aprm") == null) {
                            context.Extraction_Aprm = null;
                        } else {
                            try{
                                context.Extraction_Aprm=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Aprm"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Aprm", e.getMessage()));
                                context.Extraction_Aprm=null;
                            }
                        }
                        context.setContextType("Extraction_Jour", "id_Integer");
                        if(context.getStringValue("Extraction_Jour") == null) {
                            context.Extraction_Jour = null;
                        } else {
                            try{
                                context.Extraction_Jour=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Jour"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Jour", e.getMessage()));
                                context.Extraction_Jour=null;
                            }
                        }
                        context.setContextType("Extraction_Matin", "id_Integer");
                        if(context.getStringValue("Extraction_Matin") == null) {
                            context.Extraction_Matin = null;
                        } else {
                            try{
                                context.Extraction_Matin=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Matin"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Matin", e.getMessage()));
                                context.Extraction_Matin=null;
                            }
                        }
                        context.setContextType("start_date", "id_String");
                        if(context.getStringValue("start_date") == null) {
                            context.start_date = null;
                        } else {
                            context.start_date=(String) context.getProperty("start_date");
                        }
                        context.setContextType("Urbantz_directory", "id_String");
                        if(context.getStringValue("Urbantz_directory") == null) {
                            context.Urbantz_directory = null;
                        } else {
                            context.Urbantz_directory=(String) context.getProperty("Urbantz_directory");
                        }
                        context.setContextType("urbantz_extraction_date", "id_String");
                        if(context.getStringValue("urbantz_extraction_date") == null) {
                            context.urbantz_extraction_date = null;
                        } else {
                            context.urbantz_extraction_date=(String) context.getProperty("urbantz_extraction_date");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                        processContext_1();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Billing_BSO_Months")) {
                context.Billing_BSO_Months = (String) parentContextMap.get("Billing_BSO_Months");
            }if (parentContextMap.containsKey("Billing_BSO_Start_Year")) {
                context.Billing_BSO_Start_Year = (Integer) parentContextMap.get("Billing_BSO_Start_Year");
            }if (parentContextMap.containsKey("Billing_Comptabilite_File")) {
                context.Billing_Comptabilite_File = (String) parentContextMap.get("Billing_Comptabilite_File");
            }if (parentContextMap.containsKey("Billing_Comptabilite_Folder")) {
                context.Billing_Comptabilite_Folder = (String) parentContextMap.get("Billing_Comptabilite_Folder");
            }if (parentContextMap.containsKey("Billing_Distant_Rep")) {
                context.Billing_Distant_Rep = (String) parentContextMap.get("Billing_Distant_Rep");
            }if (parentContextMap.containsKey("Billing_File_Masque")) {
                context.Billing_File_Masque = (String) parentContextMap.get("Billing_File_Masque");
            }if (parentContextMap.containsKey("Billing_Local_Rep")) {
                context.Billing_Local_Rep = (String) parentContextMap.get("Billing_Local_Rep");
            }if (parentContextMap.containsKey("Billing_Name")) {
                context.Billing_Name = (String) parentContextMap.get("Billing_Name");
            }if (parentContextMap.containsKey("Billing_Start_Number")) {
                context.Billing_Start_Number = (Integer) parentContextMap.get("Billing_Start_Number");
            }if (parentContextMap.containsKey("Billing_TVA_default_value")) {
                context.Billing_TVA_default_value = (Float) parentContextMap.get("Billing_TVA_default_value");
            }if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("ODS_Database")) {
                context.ODS_Database = (String) parentContextMap.get("ODS_Database");
            }if (parentContextMap.containsKey("PBI_Database")) {
                context.PBI_Database = (String) parentContextMap.get("PBI_Database");
            }if (parentContextMap.containsKey("PBI_PC_Database")) {
                context.PBI_PC_Database = (String) parentContextMap.get("PBI_PC_Database");
            }if (parentContextMap.containsKey("PBI_RT_Database")) {
                context.PBI_RT_Database = (String) parentContextMap.get("PBI_RT_Database");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("DataMart_Clean_Database")) {
                context.DataMart_Clean_Database = (String) parentContextMap.get("DataMart_Clean_Database");
            }if (parentContextMap.containsKey("DataMart_Clean_Max_Date")) {
                context.DataMart_Clean_Max_Date = (String) parentContextMap.get("DataMart_Clean_Max_Date");
            }if (parentContextMap.containsKey("DataMart_Clean_Min_Date")) {
                context.DataMart_Clean_Min_Date = (String) parentContextMap.get("DataMart_Clean_Min_Date");
            }if (parentContextMap.containsKey("DataMart_Closure_Date_PlusX")) {
                context.DataMart_Closure_Date_PlusX = (Integer) parentContextMap.get("DataMart_Closure_Date_PlusX");
            }if (parentContextMap.containsKey("Limit_Percent")) {
                context.Limit_Percent = (Integer) parentContextMap.get("Limit_Percent");
            }if (parentContextMap.containsKey("Logistic_Max_Date_Plus_One")) {
                context.Logistic_Max_Date_Plus_One = (String) parentContextMap.get("Logistic_Max_Date_Plus_One");
            }if (parentContextMap.containsKey("Logistic_Min_Date_Minus_One")) {
                context.Logistic_Min_Date_Minus_One = (String) parentContextMap.get("Logistic_Min_Date_Minus_One");
            }if (parentContextMap.containsKey("deleted_J_minus_X")) {
                context.deleted_J_minus_X = (Integer) parentContextMap.get("deleted_J_minus_X");
            }if (parentContextMap.containsKey("deleted_J_plusOne_X")) {
                context.deleted_J_plusOne_X = (Integer) parentContextMap.get("deleted_J_plusOne_X");
            }if (parentContextMap.containsKey("FTP_DistantRep")) {
                context.FTP_DistantRep = (String) parentContextMap.get("FTP_DistantRep");
            }if (parentContextMap.containsKey("FTP_FileMasque")) {
                context.FTP_FileMasque = (String) parentContextMap.get("FTP_FileMasque");
            }if (parentContextMap.containsKey("FTP_Hote")) {
                context.FTP_Hote = (String) parentContextMap.get("FTP_Hote");
            }if (parentContextMap.containsKey("FTP_Password")) {
                context.FTP_Password = (java.lang.String) parentContextMap.get("FTP_Password");
            }if (parentContextMap.containsKey("FTP_Port")) {
                context.FTP_Port = (Integer) parentContextMap.get("FTP_Port");
            }if (parentContextMap.containsKey("FTP_ST_DistantRep")) {
                context.FTP_ST_DistantRep = (String) parentContextMap.get("FTP_ST_DistantRep");
            }if (parentContextMap.containsKey("FTP_User")) {
                context.FTP_User = (String) parentContextMap.get("FTP_User");
            }if (parentContextMap.containsKey("FTP_Wms_Port")) {
                context.FTP_Wms_Port = (Integer) parentContextMap.get("FTP_Wms_Port");
            }if (parentContextMap.containsKey("keyStore_file_name")) {
                context.keyStore_file_name = (String) parentContextMap.get("keyStore_file_name");
            }if (parentContextMap.containsKey("KeyStore_Repo")) {
                context.KeyStore_Repo = (String) parentContextMap.get("KeyStore_Repo");
            }if (parentContextMap.containsKey("mail_password")) {
                context.mail_password = (String) parentContextMap.get("mail_password");
            }if (parentContextMap.containsKey("send_mail_from")) {
                context.send_mail_from = (String) parentContextMap.get("send_mail_from");
            }if (parentContextMap.containsKey("send_mail_to")) {
                context.send_mail_to = (String) parentContextMap.get("send_mail_to");
            }if (parentContextMap.containsKey("send_to_second_mail")) {
                context.send_to_second_mail = (String) parentContextMap.get("send_to_second_mail");
            }if (parentContextMap.containsKey("send_to_third_mail")) {
                context.send_to_third_mail = (String) parentContextMap.get("send_to_third_mail");
            }if (parentContextMap.containsKey("Clients_Masque")) {
                context.Clients_Masque = (String) parentContextMap.get("Clients_Masque");
            }if (parentContextMap.containsKey("Code_client_masque")) {
                context.Code_client_masque = (String) parentContextMap.get("Code_client_masque");
            }if (parentContextMap.containsKey("Command_Logistic_Invalid_Date")) {
                context.Command_Logistic_Invalid_Date = (String) parentContextMap.get("Command_Logistic_Invalid_Date");
            }if (parentContextMap.containsKey("Command_Logistic_Masque")) {
                context.Command_Logistic_Masque = (String) parentContextMap.get("Command_Logistic_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque")) {
                context.Command_Transport_Masque = (String) parentContextMap.get("Command_Transport_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque_Express")) {
                context.Command_Transport_Masque_Express = (String) parentContextMap.get("Command_Transport_Masque_Express");
            }if (parentContextMap.containsKey("Ecolotrans_JP")) {
                context.Ecolotrans_JP = (String) parentContextMap.get("Ecolotrans_JP");
            }if (parentContextMap.containsKey("Holiday_Days_Masque")) {
                context.Holiday_Days_Masque = (String) parentContextMap.get("Holiday_Days_Masque");
            }if (parentContextMap.containsKey("Livraisons_Exception")) {
                context.Livraisons_Exception = (String) parentContextMap.get("Livraisons_Exception");
            }if (parentContextMap.containsKey("Livraisons_Masque")) {
                context.Livraisons_Masque = (String) parentContextMap.get("Livraisons_Masque");
            }if (parentContextMap.containsKey("Livraisons_Ok")) {
                context.Livraisons_Ok = (String) parentContextMap.get("Livraisons_Ok");
            }if (parentContextMap.containsKey("ST_Drivers")) {
                context.ST_Drivers = (String) parentContextMap.get("ST_Drivers");
            }if (parentContextMap.containsKey("Tarification_Logistic_Masque")) {
                context.Tarification_Logistic_Masque = (String) parentContextMap.get("Tarification_Logistic_Masque");
            }if (parentContextMap.containsKey("Tarification_Transport_Masque")) {
                context.Tarification_Transport_Masque = (String) parentContextMap.get("Tarification_Transport_Masque");
            }if (parentContextMap.containsKey("Tournee_Masque")) {
                context.Tournee_Masque = (String) parentContextMap.get("Tournee_Masque");
            }if (parentContextMap.containsKey("TVA_Exceptions")) {
                context.TVA_Exceptions = (String) parentContextMap.get("TVA_Exceptions");
            }if (parentContextMap.containsKey("Backup")) {
                context.Backup = (String) parentContextMap.get("Backup");
            }if (parentContextMap.containsKey("Server_Clean")) {
                context.Server_Clean = (String) parentContextMap.get("Server_Clean");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Server_Out")) {
                context.Server_Out = (String) parentContextMap.get("Server_Out");
            }if (parentContextMap.containsKey("Server_Out_DataMart")) {
                context.Server_Out_DataMart = (String) parentContextMap.get("Server_Out_DataMart");
            }if (parentContextMap.containsKey("Art_masque")) {
                context.Art_masque = (String) parentContextMap.get("Art_masque");
            }if (parentContextMap.containsKey("Cdc_masque")) {
                context.Cdc_masque = (String) parentContextMap.get("Cdc_masque");
            }if (parentContextMap.containsKey("Cre_masque")) {
                context.Cre_masque = (String) parentContextMap.get("Cre_masque");
            }if (parentContextMap.containsKey("Crp_masque")) {
                context.Crp_masque = (String) parentContextMap.get("Crp_masque");
            }if (parentContextMap.containsKey("Crr_masque")) {
                context.Crr_masque = (String) parentContextMap.get("Crr_masque");
            }if (parentContextMap.containsKey("Distant_Magistor_Clients_Input")) {
                context.Distant_Magistor_Clients_Input = (String) parentContextMap.get("Distant_Magistor_Clients_Input");
            }if (parentContextMap.containsKey("Distant_Magistor_Clients_Test_Input")) {
                context.Distant_Magistor_Clients_Test_Input = (String) parentContextMap.get("Distant_Magistor_Clients_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Input")) {
                context.Distant_Magistor1_Input = (String) parentContextMap.get("Distant_Magistor1_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Output")) {
                context.Distant_Magistor1_Output = (String) parentContextMap.get("Distant_Magistor1_Output");
            }if (parentContextMap.containsKey("Distant_Magistor1_Test_Input")) {
                context.Distant_Magistor1_Test_Input = (String) parentContextMap.get("Distant_Magistor1_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Test_Output")) {
                context.Distant_Magistor1_Test_Output = (String) parentContextMap.get("Distant_Magistor1_Test_Output");
            }if (parentContextMap.containsKey("Distant_Magistor2_Input")) {
                context.Distant_Magistor2_Input = (String) parentContextMap.get("Distant_Magistor2_Input");
            }if (parentContextMap.containsKey("Distant_Magistor2_Output")) {
                context.Distant_Magistor2_Output = (String) parentContextMap.get("Distant_Magistor2_Output");
            }if (parentContextMap.containsKey("Distant_Magistor2_Test_Input")) {
                context.Distant_Magistor2_Test_Input = (String) parentContextMap.get("Distant_Magistor2_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor2_Test_Output")) {
                context.Distant_Magistor2_Test_Output = (String) parentContextMap.get("Distant_Magistor2_Test_Output");
            }if (parentContextMap.containsKey("Drc_masque")) {
                context.Drc_masque = (String) parentContextMap.get("Drc_masque");
            }if (parentContextMap.containsKey("Mvt_masque")) {
                context.Mvt_masque = (String) parentContextMap.get("Mvt_masque");
            }if (parentContextMap.containsKey("Stk_masque")) {
                context.Stk_masque = (String) parentContextMap.get("Stk_masque");
            }if (parentContextMap.containsKey("Xml_File_Masque")) {
                context.Xml_File_Masque = (String) parentContextMap.get("Xml_File_Masque");
            }if (parentContextMap.containsKey("Article_Exceptions")) {
                context.Article_Exceptions = (String) parentContextMap.get("Article_Exceptions");
            }if (parentContextMap.containsKey("Cleaning_Reject_Logistic_price_is_zero")) {
                context.Cleaning_Reject_Logistic_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Logistic_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Reject_Rep")) {
                context.Cleaning_Reject_Rep = (String) parentContextMap.get("Cleaning_Reject_Rep");
            }if (parentContextMap.containsKey("Cleaning_Reject_Transport_price_is_zero")) {
                context.Cleaning_Reject_Transport_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Transport_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Transport_no_PostalCode")) {
                context.Cleaning_Transport_no_PostalCode = (String) parentContextMap.get("Cleaning_Transport_no_PostalCode");
            }if (parentContextMap.containsKey("Commande_Exceptions")) {
                context.Commande_Exceptions = (String) parentContextMap.get("Commande_Exceptions");
            }if (parentContextMap.containsKey("Conditionnement_Exceptions")) {
                context.Conditionnement_Exceptions = (String) parentContextMap.get("Conditionnement_Exceptions");
            }if (parentContextMap.containsKey("CR_Reception_Exceptions")) {
                context.CR_Reception_Exceptions = (String) parentContextMap.get("CR_Reception_Exceptions");
            }if (parentContextMap.containsKey("Csv_File_Masque")) {
                context.Csv_File_Masque = (String) parentContextMap.get("Csv_File_Masque");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Command_Error")) {
                context.Diagnostic_Reject_Command_Error = (String) parentContextMap.get("Diagnostic_Reject_Command_Error");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Day_Not_Ok")) {
                context.Diagnostic_Reject_Day_Not_Ok = (String) parentContextMap.get("Diagnostic_Reject_Day_Not_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Postal_Code_Ok")) {
                context.Diagnostic_Reject_Postal_Code_Ok = (String) parentContextMap.get("Diagnostic_Reject_Postal_Code_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Rep")) {
                context.Diagnostic_Reject_Rep = (String) parentContextMap.get("Diagnostic_Reject_Rep");
            }if (parentContextMap.containsKey("Dossier_Reception_Exceptions")) {
                context.Dossier_Reception_Exceptions = (String) parentContextMap.get("Dossier_Reception_Exceptions");
            }if (parentContextMap.containsKey("Excel_File_Masque")) {
                context.Excel_File_Masque = (String) parentContextMap.get("Excel_File_Masque");
            }if (parentContextMap.containsKey("Ligne_Commande_Exceptions")) {
                context.Ligne_Commande_Exceptions = (String) parentContextMap.get("Ligne_Commande_Exceptions");
            }if (parentContextMap.containsKey("Migration_Billing_Not_Ok")) {
                context.Migration_Billing_Not_Ok = (String) parentContextMap.get("Migration_Billing_Not_Ok");
            }if (parentContextMap.containsKey("Reject_Client_File")) {
                context.Reject_Client_File = (String) parentContextMap.get("Reject_Client_File");
            }if (parentContextMap.containsKey("Reject_Client_Local_Rep")) {
                context.Reject_Client_Local_Rep = (String) parentContextMap.get("Reject_Client_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Command_Logisitc_Code_Client")) {
                context.Reject_Command_Logisitc_Code_Client = (String) parentContextMap.get("Reject_Command_Logisitc_Code_Client");
            }if (parentContextMap.containsKey("Reject_Command_Transport_Code_Client")) {
                context.Reject_Command_Transport_Code_Client = (String) parentContextMap.get("Reject_Command_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Distant_Rep")) {
                context.Reject_Distant_Rep = (String) parentContextMap.get("Reject_Distant_Rep");
            }if (parentContextMap.containsKey("Reject_Distant_Rep_DataMart")) {
                context.Reject_Distant_Rep_DataMart = (String) parentContextMap.get("Reject_Distant_Rep_DataMart");
            }if (parentContextMap.containsKey("Reject_Duplicated_Client_File")) {
                context.Reject_Duplicated_Client_File = (String) parentContextMap.get("Reject_Duplicated_Client_File");
            }if (parentContextMap.containsKey("Reject_Migration_Local_Rep")) {
                context.Reject_Migration_Local_Rep = (String) parentContextMap.get("Reject_Migration_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Not_Complet_Client")) {
                context.Reject_Not_Complet_Client = (String) parentContextMap.get("Reject_Not_Complet_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Local_Rep")) {
                context.Reject_Service_Detail_Local_Rep = (String) parentContextMap.get("Reject_Service_Detail_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_DB")) {
                context.Reject_Service_Detail_Logistic_DB = (String) parentContextMap.get("Reject_Service_Detail_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_Unknown_Client")) {
                context.Reject_Service_Detail_Logistic_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Logistic_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_DB")) {
                context.Reject_Service_Detail_Transport_DB = (String) parentContextMap.get("Reject_Service_Detail_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_Unknown_Client")) {
                context.Reject_Service_Detail_Transport_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Transport_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Local_Rep")) {
                context.Reject_Tarification_Local_Rep = (String) parentContextMap.get("Reject_Tarification_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_Code_Client")) {
                context.Reject_Tarification_Logistic_Code_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_DB")) {
                context.Reject_Tarification_Logistic_DB = (String) parentContextMap.get("Reject_Tarification_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_unknown_Client")) {
                context.Reject_Tarification_Logistic_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_Code_Client")) {
                context.Reject_Tarification_Transport_Code_Client = (String) parentContextMap.get("Reject_Tarification_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_DB")) {
                context.Reject_Tarification_Transport_DB = (String) parentContextMap.get("Reject_Tarification_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_unknown_Client")) {
                context.Reject_Tarification_Transport_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Transport_unknown_Client");
            }if (parentContextMap.containsKey("code_client_length")) {
                context.code_client_length = (Integer) parentContextMap.get("code_client_length");
            }if (parentContextMap.containsKey("code_client_regex")) {
                context.code_client_regex = (String) parentContextMap.get("code_client_regex");
            }if (parentContextMap.containsKey("Livraison_directory")) {
                context.Livraison_directory = (String) parentContextMap.get("Livraison_directory");
            }if (parentContextMap.containsKey("Round_Delay_Minus_Days")) {
                context.Round_Delay_Minus_Days = (Integer) parentContextMap.get("Round_Delay_Minus_Days");
            }if (parentContextMap.containsKey("Round_Delay_Plus_Days_Plus_One")) {
                context.Round_Delay_Plus_Days_Plus_One = (Integer) parentContextMap.get("Round_Delay_Plus_Days_Plus_One");
            }if (parentContextMap.containsKey("Round_directory")) {
                context.Round_directory = (String) parentContextMap.get("Round_directory");
            }if (parentContextMap.containsKey("Round_file_name")) {
                context.Round_file_name = (String) parentContextMap.get("Round_file_name");
            }if (parentContextMap.containsKey("Round_Minus_Days")) {
                context.Round_Minus_Days = (Integer) parentContextMap.get("Round_Minus_Days");
            }if (parentContextMap.containsKey("Salesforce_Name")) {
                context.Salesforce_Name = (String) parentContextMap.get("Salesforce_Name");
            }if (parentContextMap.containsKey("Salesforce_Password")) {
                context.Salesforce_Password = (java.lang.String) parentContextMap.get("Salesforce_Password");
            }if (parentContextMap.containsKey("Salesforce_Security_Token")) {
                context.Salesforce_Security_Token = (java.lang.String) parentContextMap.get("Salesforce_Security_Token");
            }if (parentContextMap.containsKey("Salesforce_User_ID")) {
                context.Salesforce_User_ID = (String) parentContextMap.get("Salesforce_User_ID");
            }if (parentContextMap.containsKey("comptabilite_analytique_month")) {
                context.comptabilite_analytique_month = (String) parentContextMap.get("comptabilite_analytique_month");
            }if (parentContextMap.containsKey("comptabilite_analytique_year")) {
                context.comptabilite_analytique_year = (String) parentContextMap.get("comptabilite_analytique_year");
            }if (parentContextMap.containsKey("Ecolotrans_JP_Month_MM")) {
                context.Ecolotrans_JP_Month_MM = (String) parentContextMap.get("Ecolotrans_JP_Month_MM");
            }if (parentContextMap.containsKey("end_date")) {
                context.end_date = (String) parentContextMap.get("end_date");
            }if (parentContextMap.containsKey("Extraction_Aprm")) {
                context.Extraction_Aprm = (Integer) parentContextMap.get("Extraction_Aprm");
            }if (parentContextMap.containsKey("Extraction_Jour")) {
                context.Extraction_Jour = (Integer) parentContextMap.get("Extraction_Jour");
            }if (parentContextMap.containsKey("Extraction_Matin")) {
                context.Extraction_Matin = (Integer) parentContextMap.get("Extraction_Matin");
            }if (parentContextMap.containsKey("start_date")) {
                context.start_date = (String) parentContextMap.get("start_date");
            }if (parentContextMap.containsKey("Urbantz_directory")) {
                context.Urbantz_directory = (String) parentContextMap.get("Urbantz_directory");
            }if (parentContextMap.containsKey("urbantz_extraction_date")) {
                context.urbantz_extraction_date = (String) parentContextMap.get("urbantz_extraction_date");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("FTP_Password");
			parametersToEncrypt.add("Salesforce_Password");
			parametersToEncrypt.add("Salesforce_Security_Token");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob




		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tWarn_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tWarn_1) {
globalMap.put("tWarn_1_SUBPROCESS_STATE", -1);

e_tWarn_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeFtpConnections();


    }






    private void closeFtpConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tFTPConnection_1");
            if (obj_conn != null) {
                ((org.apache.commons.net.ftp.FTPClient) obj_conn).logout();
                ((org.apache.commons.net.ftp.FTPClient) obj_conn).disconnect();
            }
            obj_conn = globalMap.remove("conn_tFTPConnection_2");
            if (obj_conn != null) {
                ((com.jcraft.jsch.ChannelSftp) obj_conn).quit();
            }
        } catch (java.lang.Exception e) {
        }
    }








    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();


            connections.put("conn_tFTPConnection_1", globalMap.get("conn_tFTPConnection_1"));
            connections.put("conn_tFTPConnection_2", globalMap.get("conn_tFTPConnection_2"));




        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     648978 characters generated by Talend Cloud Data Integration 
 *     on the 18 avril 2024 à 12:49:14 CET
 ************************************************************************************************/
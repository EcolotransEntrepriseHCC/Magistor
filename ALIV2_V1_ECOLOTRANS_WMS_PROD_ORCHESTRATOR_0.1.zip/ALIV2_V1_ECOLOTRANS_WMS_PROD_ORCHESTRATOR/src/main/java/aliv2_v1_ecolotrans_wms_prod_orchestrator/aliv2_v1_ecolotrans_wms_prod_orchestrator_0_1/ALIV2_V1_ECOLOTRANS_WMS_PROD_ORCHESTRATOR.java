
package aliv2_v1_ecolotrans_wms_prod_orchestrator.aliv2_v1_ecolotrans_wms_prod_orchestrator_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR Purpose: <br>
 * Description:  <br>
 * @author m.zoutat@ecolotrans.com
 * @version 8.0.1.20240222_1049-patch
 * @status 
 */
public class ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR implements TalendJob {
	static {System.setProperty("TalendJob.log", "ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Billing_BSO_Months != null){
				
					this.setProperty("Billing_BSO_Months", Billing_BSO_Months.toString());
				
			}
			
			if(Billing_BSO_Start_Year != null){
				
					this.setProperty("Billing_BSO_Start_Year", Billing_BSO_Start_Year.toString());
				
			}
			
			if(Billing_Comptabilite_File != null){
				
					this.setProperty("Billing_Comptabilite_File", Billing_Comptabilite_File.toString());
				
			}
			
			if(Billing_Comptabilite_Folder != null){
				
					this.setProperty("Billing_Comptabilite_Folder", Billing_Comptabilite_Folder.toString());
				
			}
			
			if(Billing_Distant_Rep != null){
				
					this.setProperty("Billing_Distant_Rep", Billing_Distant_Rep.toString());
				
			}
			
			if(Billing_File_Masque != null){
				
					this.setProperty("Billing_File_Masque", Billing_File_Masque.toString());
				
			}
			
			if(Billing_Local_Rep != null){
				
					this.setProperty("Billing_Local_Rep", Billing_Local_Rep.toString());
				
			}
			
			if(Billing_Name != null){
				
					this.setProperty("Billing_Name", Billing_Name.toString());
				
			}
			
			if(Billing_Start_Number != null){
				
					this.setProperty("Billing_Start_Number", Billing_Start_Number.toString());
				
			}
			
			if(Billing_TVA_default_value != null){
				
					this.setProperty("Billing_TVA_default_value", Billing_TVA_default_value.toString());
				
			}
			
			if(Clean_distant_Rep != null){
				
					this.setProperty("Clean_distant_Rep", Clean_distant_Rep.toString());
				
			}
			
			if(Client_DataBase != null){
				
					this.setProperty("Client_DataBase", Client_DataBase.toString());
				
			}
			
			if(DB_Password != null){
				
					this.setProperty("DB_Password", DB_Password.toString());
				
			}
			
			if(Hote != null){
				
					this.setProperty("Hote", Hote.toString());
				
			}
			
			if(ODS_Database != null){
				
					this.setProperty("ODS_Database", ODS_Database.toString());
				
			}
			
			if(PBI_Database != null){
				
					this.setProperty("PBI_Database", PBI_Database.toString());
				
			}
			
			if(PBI_PC_Database != null){
				
					this.setProperty("PBI_PC_Database", PBI_PC_Database.toString());
				
			}
			
			if(PBI_RT_Database != null){
				
					this.setProperty("PBI_RT_Database", PBI_RT_Database.toString());
				
			}
			
			if(Port != null){
				
					this.setProperty("Port", Port.toString());
				
			}
			
			if(User != null){
				
					this.setProperty("User", User.toString());
				
			}
			
			if(DataMart_Clean_Database != null){
				
					this.setProperty("DataMart_Clean_Database", DataMart_Clean_Database.toString());
				
			}
			
			if(DataMart_Clean_Max_Date != null){
				
					this.setProperty("DataMart_Clean_Max_Date", DataMart_Clean_Max_Date.toString());
				
			}
			
			if(DataMart_Clean_Min_Date != null){
				
					this.setProperty("DataMart_Clean_Min_Date", DataMart_Clean_Min_Date.toString());
				
			}
			
			if(DataMart_Closure_Date_PlusX != null){
				
					this.setProperty("DataMart_Closure_Date_PlusX", DataMart_Closure_Date_PlusX.toString());
				
			}
			
			if(Limit_Percent != null){
				
					this.setProperty("Limit_Percent", Limit_Percent.toString());
				
			}
			
			if(Logistic_Max_Date_Plus_One != null){
				
					this.setProperty("Logistic_Max_Date_Plus_One", Logistic_Max_Date_Plus_One.toString());
				
			}
			
			if(Logistic_Min_Date_Minus_One != null){
				
					this.setProperty("Logistic_Min_Date_Minus_One", Logistic_Min_Date_Minus_One.toString());
				
			}
			
			if(deleted_J_minus_X != null){
				
					this.setProperty("deleted_J_minus_X", deleted_J_minus_X.toString());
				
			}
			
			if(deleted_J_plusOne_X != null){
				
					this.setProperty("deleted_J_plusOne_X", deleted_J_plusOne_X.toString());
				
			}
			
			if(FTP_DistantRep != null){
				
					this.setProperty("FTP_DistantRep", FTP_DistantRep.toString());
				
			}
			
			if(FTP_FileMasque != null){
				
					this.setProperty("FTP_FileMasque", FTP_FileMasque.toString());
				
			}
			
			if(FTP_Hote != null){
				
					this.setProperty("FTP_Hote", FTP_Hote.toString());
				
			}
			
			if(FTP_Password != null){
				
					this.setProperty("FTP_Password", FTP_Password.toString());
				
			}
			
			if(FTP_Port != null){
				
					this.setProperty("FTP_Port", FTP_Port.toString());
				
			}
			
			if(FTP_ST_DistantRep != null){
				
					this.setProperty("FTP_ST_DistantRep", FTP_ST_DistantRep.toString());
				
			}
			
			if(FTP_User != null){
				
					this.setProperty("FTP_User", FTP_User.toString());
				
			}
			
			if(FTP_Wms_Port != null){
				
					this.setProperty("FTP_Wms_Port", FTP_Wms_Port.toString());
				
			}
			
			if(keyStore_file_name != null){
				
					this.setProperty("keyStore_file_name", keyStore_file_name.toString());
				
			}
			
			if(KeyStore_Repo != null){
				
					this.setProperty("KeyStore_Repo", KeyStore_Repo.toString());
				
			}
			
			if(mail_password != null){
				
					this.setProperty("mail_password", mail_password.toString());
				
			}
			
			if(send_mail_from != null){
				
					this.setProperty("send_mail_from", send_mail_from.toString());
				
			}
			
			if(send_mail_to != null){
				
					this.setProperty("send_mail_to", send_mail_to.toString());
				
			}
			
			if(send_to_second_mail != null){
				
					this.setProperty("send_to_second_mail", send_to_second_mail.toString());
				
			}
			
			if(send_to_third_mail != null){
				
					this.setProperty("send_to_third_mail", send_to_third_mail.toString());
				
			}
			
			if(Clients_Masque != null){
				
					this.setProperty("Clients_Masque", Clients_Masque.toString());
				
			}
			
			if(Code_client_masque != null){
				
					this.setProperty("Code_client_masque", Code_client_masque.toString());
				
			}
			
			if(Command_Logistic_Invalid_Date != null){
				
					this.setProperty("Command_Logistic_Invalid_Date", Command_Logistic_Invalid_Date.toString());
				
			}
			
			if(Command_Logistic_Masque != null){
				
					this.setProperty("Command_Logistic_Masque", Command_Logistic_Masque.toString());
				
			}
			
			if(Command_Transport_Masque != null){
				
					this.setProperty("Command_Transport_Masque", Command_Transport_Masque.toString());
				
			}
			
			if(Command_Transport_Masque_Express != null){
				
					this.setProperty("Command_Transport_Masque_Express", Command_Transport_Masque_Express.toString());
				
			}
			
			if(Ecolotrans_JP != null){
				
					this.setProperty("Ecolotrans_JP", Ecolotrans_JP.toString());
				
			}
			
			if(Holiday_Days_Masque != null){
				
					this.setProperty("Holiday_Days_Masque", Holiday_Days_Masque.toString());
				
			}
			
			if(Livraisons_Exception != null){
				
					this.setProperty("Livraisons_Exception", Livraisons_Exception.toString());
				
			}
			
			if(Livraisons_Masque != null){
				
					this.setProperty("Livraisons_Masque", Livraisons_Masque.toString());
				
			}
			
			if(Livraisons_Ok != null){
				
					this.setProperty("Livraisons_Ok", Livraisons_Ok.toString());
				
			}
			
			if(ST_Drivers != null){
				
					this.setProperty("ST_Drivers", ST_Drivers.toString());
				
			}
			
			if(Tarification_Logistic_Masque != null){
				
					this.setProperty("Tarification_Logistic_Masque", Tarification_Logistic_Masque.toString());
				
			}
			
			if(Tarification_Transport_Masque != null){
				
					this.setProperty("Tarification_Transport_Masque", Tarification_Transport_Masque.toString());
				
			}
			
			if(Tournee_Masque != null){
				
					this.setProperty("Tournee_Masque", Tournee_Masque.toString());
				
			}
			
			if(TVA_Exceptions != null){
				
					this.setProperty("TVA_Exceptions", TVA_Exceptions.toString());
				
			}
			
			if(Backup != null){
				
					this.setProperty("Backup", Backup.toString());
				
			}
			
			if(Server_Clean != null){
				
					this.setProperty("Server_Clean", Server_Clean.toString());
				
			}
			
			if(Server_In != null){
				
					this.setProperty("Server_In", Server_In.toString());
				
			}
			
			if(Server_Out != null){
				
					this.setProperty("Server_Out", Server_Out.toString());
				
			}
			
			if(Server_Out_DataMart != null){
				
					this.setProperty("Server_Out_DataMart", Server_Out_DataMart.toString());
				
			}
			
			if(Art_masque != null){
				
					this.setProperty("Art_masque", Art_masque.toString());
				
			}
			
			if(Cdc_masque != null){
				
					this.setProperty("Cdc_masque", Cdc_masque.toString());
				
			}
			
			if(Cre_masque != null){
				
					this.setProperty("Cre_masque", Cre_masque.toString());
				
			}
			
			if(Crp_masque != null){
				
					this.setProperty("Crp_masque", Crp_masque.toString());
				
			}
			
			if(Crr_masque != null){
				
					this.setProperty("Crr_masque", Crr_masque.toString());
				
			}
			
			if(Distant_Magistor_Clients_Input != null){
				
					this.setProperty("Distant_Magistor_Clients_Input", Distant_Magistor_Clients_Input.toString());
				
			}
			
			if(Distant_Magistor_Clients_Test_Input != null){
				
					this.setProperty("Distant_Magistor_Clients_Test_Input", Distant_Magistor_Clients_Test_Input.toString());
				
			}
			
			if(Distant_Magistor1_Input != null){
				
					this.setProperty("Distant_Magistor1_Input", Distant_Magistor1_Input.toString());
				
			}
			
			if(Distant_Magistor1_Output != null){
				
					this.setProperty("Distant_Magistor1_Output", Distant_Magistor1_Output.toString());
				
			}
			
			if(Distant_Magistor1_Test_Input != null){
				
					this.setProperty("Distant_Magistor1_Test_Input", Distant_Magistor1_Test_Input.toString());
				
			}
			
			if(Distant_Magistor1_Test_Output != null){
				
					this.setProperty("Distant_Magistor1_Test_Output", Distant_Magistor1_Test_Output.toString());
				
			}
			
			if(Distant_Magistor2_Input != null){
				
					this.setProperty("Distant_Magistor2_Input", Distant_Magistor2_Input.toString());
				
			}
			
			if(Distant_Magistor2_Output != null){
				
					this.setProperty("Distant_Magistor2_Output", Distant_Magistor2_Output.toString());
				
			}
			
			if(Distant_Magistor2_Test_Input != null){
				
					this.setProperty("Distant_Magistor2_Test_Input", Distant_Magistor2_Test_Input.toString());
				
			}
			
			if(Distant_Magistor2_Test_Output != null){
				
					this.setProperty("Distant_Magistor2_Test_Output", Distant_Magistor2_Test_Output.toString());
				
			}
			
			if(Drc_masque != null){
				
					this.setProperty("Drc_masque", Drc_masque.toString());
				
			}
			
			if(Mvt_masque != null){
				
					this.setProperty("Mvt_masque", Mvt_masque.toString());
				
			}
			
			if(Stk_masque != null){
				
					this.setProperty("Stk_masque", Stk_masque.toString());
				
			}
			
			if(Xml_File_Masque != null){
				
					this.setProperty("Xml_File_Masque", Xml_File_Masque.toString());
				
			}
			
			if(Article_Exceptions != null){
				
					this.setProperty("Article_Exceptions", Article_Exceptions.toString());
				
			}
			
			if(Cleaning_Reject_Logistic_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Logistic_price_is_zero", Cleaning_Reject_Logistic_price_is_zero.toString());
				
			}
			
			if(Cleaning_Reject_Rep != null){
				
					this.setProperty("Cleaning_Reject_Rep", Cleaning_Reject_Rep.toString());
				
			}
			
			if(Cleaning_Reject_Transport_price_is_zero != null){
				
					this.setProperty("Cleaning_Reject_Transport_price_is_zero", Cleaning_Reject_Transport_price_is_zero.toString());
				
			}
			
			if(Cleaning_Transport_no_PostalCode != null){
				
					this.setProperty("Cleaning_Transport_no_PostalCode", Cleaning_Transport_no_PostalCode.toString());
				
			}
			
			if(Commande_Exceptions != null){
				
					this.setProperty("Commande_Exceptions", Commande_Exceptions.toString());
				
			}
			
			if(Conditionnement_Exceptions != null){
				
					this.setProperty("Conditionnement_Exceptions", Conditionnement_Exceptions.toString());
				
			}
			
			if(CR_Reception_Exceptions != null){
				
					this.setProperty("CR_Reception_Exceptions", CR_Reception_Exceptions.toString());
				
			}
			
			if(Csv_File_Masque != null){
				
					this.setProperty("Csv_File_Masque", Csv_File_Masque.toString());
				
			}
			
			if(Diagnostic_Reject_Command_Error != null){
				
					this.setProperty("Diagnostic_Reject_Command_Error", Diagnostic_Reject_Command_Error.toString());
				
			}
			
			if(Diagnostic_Reject_Day_Not_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Day_Not_Ok", Diagnostic_Reject_Day_Not_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Postal_Code_Ok != null){
				
					this.setProperty("Diagnostic_Reject_Postal_Code_Ok", Diagnostic_Reject_Postal_Code_Ok.toString());
				
			}
			
			if(Diagnostic_Reject_Rep != null){
				
					this.setProperty("Diagnostic_Reject_Rep", Diagnostic_Reject_Rep.toString());
				
			}
			
			if(Dossier_Reception_Exceptions != null){
				
					this.setProperty("Dossier_Reception_Exceptions", Dossier_Reception_Exceptions.toString());
				
			}
			
			if(Excel_File_Masque != null){
				
					this.setProperty("Excel_File_Masque", Excel_File_Masque.toString());
				
			}
			
			if(Ligne_Commande_Exceptions != null){
				
					this.setProperty("Ligne_Commande_Exceptions", Ligne_Commande_Exceptions.toString());
				
			}
			
			if(Migration_Billing_Not_Ok != null){
				
					this.setProperty("Migration_Billing_Not_Ok", Migration_Billing_Not_Ok.toString());
				
			}
			
			if(Reject_Client_File != null){
				
					this.setProperty("Reject_Client_File", Reject_Client_File.toString());
				
			}
			
			if(Reject_Client_Local_Rep != null){
				
					this.setProperty("Reject_Client_Local_Rep", Reject_Client_Local_Rep.toString());
				
			}
			
			if(Reject_Command_Logisitc_Code_Client != null){
				
					this.setProperty("Reject_Command_Logisitc_Code_Client", Reject_Command_Logisitc_Code_Client.toString());
				
			}
			
			if(Reject_Command_Transport_Code_Client != null){
				
					this.setProperty("Reject_Command_Transport_Code_Client", Reject_Command_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Distant_Rep != null){
				
					this.setProperty("Reject_Distant_Rep", Reject_Distant_Rep.toString());
				
			}
			
			if(Reject_Distant_Rep_DataMart != null){
				
					this.setProperty("Reject_Distant_Rep_DataMart", Reject_Distant_Rep_DataMart.toString());
				
			}
			
			if(Reject_Duplicated_Client_File != null){
				
					this.setProperty("Reject_Duplicated_Client_File", Reject_Duplicated_Client_File.toString());
				
			}
			
			if(Reject_Migration_Local_Rep != null){
				
					this.setProperty("Reject_Migration_Local_Rep", Reject_Migration_Local_Rep.toString());
				
			}
			
			if(Reject_Not_Complet_Client != null){
				
					this.setProperty("Reject_Not_Complet_Client", Reject_Not_Complet_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Local_Rep != null){
				
					this.setProperty("Reject_Service_Detail_Local_Rep", Reject_Service_Detail_Local_Rep.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_DB != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_DB", Reject_Service_Detail_Logistic_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Logistic_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Logistic_Unknown_Client", Reject_Service_Detail_Logistic_Unknown_Client.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_DB != null){
				
					this.setProperty("Reject_Service_Detail_Transport_DB", Reject_Service_Detail_Transport_DB.toString());
				
			}
			
			if(Reject_Service_Detail_Transport_Unknown_Client != null){
				
					this.setProperty("Reject_Service_Detail_Transport_Unknown_Client", Reject_Service_Detail_Transport_Unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Local_Rep != null){
				
					this.setProperty("Reject_Tarification_Local_Rep", Reject_Tarification_Local_Rep.toString());
				
			}
			
			if(Reject_Tarification_Logistic_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_Code_Client", Reject_Tarification_Logistic_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Logistic_DB != null){
				
					this.setProperty("Reject_Tarification_Logistic_DB", Reject_Tarification_Logistic_DB.toString());
				
			}
			
			if(Reject_Tarification_Logistic_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Logistic_unknown_Client", Reject_Tarification_Logistic_unknown_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_Code_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_Code_Client", Reject_Tarification_Transport_Code_Client.toString());
				
			}
			
			if(Reject_Tarification_Transport_DB != null){
				
					this.setProperty("Reject_Tarification_Transport_DB", Reject_Tarification_Transport_DB.toString());
				
			}
			
			if(Reject_Tarification_Transport_unknown_Client != null){
				
					this.setProperty("Reject_Tarification_Transport_unknown_Client", Reject_Tarification_Transport_unknown_Client.toString());
				
			}
			
			if(code_client_length != null){
				
					this.setProperty("code_client_length", code_client_length.toString());
				
			}
			
			if(code_client_regex != null){
				
					this.setProperty("code_client_regex", code_client_regex.toString());
				
			}
			
			if(Livraison_directory != null){
				
					this.setProperty("Livraison_directory", Livraison_directory.toString());
				
			}
			
			if(Round_Delay_Minus_Days != null){
				
					this.setProperty("Round_Delay_Minus_Days", Round_Delay_Minus_Days.toString());
				
			}
			
			if(Round_Delay_Plus_Days_Plus_One != null){
				
					this.setProperty("Round_Delay_Plus_Days_Plus_One", Round_Delay_Plus_Days_Plus_One.toString());
				
			}
			
			if(Round_directory != null){
				
					this.setProperty("Round_directory", Round_directory.toString());
				
			}
			
			if(Round_file_name != null){
				
					this.setProperty("Round_file_name", Round_file_name.toString());
				
			}
			
			if(Round_Minus_Days != null){
				
					this.setProperty("Round_Minus_Days", Round_Minus_Days.toString());
				
			}
			
			if(Salesforce_Name != null){
				
					this.setProperty("Salesforce_Name", Salesforce_Name.toString());
				
			}
			
			if(Salesforce_Password != null){
				
					this.setProperty("Salesforce_Password", Salesforce_Password.toString());
				
			}
			
			if(Salesforce_Security_Token != null){
				
					this.setProperty("Salesforce_Security_Token", Salesforce_Security_Token.toString());
				
			}
			
			if(Salesforce_User_ID != null){
				
					this.setProperty("Salesforce_User_ID", Salesforce_User_ID.toString());
				
			}
			
			if(comptabilite_analytique_month != null){
				
					this.setProperty("comptabilite_analytique_month", comptabilite_analytique_month.toString());
				
			}
			
			if(comptabilite_analytique_year != null){
				
					this.setProperty("comptabilite_analytique_year", comptabilite_analytique_year.toString());
				
			}
			
			if(Ecolotrans_JP_Month_MM != null){
				
					this.setProperty("Ecolotrans_JP_Month_MM", Ecolotrans_JP_Month_MM.toString());
				
			}
			
			if(end_date != null){
				
					this.setProperty("end_date", end_date.toString());
				
			}
			
			if(Extraction_Aprm != null){
				
					this.setProperty("Extraction_Aprm", Extraction_Aprm.toString());
				
			}
			
			if(Extraction_Jour != null){
				
					this.setProperty("Extraction_Jour", Extraction_Jour.toString());
				
			}
			
			if(Extraction_Matin != null){
				
					this.setProperty("Extraction_Matin", Extraction_Matin.toString());
				
			}
			
			if(start_date != null){
				
					this.setProperty("start_date", start_date.toString());
				
			}
			
			if(Urbantz_directory != null){
				
					this.setProperty("Urbantz_directory", Urbantz_directory.toString());
				
			}
			
			if(urbantz_extraction_date != null){
				
					this.setProperty("urbantz_extraction_date", urbantz_extraction_date.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String Billing_BSO_Months;
public String getBilling_BSO_Months(){
	return this.Billing_BSO_Months;
}
public Integer Billing_BSO_Start_Year;
public Integer getBilling_BSO_Start_Year(){
	return this.Billing_BSO_Start_Year;
}
public String Billing_Comptabilite_File;
public String getBilling_Comptabilite_File(){
	return this.Billing_Comptabilite_File;
}
public String Billing_Comptabilite_Folder;
public String getBilling_Comptabilite_Folder(){
	return this.Billing_Comptabilite_Folder;
}
public String Billing_Distant_Rep;
public String getBilling_Distant_Rep(){
	return this.Billing_Distant_Rep;
}
public String Billing_File_Masque;
public String getBilling_File_Masque(){
	return this.Billing_File_Masque;
}
public String Billing_Local_Rep;
public String getBilling_Local_Rep(){
	return this.Billing_Local_Rep;
}
public String Billing_Name;
public String getBilling_Name(){
	return this.Billing_Name;
}
public Integer Billing_Start_Number;
public Integer getBilling_Start_Number(){
	return this.Billing_Start_Number;
}
public Float Billing_TVA_default_value;
public Float getBilling_TVA_default_value(){
	return this.Billing_TVA_default_value;
}
public String Clean_distant_Rep;
public String getClean_distant_Rep(){
	return this.Clean_distant_Rep;
}
public String Client_DataBase;
public String getClient_DataBase(){
	return this.Client_DataBase;
}
public java.lang.String DB_Password;
public java.lang.String getDB_Password(){
	return this.DB_Password;
}
public String Hote;
public String getHote(){
	return this.Hote;
}
public String ODS_Database;
public String getODS_Database(){
	return this.ODS_Database;
}
public String PBI_Database;
public String getPBI_Database(){
	return this.PBI_Database;
}
public String PBI_PC_Database;
public String getPBI_PC_Database(){
	return this.PBI_PC_Database;
}
public String PBI_RT_Database;
public String getPBI_RT_Database(){
	return this.PBI_RT_Database;
}
public Integer Port;
public Integer getPort(){
	return this.Port;
}
public String User;
public String getUser(){
	return this.User;
}
public String DataMart_Clean_Database;
public String getDataMart_Clean_Database(){
	return this.DataMart_Clean_Database;
}
public String DataMart_Clean_Max_Date;
public String getDataMart_Clean_Max_Date(){
	return this.DataMart_Clean_Max_Date;
}
public String DataMart_Clean_Min_Date;
public String getDataMart_Clean_Min_Date(){
	return this.DataMart_Clean_Min_Date;
}
public Integer DataMart_Closure_Date_PlusX;
public Integer getDataMart_Closure_Date_PlusX(){
	return this.DataMart_Closure_Date_PlusX;
}
public Integer Limit_Percent;
public Integer getLimit_Percent(){
	return this.Limit_Percent;
}
public String Logistic_Max_Date_Plus_One;
public String getLogistic_Max_Date_Plus_One(){
	return this.Logistic_Max_Date_Plus_One;
}
public String Logistic_Min_Date_Minus_One;
public String getLogistic_Min_Date_Minus_One(){
	return this.Logistic_Min_Date_Minus_One;
}
public Integer deleted_J_minus_X;
public Integer getDeleted_J_minus_X(){
	return this.deleted_J_minus_X;
}
public Integer deleted_J_plusOne_X;
public Integer getDeleted_J_plusOne_X(){
	return this.deleted_J_plusOne_X;
}
		public String FTP_DistantRep;
		public String getFTP_DistantRep(){
			return this.FTP_DistantRep;
		}
		
public String FTP_FileMasque;
public String getFTP_FileMasque(){
	return this.FTP_FileMasque;
}
public String FTP_Hote;
public String getFTP_Hote(){
	return this.FTP_Hote;
}
public java.lang.String FTP_Password;
public java.lang.String getFTP_Password(){
	return this.FTP_Password;
}
public Integer FTP_Port;
public Integer getFTP_Port(){
	return this.FTP_Port;
}
public String FTP_ST_DistantRep;
public String getFTP_ST_DistantRep(){
	return this.FTP_ST_DistantRep;
}
public String FTP_User;
public String getFTP_User(){
	return this.FTP_User;
}
public Integer FTP_Wms_Port;
public Integer getFTP_Wms_Port(){
	return this.FTP_Wms_Port;
}
public String keyStore_file_name;
public String getKeyStore_file_name(){
	return this.keyStore_file_name;
}
public String KeyStore_Repo;
public String getKeyStore_Repo(){
	return this.KeyStore_Repo;
}
public String mail_password;
public String getMail_password(){
	return this.mail_password;
}
public String send_mail_from;
public String getSend_mail_from(){
	return this.send_mail_from;
}
public String send_mail_to;
public String getSend_mail_to(){
	return this.send_mail_to;
}
public String send_to_second_mail;
public String getSend_to_second_mail(){
	return this.send_to_second_mail;
}
public String send_to_third_mail;
public String getSend_to_third_mail(){
	return this.send_to_third_mail;
}
public String Clients_Masque;
public String getClients_Masque(){
	return this.Clients_Masque;
}
public String Code_client_masque;
public String getCode_client_masque(){
	return this.Code_client_masque;
}
public String Command_Logistic_Invalid_Date;
public String getCommand_Logistic_Invalid_Date(){
	return this.Command_Logistic_Invalid_Date;
}
public String Command_Logistic_Masque;
public String getCommand_Logistic_Masque(){
	return this.Command_Logistic_Masque;
}
public String Command_Transport_Masque;
public String getCommand_Transport_Masque(){
	return this.Command_Transport_Masque;
}
public String Command_Transport_Masque_Express;
public String getCommand_Transport_Masque_Express(){
	return this.Command_Transport_Masque_Express;
}
public String Ecolotrans_JP;
public String getEcolotrans_JP(){
	return this.Ecolotrans_JP;
}
public String Holiday_Days_Masque;
public String getHoliday_Days_Masque(){
	return this.Holiday_Days_Masque;
}
public String Livraisons_Exception;
public String getLivraisons_Exception(){
	return this.Livraisons_Exception;
}
public String Livraisons_Masque;
public String getLivraisons_Masque(){
	return this.Livraisons_Masque;
}
public String Livraisons_Ok;
public String getLivraisons_Ok(){
	return this.Livraisons_Ok;
}
public String ST_Drivers;
public String getST_Drivers(){
	return this.ST_Drivers;
}
public String Tarification_Logistic_Masque;
public String getTarification_Logistic_Masque(){
	return this.Tarification_Logistic_Masque;
}
public String Tarification_Transport_Masque;
public String getTarification_Transport_Masque(){
	return this.Tarification_Transport_Masque;
}
public String Tournee_Masque;
public String getTournee_Masque(){
	return this.Tournee_Masque;
}
public String TVA_Exceptions;
public String getTVA_Exceptions(){
	return this.TVA_Exceptions;
}
public String Backup;
public String getBackup(){
	return this.Backup;
}
public String Server_Clean;
public String getServer_Clean(){
	return this.Server_Clean;
}
public String Server_In;
public String getServer_In(){
	return this.Server_In;
}
public String Server_Out;
public String getServer_Out(){
	return this.Server_Out;
}
public String Server_Out_DataMart;
public String getServer_Out_DataMart(){
	return this.Server_Out_DataMart;
}
public String Art_masque;
public String getArt_masque(){
	return this.Art_masque;
}
public String Cdc_masque;
public String getCdc_masque(){
	return this.Cdc_masque;
}
public String Cre_masque;
public String getCre_masque(){
	return this.Cre_masque;
}
public String Crp_masque;
public String getCrp_masque(){
	return this.Crp_masque;
}
public String Crr_masque;
public String getCrr_masque(){
	return this.Crr_masque;
}
public String Distant_Magistor_Clients_Input;
public String getDistant_Magistor_Clients_Input(){
	return this.Distant_Magistor_Clients_Input;
}
public String Distant_Magistor_Clients_Test_Input;
public String getDistant_Magistor_Clients_Test_Input(){
	return this.Distant_Magistor_Clients_Test_Input;
}
public String Distant_Magistor1_Input;
public String getDistant_Magistor1_Input(){
	return this.Distant_Magistor1_Input;
}
public String Distant_Magistor1_Output;
public String getDistant_Magistor1_Output(){
	return this.Distant_Magistor1_Output;
}
public String Distant_Magistor1_Test_Input;
public String getDistant_Magistor1_Test_Input(){
	return this.Distant_Magistor1_Test_Input;
}
public String Distant_Magistor1_Test_Output;
public String getDistant_Magistor1_Test_Output(){
	return this.Distant_Magistor1_Test_Output;
}
public String Distant_Magistor2_Input;
public String getDistant_Magistor2_Input(){
	return this.Distant_Magistor2_Input;
}
public String Distant_Magistor2_Output;
public String getDistant_Magistor2_Output(){
	return this.Distant_Magistor2_Output;
}
public String Distant_Magistor2_Test_Input;
public String getDistant_Magistor2_Test_Input(){
	return this.Distant_Magistor2_Test_Input;
}
public String Distant_Magistor2_Test_Output;
public String getDistant_Magistor2_Test_Output(){
	return this.Distant_Magistor2_Test_Output;
}
public String Drc_masque;
public String getDrc_masque(){
	return this.Drc_masque;
}
public String Mvt_masque;
public String getMvt_masque(){
	return this.Mvt_masque;
}
public String Stk_masque;
public String getStk_masque(){
	return this.Stk_masque;
}
public String Xml_File_Masque;
public String getXml_File_Masque(){
	return this.Xml_File_Masque;
}
public String Article_Exceptions;
public String getArticle_Exceptions(){
	return this.Article_Exceptions;
}
public String Cleaning_Reject_Logistic_price_is_zero;
public String getCleaning_Reject_Logistic_price_is_zero(){
	return this.Cleaning_Reject_Logistic_price_is_zero;
}
public String Cleaning_Reject_Rep;
public String getCleaning_Reject_Rep(){
	return this.Cleaning_Reject_Rep;
}
public String Cleaning_Reject_Transport_price_is_zero;
public String getCleaning_Reject_Transport_price_is_zero(){
	return this.Cleaning_Reject_Transport_price_is_zero;
}
public String Cleaning_Transport_no_PostalCode;
public String getCleaning_Transport_no_PostalCode(){
	return this.Cleaning_Transport_no_PostalCode;
}
public String Commande_Exceptions;
public String getCommande_Exceptions(){
	return this.Commande_Exceptions;
}
public String Conditionnement_Exceptions;
public String getConditionnement_Exceptions(){
	return this.Conditionnement_Exceptions;
}
public String CR_Reception_Exceptions;
public String getCR_Reception_Exceptions(){
	return this.CR_Reception_Exceptions;
}
public String Csv_File_Masque;
public String getCsv_File_Masque(){
	return this.Csv_File_Masque;
}
public String Diagnostic_Reject_Command_Error;
public String getDiagnostic_Reject_Command_Error(){
	return this.Diagnostic_Reject_Command_Error;
}
public String Diagnostic_Reject_Day_Not_Ok;
public String getDiagnostic_Reject_Day_Not_Ok(){
	return this.Diagnostic_Reject_Day_Not_Ok;
}
public String Diagnostic_Reject_Postal_Code_Ok;
public String getDiagnostic_Reject_Postal_Code_Ok(){
	return this.Diagnostic_Reject_Postal_Code_Ok;
}
public String Diagnostic_Reject_Rep;
public String getDiagnostic_Reject_Rep(){
	return this.Diagnostic_Reject_Rep;
}
public String Dossier_Reception_Exceptions;
public String getDossier_Reception_Exceptions(){
	return this.Dossier_Reception_Exceptions;
}
public String Excel_File_Masque;
public String getExcel_File_Masque(){
	return this.Excel_File_Masque;
}
public String Ligne_Commande_Exceptions;
public String getLigne_Commande_Exceptions(){
	return this.Ligne_Commande_Exceptions;
}
public String Migration_Billing_Not_Ok;
public String getMigration_Billing_Not_Ok(){
	return this.Migration_Billing_Not_Ok;
}
public String Reject_Client_File;
public String getReject_Client_File(){
	return this.Reject_Client_File;
}
public String Reject_Client_Local_Rep;
public String getReject_Client_Local_Rep(){
	return this.Reject_Client_Local_Rep;
}
public String Reject_Command_Logisitc_Code_Client;
public String getReject_Command_Logisitc_Code_Client(){
	return this.Reject_Command_Logisitc_Code_Client;
}
public String Reject_Command_Transport_Code_Client;
public String getReject_Command_Transport_Code_Client(){
	return this.Reject_Command_Transport_Code_Client;
}
public String Reject_Distant_Rep;
public String getReject_Distant_Rep(){
	return this.Reject_Distant_Rep;
}
public String Reject_Distant_Rep_DataMart;
public String getReject_Distant_Rep_DataMart(){
	return this.Reject_Distant_Rep_DataMart;
}
public String Reject_Duplicated_Client_File;
public String getReject_Duplicated_Client_File(){
	return this.Reject_Duplicated_Client_File;
}
public String Reject_Migration_Local_Rep;
public String getReject_Migration_Local_Rep(){
	return this.Reject_Migration_Local_Rep;
}
public String Reject_Not_Complet_Client;
public String getReject_Not_Complet_Client(){
	return this.Reject_Not_Complet_Client;
}
public String Reject_Service_Detail_Local_Rep;
public String getReject_Service_Detail_Local_Rep(){
	return this.Reject_Service_Detail_Local_Rep;
}
public String Reject_Service_Detail_Logistic_DB;
public String getReject_Service_Detail_Logistic_DB(){
	return this.Reject_Service_Detail_Logistic_DB;
}
public String Reject_Service_Detail_Logistic_Unknown_Client;
public String getReject_Service_Detail_Logistic_Unknown_Client(){
	return this.Reject_Service_Detail_Logistic_Unknown_Client;
}
public String Reject_Service_Detail_Transport_DB;
public String getReject_Service_Detail_Transport_DB(){
	return this.Reject_Service_Detail_Transport_DB;
}
public String Reject_Service_Detail_Transport_Unknown_Client;
public String getReject_Service_Detail_Transport_Unknown_Client(){
	return this.Reject_Service_Detail_Transport_Unknown_Client;
}
public String Reject_Tarification_Local_Rep;
public String getReject_Tarification_Local_Rep(){
	return this.Reject_Tarification_Local_Rep;
}
public String Reject_Tarification_Logistic_Code_Client;
public String getReject_Tarification_Logistic_Code_Client(){
	return this.Reject_Tarification_Logistic_Code_Client;
}
public String Reject_Tarification_Logistic_DB;
public String getReject_Tarification_Logistic_DB(){
	return this.Reject_Tarification_Logistic_DB;
}
public String Reject_Tarification_Logistic_unknown_Client;
public String getReject_Tarification_Logistic_unknown_Client(){
	return this.Reject_Tarification_Logistic_unknown_Client;
}
public String Reject_Tarification_Transport_Code_Client;
public String getReject_Tarification_Transport_Code_Client(){
	return this.Reject_Tarification_Transport_Code_Client;
}
public String Reject_Tarification_Transport_DB;
public String getReject_Tarification_Transport_DB(){
	return this.Reject_Tarification_Transport_DB;
}
public String Reject_Tarification_Transport_unknown_Client;
public String getReject_Tarification_Transport_unknown_Client(){
	return this.Reject_Tarification_Transport_unknown_Client;
}
public Integer code_client_length;
public Integer getCode_client_length(){
	return this.code_client_length;
}
public String code_client_regex;
public String getCode_client_regex(){
	return this.code_client_regex;
}
public String Livraison_directory;
public String getLivraison_directory(){
	return this.Livraison_directory;
}
public Integer Round_Delay_Minus_Days;
public Integer getRound_Delay_Minus_Days(){
	return this.Round_Delay_Minus_Days;
}
public Integer Round_Delay_Plus_Days_Plus_One;
public Integer getRound_Delay_Plus_Days_Plus_One(){
	return this.Round_Delay_Plus_Days_Plus_One;
}
public String Round_directory;
public String getRound_directory(){
	return this.Round_directory;
}
public String Round_file_name;
public String getRound_file_name(){
	return this.Round_file_name;
}
public Integer Round_Minus_Days;
public Integer getRound_Minus_Days(){
	return this.Round_Minus_Days;
}
public String Salesforce_Name;
public String getSalesforce_Name(){
	return this.Salesforce_Name;
}
public java.lang.String Salesforce_Password;
public java.lang.String getSalesforce_Password(){
	return this.Salesforce_Password;
}
public java.lang.String Salesforce_Security_Token;
public java.lang.String getSalesforce_Security_Token(){
	return this.Salesforce_Security_Token;
}
public String Salesforce_User_ID;
public String getSalesforce_User_ID(){
	return this.Salesforce_User_ID;
}
public String comptabilite_analytique_month;
public String getComptabilite_analytique_month(){
	return this.comptabilite_analytique_month;
}
public String comptabilite_analytique_year;
public String getComptabilite_analytique_year(){
	return this.comptabilite_analytique_year;
}
public String Ecolotrans_JP_Month_MM;
public String getEcolotrans_JP_Month_MM(){
	return this.Ecolotrans_JP_Month_MM;
}
public String end_date;
public String getEnd_date(){
	return this.end_date;
}
public Integer Extraction_Aprm;
public Integer getExtraction_Aprm(){
	return this.Extraction_Aprm;
}
public Integer Extraction_Jour;
public Integer getExtraction_Jour(){
	return this.Extraction_Jour;
}
public Integer Extraction_Matin;
public Integer getExtraction_Matin(){
	return this.Extraction_Matin;
}
public String start_date;
public String getStart_date(){
	return this.start_date;
}
public String Urbantz_directory;
public String getUrbantz_directory(){
	return this.Urbantz_directory;
}
public String urbantz_extraction_date;
public String getUrbantz_extraction_date(){
	return this.urbantz_extraction_date;
}
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR";
	private final String projectName = "ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_zbxZFXZ4Ee6j9cQuSh5lZA", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_zbxZFXZ4Ee6j9cQuSh5lZA", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tRunJob_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
					tRunJob_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
					tRunJob_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
					tRunJob_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
					tRunJob_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
					tRunJob_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tRunJob_1Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRunJob_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError2", 0, "error");
						}
					
					errorCode = null;
					tRunJob_2Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRunJob_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError3", 0, "error");
						}
					
					errorCode = null;
					tRunJob_3Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRunJob_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError5", 0, "error");
						}
					
					errorCode = null;
					tRunJob_5Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRunJob_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError6", 0, "error");
						}
					
					errorCode = null;
					tRunJob_6Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tRunJob_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	








public void tRunJob_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_4");
		org.slf4j.MDC.put("_subJobPid", "OpXgAs_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_4", false);
		start_Hash.put("tRunJob_4", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRunJob_4");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		
		int tos_count_tRunJob_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_4 = new StringBuilder();
                    log4jParamters_tRunJob_4.append("Parameters:");
                            log4jParamters_tRunJob_4.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + (log4jParamters_tRunJob_4) );
                    } 
                } 
            new BytesLimit65535_tRunJob_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_4", "Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_4 begin ] stop
 */
	
	/**
	 * [tRunJob_4 main ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		
	java.util.List<String> paraList_tRunJob_4 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_4.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_4.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_4.add("--father_node=tRunJob_4");
	      			
	        				paraList_tRunJob_4.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_4.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_4.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_4.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_4.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_4 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_4 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_4".equals(tRunJobName_tRunJob_4) && childResumePath_tRunJob_4 != null){
		paraList_tRunJob_4.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_4.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_4");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_4 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_4 = null;

	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_input_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES childJob_tRunJob_4 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_input_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_4 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_4) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_4 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_4 : talendDataSources_tRunJob_4
			        .entrySet()) {
	            dataSources_tRunJob_4.put(talendDataSourceEntry_tRunJob_4.getKey(),
	                    talendDataSourceEntry_tRunJob_4.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_4.setDataSources(dataSources_tRunJob_4);
	    }
		  
			childJob_tRunJob_4.parentContextMap = parentContextMap_tRunJob_4;
		  
		
			log.info("tRunJob_4 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_input_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_4 = childJob_tRunJob_4.runJob((String[]) paraList_tRunJob_4.toArray(new String[paraList_tRunJob_4.size()]));
		
			log.info("tRunJob_4 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_input_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES' is done.");
		
            if(childJob_tRunJob_4.getErrorCode() == null){
                globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getStatus() != null && ("failure").equals(childJob_tRunJob_4.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getErrorCode());
            }
            if (childJob_tRunJob_4.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_4_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_4.getExceptionStackTrace());
            }

 


	tos_count_tRunJob_4++;

/**
 * [tRunJob_4 main ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		

 



/**
 * [tRunJob_4 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		

 



/**
 * [tRunJob_4 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_4 end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Done.") );

ok_Hash.put("tRunJob_4", true);
end_Hash.put("tRunJob_4", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRunJob_4", end_Hash.get("tRunJob_4")-start_Hash.get("tRunJob_4"));
tStatCatcher_1Process(globalMap);



/**
 * [tRunJob_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tRunJob_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_4 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_4";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		
	
 



/**
 * [tRunJob_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_4_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_7");
		org.slf4j.MDC.put("_subJobPid", "NPPtlQ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_7", false);
		start_Hash.put("tRunJob_7", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRunJob_7");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		
		int tos_count_tRunJob_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_7 = new StringBuilder();
                    log4jParamters_tRunJob_7.append("Parameters:");
                            log4jParamters_tRunJob_7.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                            log4jParamters_tRunJob_7.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_7 - "  + (log4jParamters_tRunJob_7) );
                    } 
                } 
            new BytesLimit65535_tRunJob_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_7", "Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_7 begin ] stop
 */
	
	/**
	 * [tRunJob_7 main ] start
	 */

	

	
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		
	java.util.List<String> paraList_tRunJob_7 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_7.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_7.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_7.add("--father_node=tRunJob_7");
	      			
	        				paraList_tRunJob_7.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_7.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_7.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_7.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_7.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_7 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_7 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_7".equals(tRunJobName_tRunJob_7) && childResumePath_tRunJob_7 != null){
		paraList_tRunJob_7.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_7.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_7");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_7 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_7 = null;

	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_art_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES childJob_tRunJob_7 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_art_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_7 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_7) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_7 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_7 : talendDataSources_tRunJob_7
			        .entrySet()) {
	            dataSources_tRunJob_7.put(talendDataSourceEntry_tRunJob_7.getKey(),
	                    talendDataSourceEntry_tRunJob_7.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_7.setDataSources(dataSources_tRunJob_7);
	    }
		  
			childJob_tRunJob_7.parentContextMap = parentContextMap_tRunJob_7;
		  
		
			log.info("tRunJob_7 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_art_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_7 = childJob_tRunJob_7.runJob((String[]) paraList_tRunJob_7.toArray(new String[paraList_tRunJob_7.size()]));
		
			log.info("tRunJob_7 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_verify_art_files_0_1.Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES' is done.");
		
            if(childJob_tRunJob_7.getErrorCode() == null){
                globalMap.put("tRunJob_7_CHILD_RETURN_CODE", childJob_tRunJob_7.getStatus() != null && ("failure").equals(childJob_tRunJob_7.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_7_CHILD_RETURN_CODE", childJob_tRunJob_7.getErrorCode());
            }
            if (childJob_tRunJob_7.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_7_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_7.getExceptionStackTrace());
            }

 


	tos_count_tRunJob_7++;

/**
 * [tRunJob_7 main ] stop
 */
	
	/**
	 * [tRunJob_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		

 



/**
 * [tRunJob_7 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		

 



/**
 * [tRunJob_7 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_7 end ] start
	 */

	

	
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_7 - "  + ("Done.") );

ok_Hash.put("tRunJob_7", true);
end_Hash.put("tRunJob_7", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRunJob_7", end_Hash.get("tRunJob_7")-start_Hash.get("tRunJob_7"));
tStatCatcher_1Process(globalMap);



/**
 * [tRunJob_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tRunJob_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_7 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_7";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		
	
 



/**
 * [tRunJob_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_7_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_8");
		org.slf4j.MDC.put("_subJobPid", "oDM45f_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_8", false);
		start_Hash.put("tRunJob_8", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRunJob_8");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		
		int tos_count_tRunJob_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_8 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_8{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_8 = new StringBuilder();
                    log4jParamters_tRunJob_8.append("Parameters:");
                            log4jParamters_tRunJob_8.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                            log4jParamters_tRunJob_8.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_8 - "  + (log4jParamters_tRunJob_8) );
                    } 
                } 
            new BytesLimit65535_tRunJob_8().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_8", "Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_8 begin ] stop
 */
	
	/**
	 * [tRunJob_8 main ] start
	 */

	

	
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		
	java.util.List<String> paraList_tRunJob_8 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_8.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_8.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_8.add("--father_node=tRunJob_8");
	      			
	        				paraList_tRunJob_8.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_8.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_8.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_8.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_8.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_8 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_8 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_8".equals(tRunJobName_tRunJob_8) && childResumePath_tRunJob_8 != null){
		paraList_tRunJob_8.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_8.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_8");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_8 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_8 = null;

	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_pre_diagnostic_input_files_0_1.Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES childJob_tRunJob_8 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_pre_diagnostic_input_files_0_1.Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_8 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_8) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_8 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_8 : talendDataSources_tRunJob_8
			        .entrySet()) {
	            dataSources_tRunJob_8.put(talendDataSourceEntry_tRunJob_8.getKey(),
	                    talendDataSourceEntry_tRunJob_8.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_8.setDataSources(dataSources_tRunJob_8);
	    }
		  
			childJob_tRunJob_8.parentContextMap = parentContextMap_tRunJob_8;
		  
		
			log.info("tRunJob_8 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_pre_diagnostic_input_files_0_1.Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_8 = childJob_tRunJob_8.runJob((String[]) paraList_tRunJob_8.toArray(new String[paraList_tRunJob_8.size()]));
		
			log.info("tRunJob_8 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_pre_diagnostic_input_files_0_1.Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES' is done.");
		
            if(childJob_tRunJob_8.getErrorCode() == null){
                globalMap.put("tRunJob_8_CHILD_RETURN_CODE", childJob_tRunJob_8.getStatus() != null && ("failure").equals(childJob_tRunJob_8.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_8_CHILD_RETURN_CODE", childJob_tRunJob_8.getErrorCode());
            }
            if (childJob_tRunJob_8.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_8_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_8.getExceptionStackTrace());
            }

 


	tos_count_tRunJob_8++;

/**
 * [tRunJob_8 main ] stop
 */
	
	/**
	 * [tRunJob_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		

 



/**
 * [tRunJob_8 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		

 



/**
 * [tRunJob_8 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_8 end ] start
	 */

	

	
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_8 - "  + ("Done.") );

ok_Hash.put("tRunJob_8", true);
end_Hash.put("tRunJob_8", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRunJob_8", end_Hash.get("tRunJob_8")-start_Hash.get("tRunJob_8"));
tStatCatcher_1Process(globalMap);



/**
 * [tRunJob_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tRunJob_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_8 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_8";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		
	
 



/**
 * [tRunJob_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_8_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_9");
		org.slf4j.MDC.put("_subJobPid", "duxfkX_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_9", false);
		start_Hash.put("tRunJob_9", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRunJob_9");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		
		int tos_count_tRunJob_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_9{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_9 = new StringBuilder();
                    log4jParamters_tRunJob_9.append("Parameters:");
                            log4jParamters_tRunJob_9.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                            log4jParamters_tRunJob_9.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + (log4jParamters_tRunJob_9) );
                    } 
                } 
            new BytesLimit65535_tRunJob_9().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_9", "Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_9 begin ] stop
 */
	
	/**
	 * [tRunJob_9 main ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		
	java.util.List<String> paraList_tRunJob_9 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_9.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_9.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_9.add("--father_node=tRunJob_9");
	      			
	        				paraList_tRunJob_9.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_9.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_9.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_9.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_9.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_9 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_9 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_9".equals(tRunJobName_tRunJob_9) && childResumePath_tRunJob_9 != null){
		paraList_tRunJob_9.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_9.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_9");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_9 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_9 = null;

	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_clean_input_files_0_1.Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES childJob_tRunJob_9 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_clean_input_files_0_1.Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_9 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_9) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_9 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_9 : talendDataSources_tRunJob_9
			        .entrySet()) {
	            dataSources_tRunJob_9.put(talendDataSourceEntry_tRunJob_9.getKey(),
	                    talendDataSourceEntry_tRunJob_9.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_9.setDataSources(dataSources_tRunJob_9);
	    }
		  
			childJob_tRunJob_9.parentContextMap = parentContextMap_tRunJob_9;
		  
		
			log.info("tRunJob_9 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_clean_input_files_0_1.Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_9 = childJob_tRunJob_9.runJob((String[]) paraList_tRunJob_9.toArray(new String[paraList_tRunJob_9.size()]));
		
			log.info("tRunJob_9 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_clean_input_files_0_1.Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES' is done.");
		
            if(childJob_tRunJob_9.getErrorCode() == null){
                globalMap.put("tRunJob_9_CHILD_RETURN_CODE", childJob_tRunJob_9.getStatus() != null && ("failure").equals(childJob_tRunJob_9.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_9_CHILD_RETURN_CODE", childJob_tRunJob_9.getErrorCode());
            }
            if (childJob_tRunJob_9.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_9_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_9.getExceptionStackTrace());
            }

 


	tos_count_tRunJob_9++;

/**
 * [tRunJob_9 main ] stop
 */
	
	/**
	 * [tRunJob_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		

 



/**
 * [tRunJob_9 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		

 



/**
 * [tRunJob_9 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_9 end ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_9 - "  + ("Done.") );

ok_Hash.put("tRunJob_9", true);
end_Hash.put("tRunJob_9", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRunJob_9", end_Hash.get("tRunJob_9")-start_Hash.get("tRunJob_9"));
tStatCatcher_1Process(globalMap);



/**
 * [tRunJob_9 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tRunJob_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_9 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_9";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		
	
 



/**
 * [tRunJob_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_9_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_10");
		org.slf4j.MDC.put("_subJobPid", "lmka9I_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_10", false);
		start_Hash.put("tRunJob_10", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRunJob_10");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		
		int tos_count_tRunJob_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_10{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_10 = new StringBuilder();
                    log4jParamters_tRunJob_10.append("Parameters:");
                            log4jParamters_tRunJob_10.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_NOTIFICATION");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                            log4jParamters_tRunJob_10.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + (log4jParamters_tRunJob_10) );
                    } 
                } 
            new BytesLimit65535_tRunJob_10().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_10", "Massi_ECOLOTRANS_WMS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_10 begin ] stop
 */
	
	/**
	 * [tRunJob_10 main ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_10 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_10.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_10.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_10.add("--father_node=tRunJob_10");
	      			
	        				paraList_tRunJob_10.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_10.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_10.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_10.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_10.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_10 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_10 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_10".equals(tRunJobName_tRunJob_10) && childResumePath_tRunJob_10 != null){
		paraList_tRunJob_10.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_10.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_10");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_10 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_10 = null;

	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_notification_0_1.Massi_ECOLOTRANS_WMS_NOTIFICATION childJob_tRunJob_10 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_notification_0_1.Massi_ECOLOTRANS_WMS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_10 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_10) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_10 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_10 : talendDataSources_tRunJob_10
			        .entrySet()) {
	            dataSources_tRunJob_10.put(talendDataSourceEntry_tRunJob_10.getKey(),
	                    talendDataSourceEntry_tRunJob_10.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_10.setDataSources(dataSources_tRunJob_10);
	    }
		  
			childJob_tRunJob_10.parentContextMap = parentContextMap_tRunJob_10;
		  
		
			log.info("tRunJob_10 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_notification_0_1.Massi_ECOLOTRANS_WMS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_10 = childJob_tRunJob_10.runJob((String[]) paraList_tRunJob_10.toArray(new String[paraList_tRunJob_10.size()]));
		
			log.info("tRunJob_10 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_notification_0_1.Massi_ECOLOTRANS_WMS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_10.getErrorCode() == null){
                globalMap.put("tRunJob_10_CHILD_RETURN_CODE", childJob_tRunJob_10.getStatus() != null && ("failure").equals(childJob_tRunJob_10.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_10_CHILD_RETURN_CODE", childJob_tRunJob_10.getErrorCode());
            }
            if (childJob_tRunJob_10.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_10_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_10.getExceptionStackTrace());
            }

 


	tos_count_tRunJob_10++;

/**
 * [tRunJob_10 main ] stop
 */
	
	/**
	 * [tRunJob_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		

 



/**
 * [tRunJob_10 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		

 



/**
 * [tRunJob_10 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_10 end ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_10 - "  + ("Done.") );

ok_Hash.put("tRunJob_10", true);
end_Hash.put("tRunJob_10", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRunJob_10", end_Hash.get("tRunJob_10")-start_Hash.get("tRunJob_10"));
tStatCatcher_1Process(globalMap);



/**
 * [tRunJob_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_10 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_10";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_10_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_6");
		org.slf4j.MDC.put("_subJobPid", "uuP9l4_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_6", false);
		start_Hash.put("tRunJob_6", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
		int tos_count_tRunJob_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_6 = new StringBuilder();
                    log4jParamters_tRunJob_6.append("Parameters:");
                            log4jParamters_tRunJob_6.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("Job_Name")+", PARAM_VALUE_COLUMN="+("\"Massi_ECOLOTRANS_WMS_NOTIFICATION\"")+"}, {PARAM_NAME_COLUMN="+("Error_Source")+", PARAM_VALUE_COLUMN="+("\"plan WMS\"")+"}]");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + (log4jParamters_tRunJob_6) );
                    } 
                } 
            new BytesLimit65535_tRunJob_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_6", "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_6 begin ] stop
 */
	
	/**
	 * [tRunJob_6 main ] start
	 */

	

	
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_6 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_6.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_6.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_6.add("--father_node=tRunJob_6");
	      			
	        				paraList_tRunJob_6.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_6.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_6.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_6.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_6.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_6 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_6 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_6".equals(tRunJobName_tRunJob_6) && childResumePath_tRunJob_6 != null){
		paraList_tRunJob_6.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_6.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_6");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_6 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_6 = null;

	
		obj_tRunJob_6 = "Massi_ECOLOTRANS_WMS_NOTIFICATION";
		if(obj_tRunJob_6!=null) {
			if (obj_tRunJob_6.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_6.add("--context_param Job_Name=" + ((java.util.Date) obj_tRunJob_6).getTime());
			} else {
				
					paraList_tRunJob_6.add("--context_param Job_Name=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_6));
					
				
			}
		} else {
			paraList_tRunJob_6.add("--context_param Job_Name=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_6.put("Job_Name", obj_tRunJob_6);
	
		obj_tRunJob_6 = "plan WMS";
		if(obj_tRunJob_6!=null) {
			if (obj_tRunJob_6.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_6.add("--context_param Error_Source=" + ((java.util.Date) obj_tRunJob_6).getTime());
			} else {
				
					paraList_tRunJob_6.add("--context_param Error_Source=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_6));
					
				
			}
		} else {
			paraList_tRunJob_6.add("--context_param Error_Source=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_6.put("Error_Source", obj_tRunJob_6);
	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION childJob_tRunJob_6 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_6 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_6) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_6 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_6 : talendDataSources_tRunJob_6
			        .entrySet()) {
	            dataSources_tRunJob_6.put(talendDataSourceEntry_tRunJob_6.getKey(),
	                    talendDataSourceEntry_tRunJob_6.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_6.setDataSources(dataSources_tRunJob_6);
	    }
		  
			childJob_tRunJob_6.parentContextMap = parentContextMap_tRunJob_6;
		  
		
			log.info("tRunJob_6 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_6 = childJob_tRunJob_6.runJob((String[]) paraList_tRunJob_6.toArray(new String[paraList_tRunJob_6.size()]));
		
			log.info("tRunJob_6 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_6.getErrorCode() == null){
                globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getStatus() != null && ("failure").equals(childJob_tRunJob_6.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getErrorCode());
            }
            if (childJob_tRunJob_6.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_6_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_6.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_6.getErrorCode();
                if (childJob_tRunJob_6.getErrorCode() != null || ("failure").equals(childJob_tRunJob_6.getStatus())) {
                    java.lang.Exception ce_tRunJob_6 = childJob_tRunJob_6.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_6!=null) ? (ce_tRunJob_6.getClass().getName() + ": " + ce_tRunJob_6.getMessage()) : ""));
                }

 


	tos_count_tRunJob_6++;

/**
 * [tRunJob_6 main ] stop
 */
	
	/**
	 * [tRunJob_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_6 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_6 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_6 end ] start
	 */

	

	
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Done.") );

ok_Hash.put("tRunJob_6", true);
end_Hash.put("tRunJob_6", System.currentTimeMillis());




/**
 * [tRunJob_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_6 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_6";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_6_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_5");
		org.slf4j.MDC.put("_subJobPid", "7Q5USl_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_5", false);
		start_Hash.put("tRunJob_5", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
		int tos_count_tRunJob_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_5 = new StringBuilder();
                    log4jParamters_tRunJob_5.append("Parameters:");
                            log4jParamters_tRunJob_5.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("Job_Name")+", PARAM_VALUE_COLUMN="+("\"Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES\"")+"}, {PARAM_NAME_COLUMN="+("Error_Source")+", PARAM_VALUE_COLUMN="+("\"plan WMS\"")+"}]");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + (log4jParamters_tRunJob_5) );
                    } 
                } 
            new BytesLimit65535_tRunJob_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_5", "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_5 begin ] stop
 */
	
	/**
	 * [tRunJob_5 main ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_5 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_5.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_5.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_5.add("--father_node=tRunJob_5");
	      			
	        				paraList_tRunJob_5.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_5.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_5.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_5.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_5.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_5 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_5 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_5".equals(tRunJobName_tRunJob_5) && childResumePath_tRunJob_5 != null){
		paraList_tRunJob_5.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_5.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_5");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_5 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_5 = null;

	
		obj_tRunJob_5 = "Massi_ECOLOTRANS_WMS_CLEAN_INPUT_FILES";
		if(obj_tRunJob_5!=null) {
			if (obj_tRunJob_5.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_5.add("--context_param Job_Name=" + ((java.util.Date) obj_tRunJob_5).getTime());
			} else {
				
					paraList_tRunJob_5.add("--context_param Job_Name=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
					
				
			}
		} else {
			paraList_tRunJob_5.add("--context_param Job_Name=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("Job_Name", obj_tRunJob_5);
	
		obj_tRunJob_5 = "plan WMS";
		if(obj_tRunJob_5!=null) {
			if (obj_tRunJob_5.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_5.add("--context_param Error_Source=" + ((java.util.Date) obj_tRunJob_5).getTime());
			} else {
				
					paraList_tRunJob_5.add("--context_param Error_Source=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
					
				
			}
		} else {
			paraList_tRunJob_5.add("--context_param Error_Source=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("Error_Source", obj_tRunJob_5);
	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION childJob_tRunJob_5 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_5 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_5) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_5 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_5 : talendDataSources_tRunJob_5
			        .entrySet()) {
	            dataSources_tRunJob_5.put(talendDataSourceEntry_tRunJob_5.getKey(),
	                    talendDataSourceEntry_tRunJob_5.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_5.setDataSources(dataSources_tRunJob_5);
	    }
		  
			childJob_tRunJob_5.parentContextMap = parentContextMap_tRunJob_5;
		  
		
			log.info("tRunJob_5 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_5 = childJob_tRunJob_5.runJob((String[]) paraList_tRunJob_5.toArray(new String[paraList_tRunJob_5.size()]));
		
			log.info("tRunJob_5 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_5.getErrorCode() == null){
                globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getStatus() != null && ("failure").equals(childJob_tRunJob_5.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getErrorCode());
            }
            if (childJob_tRunJob_5.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_5_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_5.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_5.getErrorCode();
                if (childJob_tRunJob_5.getErrorCode() != null || ("failure").equals(childJob_tRunJob_5.getStatus())) {
                    java.lang.Exception ce_tRunJob_5 = childJob_tRunJob_5.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_5!=null) ? (ce_tRunJob_5.getClass().getName() + ": " + ce_tRunJob_5.getMessage()) : ""));
                }

 


	tos_count_tRunJob_5++;

/**
 * [tRunJob_5 main ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_5 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_5 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_5 end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Done.") );

ok_Hash.put("tRunJob_5", true);
end_Hash.put("tRunJob_5", System.currentTimeMillis());




/**
 * [tRunJob_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_5 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_5";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_5_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_3");
		org.slf4j.MDC.put("_subJobPid", "gvO8b9_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_3", false);
		start_Hash.put("tRunJob_3", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
		int tos_count_tRunJob_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_3 = new StringBuilder();
                    log4jParamters_tRunJob_3.append("Parameters:");
                            log4jParamters_tRunJob_3.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("Job_Name")+", PARAM_VALUE_COLUMN="+("\"Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES\"")+"}, {PARAM_NAME_COLUMN="+("Error_Source")+", PARAM_VALUE_COLUMN="+("\"plan WMS\"")+"}]");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                            log4jParamters_tRunJob_3.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + (log4jParamters_tRunJob_3) );
                    } 
                } 
            new BytesLimit65535_tRunJob_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_3", "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_3 begin ] stop
 */
	
	/**
	 * [tRunJob_3 main ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_3 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_3.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_3.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_3.add("--father_node=tRunJob_3");
	      			
	        				paraList_tRunJob_3.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_3.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_3.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_3.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_3.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_3 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_3 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_3".equals(tRunJobName_tRunJob_3) && childResumePath_tRunJob_3 != null){
		paraList_tRunJob_3.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_3.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_3");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_3 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_3 = null;

	
		obj_tRunJob_3 = "Massi_ECOLOTRANS_WMS_PRE_DIAGNOSTIC_INPUT_FILES";
		if(obj_tRunJob_3!=null) {
			if (obj_tRunJob_3.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_3.add("--context_param Job_Name=" + ((java.util.Date) obj_tRunJob_3).getTime());
			} else {
				
					paraList_tRunJob_3.add("--context_param Job_Name=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
					
				
			}
		} else {
			paraList_tRunJob_3.add("--context_param Job_Name=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("Job_Name", obj_tRunJob_3);
	
		obj_tRunJob_3 = "plan WMS";
		if(obj_tRunJob_3!=null) {
			if (obj_tRunJob_3.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_3.add("--context_param Error_Source=" + ((java.util.Date) obj_tRunJob_3).getTime());
			} else {
				
					paraList_tRunJob_3.add("--context_param Error_Source=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
					
				
			}
		} else {
			paraList_tRunJob_3.add("--context_param Error_Source=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("Error_Source", obj_tRunJob_3);
	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION childJob_tRunJob_3 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_3 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_3) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_3 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_3 : talendDataSources_tRunJob_3
			        .entrySet()) {
	            dataSources_tRunJob_3.put(talendDataSourceEntry_tRunJob_3.getKey(),
	                    talendDataSourceEntry_tRunJob_3.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_3.setDataSources(dataSources_tRunJob_3);
	    }
		  
			childJob_tRunJob_3.parentContextMap = parentContextMap_tRunJob_3;
		  
		
			log.info("tRunJob_3 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_3 = childJob_tRunJob_3.runJob((String[]) paraList_tRunJob_3.toArray(new String[paraList_tRunJob_3.size()]));
		
			log.info("tRunJob_3 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_3.getErrorCode() == null){
                globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getStatus() != null && ("failure").equals(childJob_tRunJob_3.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getErrorCode());
            }
            if (childJob_tRunJob_3.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_3_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_3.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_3.getErrorCode();
                if (childJob_tRunJob_3.getErrorCode() != null || ("failure").equals(childJob_tRunJob_3.getStatus())) {
                    java.lang.Exception ce_tRunJob_3 = childJob_tRunJob_3.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_3!=null) ? (ce_tRunJob_3.getClass().getName() + ": " + ce_tRunJob_3.getMessage()) : ""));
                }

 


	tos_count_tRunJob_3++;

/**
 * [tRunJob_3 main ] stop
 */
	
	/**
	 * [tRunJob_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_3 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_3 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_3 end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Done.") );

ok_Hash.put("tRunJob_3", true);
end_Hash.put("tRunJob_3", System.currentTimeMillis());




/**
 * [tRunJob_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_3 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_3";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_2");
		org.slf4j.MDC.put("_subJobPid", "JxuBEj_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_2", false);
		start_Hash.put("tRunJob_2", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
		int tos_count_tRunJob_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_2 = new StringBuilder();
                    log4jParamters_tRunJob_2.append("Parameters:");
                            log4jParamters_tRunJob_2.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("Job_Name")+", PARAM_VALUE_COLUMN="+("\"Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES\"")+"}, {PARAM_NAME_COLUMN="+("Error_Source")+", PARAM_VALUE_COLUMN="+("\"plan WMS\"")+"}]");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                            log4jParamters_tRunJob_2.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + (log4jParamters_tRunJob_2) );
                    } 
                } 
            new BytesLimit65535_tRunJob_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_2", "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_2 begin ] stop
 */
	
	/**
	 * [tRunJob_2 main ] start
	 */

	

	
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_2 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_2.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_2.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_2.add("--father_node=tRunJob_2");
	      			
	        				paraList_tRunJob_2.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_2.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_2.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_2.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_2.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_2 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_2 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_2".equals(tRunJobName_tRunJob_2) && childResumePath_tRunJob_2 != null){
		paraList_tRunJob_2.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_2.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_2");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_2 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_2 = null;

	
		obj_tRunJob_2 = "Massi_ECOLOTRANS_WMS_VERIFY_ART_FILES";
		if(obj_tRunJob_2!=null) {
			if (obj_tRunJob_2.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_2.add("--context_param Job_Name=" + ((java.util.Date) obj_tRunJob_2).getTime());
			} else {
				
					paraList_tRunJob_2.add("--context_param Job_Name=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
					
				
			}
		} else {
			paraList_tRunJob_2.add("--context_param Job_Name=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("Job_Name", obj_tRunJob_2);
	
		obj_tRunJob_2 = "plan WMS";
		if(obj_tRunJob_2!=null) {
			if (obj_tRunJob_2.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_2.add("--context_param Error_Source=" + ((java.util.Date) obj_tRunJob_2).getTime());
			} else {
				
					paraList_tRunJob_2.add("--context_param Error_Source=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
					
				
			}
		} else {
			paraList_tRunJob_2.add("--context_param Error_Source=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("Error_Source", obj_tRunJob_2);
	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION childJob_tRunJob_2 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_2 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_2) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_2 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_2 : talendDataSources_tRunJob_2
			        .entrySet()) {
	            dataSources_tRunJob_2.put(talendDataSourceEntry_tRunJob_2.getKey(),
	                    talendDataSourceEntry_tRunJob_2.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_2.setDataSources(dataSources_tRunJob_2);
	    }
		  
			childJob_tRunJob_2.parentContextMap = parentContextMap_tRunJob_2;
		  
		
			log.info("tRunJob_2 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_2 = childJob_tRunJob_2.runJob((String[]) paraList_tRunJob_2.toArray(new String[paraList_tRunJob_2.size()]));
		
			log.info("tRunJob_2 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_2.getErrorCode() == null){
                globalMap.put("tRunJob_2_CHILD_RETURN_CODE", childJob_tRunJob_2.getStatus() != null && ("failure").equals(childJob_tRunJob_2.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_2_CHILD_RETURN_CODE", childJob_tRunJob_2.getErrorCode());
            }
            if (childJob_tRunJob_2.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_2_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_2.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_2.getErrorCode();
                if (childJob_tRunJob_2.getErrorCode() != null || ("failure").equals(childJob_tRunJob_2.getStatus())) {
                    java.lang.Exception ce_tRunJob_2 = childJob_tRunJob_2.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_2!=null) ? (ce_tRunJob_2.getClass().getName() + ": " + ce_tRunJob_2.getMessage()) : ""));
                }

 


	tos_count_tRunJob_2++;

/**
 * [tRunJob_2 main ] stop
 */
	
	/**
	 * [tRunJob_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_2 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_2 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_2 end ] start
	 */

	

	
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Done.") );

ok_Hash.put("tRunJob_2", true);
end_Hash.put("tRunJob_2", System.currentTimeMillis());




/**
 * [tRunJob_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_2 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_2";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_2_SUBPROCESS_STATE", 1);
	}
	


public void tRunJob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tRunJob_1");
		org.slf4j.MDC.put("_subJobPid", "rKFion_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_1", false);
		start_Hash.put("tRunJob_1", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
		int tos_count_tRunJob_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_1 = new StringBuilder();
                    log4jParamters_tRunJob_1.append("Parameters:");
                            log4jParamters_tRunJob_1.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("PROCESS" + " = " + "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("Job_Name")+", PARAM_VALUE_COLUMN="+("\"Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES\"")+"}, {PARAM_NAME_COLUMN="+("Error_Source")+", PARAM_VALUE_COLUMN="+("\"plan WMS\"")+"}]");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                            log4jParamters_tRunJob_1.append("USE_DYNAMIC_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + (log4jParamters_tRunJob_1) );
                    } 
                } 
            new BytesLimit65535_tRunJob_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tRunJob_1", "Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_1 begin ] stop
 */
	
	/**
	 * [tRunJob_1 main ] start
	 */

	

	
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	java.util.List<String> paraList_tRunJob_1 = new java.util.ArrayList<String>();
	
	        				paraList_tRunJob_1.add("--father_pid="+pid);
	      			
	        				paraList_tRunJob_1.add("--root_pid="+rootPid);
	      			
	        				paraList_tRunJob_1.add("--father_node=tRunJob_1");
	      			
	        				paraList_tRunJob_1.add("--context=prod");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_1.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_1.add("--audit.enabled="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_1.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_1.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_1 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_1 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_1".equals(tRunJobName_tRunJob_1) && childResumePath_tRunJob_1 != null){
		paraList_tRunJob_1.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_1.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_1");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_1 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_1 = null;

	
		obj_tRunJob_1 = "Massi_ECOLOTRANS_WMS_VERIFY_INPUT_FILES";
		if(obj_tRunJob_1!=null) {
			if (obj_tRunJob_1.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_1.add("--context_param Job_Name=" + ((java.util.Date) obj_tRunJob_1).getTime());
			} else {
				
					paraList_tRunJob_1.add("--context_param Job_Name=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
					
				
			}
		} else {
			paraList_tRunJob_1.add("--context_param Job_Name=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("Job_Name", obj_tRunJob_1);
	
		obj_tRunJob_1 = "plan WMS";
		if(obj_tRunJob_1!=null) {
			if (obj_tRunJob_1.getClass().getName().equals("java.util.Date")) {
				paraList_tRunJob_1.add("--context_param Error_Source=" + ((java.util.Date) obj_tRunJob_1).getTime());
			} else {
				
					paraList_tRunJob_1.add("--context_param Error_Source=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
					
				
			}
		} else {
			paraList_tRunJob_1.add("--context_param Error_Source=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("Error_Source", obj_tRunJob_1);
	
	
		aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION childJob_tRunJob_1 = new aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_1 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_1) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_1 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_1 : talendDataSources_tRunJob_1
			        .entrySet()) {
	            dataSources_tRunJob_1.put(talendDataSourceEntry_tRunJob_1.getKey(),
	                    talendDataSourceEntry_tRunJob_1.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_1.setDataSources(dataSources_tRunJob_1);
	    }
		  
			childJob_tRunJob_1.parentContextMap = parentContextMap_tRunJob_1;
		  
		
			log.info("tRunJob_1 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' starts on the version '0.1' with the context 'prod'.");
		
		String[][] childReturn_tRunJob_1 = childJob_tRunJob_1.runJob((String[]) paraList_tRunJob_1.toArray(new String[paraList_tRunJob_1.size()]));
		
			log.info("tRunJob_1 - The child job 'aliv2_v1_ecolotrans_wms_prod_orchestrator.massi_ecolotrans_wms_execution_status_notification_0_1.Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION' is done.");
		
            if(childJob_tRunJob_1.getErrorCode() == null){
                globalMap.put("tRunJob_1_CHILD_RETURN_CODE", childJob_tRunJob_1.getStatus() != null && ("failure").equals(childJob_tRunJob_1.getStatus()) ? 1 : 0);
            }else{
                globalMap.put("tRunJob_1_CHILD_RETURN_CODE", childJob_tRunJob_1.getErrorCode());
            }
            if (childJob_tRunJob_1.getExceptionStackTrace() != null) {
                globalMap.put("tRunJob_1_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_1.getExceptionStackTrace());
            }
                    errorCode = childJob_tRunJob_1.getErrorCode();
                if (childJob_tRunJob_1.getErrorCode() != null || ("failure").equals(childJob_tRunJob_1.getStatus())) {
                    java.lang.Exception ce_tRunJob_1 = childJob_tRunJob_1.getException();
                    throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_1!=null) ? (ce_tRunJob_1.getClass().getName() + ": " + ce_tRunJob_1.getMessage()) : ""));
                }

 


	tos_count_tRunJob_1++;

/**
 * [tRunJob_1 main ] stop
 */
	
	/**
	 * [tRunJob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_1 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 



/**
 * [tRunJob_1 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_1 end ] start
	 */

	

	
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + ("Done.") );

ok_Hash.put("tRunJob_1", true);
end_Hash.put("tRunJob_1", System.currentTimeMillis());




/**
 * [tRunJob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_1 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_1";
	
	
			cLabel="Massi_ECOLOTRANS_WMS_EXECUTION_STATUS_NOTIFICATION";
		
	
 



/**
 * [tRunJob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[0];
    static byte[] commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}

				public Boolean momentIsNullable(){
				    return true;
				}
				public Boolean momentIsKey(){
				    return false;
				}
				public Integer momentLength(){
				    return 0;
				}
				public Integer momentPrecision(){
				    return 0;
				}
				public String momentDefault(){
				
					return "";
				
				}
				public String momentComment(){
				
				    return null;
				
				}
				public String momentPattern(){
				
					return "yyyy-MM-dd HH:mm:ss";
				
				}
				public String momentOriginalDbColumnName(){
				
					return "moment";
				
				}

				
			    public String pid;

				public String getPid () {
					return this.pid;
				}

				public Boolean pidIsNullable(){
				    return true;
				}
				public Boolean pidIsKey(){
				    return false;
				}
				public Integer pidLength(){
				    return 20;
				}
				public Integer pidPrecision(){
				    return 0;
				}
				public String pidDefault(){
				
					return "";
				
				}
				public String pidComment(){
				
				    return null;
				
				}
				public String pidPattern(){
				
				    return null;
				
				}
				public String pidOriginalDbColumnName(){
				
					return "pid";
				
				}

				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}

				public Boolean father_pidIsNullable(){
				    return true;
				}
				public Boolean father_pidIsKey(){
				    return false;
				}
				public Integer father_pidLength(){
				    return 20;
				}
				public Integer father_pidPrecision(){
				    return 0;
				}
				public String father_pidDefault(){
				
					return "";
				
				}
				public String father_pidComment(){
				
				    return null;
				
				}
				public String father_pidPattern(){
				
				    return null;
				
				}
				public String father_pidOriginalDbColumnName(){
				
					return "father_pid";
				
				}

				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}

				public Boolean root_pidIsNullable(){
				    return true;
				}
				public Boolean root_pidIsKey(){
				    return false;
				}
				public Integer root_pidLength(){
				    return 20;
				}
				public Integer root_pidPrecision(){
				    return 0;
				}
				public String root_pidDefault(){
				
					return "";
				
				}
				public String root_pidComment(){
				
				    return null;
				
				}
				public String root_pidPattern(){
				
				    return null;
				
				}
				public String root_pidOriginalDbColumnName(){
				
					return "root_pid";
				
				}

				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}

				public Boolean system_pidIsNullable(){
				    return true;
				}
				public Boolean system_pidIsKey(){
				    return false;
				}
				public Integer system_pidLength(){
				    return 8;
				}
				public Integer system_pidPrecision(){
				    return 0;
				}
				public String system_pidDefault(){
				
					return "";
				
				}
				public String system_pidComment(){
				
				    return null;
				
				}
				public String system_pidPattern(){
				
				    return null;
				
				}
				public String system_pidOriginalDbColumnName(){
				
					return "system_pid";
				
				}

				
			    public String project;

				public String getProject () {
					return this.project;
				}

				public Boolean projectIsNullable(){
				    return true;
				}
				public Boolean projectIsKey(){
				    return false;
				}
				public Integer projectLength(){
				    return 50;
				}
				public Integer projectPrecision(){
				    return 0;
				}
				public String projectDefault(){
				
					return "";
				
				}
				public String projectComment(){
				
				    return null;
				
				}
				public String projectPattern(){
				
				    return null;
				
				}
				public String projectOriginalDbColumnName(){
				
					return "project";
				
				}

				
			    public String job;

				public String getJob () {
					return this.job;
				}

				public Boolean jobIsNullable(){
				    return true;
				}
				public Boolean jobIsKey(){
				    return false;
				}
				public Integer jobLength(){
				    return 255;
				}
				public Integer jobPrecision(){
				    return 0;
				}
				public String jobDefault(){
				
					return "";
				
				}
				public String jobComment(){
				
				    return null;
				
				}
				public String jobPattern(){
				
				    return null;
				
				}
				public String jobOriginalDbColumnName(){
				
					return "job";
				
				}

				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}

				public Boolean job_repository_idIsNullable(){
				    return true;
				}
				public Boolean job_repository_idIsKey(){
				    return false;
				}
				public Integer job_repository_idLength(){
				    return 255;
				}
				public Integer job_repository_idPrecision(){
				    return 0;
				}
				public String job_repository_idDefault(){
				
					return "";
				
				}
				public String job_repository_idComment(){
				
				    return null;
				
				}
				public String job_repository_idPattern(){
				
				    return null;
				
				}
				public String job_repository_idOriginalDbColumnName(){
				
					return "job_repository_id";
				
				}

				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}

				public Boolean job_versionIsNullable(){
				    return true;
				}
				public Boolean job_versionIsKey(){
				    return false;
				}
				public Integer job_versionLength(){
				    return 255;
				}
				public Integer job_versionPrecision(){
				    return 0;
				}
				public String job_versionDefault(){
				
					return "";
				
				}
				public String job_versionComment(){
				
				    return null;
				
				}
				public String job_versionPattern(){
				
				    return null;
				
				}
				public String job_versionOriginalDbColumnName(){
				
					return "job_version";
				
				}

				
			    public String context;

				public String getContext () {
					return this.context;
				}

				public Boolean contextIsNullable(){
				    return true;
				}
				public Boolean contextIsKey(){
				    return false;
				}
				public Integer contextLength(){
				    return 50;
				}
				public Integer contextPrecision(){
				    return 0;
				}
				public String contextDefault(){
				
					return "";
				
				}
				public String contextComment(){
				
				    return null;
				
				}
				public String contextPattern(){
				
				    return null;
				
				}
				public String contextOriginalDbColumnName(){
				
					return "context";
				
				}

				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}

				public Boolean originIsNullable(){
				    return true;
				}
				public Boolean originIsKey(){
				    return false;
				}
				public Integer originLength(){
				    return 255;
				}
				public Integer originPrecision(){
				    return 0;
				}
				public String originDefault(){
				
					return "";
				
				}
				public String originComment(){
				
				    return null;
				
				}
				public String originPattern(){
				
				    return null;
				
				}
				public String originOriginalDbColumnName(){
				
					return "origin";
				
				}

				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}

				public Boolean message_typeIsNullable(){
				    return true;
				}
				public Boolean message_typeIsKey(){
				    return false;
				}
				public Integer message_typeLength(){
				    return 255;
				}
				public Integer message_typePrecision(){
				    return 0;
				}
				public String message_typeDefault(){
				
					return "";
				
				}
				public String message_typeComment(){
				
				    return null;
				
				}
				public String message_typePattern(){
				
				    return null;
				
				}
				public String message_typeOriginalDbColumnName(){
				
					return "message_type";
				
				}

				
			    public String message;

				public String getMessage () {
					return this.message;
				}

				public Boolean messageIsNullable(){
				    return true;
				}
				public Boolean messageIsKey(){
				    return false;
				}
				public Integer messageLength(){
				    return 255;
				}
				public Integer messagePrecision(){
				    return 0;
				}
				public String messageDefault(){
				
					return "";
				
				}
				public String messageComment(){
				
				    return null;
				
				}
				public String messagePattern(){
				
				    return null;
				
				}
				public String messageOriginalDbColumnName(){
				
					return "message";
				
				}

				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}

				public Boolean durationIsNullable(){
				    return true;
				}
				public Boolean durationIsKey(){
				    return false;
				}
				public Integer durationLength(){
				    return 8;
				}
				public Integer durationPrecision(){
				    return 0;
				}
				public String durationDefault(){
				
					return "";
				
				}
				public String durationComment(){
				
				    return null;
				
				}
				public String durationPattern(){
				
				    return null;
				
				}
				public String durationOriginalDbColumnName(){
				
					return "duration";
				
				}

				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.length) {
				if(length < 1024 && commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.length == 0) {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[1024];
				} else {
   					commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR, 0, length);
			strReturn = new String(commonByteArray_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR_ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tStatCatcher_1");
		org.slf4j.MDC.put("_subJobPid", "mulcLn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tLogRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogRow_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
                    log4jParamters_tLogRow_1.append("Parameters:");
                            log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "false");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "true");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                        log4jParamters_tLogRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + (log4jParamters_tLogRow_1) );
                    } 
                } 
            new BytesLimit65535_tLogRow_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_1", "tLogRow_1", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_1 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[14];

        public void addRow(String[] row) {

            for (int i = 0; i < 14; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 13 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 13 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[13] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
        util_tLogRow_1.setTableName("tLogRow_1");
        util_tLogRow_1.addRow(new String[]{"moment","pid","father_pid","root_pid","system_pid","project","job","job_repository_id","job_version","context","origin","message_type","message","duration",});        
 		StringBuilder strBuffer_tLogRow_1 = null;
		int nb_line_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";
	
	
		int tos_count_tStatCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tStatCatcher_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tStatCatcher_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tStatCatcher_1 = new StringBuilder();
                    log4jParamters_tStatCatcher_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tStatCatcher_1 - "  + (log4jParamters_tStatCatcher_1) );
                    } 
                } 
            new BytesLimit65535_tStatCatcher_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tStatCatcher_1", "tStatCatcher_1", "tStatCatcher");
				talendJobLogProcess(globalMap);
			}
			

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";
	
	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";
	
	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tStatCatcher_1","tStatCatcher_1","tStatCatcher","tLogRow_1","tLogRow_1","tLogRow"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_1 = new String[14];
   				
	    		if(row1.moment != null) { //              
                 row_tLogRow_1[0]=    						
								FormatterUtils.format_Date(row1.moment, "yyyy-MM-dd HH:mm:ss")
					          ;	
							
	    		} //			
    			   				
	    		if(row1.pid != null) { //              
                 row_tLogRow_1[1]=    						    
				                String.valueOf(row1.pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.father_pid != null) { //              
                 row_tLogRow_1[2]=    						    
				                String.valueOf(row1.father_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.root_pid != null) { //              
                 row_tLogRow_1[3]=    						    
				                String.valueOf(row1.root_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.system_pid != null) { //              
                 row_tLogRow_1[4]=    						    
				                String.valueOf(row1.system_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.project != null) { //              
                 row_tLogRow_1[5]=    						    
				                String.valueOf(row1.project)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.job != null) { //              
                 row_tLogRow_1[6]=    						    
				                String.valueOf(row1.job)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.job_repository_id != null) { //              
                 row_tLogRow_1[7]=    						    
				                String.valueOf(row1.job_repository_id)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.job_version != null) { //              
                 row_tLogRow_1[8]=    						    
				                String.valueOf(row1.job_version)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.context != null) { //              
                 row_tLogRow_1[9]=    						    
				                String.valueOf(row1.context)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.origin != null) { //              
                 row_tLogRow_1[10]=    						    
				                String.valueOf(row1.origin)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.message_type != null) { //              
                 row_tLogRow_1[11]=    						    
				                String.valueOf(row1.message_type)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.message != null) { //              
                 row_tLogRow_1[12]=    						    
				                String.valueOf(row1.message)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.duration != null) { //              
                 row_tLogRow_1[13]=    						    
				                String.valueOf(row1.duration)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_1.addRow(row_tLogRow_1);	
				nb_line_tLogRow_1++;
                	log.info("tLogRow_1 - Content of row "+nb_line_tLogRow_1+": " + TalendString.unionString("|",row_tLogRow_1));
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";
	
	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";
	
	

	}


 
                if(log.isDebugEnabled())
            log.debug("tStatCatcher_1 - "  + ("Done.") );

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_1 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_1);
                    }
                    
                    consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
                    consoleOut_tLogRow_1.flush();
//////
globalMap.put("tLogRow_1_NB_LINE",nb_line_tLogRow_1);
                if(log.isInfoEnabled())
            log.info("tLogRow_1 - "  + ("Printed row count: ")  + (nb_line_tLogRow_1)  + (".") );

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tStatCatcher_1","tStatCatcher_1","tStatCatcher","tLogRow_1","tLogRow_1","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Done.") );

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";
	
	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "OTVBOW_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "prod";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATORClass = new ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR();

        int exitCode = ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATORClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20240222_1049-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_zbxZFXZ4Ee6j9cQuSh5lZA");
                org.slf4j.MDC.put("_compiledAtTimestamp","2024-04-18T11:49:28.767394100Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.class.getClassLoader().getResourceAsStream("aliv2_v1_ecolotrans_wms_prod_orchestrator/aliv2_v1_ecolotrans_wms_prod_orchestrator_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Billing_BSO_Months", "id_String");
                        if(context.getStringValue("Billing_BSO_Months") == null) {
                            context.Billing_BSO_Months = null;
                        } else {
                            context.Billing_BSO_Months=(String) context.getProperty("Billing_BSO_Months");
                        }
                        context.setContextType("Billing_BSO_Start_Year", "id_Integer");
                        if(context.getStringValue("Billing_BSO_Start_Year") == null) {
                            context.Billing_BSO_Start_Year = null;
                        } else {
                            try{
                                context.Billing_BSO_Start_Year=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Billing_BSO_Start_Year"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_BSO_Start_Year", e.getMessage()));
                                context.Billing_BSO_Start_Year=null;
                            }
                        }
                        context.setContextType("Billing_Comptabilite_File", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_File") == null) {
                            context.Billing_Comptabilite_File = null;
                        } else {
                            context.Billing_Comptabilite_File=(String) context.getProperty("Billing_Comptabilite_File");
                        }
                        context.setContextType("Billing_Comptabilite_Folder", "id_String");
                        if(context.getStringValue("Billing_Comptabilite_Folder") == null) {
                            context.Billing_Comptabilite_Folder = null;
                        } else {
                            context.Billing_Comptabilite_Folder=(String) context.getProperty("Billing_Comptabilite_Folder");
                        }
                        context.setContextType("Billing_Distant_Rep", "id_String");
                        if(context.getStringValue("Billing_Distant_Rep") == null) {
                            context.Billing_Distant_Rep = null;
                        } else {
                            context.Billing_Distant_Rep=(String) context.getProperty("Billing_Distant_Rep");
                        }
                        context.setContextType("Billing_File_Masque", "id_String");
                        if(context.getStringValue("Billing_File_Masque") == null) {
                            context.Billing_File_Masque = null;
                        } else {
                            context.Billing_File_Masque=(String) context.getProperty("Billing_File_Masque");
                        }
                        context.setContextType("Billing_Local_Rep", "id_String");
                        if(context.getStringValue("Billing_Local_Rep") == null) {
                            context.Billing_Local_Rep = null;
                        } else {
                            context.Billing_Local_Rep=(String) context.getProperty("Billing_Local_Rep");
                        }
                        context.setContextType("Billing_Name", "id_String");
                        if(context.getStringValue("Billing_Name") == null) {
                            context.Billing_Name = null;
                        } else {
                            context.Billing_Name=(String) context.getProperty("Billing_Name");
                        }
                        context.setContextType("Billing_Start_Number", "id_Integer");
                        if(context.getStringValue("Billing_Start_Number") == null) {
                            context.Billing_Start_Number = null;
                        } else {
                            try{
                                context.Billing_Start_Number=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Billing_Start_Number"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_Start_Number", e.getMessage()));
                                context.Billing_Start_Number=null;
                            }
                        }
                        context.setContextType("Billing_TVA_default_value", "id_Float");
                        if(context.getStringValue("Billing_TVA_default_value") == null) {
                            context.Billing_TVA_default_value = null;
                        } else {
                            try{
                                context.Billing_TVA_default_value=routines.system.ParserUtils.parseTo_Float (context.getProperty("Billing_TVA_default_value"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Billing_TVA_default_value", e.getMessage()));
                                context.Billing_TVA_default_value=null;
                            }
                        }
                        context.setContextType("Clean_distant_Rep", "id_String");
                        if(context.getStringValue("Clean_distant_Rep") == null) {
                            context.Clean_distant_Rep = null;
                        } else {
                            context.Clean_distant_Rep=(String) context.getProperty("Clean_distant_Rep");
                        }
                        context.setContextType("Client_DataBase", "id_String");
                        if(context.getStringValue("Client_DataBase") == null) {
                            context.Client_DataBase = null;
                        } else {
                            context.Client_DataBase=(String) context.getProperty("Client_DataBase");
                        }
                        context.setContextType("DB_Password", "id_Password");
                        if(context.getStringValue("DB_Password") == null) {
                            context.DB_Password = null;
                        } else {
                            String pwd_DB_Password_value = context.getProperty("DB_Password");
                            context.DB_Password = null;
                            if(pwd_DB_Password_value!=null) {
                                if(context_param.containsKey("DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.DB_Password = pwd_DB_Password_value;
                                } else if (!pwd_DB_Password_value.isEmpty()) {
                                    try {
                                        context.DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_DB_Password_value);
                                        context.put("DB_Password",context.DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Hote", "id_String");
                        if(context.getStringValue("Hote") == null) {
                            context.Hote = null;
                        } else {
                            context.Hote=(String) context.getProperty("Hote");
                        }
                        context.setContextType("ODS_Database", "id_String");
                        if(context.getStringValue("ODS_Database") == null) {
                            context.ODS_Database = null;
                        } else {
                            context.ODS_Database=(String) context.getProperty("ODS_Database");
                        }
                        context.setContextType("PBI_Database", "id_String");
                        if(context.getStringValue("PBI_Database") == null) {
                            context.PBI_Database = null;
                        } else {
                            context.PBI_Database=(String) context.getProperty("PBI_Database");
                        }
                        context.setContextType("PBI_PC_Database", "id_String");
                        if(context.getStringValue("PBI_PC_Database") == null) {
                            context.PBI_PC_Database = null;
                        } else {
                            context.PBI_PC_Database=(String) context.getProperty("PBI_PC_Database");
                        }
                        context.setContextType("PBI_RT_Database", "id_String");
                        if(context.getStringValue("PBI_RT_Database") == null) {
                            context.PBI_RT_Database = null;
                        } else {
                            context.PBI_RT_Database=(String) context.getProperty("PBI_RT_Database");
                        }
                        context.setContextType("Port", "id_Integer");
                        if(context.getStringValue("Port") == null) {
                            context.Port = null;
                        } else {
                            try{
                                context.Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Port", e.getMessage()));
                                context.Port=null;
                            }
                        }
                        context.setContextType("User", "id_String");
                        if(context.getStringValue("User") == null) {
                            context.User = null;
                        } else {
                            context.User=(String) context.getProperty("User");
                        }
                        context.setContextType("DataMart_Clean_Database", "id_String");
                        if(context.getStringValue("DataMart_Clean_Database") == null) {
                            context.DataMart_Clean_Database = null;
                        } else {
                            context.DataMart_Clean_Database=(String) context.getProperty("DataMart_Clean_Database");
                        }
                        context.setContextType("DataMart_Clean_Max_Date", "id_String");
                        if(context.getStringValue("DataMart_Clean_Max_Date") == null) {
                            context.DataMart_Clean_Max_Date = null;
                        } else {
                            context.DataMart_Clean_Max_Date=(String) context.getProperty("DataMart_Clean_Max_Date");
                        }
                        context.setContextType("DataMart_Clean_Min_Date", "id_String");
                        if(context.getStringValue("DataMart_Clean_Min_Date") == null) {
                            context.DataMart_Clean_Min_Date = null;
                        } else {
                            context.DataMart_Clean_Min_Date=(String) context.getProperty("DataMart_Clean_Min_Date");
                        }
                        context.setContextType("DataMart_Closure_Date_PlusX", "id_Integer");
                        if(context.getStringValue("DataMart_Closure_Date_PlusX") == null) {
                            context.DataMart_Closure_Date_PlusX = null;
                        } else {
                            try{
                                context.DataMart_Closure_Date_PlusX=routines.system.ParserUtils.parseTo_Integer (context.getProperty("DataMart_Closure_Date_PlusX"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "DataMart_Closure_Date_PlusX", e.getMessage()));
                                context.DataMart_Closure_Date_PlusX=null;
                            }
                        }
                        context.setContextType("Limit_Percent", "id_Integer");
                        if(context.getStringValue("Limit_Percent") == null) {
                            context.Limit_Percent = null;
                        } else {
                            try{
                                context.Limit_Percent=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Limit_Percent"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Limit_Percent", e.getMessage()));
                                context.Limit_Percent=null;
                            }
                        }
                        context.setContextType("Logistic_Max_Date_Plus_One", "id_String");
                        if(context.getStringValue("Logistic_Max_Date_Plus_One") == null) {
                            context.Logistic_Max_Date_Plus_One = null;
                        } else {
                            context.Logistic_Max_Date_Plus_One=(String) context.getProperty("Logistic_Max_Date_Plus_One");
                        }
                        context.setContextType("Logistic_Min_Date_Minus_One", "id_String");
                        if(context.getStringValue("Logistic_Min_Date_Minus_One") == null) {
                            context.Logistic_Min_Date_Minus_One = null;
                        } else {
                            context.Logistic_Min_Date_Minus_One=(String) context.getProperty("Logistic_Min_Date_Minus_One");
                        }
                        context.setContextType("deleted_J_minus_X", "id_Integer");
                        if(context.getStringValue("deleted_J_minus_X") == null) {
                            context.deleted_J_minus_X = null;
                        } else {
                            try{
                                context.deleted_J_minus_X=routines.system.ParserUtils.parseTo_Integer (context.getProperty("deleted_J_minus_X"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "deleted_J_minus_X", e.getMessage()));
                                context.deleted_J_minus_X=null;
                            }
                        }
                        context.setContextType("deleted_J_plusOne_X", "id_Integer");
                        if(context.getStringValue("deleted_J_plusOne_X") == null) {
                            context.deleted_J_plusOne_X = null;
                        } else {
                            try{
                                context.deleted_J_plusOne_X=routines.system.ParserUtils.parseTo_Integer (context.getProperty("deleted_J_plusOne_X"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "deleted_J_plusOne_X", e.getMessage()));
                                context.deleted_J_plusOne_X=null;
                            }
                        }
                        context.setContextType("FTP_DistantRep", "id_Directory");
                        if(context.getStringValue("FTP_DistantRep") == null) {
                            context.FTP_DistantRep = null;
                        } else {
                            context.FTP_DistantRep=(String) context.getProperty("FTP_DistantRep");
                        }
                        context.setContextType("FTP_FileMasque", "id_String");
                        if(context.getStringValue("FTP_FileMasque") == null) {
                            context.FTP_FileMasque = null;
                        } else {
                            context.FTP_FileMasque=(String) context.getProperty("FTP_FileMasque");
                        }
                        context.setContextType("FTP_Hote", "id_String");
                        if(context.getStringValue("FTP_Hote") == null) {
                            context.FTP_Hote = null;
                        } else {
                            context.FTP_Hote=(String) context.getProperty("FTP_Hote");
                        }
                        context.setContextType("FTP_Password", "id_Password");
                        if(context.getStringValue("FTP_Password") == null) {
                            context.FTP_Password = null;
                        } else {
                            String pwd_FTP_Password_value = context.getProperty("FTP_Password");
                            context.FTP_Password = null;
                            if(pwd_FTP_Password_value!=null) {
                                if(context_param.containsKey("FTP_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.FTP_Password = pwd_FTP_Password_value;
                                } else if (!pwd_FTP_Password_value.isEmpty()) {
                                    try {
                                        context.FTP_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_FTP_Password_value);
                                        context.put("FTP_Password",context.FTP_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("FTP_Port", "id_Integer");
                        if(context.getStringValue("FTP_Port") == null) {
                            context.FTP_Port = null;
                        } else {
                            try{
                                context.FTP_Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("FTP_Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "FTP_Port", e.getMessage()));
                                context.FTP_Port=null;
                            }
                        }
                        context.setContextType("FTP_ST_DistantRep", "id_String");
                        if(context.getStringValue("FTP_ST_DistantRep") == null) {
                            context.FTP_ST_DistantRep = null;
                        } else {
                            context.FTP_ST_DistantRep=(String) context.getProperty("FTP_ST_DistantRep");
                        }
                        context.setContextType("FTP_User", "id_String");
                        if(context.getStringValue("FTP_User") == null) {
                            context.FTP_User = null;
                        } else {
                            context.FTP_User=(String) context.getProperty("FTP_User");
                        }
                        context.setContextType("FTP_Wms_Port", "id_Integer");
                        if(context.getStringValue("FTP_Wms_Port") == null) {
                            context.FTP_Wms_Port = null;
                        } else {
                            try{
                                context.FTP_Wms_Port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("FTP_Wms_Port"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "FTP_Wms_Port", e.getMessage()));
                                context.FTP_Wms_Port=null;
                            }
                        }
                        context.setContextType("keyStore_file_name", "id_String");
                        if(context.getStringValue("keyStore_file_name") == null) {
                            context.keyStore_file_name = null;
                        } else {
                            context.keyStore_file_name=(String) context.getProperty("keyStore_file_name");
                        }
                        context.setContextType("KeyStore_Repo", "id_String");
                        if(context.getStringValue("KeyStore_Repo") == null) {
                            context.KeyStore_Repo = null;
                        } else {
                            context.KeyStore_Repo=(String) context.getProperty("KeyStore_Repo");
                        }
                        context.setContextType("mail_password", "id_String");
                        if(context.getStringValue("mail_password") == null) {
                            context.mail_password = null;
                        } else {
                            context.mail_password=(String) context.getProperty("mail_password");
                        }
                        context.setContextType("send_mail_from", "id_String");
                        if(context.getStringValue("send_mail_from") == null) {
                            context.send_mail_from = null;
                        } else {
                            context.send_mail_from=(String) context.getProperty("send_mail_from");
                        }
                        context.setContextType("send_mail_to", "id_String");
                        if(context.getStringValue("send_mail_to") == null) {
                            context.send_mail_to = null;
                        } else {
                            context.send_mail_to=(String) context.getProperty("send_mail_to");
                        }
                        context.setContextType("send_to_second_mail", "id_String");
                        if(context.getStringValue("send_to_second_mail") == null) {
                            context.send_to_second_mail = null;
                        } else {
                            context.send_to_second_mail=(String) context.getProperty("send_to_second_mail");
                        }
                        context.setContextType("send_to_third_mail", "id_String");
                        if(context.getStringValue("send_to_third_mail") == null) {
                            context.send_to_third_mail = null;
                        } else {
                            context.send_to_third_mail=(String) context.getProperty("send_to_third_mail");
                        }
                        context.setContextType("Clients_Masque", "id_String");
                        if(context.getStringValue("Clients_Masque") == null) {
                            context.Clients_Masque = null;
                        } else {
                            context.Clients_Masque=(String) context.getProperty("Clients_Masque");
                        }
                        context.setContextType("Code_client_masque", "id_String");
                        if(context.getStringValue("Code_client_masque") == null) {
                            context.Code_client_masque = null;
                        } else {
                            context.Code_client_masque=(String) context.getProperty("Code_client_masque");
                        }
                        context.setContextType("Command_Logistic_Invalid_Date", "id_String");
                        if(context.getStringValue("Command_Logistic_Invalid_Date") == null) {
                            context.Command_Logistic_Invalid_Date = null;
                        } else {
                            context.Command_Logistic_Invalid_Date=(String) context.getProperty("Command_Logistic_Invalid_Date");
                        }
                        context.setContextType("Command_Logistic_Masque", "id_String");
                        if(context.getStringValue("Command_Logistic_Masque") == null) {
                            context.Command_Logistic_Masque = null;
                        } else {
                            context.Command_Logistic_Masque=(String) context.getProperty("Command_Logistic_Masque");
                        }
                        context.setContextType("Command_Transport_Masque", "id_String");
                        if(context.getStringValue("Command_Transport_Masque") == null) {
                            context.Command_Transport_Masque = null;
                        } else {
                            context.Command_Transport_Masque=(String) context.getProperty("Command_Transport_Masque");
                        }
                        context.setContextType("Command_Transport_Masque_Express", "id_String");
                        if(context.getStringValue("Command_Transport_Masque_Express") == null) {
                            context.Command_Transport_Masque_Express = null;
                        } else {
                            context.Command_Transport_Masque_Express=(String) context.getProperty("Command_Transport_Masque_Express");
                        }
                        context.setContextType("Ecolotrans_JP", "id_String");
                        if(context.getStringValue("Ecolotrans_JP") == null) {
                            context.Ecolotrans_JP = null;
                        } else {
                            context.Ecolotrans_JP=(String) context.getProperty("Ecolotrans_JP");
                        }
                        context.setContextType("Holiday_Days_Masque", "id_String");
                        if(context.getStringValue("Holiday_Days_Masque") == null) {
                            context.Holiday_Days_Masque = null;
                        } else {
                            context.Holiday_Days_Masque=(String) context.getProperty("Holiday_Days_Masque");
                        }
                        context.setContextType("Livraisons_Exception", "id_String");
                        if(context.getStringValue("Livraisons_Exception") == null) {
                            context.Livraisons_Exception = null;
                        } else {
                            context.Livraisons_Exception=(String) context.getProperty("Livraisons_Exception");
                        }
                        context.setContextType("Livraisons_Masque", "id_String");
                        if(context.getStringValue("Livraisons_Masque") == null) {
                            context.Livraisons_Masque = null;
                        } else {
                            context.Livraisons_Masque=(String) context.getProperty("Livraisons_Masque");
                        }
                        context.setContextType("Livraisons_Ok", "id_String");
                        if(context.getStringValue("Livraisons_Ok") == null) {
                            context.Livraisons_Ok = null;
                        } else {
                            context.Livraisons_Ok=(String) context.getProperty("Livraisons_Ok");
                        }
                        context.setContextType("ST_Drivers", "id_String");
                        if(context.getStringValue("ST_Drivers") == null) {
                            context.ST_Drivers = null;
                        } else {
                            context.ST_Drivers=(String) context.getProperty("ST_Drivers");
                        }
                        context.setContextType("Tarification_Logistic_Masque", "id_String");
                        if(context.getStringValue("Tarification_Logistic_Masque") == null) {
                            context.Tarification_Logistic_Masque = null;
                        } else {
                            context.Tarification_Logistic_Masque=(String) context.getProperty("Tarification_Logistic_Masque");
                        }
                        context.setContextType("Tarification_Transport_Masque", "id_String");
                        if(context.getStringValue("Tarification_Transport_Masque") == null) {
                            context.Tarification_Transport_Masque = null;
                        } else {
                            context.Tarification_Transport_Masque=(String) context.getProperty("Tarification_Transport_Masque");
                        }
                        context.setContextType("Tournee_Masque", "id_String");
                        if(context.getStringValue("Tournee_Masque") == null) {
                            context.Tournee_Masque = null;
                        } else {
                            context.Tournee_Masque=(String) context.getProperty("Tournee_Masque");
                        }
                        context.setContextType("TVA_Exceptions", "id_String");
                        if(context.getStringValue("TVA_Exceptions") == null) {
                            context.TVA_Exceptions = null;
                        } else {
                            context.TVA_Exceptions=(String) context.getProperty("TVA_Exceptions");
                        }
                        context.setContextType("Backup", "id_String");
                        if(context.getStringValue("Backup") == null) {
                            context.Backup = null;
                        } else {
                            context.Backup=(String) context.getProperty("Backup");
                        }
                        context.setContextType("Server_Clean", "id_String");
                        if(context.getStringValue("Server_Clean") == null) {
                            context.Server_Clean = null;
                        } else {
                            context.Server_Clean=(String) context.getProperty("Server_Clean");
                        }
                        context.setContextType("Server_In", "id_String");
                        if(context.getStringValue("Server_In") == null) {
                            context.Server_In = null;
                        } else {
                            context.Server_In=(String) context.getProperty("Server_In");
                        }
                        context.setContextType("Server_Out", "id_String");
                        if(context.getStringValue("Server_Out") == null) {
                            context.Server_Out = null;
                        } else {
                            context.Server_Out=(String) context.getProperty("Server_Out");
                        }
                        context.setContextType("Server_Out_DataMart", "id_String");
                        if(context.getStringValue("Server_Out_DataMart") == null) {
                            context.Server_Out_DataMart = null;
                        } else {
                            context.Server_Out_DataMart=(String) context.getProperty("Server_Out_DataMart");
                        }
                        context.setContextType("Art_masque", "id_String");
                        if(context.getStringValue("Art_masque") == null) {
                            context.Art_masque = null;
                        } else {
                            context.Art_masque=(String) context.getProperty("Art_masque");
                        }
                        context.setContextType("Cdc_masque", "id_String");
                        if(context.getStringValue("Cdc_masque") == null) {
                            context.Cdc_masque = null;
                        } else {
                            context.Cdc_masque=(String) context.getProperty("Cdc_masque");
                        }
                        context.setContextType("Cre_masque", "id_String");
                        if(context.getStringValue("Cre_masque") == null) {
                            context.Cre_masque = null;
                        } else {
                            context.Cre_masque=(String) context.getProperty("Cre_masque");
                        }
                        context.setContextType("Crp_masque", "id_String");
                        if(context.getStringValue("Crp_masque") == null) {
                            context.Crp_masque = null;
                        } else {
                            context.Crp_masque=(String) context.getProperty("Crp_masque");
                        }
                        context.setContextType("Crr_masque", "id_String");
                        if(context.getStringValue("Crr_masque") == null) {
                            context.Crr_masque = null;
                        } else {
                            context.Crr_masque=(String) context.getProperty("Crr_masque");
                        }
                        context.setContextType("Distant_Magistor_Clients_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor_Clients_Input") == null) {
                            context.Distant_Magistor_Clients_Input = null;
                        } else {
                            context.Distant_Magistor_Clients_Input=(String) context.getProperty("Distant_Magistor_Clients_Input");
                        }
                        context.setContextType("Distant_Magistor_Clients_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor_Clients_Test_Input") == null) {
                            context.Distant_Magistor_Clients_Test_Input = null;
                        } else {
                            context.Distant_Magistor_Clients_Test_Input=(String) context.getProperty("Distant_Magistor_Clients_Test_Input");
                        }
                        context.setContextType("Distant_Magistor1_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Input") == null) {
                            context.Distant_Magistor1_Input = null;
                        } else {
                            context.Distant_Magistor1_Input=(String) context.getProperty("Distant_Magistor1_Input");
                        }
                        context.setContextType("Distant_Magistor1_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Output") == null) {
                            context.Distant_Magistor1_Output = null;
                        } else {
                            context.Distant_Magistor1_Output=(String) context.getProperty("Distant_Magistor1_Output");
                        }
                        context.setContextType("Distant_Magistor1_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Test_Input") == null) {
                            context.Distant_Magistor1_Test_Input = null;
                        } else {
                            context.Distant_Magistor1_Test_Input=(String) context.getProperty("Distant_Magistor1_Test_Input");
                        }
                        context.setContextType("Distant_Magistor1_Test_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor1_Test_Output") == null) {
                            context.Distant_Magistor1_Test_Output = null;
                        } else {
                            context.Distant_Magistor1_Test_Output=(String) context.getProperty("Distant_Magistor1_Test_Output");
                        }
                        context.setContextType("Distant_Magistor2_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Input") == null) {
                            context.Distant_Magistor2_Input = null;
                        } else {
                            context.Distant_Magistor2_Input=(String) context.getProperty("Distant_Magistor2_Input");
                        }
                        context.setContextType("Distant_Magistor2_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Output") == null) {
                            context.Distant_Magistor2_Output = null;
                        } else {
                            context.Distant_Magistor2_Output=(String) context.getProperty("Distant_Magistor2_Output");
                        }
                        context.setContextType("Distant_Magistor2_Test_Input", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Test_Input") == null) {
                            context.Distant_Magistor2_Test_Input = null;
                        } else {
                            context.Distant_Magistor2_Test_Input=(String) context.getProperty("Distant_Magistor2_Test_Input");
                        }
                        context.setContextType("Distant_Magistor2_Test_Output", "id_String");
                        if(context.getStringValue("Distant_Magistor2_Test_Output") == null) {
                            context.Distant_Magistor2_Test_Output = null;
                        } else {
                            context.Distant_Magistor2_Test_Output=(String) context.getProperty("Distant_Magistor2_Test_Output");
                        }
                        context.setContextType("Drc_masque", "id_String");
                        if(context.getStringValue("Drc_masque") == null) {
                            context.Drc_masque = null;
                        } else {
                            context.Drc_masque=(String) context.getProperty("Drc_masque");
                        }
                        context.setContextType("Mvt_masque", "id_String");
                        if(context.getStringValue("Mvt_masque") == null) {
                            context.Mvt_masque = null;
                        } else {
                            context.Mvt_masque=(String) context.getProperty("Mvt_masque");
                        }
                        context.setContextType("Stk_masque", "id_String");
                        if(context.getStringValue("Stk_masque") == null) {
                            context.Stk_masque = null;
                        } else {
                            context.Stk_masque=(String) context.getProperty("Stk_masque");
                        }
                        context.setContextType("Xml_File_Masque", "id_String");
                        if(context.getStringValue("Xml_File_Masque") == null) {
                            context.Xml_File_Masque = null;
                        } else {
                            context.Xml_File_Masque=(String) context.getProperty("Xml_File_Masque");
                        }
                        context.setContextType("Article_Exceptions", "id_String");
                        if(context.getStringValue("Article_Exceptions") == null) {
                            context.Article_Exceptions = null;
                        } else {
                            context.Article_Exceptions=(String) context.getProperty("Article_Exceptions");
                        }
                        context.setContextType("Cleaning_Reject_Logistic_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Logistic_price_is_zero") == null) {
                            context.Cleaning_Reject_Logistic_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Logistic_price_is_zero=(String) context.getProperty("Cleaning_Reject_Logistic_price_is_zero");
                        }
                        context.setContextType("Cleaning_Reject_Rep", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Rep") == null) {
                            context.Cleaning_Reject_Rep = null;
                        } else {
                            context.Cleaning_Reject_Rep=(String) context.getProperty("Cleaning_Reject_Rep");
                        }
                        context.setContextType("Cleaning_Reject_Transport_price_is_zero", "id_String");
                        if(context.getStringValue("Cleaning_Reject_Transport_price_is_zero") == null) {
                            context.Cleaning_Reject_Transport_price_is_zero = null;
                        } else {
                            context.Cleaning_Reject_Transport_price_is_zero=(String) context.getProperty("Cleaning_Reject_Transport_price_is_zero");
                        }
                        context.setContextType("Cleaning_Transport_no_PostalCode", "id_String");
                        if(context.getStringValue("Cleaning_Transport_no_PostalCode") == null) {
                            context.Cleaning_Transport_no_PostalCode = null;
                        } else {
                            context.Cleaning_Transport_no_PostalCode=(String) context.getProperty("Cleaning_Transport_no_PostalCode");
                        }
                        context.setContextType("Commande_Exceptions", "id_String");
                        if(context.getStringValue("Commande_Exceptions") == null) {
                            context.Commande_Exceptions = null;
                        } else {
                            context.Commande_Exceptions=(String) context.getProperty("Commande_Exceptions");
                        }
                        context.setContextType("Conditionnement_Exceptions", "id_String");
                        if(context.getStringValue("Conditionnement_Exceptions") == null) {
                            context.Conditionnement_Exceptions = null;
                        } else {
                            context.Conditionnement_Exceptions=(String) context.getProperty("Conditionnement_Exceptions");
                        }
                        context.setContextType("CR_Reception_Exceptions", "id_String");
                        if(context.getStringValue("CR_Reception_Exceptions") == null) {
                            context.CR_Reception_Exceptions = null;
                        } else {
                            context.CR_Reception_Exceptions=(String) context.getProperty("CR_Reception_Exceptions");
                        }
                        context.setContextType("Csv_File_Masque", "id_String");
                        if(context.getStringValue("Csv_File_Masque") == null) {
                            context.Csv_File_Masque = null;
                        } else {
                            context.Csv_File_Masque=(String) context.getProperty("Csv_File_Masque");
                        }
                        context.setContextType("Diagnostic_Reject_Command_Error", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Command_Error") == null) {
                            context.Diagnostic_Reject_Command_Error = null;
                        } else {
                            context.Diagnostic_Reject_Command_Error=(String) context.getProperty("Diagnostic_Reject_Command_Error");
                        }
                        context.setContextType("Diagnostic_Reject_Day_Not_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Day_Not_Ok") == null) {
                            context.Diagnostic_Reject_Day_Not_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Day_Not_Ok=(String) context.getProperty("Diagnostic_Reject_Day_Not_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Postal_Code_Ok", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Postal_Code_Ok") == null) {
                            context.Diagnostic_Reject_Postal_Code_Ok = null;
                        } else {
                            context.Diagnostic_Reject_Postal_Code_Ok=(String) context.getProperty("Diagnostic_Reject_Postal_Code_Ok");
                        }
                        context.setContextType("Diagnostic_Reject_Rep", "id_String");
                        if(context.getStringValue("Diagnostic_Reject_Rep") == null) {
                            context.Diagnostic_Reject_Rep = null;
                        } else {
                            context.Diagnostic_Reject_Rep=(String) context.getProperty("Diagnostic_Reject_Rep");
                        }
                        context.setContextType("Dossier_Reception_Exceptions", "id_String");
                        if(context.getStringValue("Dossier_Reception_Exceptions") == null) {
                            context.Dossier_Reception_Exceptions = null;
                        } else {
                            context.Dossier_Reception_Exceptions=(String) context.getProperty("Dossier_Reception_Exceptions");
                        }
                        context.setContextType("Excel_File_Masque", "id_String");
                        if(context.getStringValue("Excel_File_Masque") == null) {
                            context.Excel_File_Masque = null;
                        } else {
                            context.Excel_File_Masque=(String) context.getProperty("Excel_File_Masque");
                        }
                        }

                private void processContext_1() {
                        context.setContextType("Ligne_Commande_Exceptions", "id_String");
                        if(context.getStringValue("Ligne_Commande_Exceptions") == null) {
                            context.Ligne_Commande_Exceptions = null;
                        } else {
                            context.Ligne_Commande_Exceptions=(String) context.getProperty("Ligne_Commande_Exceptions");
                        }
                        context.setContextType("Migration_Billing_Not_Ok", "id_String");
                        if(context.getStringValue("Migration_Billing_Not_Ok") == null) {
                            context.Migration_Billing_Not_Ok = null;
                        } else {
                            context.Migration_Billing_Not_Ok=(String) context.getProperty("Migration_Billing_Not_Ok");
                        }
                        context.setContextType("Reject_Client_File", "id_String");
                        if(context.getStringValue("Reject_Client_File") == null) {
                            context.Reject_Client_File = null;
                        } else {
                            context.Reject_Client_File=(String) context.getProperty("Reject_Client_File");
                        }
                        context.setContextType("Reject_Client_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Client_Local_Rep") == null) {
                            context.Reject_Client_Local_Rep = null;
                        } else {
                            context.Reject_Client_Local_Rep=(String) context.getProperty("Reject_Client_Local_Rep");
                        }
                        context.setContextType("Reject_Command_Logisitc_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Logisitc_Code_Client") == null) {
                            context.Reject_Command_Logisitc_Code_Client = null;
                        } else {
                            context.Reject_Command_Logisitc_Code_Client=(String) context.getProperty("Reject_Command_Logisitc_Code_Client");
                        }
                        context.setContextType("Reject_Command_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Command_Transport_Code_Client") == null) {
                            context.Reject_Command_Transport_Code_Client = null;
                        } else {
                            context.Reject_Command_Transport_Code_Client=(String) context.getProperty("Reject_Command_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Distant_Rep", "id_String");
                        if(context.getStringValue("Reject_Distant_Rep") == null) {
                            context.Reject_Distant_Rep = null;
                        } else {
                            context.Reject_Distant_Rep=(String) context.getProperty("Reject_Distant_Rep");
                        }
                        context.setContextType("Reject_Distant_Rep_DataMart", "id_String");
                        if(context.getStringValue("Reject_Distant_Rep_DataMart") == null) {
                            context.Reject_Distant_Rep_DataMart = null;
                        } else {
                            context.Reject_Distant_Rep_DataMart=(String) context.getProperty("Reject_Distant_Rep_DataMart");
                        }
                        context.setContextType("Reject_Duplicated_Client_File", "id_String");
                        if(context.getStringValue("Reject_Duplicated_Client_File") == null) {
                            context.Reject_Duplicated_Client_File = null;
                        } else {
                            context.Reject_Duplicated_Client_File=(String) context.getProperty("Reject_Duplicated_Client_File");
                        }
                        context.setContextType("Reject_Migration_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Migration_Local_Rep") == null) {
                            context.Reject_Migration_Local_Rep = null;
                        } else {
                            context.Reject_Migration_Local_Rep=(String) context.getProperty("Reject_Migration_Local_Rep");
                        }
                        context.setContextType("Reject_Not_Complet_Client", "id_String");
                        if(context.getStringValue("Reject_Not_Complet_Client") == null) {
                            context.Reject_Not_Complet_Client = null;
                        } else {
                            context.Reject_Not_Complet_Client=(String) context.getProperty("Reject_Not_Complet_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Local_Rep") == null) {
                            context.Reject_Service_Detail_Local_Rep = null;
                        } else {
                            context.Reject_Service_Detail_Local_Rep=(String) context.getProperty("Reject_Service_Detail_Local_Rep");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_DB") == null) {
                            context.Reject_Service_Detail_Logistic_DB = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_DB=(String) context.getProperty("Reject_Service_Detail_Logistic_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Logistic_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Logistic_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Logistic_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Logistic_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Logistic_Unknown_Client");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_DB") == null) {
                            context.Reject_Service_Detail_Transport_DB = null;
                        } else {
                            context.Reject_Service_Detail_Transport_DB=(String) context.getProperty("Reject_Service_Detail_Transport_DB");
                        }
                        context.setContextType("Reject_Service_Detail_Transport_Unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Service_Detail_Transport_Unknown_Client") == null) {
                            context.Reject_Service_Detail_Transport_Unknown_Client = null;
                        } else {
                            context.Reject_Service_Detail_Transport_Unknown_Client=(String) context.getProperty("Reject_Service_Detail_Transport_Unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Local_Rep", "id_String");
                        if(context.getStringValue("Reject_Tarification_Local_Rep") == null) {
                            context.Reject_Tarification_Local_Rep = null;
                        } else {
                            context.Reject_Tarification_Local_Rep=(String) context.getProperty("Reject_Tarification_Local_Rep");
                        }
                        context.setContextType("Reject_Tarification_Logistic_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_Code_Client") == null) {
                            context.Reject_Tarification_Logistic_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_Code_Client=(String) context.getProperty("Reject_Tarification_Logistic_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Logistic_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_DB") == null) {
                            context.Reject_Tarification_Logistic_DB = null;
                        } else {
                            context.Reject_Tarification_Logistic_DB=(String) context.getProperty("Reject_Tarification_Logistic_DB");
                        }
                        context.setContextType("Reject_Tarification_Logistic_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Logistic_unknown_Client") == null) {
                            context.Reject_Tarification_Logistic_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Logistic_unknown_Client=(String) context.getProperty("Reject_Tarification_Logistic_unknown_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_Code_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_Code_Client") == null) {
                            context.Reject_Tarification_Transport_Code_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_Code_Client=(String) context.getProperty("Reject_Tarification_Transport_Code_Client");
                        }
                        context.setContextType("Reject_Tarification_Transport_DB", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_DB") == null) {
                            context.Reject_Tarification_Transport_DB = null;
                        } else {
                            context.Reject_Tarification_Transport_DB=(String) context.getProperty("Reject_Tarification_Transport_DB");
                        }
                        context.setContextType("Reject_Tarification_Transport_unknown_Client", "id_String");
                        if(context.getStringValue("Reject_Tarification_Transport_unknown_Client") == null) {
                            context.Reject_Tarification_Transport_unknown_Client = null;
                        } else {
                            context.Reject_Tarification_Transport_unknown_Client=(String) context.getProperty("Reject_Tarification_Transport_unknown_Client");
                        }
                        context.setContextType("code_client_length", "id_Integer");
                        if(context.getStringValue("code_client_length") == null) {
                            context.code_client_length = null;
                        } else {
                            try{
                                context.code_client_length=routines.system.ParserUtils.parseTo_Integer (context.getProperty("code_client_length"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "code_client_length", e.getMessage()));
                                context.code_client_length=null;
                            }
                        }
                        context.setContextType("code_client_regex", "id_String");
                        if(context.getStringValue("code_client_regex") == null) {
                            context.code_client_regex = null;
                        } else {
                            context.code_client_regex=(String) context.getProperty("code_client_regex");
                        }
                        context.setContextType("Livraison_directory", "id_String");
                        if(context.getStringValue("Livraison_directory") == null) {
                            context.Livraison_directory = null;
                        } else {
                            context.Livraison_directory=(String) context.getProperty("Livraison_directory");
                        }
                        context.setContextType("Round_Delay_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Delay_Minus_Days") == null) {
                            context.Round_Delay_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Delay_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Delay_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Delay_Minus_Days", e.getMessage()));
                                context.Round_Delay_Minus_Days=null;
                            }
                        }
                        context.setContextType("Round_Delay_Plus_Days_Plus_One", "id_Integer");
                        if(context.getStringValue("Round_Delay_Plus_Days_Plus_One") == null) {
                            context.Round_Delay_Plus_Days_Plus_One = null;
                        } else {
                            try{
                                context.Round_Delay_Plus_Days_Plus_One=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Delay_Plus_Days_Plus_One"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Delay_Plus_Days_Plus_One", e.getMessage()));
                                context.Round_Delay_Plus_Days_Plus_One=null;
                            }
                        }
                        context.setContextType("Round_directory", "id_String");
                        if(context.getStringValue("Round_directory") == null) {
                            context.Round_directory = null;
                        } else {
                            context.Round_directory=(String) context.getProperty("Round_directory");
                        }
                        context.setContextType("Round_file_name", "id_String");
                        if(context.getStringValue("Round_file_name") == null) {
                            context.Round_file_name = null;
                        } else {
                            context.Round_file_name=(String) context.getProperty("Round_file_name");
                        }
                        context.setContextType("Round_Minus_Days", "id_Integer");
                        if(context.getStringValue("Round_Minus_Days") == null) {
                            context.Round_Minus_Days = null;
                        } else {
                            try{
                                context.Round_Minus_Days=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Round_Minus_Days"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Round_Minus_Days", e.getMessage()));
                                context.Round_Minus_Days=null;
                            }
                        }
                        context.setContextType("Salesforce_Name", "id_String");
                        if(context.getStringValue("Salesforce_Name") == null) {
                            context.Salesforce_Name = null;
                        } else {
                            context.Salesforce_Name=(String) context.getProperty("Salesforce_Name");
                        }
                        context.setContextType("Salesforce_Password", "id_Password");
                        if(context.getStringValue("Salesforce_Password") == null) {
                            context.Salesforce_Password = null;
                        } else {
                            String pwd_Salesforce_Password_value = context.getProperty("Salesforce_Password");
                            context.Salesforce_Password = null;
                            if(pwd_Salesforce_Password_value!=null) {
                                if(context_param.containsKey("Salesforce_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Password = pwd_Salesforce_Password_value;
                                } else if (!pwd_Salesforce_Password_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Password_value);
                                        context.put("Salesforce_Password",context.Salesforce_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_Security_Token", "id_Password");
                        if(context.getStringValue("Salesforce_Security_Token") == null) {
                            context.Salesforce_Security_Token = null;
                        } else {
                            String pwd_Salesforce_Security_Token_value = context.getProperty("Salesforce_Security_Token");
                            context.Salesforce_Security_Token = null;
                            if(pwd_Salesforce_Security_Token_value!=null) {
                                if(context_param.containsKey("Salesforce_Security_Token")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Salesforce_Security_Token = pwd_Salesforce_Security_Token_value;
                                } else if (!pwd_Salesforce_Security_Token_value.isEmpty()) {
                                    try {
                                        context.Salesforce_Security_Token = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Salesforce_Security_Token_value);
                                        context.put("Salesforce_Security_Token",context.Salesforce_Security_Token);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("Salesforce_User_ID", "id_String");
                        if(context.getStringValue("Salesforce_User_ID") == null) {
                            context.Salesforce_User_ID = null;
                        } else {
                            context.Salesforce_User_ID=(String) context.getProperty("Salesforce_User_ID");
                        }
                        context.setContextType("comptabilite_analytique_month", "id_String");
                        if(context.getStringValue("comptabilite_analytique_month") == null) {
                            context.comptabilite_analytique_month = null;
                        } else {
                            context.comptabilite_analytique_month=(String) context.getProperty("comptabilite_analytique_month");
                        }
                        context.setContextType("comptabilite_analytique_year", "id_String");
                        if(context.getStringValue("comptabilite_analytique_year") == null) {
                            context.comptabilite_analytique_year = null;
                        } else {
                            context.comptabilite_analytique_year=(String) context.getProperty("comptabilite_analytique_year");
                        }
                        context.setContextType("Ecolotrans_JP_Month_MM", "id_String");
                        if(context.getStringValue("Ecolotrans_JP_Month_MM") == null) {
                            context.Ecolotrans_JP_Month_MM = null;
                        } else {
                            context.Ecolotrans_JP_Month_MM=(String) context.getProperty("Ecolotrans_JP_Month_MM");
                        }
                        context.setContextType("end_date", "id_String");
                        if(context.getStringValue("end_date") == null) {
                            context.end_date = null;
                        } else {
                            context.end_date=(String) context.getProperty("end_date");
                        }
                        context.setContextType("Extraction_Aprm", "id_Integer");
                        if(context.getStringValue("Extraction_Aprm") == null) {
                            context.Extraction_Aprm = null;
                        } else {
                            try{
                                context.Extraction_Aprm=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Aprm"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Aprm", e.getMessage()));
                                context.Extraction_Aprm=null;
                            }
                        }
                        context.setContextType("Extraction_Jour", "id_Integer");
                        if(context.getStringValue("Extraction_Jour") == null) {
                            context.Extraction_Jour = null;
                        } else {
                            try{
                                context.Extraction_Jour=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Jour"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Jour", e.getMessage()));
                                context.Extraction_Jour=null;
                            }
                        }
                        context.setContextType("Extraction_Matin", "id_Integer");
                        if(context.getStringValue("Extraction_Matin") == null) {
                            context.Extraction_Matin = null;
                        } else {
                            try{
                                context.Extraction_Matin=routines.system.ParserUtils.parseTo_Integer (context.getProperty("Extraction_Matin"));
                            } catch(NumberFormatException e){
                                log.warn(String.format("Null value will be used for context parameter %s: %s", "Extraction_Matin", e.getMessage()));
                                context.Extraction_Matin=null;
                            }
                        }
                        context.setContextType("start_date", "id_String");
                        if(context.getStringValue("start_date") == null) {
                            context.start_date = null;
                        } else {
                            context.start_date=(String) context.getProperty("start_date");
                        }
                        context.setContextType("Urbantz_directory", "id_String");
                        if(context.getStringValue("Urbantz_directory") == null) {
                            context.Urbantz_directory = null;
                        } else {
                            context.Urbantz_directory=(String) context.getProperty("Urbantz_directory");
                        }
                        context.setContextType("urbantz_extraction_date", "id_String");
                        if(context.getStringValue("urbantz_extraction_date") == null) {
                            context.urbantz_extraction_date = null;
                        } else {
                            context.urbantz_extraction_date=(String) context.getProperty("urbantz_extraction_date");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                        processContext_1();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Billing_BSO_Months")) {
                context.Billing_BSO_Months = (String) parentContextMap.get("Billing_BSO_Months");
            }if (parentContextMap.containsKey("Billing_BSO_Start_Year")) {
                context.Billing_BSO_Start_Year = (Integer) parentContextMap.get("Billing_BSO_Start_Year");
            }if (parentContextMap.containsKey("Billing_Comptabilite_File")) {
                context.Billing_Comptabilite_File = (String) parentContextMap.get("Billing_Comptabilite_File");
            }if (parentContextMap.containsKey("Billing_Comptabilite_Folder")) {
                context.Billing_Comptabilite_Folder = (String) parentContextMap.get("Billing_Comptabilite_Folder");
            }if (parentContextMap.containsKey("Billing_Distant_Rep")) {
                context.Billing_Distant_Rep = (String) parentContextMap.get("Billing_Distant_Rep");
            }if (parentContextMap.containsKey("Billing_File_Masque")) {
                context.Billing_File_Masque = (String) parentContextMap.get("Billing_File_Masque");
            }if (parentContextMap.containsKey("Billing_Local_Rep")) {
                context.Billing_Local_Rep = (String) parentContextMap.get("Billing_Local_Rep");
            }if (parentContextMap.containsKey("Billing_Name")) {
                context.Billing_Name = (String) parentContextMap.get("Billing_Name");
            }if (parentContextMap.containsKey("Billing_Start_Number")) {
                context.Billing_Start_Number = (Integer) parentContextMap.get("Billing_Start_Number");
            }if (parentContextMap.containsKey("Billing_TVA_default_value")) {
                context.Billing_TVA_default_value = (Float) parentContextMap.get("Billing_TVA_default_value");
            }if (parentContextMap.containsKey("Clean_distant_Rep")) {
                context.Clean_distant_Rep = (String) parentContextMap.get("Clean_distant_Rep");
            }if (parentContextMap.containsKey("Client_DataBase")) {
                context.Client_DataBase = (String) parentContextMap.get("Client_DataBase");
            }if (parentContextMap.containsKey("DB_Password")) {
                context.DB_Password = (java.lang.String) parentContextMap.get("DB_Password");
            }if (parentContextMap.containsKey("Hote")) {
                context.Hote = (String) parentContextMap.get("Hote");
            }if (parentContextMap.containsKey("ODS_Database")) {
                context.ODS_Database = (String) parentContextMap.get("ODS_Database");
            }if (parentContextMap.containsKey("PBI_Database")) {
                context.PBI_Database = (String) parentContextMap.get("PBI_Database");
            }if (parentContextMap.containsKey("PBI_PC_Database")) {
                context.PBI_PC_Database = (String) parentContextMap.get("PBI_PC_Database");
            }if (parentContextMap.containsKey("PBI_RT_Database")) {
                context.PBI_RT_Database = (String) parentContextMap.get("PBI_RT_Database");
            }if (parentContextMap.containsKey("Port")) {
                context.Port = (Integer) parentContextMap.get("Port");
            }if (parentContextMap.containsKey("User")) {
                context.User = (String) parentContextMap.get("User");
            }if (parentContextMap.containsKey("DataMart_Clean_Database")) {
                context.DataMart_Clean_Database = (String) parentContextMap.get("DataMart_Clean_Database");
            }if (parentContextMap.containsKey("DataMart_Clean_Max_Date")) {
                context.DataMart_Clean_Max_Date = (String) parentContextMap.get("DataMart_Clean_Max_Date");
            }if (parentContextMap.containsKey("DataMart_Clean_Min_Date")) {
                context.DataMart_Clean_Min_Date = (String) parentContextMap.get("DataMart_Clean_Min_Date");
            }if (parentContextMap.containsKey("DataMart_Closure_Date_PlusX")) {
                context.DataMart_Closure_Date_PlusX = (Integer) parentContextMap.get("DataMart_Closure_Date_PlusX");
            }if (parentContextMap.containsKey("Limit_Percent")) {
                context.Limit_Percent = (Integer) parentContextMap.get("Limit_Percent");
            }if (parentContextMap.containsKey("Logistic_Max_Date_Plus_One")) {
                context.Logistic_Max_Date_Plus_One = (String) parentContextMap.get("Logistic_Max_Date_Plus_One");
            }if (parentContextMap.containsKey("Logistic_Min_Date_Minus_One")) {
                context.Logistic_Min_Date_Minus_One = (String) parentContextMap.get("Logistic_Min_Date_Minus_One");
            }if (parentContextMap.containsKey("deleted_J_minus_X")) {
                context.deleted_J_minus_X = (Integer) parentContextMap.get("deleted_J_minus_X");
            }if (parentContextMap.containsKey("deleted_J_plusOne_X")) {
                context.deleted_J_plusOne_X = (Integer) parentContextMap.get("deleted_J_plusOne_X");
            }if (parentContextMap.containsKey("FTP_DistantRep")) {
                context.FTP_DistantRep = (String) parentContextMap.get("FTP_DistantRep");
            }if (parentContextMap.containsKey("FTP_FileMasque")) {
                context.FTP_FileMasque = (String) parentContextMap.get("FTP_FileMasque");
            }if (parentContextMap.containsKey("FTP_Hote")) {
                context.FTP_Hote = (String) parentContextMap.get("FTP_Hote");
            }if (parentContextMap.containsKey("FTP_Password")) {
                context.FTP_Password = (java.lang.String) parentContextMap.get("FTP_Password");
            }if (parentContextMap.containsKey("FTP_Port")) {
                context.FTP_Port = (Integer) parentContextMap.get("FTP_Port");
            }if (parentContextMap.containsKey("FTP_ST_DistantRep")) {
                context.FTP_ST_DistantRep = (String) parentContextMap.get("FTP_ST_DistantRep");
            }if (parentContextMap.containsKey("FTP_User")) {
                context.FTP_User = (String) parentContextMap.get("FTP_User");
            }if (parentContextMap.containsKey("FTP_Wms_Port")) {
                context.FTP_Wms_Port = (Integer) parentContextMap.get("FTP_Wms_Port");
            }if (parentContextMap.containsKey("keyStore_file_name")) {
                context.keyStore_file_name = (String) parentContextMap.get("keyStore_file_name");
            }if (parentContextMap.containsKey("KeyStore_Repo")) {
                context.KeyStore_Repo = (String) parentContextMap.get("KeyStore_Repo");
            }if (parentContextMap.containsKey("mail_password")) {
                context.mail_password = (String) parentContextMap.get("mail_password");
            }if (parentContextMap.containsKey("send_mail_from")) {
                context.send_mail_from = (String) parentContextMap.get("send_mail_from");
            }if (parentContextMap.containsKey("send_mail_to")) {
                context.send_mail_to = (String) parentContextMap.get("send_mail_to");
            }if (parentContextMap.containsKey("send_to_second_mail")) {
                context.send_to_second_mail = (String) parentContextMap.get("send_to_second_mail");
            }if (parentContextMap.containsKey("send_to_third_mail")) {
                context.send_to_third_mail = (String) parentContextMap.get("send_to_third_mail");
            }if (parentContextMap.containsKey("Clients_Masque")) {
                context.Clients_Masque = (String) parentContextMap.get("Clients_Masque");
            }if (parentContextMap.containsKey("Code_client_masque")) {
                context.Code_client_masque = (String) parentContextMap.get("Code_client_masque");
            }if (parentContextMap.containsKey("Command_Logistic_Invalid_Date")) {
                context.Command_Logistic_Invalid_Date = (String) parentContextMap.get("Command_Logistic_Invalid_Date");
            }if (parentContextMap.containsKey("Command_Logistic_Masque")) {
                context.Command_Logistic_Masque = (String) parentContextMap.get("Command_Logistic_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque")) {
                context.Command_Transport_Masque = (String) parentContextMap.get("Command_Transport_Masque");
            }if (parentContextMap.containsKey("Command_Transport_Masque_Express")) {
                context.Command_Transport_Masque_Express = (String) parentContextMap.get("Command_Transport_Masque_Express");
            }if (parentContextMap.containsKey("Ecolotrans_JP")) {
                context.Ecolotrans_JP = (String) parentContextMap.get("Ecolotrans_JP");
            }if (parentContextMap.containsKey("Holiday_Days_Masque")) {
                context.Holiday_Days_Masque = (String) parentContextMap.get("Holiday_Days_Masque");
            }if (parentContextMap.containsKey("Livraisons_Exception")) {
                context.Livraisons_Exception = (String) parentContextMap.get("Livraisons_Exception");
            }if (parentContextMap.containsKey("Livraisons_Masque")) {
                context.Livraisons_Masque = (String) parentContextMap.get("Livraisons_Masque");
            }if (parentContextMap.containsKey("Livraisons_Ok")) {
                context.Livraisons_Ok = (String) parentContextMap.get("Livraisons_Ok");
            }if (parentContextMap.containsKey("ST_Drivers")) {
                context.ST_Drivers = (String) parentContextMap.get("ST_Drivers");
            }if (parentContextMap.containsKey("Tarification_Logistic_Masque")) {
                context.Tarification_Logistic_Masque = (String) parentContextMap.get("Tarification_Logistic_Masque");
            }if (parentContextMap.containsKey("Tarification_Transport_Masque")) {
                context.Tarification_Transport_Masque = (String) parentContextMap.get("Tarification_Transport_Masque");
            }if (parentContextMap.containsKey("Tournee_Masque")) {
                context.Tournee_Masque = (String) parentContextMap.get("Tournee_Masque");
            }if (parentContextMap.containsKey("TVA_Exceptions")) {
                context.TVA_Exceptions = (String) parentContextMap.get("TVA_Exceptions");
            }if (parentContextMap.containsKey("Backup")) {
                context.Backup = (String) parentContextMap.get("Backup");
            }if (parentContextMap.containsKey("Server_Clean")) {
                context.Server_Clean = (String) parentContextMap.get("Server_Clean");
            }if (parentContextMap.containsKey("Server_In")) {
                context.Server_In = (String) parentContextMap.get("Server_In");
            }if (parentContextMap.containsKey("Server_Out")) {
                context.Server_Out = (String) parentContextMap.get("Server_Out");
            }if (parentContextMap.containsKey("Server_Out_DataMart")) {
                context.Server_Out_DataMart = (String) parentContextMap.get("Server_Out_DataMart");
            }if (parentContextMap.containsKey("Art_masque")) {
                context.Art_masque = (String) parentContextMap.get("Art_masque");
            }if (parentContextMap.containsKey("Cdc_masque")) {
                context.Cdc_masque = (String) parentContextMap.get("Cdc_masque");
            }if (parentContextMap.containsKey("Cre_masque")) {
                context.Cre_masque = (String) parentContextMap.get("Cre_masque");
            }if (parentContextMap.containsKey("Crp_masque")) {
                context.Crp_masque = (String) parentContextMap.get("Crp_masque");
            }if (parentContextMap.containsKey("Crr_masque")) {
                context.Crr_masque = (String) parentContextMap.get("Crr_masque");
            }if (parentContextMap.containsKey("Distant_Magistor_Clients_Input")) {
                context.Distant_Magistor_Clients_Input = (String) parentContextMap.get("Distant_Magistor_Clients_Input");
            }if (parentContextMap.containsKey("Distant_Magistor_Clients_Test_Input")) {
                context.Distant_Magistor_Clients_Test_Input = (String) parentContextMap.get("Distant_Magistor_Clients_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Input")) {
                context.Distant_Magistor1_Input = (String) parentContextMap.get("Distant_Magistor1_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Output")) {
                context.Distant_Magistor1_Output = (String) parentContextMap.get("Distant_Magistor1_Output");
            }if (parentContextMap.containsKey("Distant_Magistor1_Test_Input")) {
                context.Distant_Magistor1_Test_Input = (String) parentContextMap.get("Distant_Magistor1_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor1_Test_Output")) {
                context.Distant_Magistor1_Test_Output = (String) parentContextMap.get("Distant_Magistor1_Test_Output");
            }if (parentContextMap.containsKey("Distant_Magistor2_Input")) {
                context.Distant_Magistor2_Input = (String) parentContextMap.get("Distant_Magistor2_Input");
            }if (parentContextMap.containsKey("Distant_Magistor2_Output")) {
                context.Distant_Magistor2_Output = (String) parentContextMap.get("Distant_Magistor2_Output");
            }if (parentContextMap.containsKey("Distant_Magistor2_Test_Input")) {
                context.Distant_Magistor2_Test_Input = (String) parentContextMap.get("Distant_Magistor2_Test_Input");
            }if (parentContextMap.containsKey("Distant_Magistor2_Test_Output")) {
                context.Distant_Magistor2_Test_Output = (String) parentContextMap.get("Distant_Magistor2_Test_Output");
            }if (parentContextMap.containsKey("Drc_masque")) {
                context.Drc_masque = (String) parentContextMap.get("Drc_masque");
            }if (parentContextMap.containsKey("Mvt_masque")) {
                context.Mvt_masque = (String) parentContextMap.get("Mvt_masque");
            }if (parentContextMap.containsKey("Stk_masque")) {
                context.Stk_masque = (String) parentContextMap.get("Stk_masque");
            }if (parentContextMap.containsKey("Xml_File_Masque")) {
                context.Xml_File_Masque = (String) parentContextMap.get("Xml_File_Masque");
            }if (parentContextMap.containsKey("Article_Exceptions")) {
                context.Article_Exceptions = (String) parentContextMap.get("Article_Exceptions");
            }if (parentContextMap.containsKey("Cleaning_Reject_Logistic_price_is_zero")) {
                context.Cleaning_Reject_Logistic_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Logistic_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Reject_Rep")) {
                context.Cleaning_Reject_Rep = (String) parentContextMap.get("Cleaning_Reject_Rep");
            }if (parentContextMap.containsKey("Cleaning_Reject_Transport_price_is_zero")) {
                context.Cleaning_Reject_Transport_price_is_zero = (String) parentContextMap.get("Cleaning_Reject_Transport_price_is_zero");
            }if (parentContextMap.containsKey("Cleaning_Transport_no_PostalCode")) {
                context.Cleaning_Transport_no_PostalCode = (String) parentContextMap.get("Cleaning_Transport_no_PostalCode");
            }if (parentContextMap.containsKey("Commande_Exceptions")) {
                context.Commande_Exceptions = (String) parentContextMap.get("Commande_Exceptions");
            }if (parentContextMap.containsKey("Conditionnement_Exceptions")) {
                context.Conditionnement_Exceptions = (String) parentContextMap.get("Conditionnement_Exceptions");
            }if (parentContextMap.containsKey("CR_Reception_Exceptions")) {
                context.CR_Reception_Exceptions = (String) parentContextMap.get("CR_Reception_Exceptions");
            }if (parentContextMap.containsKey("Csv_File_Masque")) {
                context.Csv_File_Masque = (String) parentContextMap.get("Csv_File_Masque");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Command_Error")) {
                context.Diagnostic_Reject_Command_Error = (String) parentContextMap.get("Diagnostic_Reject_Command_Error");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Day_Not_Ok")) {
                context.Diagnostic_Reject_Day_Not_Ok = (String) parentContextMap.get("Diagnostic_Reject_Day_Not_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Postal_Code_Ok")) {
                context.Diagnostic_Reject_Postal_Code_Ok = (String) parentContextMap.get("Diagnostic_Reject_Postal_Code_Ok");
            }if (parentContextMap.containsKey("Diagnostic_Reject_Rep")) {
                context.Diagnostic_Reject_Rep = (String) parentContextMap.get("Diagnostic_Reject_Rep");
            }if (parentContextMap.containsKey("Dossier_Reception_Exceptions")) {
                context.Dossier_Reception_Exceptions = (String) parentContextMap.get("Dossier_Reception_Exceptions");
            }if (parentContextMap.containsKey("Excel_File_Masque")) {
                context.Excel_File_Masque = (String) parentContextMap.get("Excel_File_Masque");
            }if (parentContextMap.containsKey("Ligne_Commande_Exceptions")) {
                context.Ligne_Commande_Exceptions = (String) parentContextMap.get("Ligne_Commande_Exceptions");
            }if (parentContextMap.containsKey("Migration_Billing_Not_Ok")) {
                context.Migration_Billing_Not_Ok = (String) parentContextMap.get("Migration_Billing_Not_Ok");
            }if (parentContextMap.containsKey("Reject_Client_File")) {
                context.Reject_Client_File = (String) parentContextMap.get("Reject_Client_File");
            }if (parentContextMap.containsKey("Reject_Client_Local_Rep")) {
                context.Reject_Client_Local_Rep = (String) parentContextMap.get("Reject_Client_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Command_Logisitc_Code_Client")) {
                context.Reject_Command_Logisitc_Code_Client = (String) parentContextMap.get("Reject_Command_Logisitc_Code_Client");
            }if (parentContextMap.containsKey("Reject_Command_Transport_Code_Client")) {
                context.Reject_Command_Transport_Code_Client = (String) parentContextMap.get("Reject_Command_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Distant_Rep")) {
                context.Reject_Distant_Rep = (String) parentContextMap.get("Reject_Distant_Rep");
            }if (parentContextMap.containsKey("Reject_Distant_Rep_DataMart")) {
                context.Reject_Distant_Rep_DataMart = (String) parentContextMap.get("Reject_Distant_Rep_DataMart");
            }if (parentContextMap.containsKey("Reject_Duplicated_Client_File")) {
                context.Reject_Duplicated_Client_File = (String) parentContextMap.get("Reject_Duplicated_Client_File");
            }if (parentContextMap.containsKey("Reject_Migration_Local_Rep")) {
                context.Reject_Migration_Local_Rep = (String) parentContextMap.get("Reject_Migration_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Not_Complet_Client")) {
                context.Reject_Not_Complet_Client = (String) parentContextMap.get("Reject_Not_Complet_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Local_Rep")) {
                context.Reject_Service_Detail_Local_Rep = (String) parentContextMap.get("Reject_Service_Detail_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_DB")) {
                context.Reject_Service_Detail_Logistic_DB = (String) parentContextMap.get("Reject_Service_Detail_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Logistic_Unknown_Client")) {
                context.Reject_Service_Detail_Logistic_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Logistic_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_DB")) {
                context.Reject_Service_Detail_Transport_DB = (String) parentContextMap.get("Reject_Service_Detail_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Service_Detail_Transport_Unknown_Client")) {
                context.Reject_Service_Detail_Transport_Unknown_Client = (String) parentContextMap.get("Reject_Service_Detail_Transport_Unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Local_Rep")) {
                context.Reject_Tarification_Local_Rep = (String) parentContextMap.get("Reject_Tarification_Local_Rep");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_Code_Client")) {
                context.Reject_Tarification_Logistic_Code_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_DB")) {
                context.Reject_Tarification_Logistic_DB = (String) parentContextMap.get("Reject_Tarification_Logistic_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Logistic_unknown_Client")) {
                context.Reject_Tarification_Logistic_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Logistic_unknown_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_Code_Client")) {
                context.Reject_Tarification_Transport_Code_Client = (String) parentContextMap.get("Reject_Tarification_Transport_Code_Client");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_DB")) {
                context.Reject_Tarification_Transport_DB = (String) parentContextMap.get("Reject_Tarification_Transport_DB");
            }if (parentContextMap.containsKey("Reject_Tarification_Transport_unknown_Client")) {
                context.Reject_Tarification_Transport_unknown_Client = (String) parentContextMap.get("Reject_Tarification_Transport_unknown_Client");
            }if (parentContextMap.containsKey("code_client_length")) {
                context.code_client_length = (Integer) parentContextMap.get("code_client_length");
            }if (parentContextMap.containsKey("code_client_regex")) {
                context.code_client_regex = (String) parentContextMap.get("code_client_regex");
            }if (parentContextMap.containsKey("Livraison_directory")) {
                context.Livraison_directory = (String) parentContextMap.get("Livraison_directory");
            }if (parentContextMap.containsKey("Round_Delay_Minus_Days")) {
                context.Round_Delay_Minus_Days = (Integer) parentContextMap.get("Round_Delay_Minus_Days");
            }if (parentContextMap.containsKey("Round_Delay_Plus_Days_Plus_One")) {
                context.Round_Delay_Plus_Days_Plus_One = (Integer) parentContextMap.get("Round_Delay_Plus_Days_Plus_One");
            }if (parentContextMap.containsKey("Round_directory")) {
                context.Round_directory = (String) parentContextMap.get("Round_directory");
            }if (parentContextMap.containsKey("Round_file_name")) {
                context.Round_file_name = (String) parentContextMap.get("Round_file_name");
            }if (parentContextMap.containsKey("Round_Minus_Days")) {
                context.Round_Minus_Days = (Integer) parentContextMap.get("Round_Minus_Days");
            }if (parentContextMap.containsKey("Salesforce_Name")) {
                context.Salesforce_Name = (String) parentContextMap.get("Salesforce_Name");
            }if (parentContextMap.containsKey("Salesforce_Password")) {
                context.Salesforce_Password = (java.lang.String) parentContextMap.get("Salesforce_Password");
            }if (parentContextMap.containsKey("Salesforce_Security_Token")) {
                context.Salesforce_Security_Token = (java.lang.String) parentContextMap.get("Salesforce_Security_Token");
            }if (parentContextMap.containsKey("Salesforce_User_ID")) {
                context.Salesforce_User_ID = (String) parentContextMap.get("Salesforce_User_ID");
            }if (parentContextMap.containsKey("comptabilite_analytique_month")) {
                context.comptabilite_analytique_month = (String) parentContextMap.get("comptabilite_analytique_month");
            }if (parentContextMap.containsKey("comptabilite_analytique_year")) {
                context.comptabilite_analytique_year = (String) parentContextMap.get("comptabilite_analytique_year");
            }if (parentContextMap.containsKey("Ecolotrans_JP_Month_MM")) {
                context.Ecolotrans_JP_Month_MM = (String) parentContextMap.get("Ecolotrans_JP_Month_MM");
            }if (parentContextMap.containsKey("end_date")) {
                context.end_date = (String) parentContextMap.get("end_date");
            }if (parentContextMap.containsKey("Extraction_Aprm")) {
                context.Extraction_Aprm = (Integer) parentContextMap.get("Extraction_Aprm");
            }if (parentContextMap.containsKey("Extraction_Jour")) {
                context.Extraction_Jour = (Integer) parentContextMap.get("Extraction_Jour");
            }if (parentContextMap.containsKey("Extraction_Matin")) {
                context.Extraction_Matin = (Integer) parentContextMap.get("Extraction_Matin");
            }if (parentContextMap.containsKey("start_date")) {
                context.start_date = (String) parentContextMap.get("start_date");
            }if (parentContextMap.containsKey("Urbantz_directory")) {
                context.Urbantz_directory = (String) parentContextMap.get("Urbantz_directory");
            }if (parentContextMap.containsKey("urbantz_extraction_date")) {
                context.urbantz_extraction_date = (String) parentContextMap.get("urbantz_extraction_date");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("DB_Password");
			parametersToEncrypt.add("FTP_Password");
			parametersToEncrypt.add("Salesforce_Password");
			parametersToEncrypt.add("Salesforce_Security_Token");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR' - Started.");
            java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }
		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tRunJob_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tRunJob_4) {
globalMap.put("tRunJob_4_SUBPROCESS_STATE", -1);

e_tRunJob_4.printStackTrace();

}
catch (Error error_tRunJob_4 ) {
end = System.currentTimeMillis();
tStatCatcher_1.addMessage("failure", (end-startTime));
try {
 tStatCatcher_1Process(globalMap);
} catch (Exception e_tStatCatcher_1) {
e_tStatCatcher_1.printStackTrace();
}
throw error_tRunJob_4;
}


this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'ALIV2_V1_ECOLOTRANS_WMS_PROD_ORCHESTRATOR' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     339183 characters generated by Talend Cloud Data Integration 
 *     on the 18 avril 2024 à 12:49:28 CET
 ************************************************************************************************/